-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 192.168.80.57
-- Generation Time: Feb 21, 2021 at 04:10 PM
-- Server version: 5.6.46
-- PHP Version: 7.4.15

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `craft_sample_app`
--
CREATE DATABASE IF NOT EXISTS `craft_sample_app` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `craft_sample_app`;

-- --------------------------------------------------------

--
-- Table structure for table `craft_assetindexdata`
--

CREATE TABLE `craft_assetindexdata` (
  `id` int(11) NOT NULL,
  `sessionId` varchar(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text COLLATE utf8_unicode_ci,
  `size` bigint(20) UNSIGNED DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_assets`
--

CREATE TABLE `craft_assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kind` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `width` int(11) UNSIGNED DEFAULT NULL,
  `height` int(11) UNSIGNED DEFAULT NULL,
  `size` bigint(20) UNSIGNED DEFAULT NULL,
  `focalPoint` varchar(13) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_assettransformindex`
--

CREATE TABLE `craft_assettransformindex` (
  `id` int(11) NOT NULL,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_assettransforms`
--

CREATE TABLE `craft_assettransforms` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` enum('stretch','fit','crop') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center-center',
  `width` int(11) UNSIGNED DEFAULT NULL,
  `height` int(11) UNSIGNED DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_categories`
--

CREATE TABLE `craft_categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_categorygroups`
--

CREATE TABLE `craft_categorygroups` (
  `id` int(11) NOT NULL,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_categorygroups_sites`
--

CREATE TABLE `craft_categorygroups_sites` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8_unicode_ci,
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_changedattributes`
--

CREATE TABLE `craft_changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_changedattributes`
--

INSERT INTO `craft_changedattributes` (`elementId`, `siteId`, `attribute`, `dateUpdated`, `propagated`, `userId`) VALUES
(1, 1, 'firstName', '2021-02-20 17:48:05', 0, 1),
(1, 1, 'lastName', '2021-02-20 17:48:05', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `craft_changedfields`
--

CREATE TABLE `craft_changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_changedfields`
--

INSERT INTO `craft_changedfields` (`elementId`, `siteId`, `fieldId`, `dateUpdated`, `propagated`, `userId`) VALUES
(2, 1, 1, '2021-02-21 00:26:09', 0, 1),
(2, 2, 1, '2021-02-21 00:26:09', 1, 1),
(8, 1, 1, '2021-02-21 00:02:51', 0, 1),
(8, 2, 1, '2021-02-21 00:02:51', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `craft_content`
--

CREATE TABLE `craft_content` (
  `id` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `field_bodyText` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_content`
--

INSERT INTO `craft_content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_bodyText`) VALUES
(1, 1, 1, NULL, '2021-02-20 17:18:23', '2021-02-20 18:22:53', 'e1b88721-547f-4e87-9c62-e15a2a0299bb', NULL),
(2, 2, 1, 'Homepage', '2021-02-20 17:59:01', '2021-02-21 00:26:09', '93f93dd3-d6c2-4f99-ab7e-54ae6c92f3eb', '<p>Welcome to the 24hoursmedia Craft CMS Sample application.</p>\n<p>This application demonstrates the following plugins available through the plugin store:</p>\n<ul><li><a href=\"{entry:8@1:url||https://craft-sample-app.dev.cc/views-work}\">Views Work</a></li></ul>'),
(3, 2, 2, 'Homepage', '2021-02-20 17:59:01', '2021-02-21 00:26:09', 'a10472d2-a4b3-4618-a404-ed3de753ca95', '<p>Welcome to the 24hoursmedia Craft CMS Sample application.</p>\n<p>This application demonstrates the following plugins available through the plugin store:</p>\n<ul><li><a href=\"{entry:8@1:url||https://craft-sample-app.dev.cc/views-work}\">Views Work</a></li></ul>'),
(4, 3, 1, 'Homepage', '2021-02-20 17:59:01', '2021-02-20 17:59:01', '5180f2c2-2227-4f56-add2-5b48274c5318', NULL),
(5, 3, 2, 'Homepage', '2021-02-20 17:59:01', '2021-02-20 17:59:01', 'eddd144b-94b5-4284-9779-80699e2863c6', NULL),
(6, 4, 1, 'Homepage', '2021-02-20 17:59:02', '2021-02-20 17:59:02', 'ff198102-5c50-4ef7-8447-05e94a1e9682', NULL),
(7, 4, 2, 'Homepage', '2021-02-20 17:59:02', '2021-02-20 17:59:02', '6fbe59d8-556c-410c-8d98-502601c6002a', NULL),
(10, 6, 1, 'Article', '2021-02-20 18:29:25', '2021-02-20 18:29:25', '910a88df-6f0b-4918-9c49-a696e7563283', '<p>Article</p>'),
(11, 6, 2, 'Article', '2021-02-20 18:29:25', '2021-02-20 18:29:25', 'f90f93ce-2f19-46cd-807c-0bec5a7b249f', '<p>Article</p>'),
(14, 8, 1, 'Views Work', '2021-02-20 22:46:54', '2021-02-21 00:02:51', '7412f76b-7fdc-4535-8846-f7bcfdfca3d6', '<p>The Views Work plugin keeps view counts for your entries and elements.</p>'),
(15, 8, 2, 'Views Work', '2021-02-20 22:46:54', '2021-02-21 00:02:51', '1f6d3a84-ec40-484c-b515-7bc694be4116', '<p>The Views Work plugin keeps view counts for your entries and elements.</p>'),
(16, 9, 1, 'Views Work', '2021-02-20 22:46:54', '2021-02-20 22:46:54', 'e154c163-f2c1-4566-9423-7cafd429b79b', NULL),
(17, 9, 2, 'Views Work', '2021-02-20 22:46:54', '2021-02-20 22:46:54', '7f58236a-2646-40d0-9435-50e19b37bacc', NULL),
(18, 10, 1, 'Views Work', '2021-02-20 22:47:09', '2021-02-20 22:47:09', 'ace657ff-73de-4d9a-bd5c-a0f743ef2d8e', NULL),
(19, 10, 2, 'Views Work', '2021-02-20 22:47:09', '2021-02-20 22:47:09', '8f5ee061-c05e-479b-a495-a4aa64a041d6', NULL),
(20, 11, 1, NULL, '2021-02-20 22:52:23', '2021-02-21 00:05:35', '7ec42008-5bd4-49bb-8eea-bb75ddea04b7', NULL),
(21, 11, 2, NULL, '2021-02-20 22:52:23', '2021-02-21 00:05:35', 'a845fce0-e1d4-4f76-ae3f-0ef0599380a9', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `craft_craftidtokens`
--

CREATE TABLE `craft_craftidtokens` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `accessToken` text COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_deprecationerrors`
--

CREATE TABLE `craft_deprecationerrors` (
  `id` int(11) NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `line` smallint(6) UNSIGNED DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `traces` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_deprecationerrors`
--

INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 'craft.request.getUrl()', '/var/www/html/templates/_partials/left_nav.twig:3', '2021-02-21 16:09:20', '/var/www/html/templates/_partials/left_nav.twig', 3, '`craft.request.getUrl()` has been deprecated. Use `craft.app.request.absoluteUrl` instead.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/twig/variables/Request.php\",\"line\":138,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"craft.request.getUrl()\\\", \\\"`craft.request.getUrl()` has been deprecated. Use `craft.app.req...\\\"\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\variables\\\\Request\",\"file\":\"/var/www/html/vendor/twig/twig/src/Extension/CoreExtension.php\",\"line\":1507,\"class\":\"craft\\\\web\\\\twig\\\\variables\\\\Request\",\"method\":\"getUrl\",\"args\":null},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/craftcms/cms/src/helpers/Template.php\",\"line\":106,\"class\":null,\"method\":\"twig_get_attribute\",\"args\":\"craft\\\\web\\\\twig\\\\Environment, Twig\\\\Source, craft\\\\web\\\\twig\\\\variables\\\\Request, \\\"url\\\", ...\"},{\"objectClass\":null,\"file\":\"/var/www/html/storage/runtime/compiled_templates/62/62cf48263efe60ada2aaf14e3f5d472eaa17e4c9cc56af0c18ab933e1374cbd8.php\",\"line\":42,\"class\":\"craft\\\\helpers\\\\Template\",\"method\":\"attribute\",\"args\":\"craft\\\\web\\\\twig\\\\Environment, Twig\\\\Source, craft\\\\web\\\\twig\\\\variables\\\\Request, \\\"url\\\", ...\"},{\"objectClass\":\"__TwigTemplate_bc0fadceccf40ce0c2f3f5a48a9ce15ee5c24c27f0af7fbc70c27378b55c4224\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_bc0fadceccf40ce0c2f3f5a48a9ce15ee5c24c27f0af7fbc70c27378b55c4224\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], []\"},{\"objectClass\":\"__TwigTemplate_bc0fadceccf40ce0c2f3f5a48a9ce15ee5c24c27f0af7fbc70c27378b55c4224\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], []\"},{\"objectClass\":\"__TwigTemplate_bc0fadceccf40ce0c2f3f5a48a9ce15ee5c24c27f0af7fbc70c27378b55c4224\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":84,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 16:09:20', '2021-02-21 16:09:20', '702f06d2-02c2-4468-b50f-667596596de7'),
(154, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:40', '2021-02-20 23:43:10', '/var/www/html/templates/views-work/_index.twig', 40, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":114,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-20 23:43:10', '2021-02-20 23:43:10', '43969556-4c75-4d6a-98b0-ceac7c98ec0d'),
(162, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:57', '2021-02-20 23:53:32', '/var/www/html/templates/views-work/_index.twig', 57, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":452,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":428,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___14056882\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":117,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-20 23:53:32', '2021-02-20 23:53:32', '3b72d644-51e4-4097-9fb4-832d588f36d8');
INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(166, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:45', '2021-02-20 23:48:39', '/var/www/html/templates/views-work/_index.twig', 45, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":119,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-20 23:48:39', '2021-02-20 23:48:39', 'ee14a0b3-425a-451e-bcc2-2bc15a371bde'),
(170, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:42', '2021-02-20 23:53:32', '/var/www/html/templates/views-work/_index.twig', 42, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":280,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":256,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___968484433\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":109,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-20 23:53:32', '2021-02-20 23:53:32', '4600afb2-80f4-4a62-87a0-8912b3ab1a84'),
(204, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:43', '2021-02-20 23:59:47', '/var/www/html/templates/views-work/_index.twig', 43, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":305,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":281,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1734851399\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":110,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-20 23:59:47', '2021-02-20 23:59:47', '2bec39fc-0fd0-400f-8706-a7d77a21b10b');
INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(205, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:58', '2021-02-20 23:59:47', '/var/www/html/templates/views-work/_index.twig', 58, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":493,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":469,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1894544883\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":118,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-20 23:59:47', '2021-02-20 23:59:47', '9bf92834-6f81-49ad-ad0c-4dc46f7b9732'),
(272, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:73', '2021-02-20 23:59:47', '/var/www/html/templates/views-work/_index.twig', 73, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":681,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":657,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___944934842\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":126,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"v\\\" => \\\"2\\\"]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-20 23:59:47', '2021-02-20 23:59:47', '705173fb-5f6b-4dc0-97dd-681932264e40');
INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(290, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:46', '2021-02-21 00:03:33', '/var/www/html/templates/views-work/_index.twig', 46, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":311,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":287,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___2100614317\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":113,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 00:03:33', '2021-02-21 00:03:33', '8ea3ad26-6aca-4ddb-8bc2-cacbf6a31f55'),
(291, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:61', '2021-02-21 00:03:33', '/var/www/html/templates/views-work/_index.twig', 61, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":502,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":478,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1766235406\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":121,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 00:03:33', '2021-02-21 00:03:33', 'cb0a0fb1-3814-46e9-9b55-6796b208b45e');
INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(292, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:76', '2021-02-21 00:03:33', '/var/www/html/templates/views-work/_index.twig', 76, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":693,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":669,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1684653164\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":129,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 00:03:33', '2021-02-21 00:03:33', '6916d655-27c9-4adc-bf36-cd5295b8f08b'),
(363, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:48', '2021-02-21 00:04:13', '/var/www/html/templates/views-work/_index.twig', 48, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":315,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":291,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___562547804\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":115,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 00:04:13', '2021-02-21 00:04:13', '54e85201-3489-47fd-aafa-69fdff0af81b');
INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(364, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:63', '2021-02-21 00:04:13', '/var/www/html/templates/views-work/_index.twig', 63, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":508,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":484,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1499543144\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":123,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 00:04:13', '2021-02-21 00:04:13', 'f9f52eef-9543-4b28-a7dc-9820c25a952f'),
(365, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:78', '2021-02-21 00:04:13', '/var/www/html/templates/views-work/_index.twig', 78, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":701,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":677,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___8869496\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":131,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 00:04:13', '2021-02-21 00:04:13', 'a936b4bc-b88b-44b9-be97-827df1e11f78');
INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(379, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:50', '2021-02-21 16:09:20', '/var/www/html/templates/views-work/_index.twig', 50, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":319,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":295,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___423337768\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":117,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 16:09:20', '2021-02-21 16:09:20', 'ad8a2f44-7351-4446-8104-8c81a880082d'),
(380, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:65', '2021-02-21 16:09:20', '/var/www/html/templates/views-work/_index.twig', 65, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":514,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":490,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___509406526\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":125,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 16:09:20', '2021-02-21 16:09:20', '1b616dc3-cdde-4625-b0fe-b48958223607');
INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(381, 'ElementQuery::getIterator()', '/var/www/html/templates/views-work/_index.twig:80', '2021-02-21 16:09:20', '/var/www/html/templates/views-work/_index.twig', 80, 'Looping through element queries directly has been deprecated. Use the `all()` function to fetch the query results before looping over them.', '[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":575,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\EntryQuery\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":709,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/58/58febc07ef217041942694853dfd32982985b50b9d8761e9612d3230d995f6ac.php\",\"line\":51,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_8ee32b4b027fc2680e2b579c51f550f8b62f17503cd89b4721399b3f3ab9922a\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":685,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"heading\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_heading\\\"], \\\"content\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0___1918245719\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":133,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":182,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"block_body\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/51/5172024c433588f818b4217f45e2685de6940dab6960c1096d222f4cbf5d2935.php\",\"line\":92,\"class\":\"Twig\\\\Template\",\"method\":\"displayBlock\",\"args\":\"\\\"body\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"meta_title\\\" => [__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc, \\\"block_meta_title\\\"], \\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_5d1c19421b8dfea5d4313226aabdaf472e34b3f2533e029eb7a427e39e41e0fc\",\"file\":\"/var/www/html/storage/runtime/compiled_templates/0f/0f2a798ae992b4c01627a582ea661cbbedff031814ce75fcf3b5400437fe5201.php\",\"line\":43,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":405,\"class\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":378,\"class\":\"Twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"devMode\\\" => true, ...], [\\\"body\\\" => [__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0, \\\"block_body\\\"]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/Template.php\",\"line\":390,\"class\":\"Twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_46ceced2ca7998f43d4433dd3b19a1ce484a918c76fadb1c34928bdcc7b516d0\",\"file\":\"/var/www/html/vendor/twig/twig/src/TemplateWrapper.php\",\"line\":45,\"class\":\"Twig\\\\Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"Twig\\\\TemplateWrapper\",\"file\":\"/var/www/html/vendor/twig/twig/src/Environment.php\",\"line\":318,\"class\":\"Twig\\\\TemplateWrapper\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":389,\"class\":\"Twig\\\\Environment\",\"method\":\"render\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/View.php\",\"line\":450,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":257,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], \\\"site\\\"\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":100,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"views-work/_index\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Controller.php\",\"line\":181,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Controller.php\",\"line\":190,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Module.php\",\"line\":534,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":274,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/web/Application.php\",\"line\":104,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"views-work/_index\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/craftcms/cms/src/web/Application.php\",\"line\":259,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/vendor/yiisoft/yii2/base/Application.php\",\"line\":392,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/var/www/html/web/index.php\",\"line\":22,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]', '2021-02-21 16:09:20', '2021-02-21 16:09:20', '45631cc1-dd70-4f88-887e-3977d320fcff');

-- --------------------------------------------------------

--
-- Table structure for table `craft_drafts`
--

CREATE TABLE `craft_drafts` (
  `id` int(11) NOT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_elementindexsettings`
--

CREATE TABLE `craft_elementindexsettings` (
  `id` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_elements`
--

CREATE TABLE `craft_elements` (
  `id` int(11) NOT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_elements`
--

INSERT INTO `craft_elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES
(1, NULL, NULL, NULL, 'craft\\elements\\User', 1, 0, '2021-02-20 17:18:23', '2021-02-20 18:22:53', NULL, '7ebfe085-f0dd-4282-8b32-1cdd115a0f1c'),
(2, NULL, NULL, 1, 'craft\\elements\\Entry', 1, 0, '2021-02-20 17:59:01', '2021-02-21 00:26:09', NULL, '2f0b47ec-a510-45cc-a0ba-200c97b04e26'),
(3, NULL, 1, 1, 'craft\\elements\\Entry', 1, 0, '2021-02-20 17:59:01', '2021-02-20 17:59:01', NULL, '60180bda-d5a2-4c84-880d-47572885d281'),
(4, NULL, 2, 1, 'craft\\elements\\Entry', 1, 0, '2021-02-20 17:59:02', '2021-02-20 17:59:02', NULL, '64246c07-89c8-4d7a-9494-2e617f68cd58'),
(6, NULL, NULL, 2, 'craft\\elements\\Entry', 1, 0, '2021-02-20 18:29:25', '2021-02-20 18:29:25', NULL, 'fee6ef84-fbe1-474a-8f8d-40359a7d4c90'),
(8, NULL, NULL, 3, 'craft\\elements\\Entry', 1, 0, '2021-02-20 22:46:54', '2021-02-21 00:02:50', NULL, '908cbe8c-b83a-460b-b590-85d11477c294'),
(9, NULL, 3, 3, 'craft\\elements\\Entry', 1, 0, '2021-02-20 22:46:54', '2021-02-20 22:46:54', NULL, '1beaf4be-89c9-4f21-9a8c-1550d74f40b2'),
(10, NULL, 4, 3, 'craft\\elements\\Entry', 1, 0, '2021-02-20 22:47:09', '2021-02-20 22:47:09', NULL, '12841501-3e77-472f-b3ad-30e31e85e89b'),
(11, NULL, NULL, 5, 'craft\\elements\\GlobalSet', 1, 0, '2021-02-20 22:52:23', '2021-02-21 00:05:35', NULL, '352f1183-78f1-4868-870f-d09fdd4c0b9a'),
(12, NULL, NULL, 4, 'craft\\elements\\MatrixBlock', 1, 0, '2021-02-20 22:52:42', '2021-02-21 00:05:35', NULL, '34b29f86-5199-4539-8463-149d3fa4b921'),
(13, NULL, NULL, 4, 'craft\\elements\\MatrixBlock', 1, 0, '2021-02-21 00:05:35', '2021-02-21 00:05:35', NULL, 'eac161e6-394a-4b8c-b35e-d779fe8a9a05');

-- --------------------------------------------------------

--
-- Table structure for table `craft_elements_sites`
--

CREATE TABLE `craft_elements_sites` (
  `id` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_elements_sites`
--

INSERT INTO `craft_elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 1, 1, NULL, NULL, 1, '2021-02-20 17:18:23', '2021-02-20 17:18:23', '78633782-bd51-4d97-8cb1-f0541ff73fda'),
(2, 2, 1, 'homepage', '__home__', 1, '2021-02-20 17:59:01', '2021-02-20 17:59:01', 'e83515e4-1351-40d1-90f8-c5709802b8c2'),
(3, 2, 2, 'homepage', '__home__', 1, '2021-02-20 17:59:01', '2021-02-20 17:59:01', 'd4601cc8-cb1f-4a26-9a78-d6afdca9d6f0'),
(4, 3, 1, 'homepage', '__home__', 1, '2021-02-20 17:59:01', '2021-02-20 17:59:01', '69f3766e-6834-4b95-8857-d2394d942d8d'),
(5, 3, 2, 'homepage', '__home__', 1, '2021-02-20 17:59:01', '2021-02-20 17:59:01', '0f7122ce-3c54-46df-9ae8-40f18f8fb2ba'),
(6, 4, 1, 'homepage', '__home__', 1, '2021-02-20 17:59:02', '2021-02-20 17:59:02', '90f7e384-2628-4581-9fe8-c3b270e10fea'),
(7, 4, 2, 'homepage', '__home__', 1, '2021-02-20 17:59:02', '2021-02-20 17:59:02', '10ccdc61-dbc1-4963-9ea3-4d3da1c20d2a'),
(10, 6, 1, 'article', 'content/article', 1, '2021-02-20 18:29:25', '2021-02-20 18:29:25', 'e7206495-661f-46b6-b415-7c1a0899e3bb'),
(11, 6, 2, 'article', 'content/article', 1, '2021-02-20 18:29:25', '2021-02-20 18:29:25', '71d50fbd-1c8e-4eea-8340-8442496f9981'),
(14, 8, 1, 'views-work', 'views-work', 1, '2021-02-20 22:46:54', '2021-02-20 22:46:54', 'dc52b240-0778-475e-b5ac-07d05ba01938'),
(15, 8, 2, 'views-work', 'views-work', 1, '2021-02-20 22:46:54', '2021-02-20 22:46:54', '7971c93e-b9a5-49b5-892e-7aa3d6c6c72f'),
(16, 9, 1, 'views-work', 'views-work', 1, '2021-02-20 22:46:54', '2021-02-20 22:46:54', '4dcd050e-cf51-4272-8b91-a25a5f2cc5da'),
(17, 9, 2, 'views-work', 'views-work', 1, '2021-02-20 22:46:54', '2021-02-20 22:46:54', 'd933c1a0-df0e-447f-96d1-330d2caea288'),
(18, 10, 1, 'views-work', 'views-work', 1, '2021-02-20 22:47:09', '2021-02-20 22:47:09', '4d71232a-2dab-43c8-9ec6-1dcaeda307c6'),
(19, 10, 2, 'views-work', 'views-work', 1, '2021-02-20 22:47:09', '2021-02-20 22:47:09', '19c65f9a-bbf7-4efb-b529-f7f501ec80f1'),
(20, 11, 1, NULL, NULL, 1, '2021-02-20 22:52:23', '2021-02-20 22:52:23', '47407328-0292-4072-9e3b-31472c408ec2'),
(21, 11, 2, NULL, NULL, 1, '2021-02-20 22:52:23', '2021-02-20 22:52:23', 'e9623a4e-697c-472c-81a1-b2e50b1d69a2'),
(22, 12, 1, NULL, NULL, 1, '2021-02-20 22:52:42', '2021-02-20 22:52:42', '43d4c320-8ebe-4abb-8c2f-8b8c49806d67'),
(23, 12, 2, NULL, NULL, 1, '2021-02-20 22:52:42', '2021-02-20 22:52:42', '647208e7-4acc-4975-872f-ec8b02df208b'),
(24, 13, 1, NULL, NULL, 1, '2021-02-21 00:05:35', '2021-02-21 00:05:35', '2a39bf0f-f725-4ec2-8ade-b70058054314'),
(25, 13, 2, NULL, NULL, 1, '2021-02-21 00:05:35', '2021-02-21 00:05:35', 'b299f036-1243-4e27-9eed-8434c76d9292');

-- --------------------------------------------------------

--
-- Table structure for table `craft_entries`
--

CREATE TABLE `craft_entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_entries`
--

INSERT INTO `craft_entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(2, 1, NULL, 1, NULL, '2021-02-20 17:59:00', NULL, NULL, '2021-02-20 17:59:01', '2021-02-20 17:59:01', '78f86ddc-7e7d-4c1d-bbbc-a0c338151285'),
(3, 1, NULL, 1, NULL, '2021-02-20 17:59:00', NULL, NULL, '2021-02-20 17:59:01', '2021-02-20 17:59:01', 'b6b7725f-2747-4dc9-8fbe-ddd86bf86361'),
(4, 1, NULL, 1, NULL, '2021-02-20 17:59:00', NULL, NULL, '2021-02-20 17:59:02', '2021-02-20 17:59:02', 'd51d68a6-5007-4bc6-a741-6158b465c564'),
(6, 2, NULL, 2, 1, '2021-02-20 18:29:00', NULL, NULL, '2021-02-20 18:29:25', '2021-02-20 18:29:25', '3e18de5b-83bf-4b16-bd32-90e969a1edc9'),
(8, 3, NULL, 3, NULL, '2021-02-20 22:46:00', NULL, NULL, '2021-02-20 22:46:54', '2021-02-20 22:46:54', '338bb2a8-8d31-49b5-9fa2-3d95f1ec5381'),
(9, 3, NULL, 3, NULL, '2021-02-20 22:46:00', NULL, NULL, '2021-02-20 22:46:54', '2021-02-20 22:46:54', 'dda1cf59-6484-4c03-b107-774668273d9e'),
(10, 3, NULL, 3, NULL, '2021-02-20 22:46:00', NULL, NULL, '2021-02-20 22:47:09', '2021-02-20 22:47:09', '66b59227-fa5f-445f-aeb8-11f252a34a36');

-- --------------------------------------------------------

--
-- Table structure for table `craft_entrytypes`
--

CREATE TABLE `craft_entrytypes` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8_unicode_ci,
  `titleFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_entrytypes`
--

INSERT INTO `craft_entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleTranslationMethod`, `titleTranslationKeyFormat`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES
(1, 1, 1, 'Homepage', 'homepage', 1, 'site', NULL, NULL, 1, '2021-02-20 17:58:28', '2021-02-20 17:58:28', NULL, '34e49f81-1fe4-44d7-aa04-14dccf40afcd'),
(2, 2, 2, 'Content', 'contents', 1, 'site', NULL, NULL, 1, '2021-02-20 18:00:02', '2021-02-20 18:00:02', NULL, '6bba2872-2501-4743-855d-0dc9e788312a'),
(3, 3, 3, 'Views Work', 'viewsWork', 0, 'site', NULL, '{section.name|raw}', 1, '2021-02-20 22:46:54', '2021-02-20 22:46:54', NULL, 'de411d21-3659-4de8-8c66-1babf1ca22f1');

-- --------------------------------------------------------

--
-- Table structure for table `craft_fieldgroups`
--

CREATE TABLE `craft_fieldgroups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_fieldgroups`
--

INSERT INTO `craft_fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES
(1, 'Common', '2021-02-20 17:18:23', '2021-02-20 17:18:23', NULL, 'd2c1603a-b601-4cc7-93de-bc643ea0ceaf');

-- --------------------------------------------------------

--
-- Table structure for table `craft_fieldlayoutfields`
--

CREATE TABLE `craft_fieldlayoutfields` (
  `id` int(11) NOT NULL,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_fieldlayoutfields`
--

INSERT INTO `craft_fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 2, 3, 1, 0, 1, '2021-02-20 18:00:10', '2021-02-20 18:00:10', '4e2c27ba-0f7b-4d0f-8237-36b12192ded5'),
(2, 1, 4, 1, 0, 1, '2021-02-20 22:26:07', '2021-02-20 22:26:07', '30197455-1ae2-4f22-ae48-35bf07e76785'),
(3, 3, 6, 1, 0, 1, '2021-02-20 22:47:09', '2021-02-20 22:47:09', '4a2dbcbb-0a7d-4ed4-8d72-4dfcb2dcb033'),
(4, 4, 7, 4, 1, 0, '2021-02-20 22:51:12', '2021-02-20 22:51:12', '0cf89024-701b-4c33-990d-d29fd3346300'),
(5, 4, 7, 3, 0, 1, '2021-02-20 22:51:12', '2021-02-20 22:51:12', '4bd1277b-5b79-47f8-9a09-784710795067'),
(6, 5, 8, 2, 0, 0, '2021-02-20 22:52:23', '2021-02-20 22:52:23', 'b97e8dd3-10c6-45fc-b768-6b182b7ff7f8');

-- --------------------------------------------------------

--
-- Table structure for table `craft_fieldlayouts`
--

CREATE TABLE `craft_fieldlayouts` (
  `id` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_fieldlayouts`
--

INSERT INTO `craft_fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES
(1, 'craft\\elements\\Entry', '2021-02-20 17:58:28', '2021-02-20 17:58:28', NULL, '619652fb-3d35-4958-8570-9488b252b7eb'),
(2, 'craft\\elements\\Entry', '2021-02-20 18:00:02', '2021-02-20 18:00:02', NULL, '391fe8d2-d51c-45cc-bc42-4c057eec98eb'),
(3, 'craft\\elements\\Entry', '2021-02-20 22:46:54', '2021-02-20 22:46:54', NULL, '51fa3541-1228-470d-8346-ccffbb033805'),
(4, 'craft\\elements\\MatrixBlock', '2021-02-20 22:51:12', '2021-02-20 22:51:12', NULL, '6027090c-2fa1-4f05-a334-cabdad3b1f18'),
(5, 'craft\\elements\\GlobalSet', '2021-02-20 22:52:23', '2021-02-20 22:52:23', NULL, '7e793981-5737-44a3-b834-04b1a9ce4e70');

-- --------------------------------------------------------

--
-- Table structure for table `craft_fieldlayouttabs`
--

CREATE TABLE `craft_fieldlayouttabs` (
  `id` int(11) NOT NULL,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `elements` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_fieldlayouttabs`
--

INSERT INTO `craft_fieldlayouttabs` (`id`, `layoutId`, `name`, `elements`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(3, 2, 'Content', '[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"83f76d5f-153a-4ace-b2c0-71e443bcdbb3\"}]', 1, '2021-02-20 18:00:10', '2021-02-20 18:00:10', 'ddd1673c-0cb7-4cc5-9e0a-368be6d00836'),
(4, 1, 'Content', '[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"83f76d5f-153a-4ace-b2c0-71e443bcdbb3\"}]', 1, '2021-02-20 22:26:07', '2021-02-20 22:26:07', 'fb0b0e75-9bf2-4597-af5c-119ae49c599d'),
(6, 3, 'Content', '[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"83f76d5f-153a-4ace-b2c0-71e443bcdbb3\"}]', 1, '2021-02-20 22:47:09', '2021-02-20 22:47:09', '065794f4-3882-4273-b637-dd1a073c3e37'),
(7, 4, 'Content', '[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"fieldUid\":\"7d0babff-760a-4351-afb1-3e4844e53295\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"70a0d9df-1da6-4ebd-a54a-8ded2d2705f7\"}]', 1, '2021-02-20 22:51:12', '2021-02-20 22:51:12', 'd835e818-3a40-4ac5-957b-3d5610a377f9'),
(8, 5, 'Left menu', '[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"afadcb1e-234b-4c7e-b927-9bfaf9c724c8\"}]', 1, '2021-02-20 22:52:23', '2021-02-20 22:52:23', '05da79f4-5b53-42ce-a14a-11162a1551ba');

-- --------------------------------------------------------

--
-- Table structure for table `craft_fields`
--

CREATE TABLE `craft_fields` (
  `id` int(11) NOT NULL,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'global',
  `instructions` text COLLATE utf8_unicode_ci,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none',
  `translationKeyFormat` text COLLATE utf8_unicode_ci,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_fields`
--

INSERT INTO `craft_fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 1, 'Body text', 'bodyText', 'global', '', 0, 'none', NULL, 'craft\\redactor\\Field', '{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"cleanupHtml\":true,\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":\"\",\"purifyHtml\":\"1\",\"redactorConfig\":\"\",\"removeEmptyTags\":\"1\",\"removeInlineStyles\":\"1\",\"removeNbsp\":\"1\",\"showHtmlButtonForNonAdmins\":\"\",\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}', '2021-02-20 17:57:25', '2021-02-20 17:57:25', '83f76d5f-153a-4ace-b2c0-71e443bcdbb3'),
(2, 1, 'Menu', 'menu', 'global', '', 0, 'site', NULL, 'craft\\fields\\Matrix', '{\"contentTable\":\"{{%matrixcontent_menu}}\",\"maxBlocks\":\"\",\"minBlocks\":\"\",\"propagationMethod\":\"all\"}', '2021-02-20 22:51:12', '2021-02-20 22:51:12', 'afadcb1e-234b-4c7e-b927-9bfaf9c724c8'),
(3, NULL, 'Entry', 'entry', 'matrixBlockType:9a81d45f-2bc7-41ef-9785-4ac541ac06a6', '', 0, 'site', NULL, 'craft\\fields\\Entries', '{\"allowSelfRelations\":false,\"limit\":\"1\",\"localizeRelations\":false,\"selectionLabel\":\"\",\"showSiteMenu\":false,\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}', '2021-02-20 22:51:12', '2021-02-20 22:51:12', '70a0d9df-1da6-4ebd-a54a-8ded2d2705f7'),
(4, NULL, 'Label', 'label', 'matrixBlockType:9a81d45f-2bc7-41ef-9785-4ac541ac06a6', '', 0, 'none', NULL, 'craft\\fields\\PlainText', '{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}', '2021-02-20 22:51:12', '2021-02-20 22:51:12', '7d0babff-760a-4351-afb1-3e4844e53295');

-- --------------------------------------------------------

--
-- Table structure for table `craft_globalsets`
--

CREATE TABLE `craft_globalsets` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_globalsets`
--

INSERT INTO `craft_globalsets` (`id`, `name`, `handle`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(11, 'Left menu', 'leftMenu', 5, '2021-02-20 22:52:23', '2021-02-20 22:52:23', '352f1183-78f1-4868-870f-d09fdd4c0b9a');

-- --------------------------------------------------------

--
-- Table structure for table `craft_gqlschemas`
--

CREATE TABLE `craft_gqlschemas` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `scope` text COLLATE utf8_unicode_ci,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_gqltokens`
--

CREATE TABLE `craft_gqltokens` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accessToken` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_info`
--

CREATE TABLE `craft_info` (
  `id` int(11) NOT NULL,
  `version` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_info`
--

INSERT INTO `craft_info` (`id`, `version`, `schemaVersion`, `maintenance`, `configVersion`, `fieldVersion`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, '3.6.6', '3.6.4', 0, 'dyciggorboud', 'zxpiwtojmygu', '2021-02-20 17:18:23', '2021-02-20 22:52:55', '9aee18fe-20c9-4412-a53f-cfd4953f769e');

-- --------------------------------------------------------

--
-- Table structure for table `craft_matrixblocks`
--

CREATE TABLE `craft_matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_matrixblocks`
--

INSERT INTO `craft_matrixblocks` (`id`, `ownerId`, `fieldId`, `typeId`, `sortOrder`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(12, 11, 2, 1, 2, NULL, '2021-02-20 22:52:42', '2021-02-21 00:05:35', '0aae77a7-0994-448c-bbdf-0f9935f21f4b'),
(13, 11, 2, 1, 1, NULL, '2021-02-21 00:05:35', '2021-02-21 00:05:35', 'cd40a30b-7b0f-4a0f-98f9-78b533c0a4b4');

-- --------------------------------------------------------

--
-- Table structure for table `craft_matrixblocktypes`
--

CREATE TABLE `craft_matrixblocktypes` (
  `id` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_matrixblocktypes`
--

INSERT INTO `craft_matrixblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 2, 4, 'Menu item', 'menuItem', 1, '2021-02-20 22:51:12', '2021-02-20 22:51:12', '9a81d45f-2bc7-41ef-9785-4ac541ac06a6');

-- --------------------------------------------------------

--
-- Table structure for table `craft_matrixcontent_menu`
--

CREATE TABLE `craft_matrixcontent_menu` (
  `id` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `field_menuItem_label` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_matrixcontent_menu`
--

INSERT INTO `craft_matrixcontent_menu` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_menuItem_label`) VALUES
(1, 12, 1, '2021-02-20 22:52:42', '2021-02-21 00:05:35', '4c4a1a96-ccfe-4218-90b2-4008b4550e38', 'Views Work'),
(2, 12, 2, '2021-02-20 22:52:42', '2021-02-21 00:05:35', '705131fa-ee8b-4782-8955-671b0626357d', 'Views Work'),
(3, 13, 1, '2021-02-21 00:05:35', '2021-02-21 00:05:35', '49e93f66-7932-4928-8b32-5289a10d9a0d', 'Welcome'),
(4, 13, 2, '2021-02-21 00:05:35', '2021-02-21 00:05:35', '4933bf2a-983a-42ea-8ba9-1b461c151810', 'Welcome');

-- --------------------------------------------------------

--
-- Table structure for table `craft_migrations`
--

CREATE TABLE `craft_migrations` (
  `id` int(11) NOT NULL,
  `track` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_migrations`
--

INSERT INTO `craft_migrations` (`id`, `track`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 'craft', 'Install', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '25e7936c-bb49-4e30-900a-e2a134beb565'),
(2, 'craft', 'm150403_183908_migrations_table_changes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '0ab4b943-2b14-4ca8-a573-b3c373ab8aca'),
(3, 'craft', 'm150403_184247_plugins_table_changes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'ab35e11d-1f0e-40ea-ad61-664cb5d67e0d'),
(4, 'craft', 'm150403_184533_field_version', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'a2748571-05bf-4b4d-87ec-f49da8bb7805'),
(5, 'craft', 'm150403_184729_type_columns', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f24807cb-8c38-4023-8112-ce212812e5d1'),
(6, 'craft', 'm150403_185142_volumes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '414349e7-b07f-429b-b9ac-e843184980ca'),
(7, 'craft', 'm150428_231346_userpreferences', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '92e681d3-089f-4dc8-9e22-d8cc8654b2b5'),
(8, 'craft', 'm150519_150900_fieldversion_conversion', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'ef6ffffc-6e9d-4181-a637-acaf0d16d566'),
(9, 'craft', 'm150617_213829_update_email_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '523de8fb-e7b4-4d7f-998f-1cfd41576929'),
(10, 'craft', 'm150721_124739_templatecachequeries', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'b2f0d95a-9612-4ef8-9d4f-d2b552976890'),
(11, 'craft', 'm150724_140822_adjust_quality_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '244570fc-f757-4ca7-a526-2cac31694530'),
(12, 'craft', 'm150815_133521_last_login_attempt_ip', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '20d130f8-27f8-4feb-a160-215920388e55'),
(13, 'craft', 'm151002_095935_volume_cache_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'a178387d-35b4-4e50-aeb1-05ddc6e0fb3e'),
(14, 'craft', 'm151005_142750_volume_s3_storage_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'c928137c-20d0-4c5d-b753-ec8cff6c5bd2'),
(15, 'craft', 'm151016_133600_delete_asset_thumbnails', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'cb1c5a2d-406d-46bd-a475-69593eb12d8e'),
(16, 'craft', 'm151209_000000_move_logo', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f92e53b1-8e26-4c62-8b18-19c158cd4690'),
(17, 'craft', 'm151211_000000_rename_fileId_to_assetId', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '323bbbb8-f439-4666-870f-ce52ed71064d'),
(18, 'craft', 'm151215_000000_rename_asset_permissions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f2213af6-877e-4359-8c07-46e12364489a'),
(19, 'craft', 'm160707_000001_rename_richtext_assetsource_setting', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '14248890-c861-4046-b174-cc6d79adfced'),
(20, 'craft', 'm160708_185142_volume_hasUrls_setting', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '539f10a6-f615-4bcb-a88e-bad18bb6a2e1'),
(21, 'craft', 'm160714_000000_increase_max_asset_filesize', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'd4767a32-256c-46ac-800c-517fd4d32812'),
(22, 'craft', 'm160727_194637_column_cleanup', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f3c05bb4-8692-4fd1-bd8e-203d3aa10e7f'),
(23, 'craft', 'm160804_110002_userphotos_to_assets', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '81ece5bf-8739-4fcd-994f-c82f7edeb78e'),
(24, 'craft', 'm160807_144858_sites', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '38688943-30f3-48e4-aab0-5d346627ac7d'),
(25, 'craft', 'm160829_000000_pending_user_content_cleanup', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1a91f8ac-bab2-4f1e-8773-d60b97d1391f'),
(26, 'craft', 'm160830_000000_asset_index_uri_increase', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '91084715-61e7-49a8-ad09-622765a5253e'),
(27, 'craft', 'm160912_230520_require_entry_type_id', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '94b67033-272b-4c4a-8a1a-b8e525b3ec81'),
(28, 'craft', 'm160913_134730_require_matrix_block_type_id', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '77d80b51-aa46-4ff3-ade7-7b82c312e06a'),
(29, 'craft', 'm160920_174553_matrixblocks_owner_site_id_nullable', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'd0116695-a595-47a9-8e40-2fe9f6568b43'),
(30, 'craft', 'm160920_231045_usergroup_handle_title_unique', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '36eaf05c-aba8-4d39-a6af-c1daa4afb497'),
(31, 'craft', 'm160925_113941_route_uri_parts', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e6e4cf21-4ed1-45e1-9ae4-df917ad98bef'),
(32, 'craft', 'm161006_205918_schemaVersion_not_null', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '399b4779-5b64-435e-9ea3-3605856cfbf7'),
(33, 'craft', 'm161007_130653_update_email_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'ec81f000-a937-43c5-a1b2-41b69eac96e2'),
(34, 'craft', 'm161013_175052_newParentId', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '99bfc748-f930-40ec-9cf0-cd377861a3e6'),
(35, 'craft', 'm161021_102916_fix_recent_entries_widgets', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '31b1bb04-7b93-4d9d-a457-9f66d6296fe1'),
(36, 'craft', 'm161021_182140_rename_get_help_widget', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '432ed5f1-a297-4a8d-8259-20db7f080481'),
(37, 'craft', 'm161025_000000_fix_char_columns', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '6edd84c7-62db-4f3e-ad53-eba1165907a4'),
(38, 'craft', 'm161029_124145_email_message_languages', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1d1982b2-55ba-4d5c-9c6e-0dab9621271f'),
(39, 'craft', 'm161108_000000_new_version_format', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '6538bac2-5617-4219-acea-d11ceb38011a'),
(40, 'craft', 'm161109_000000_index_shuffle', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'eac1ed63-f1bb-4983-988d-376fdb47bcb2'),
(41, 'craft', 'm161122_185500_no_craft_app', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'ed6cce4e-83b6-47c1-99f2-5bfffcfdce3e'),
(42, 'craft', 'm161125_150752_clear_urlmanager_cache', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'a9238f59-6ec7-4710-bd63-f51327bfacdf'),
(43, 'craft', 'm161220_000000_volumes_hasurl_notnull', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '73bd5097-6fa0-4192-b0ca-ed4b352149dc'),
(44, 'craft', 'm170114_161144_udates_permission', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '5609c936-168a-416f-bb21-9e8c7615b050'),
(45, 'craft', 'm170120_000000_schema_cleanup', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e01058e8-4116-42a9-bc5f-09d795f2d9f7'),
(46, 'craft', 'm170126_000000_assets_focal_point', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '5fc8428f-3e68-4b22-aa48-aa00bb63bb94'),
(47, 'craft', 'm170206_142126_system_name', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '9fb0b6f8-7ee2-4ced-b32e-95fbc7482edb'),
(48, 'craft', 'm170217_044740_category_branch_limits', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '6c68836a-e928-4784-9239-5d73bbba9480'),
(49, 'craft', 'm170217_120224_asset_indexing_columns', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'cc06fb5b-696f-4793-be32-ecb17001ded1'),
(50, 'craft', 'm170223_224012_plain_text_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '391e79fd-7710-4b40-8ce6-4cba0353b387'),
(51, 'craft', 'm170227_120814_focal_point_percentage', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '7fc46b0f-6d5c-4a6e-8f55-5826664eb0a6'),
(52, 'craft', 'm170228_171113_system_messages', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'aaf0158d-f0dd-4dd8-88da-549e98ae2151'),
(53, 'craft', 'm170303_140500_asset_field_source_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1f83c143-5e51-4c87-b992-9b00538f6462'),
(54, 'craft', 'm170306_150500_asset_temporary_uploads', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '15549740-2292-45d0-a447-b93b8d907304'),
(55, 'craft', 'm170523_190652_element_field_layout_ids', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '6f1cb2d3-6dc4-4a31-b837-49e08ae1a2d9'),
(56, 'craft', 'm170621_195237_format_plugin_handles', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '29744834-2d81-4b23-ab23-32045c284984'),
(57, 'craft', 'm170630_161027_deprecation_line_nullable', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e8fbe765-30fd-4c27-aedd-b0ffeda545a8'),
(58, 'craft', 'm170630_161028_deprecation_changes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'c9f190a3-58cd-483b-b1a7-d5e2cede8076'),
(59, 'craft', 'm170703_181539_plugins_table_tweaks', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e5f65749-c12d-4c31-86ad-e3920bce8443'),
(60, 'craft', 'm170704_134916_sites_tables', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '43a92fc9-126f-424b-bb88-d8cee8e225ac'),
(61, 'craft', 'm170706_183216_rename_sequences', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '99072866-4c86-4424-9dff-ac8c8214258c'),
(62, 'craft', 'm170707_094758_delete_compiled_traits', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '3b0471fd-65b6-4d00-b0e1-7aae86ddcb9a'),
(63, 'craft', 'm170731_190138_drop_asset_packagist', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '82734ea6-352a-4a8a-8f7c-cf191b75eeee'),
(64, 'craft', 'm170810_201318_create_queue_table', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '804188d1-8605-42d1-b668-ba3ca4193919'),
(65, 'craft', 'm170903_192801_longblob_for_queue_jobs', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '042f3902-94c2-4bb8-aaed-1dd96cd16c8a'),
(66, 'craft', 'm170914_204621_asset_cache_shuffle', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '3623f588-f526-4a15-8f83-6da2cc5dfc8d'),
(67, 'craft', 'm171011_214115_site_groups', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '7e08cbe4-963a-4ff6-baac-1b2d4d362c6c'),
(68, 'craft', 'm171012_151440_primary_site', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'a35a1b0e-1607-49ae-870a-b58f527b2ddc'),
(69, 'craft', 'm171013_142500_transform_interlace', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f7167739-85ee-4eef-816f-1eb43bb49a93'),
(70, 'craft', 'm171016_092553_drop_position_select', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '52cf99c3-d9b0-4fec-b997-8932052e370f'),
(71, 'craft', 'm171016_221244_less_strict_translation_method', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'c4b49851-51af-4d3d-b42e-00abdba37066'),
(72, 'craft', 'm171107_000000_assign_group_permissions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '7d1d2502-7f5c-481a-9600-a1640be64b04'),
(73, 'craft', 'm171117_000001_templatecache_index_tune', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '7a4deb31-542c-429a-b9f2-f7eab810af47'),
(74, 'craft', 'm171126_105927_disabled_plugins', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '6e8f8454-7d79-4161-970a-393507a812f9'),
(75, 'craft', 'm171130_214407_craftidtokens_table', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'bb42a59c-a2fb-4e94-91d0-50824f2bfbd0'),
(76, 'craft', 'm171202_004225_update_email_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '5586f9fc-9c83-441b-a583-e0670b0a8214'),
(77, 'craft', 'm171204_000001_templatecache_index_tune_deux', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'c08514c2-b2ef-4442-bf50-cbc010a0135c'),
(78, 'craft', 'm171205_130908_remove_craftidtokens_refreshtoken_column', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e2c38aba-216e-43cc-a6c7-815960591acc'),
(79, 'craft', 'm171218_143135_longtext_query_column', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f2539c43-894c-4517-a796-dcdb549ae62f'),
(80, 'craft', 'm171231_055546_environment_variables_to_aliases', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'c769c397-4ee6-45ce-b886-83e2e74aa45c'),
(81, 'craft', 'm180113_153740_drop_users_archived_column', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '640061fb-b5ef-495c-9668-daf975db9e1d'),
(82, 'craft', 'm180122_213433_propagate_entries_setting', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'ad447f61-6c35-4d9a-91a0-b08905b10a03'),
(83, 'craft', 'm180124_230459_fix_propagate_entries_values', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '89fe5f6c-3465-4e3c-9b0c-cad7debe0fc6'),
(84, 'craft', 'm180128_235202_set_tag_slugs', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'fa4d307f-8ed0-4488-b86e-83bacbe7233e'),
(85, 'craft', 'm180202_185551_fix_focal_points', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'a97b6d01-6afd-4ac6-a829-716099e169c6'),
(86, 'craft', 'm180217_172123_tiny_ints', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'b0be6d70-aa3b-4446-a55e-60fccf6ae874'),
(87, 'craft', 'm180321_233505_small_ints', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2e23510f-03b9-4ef6-9676-4071c956b225'),
(88, 'craft', 'm180404_182320_edition_changes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e465fbc8-1742-4a56-8fe8-47726d065e51'),
(89, 'craft', 'm180411_102218_fix_db_routes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1720b322-1679-4fe9-abbf-c7cc4247b1f6'),
(90, 'craft', 'm180416_205628_resourcepaths_table', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '8f71c78e-6da0-48c4-b338-b4c1ca4a3d98'),
(91, 'craft', 'm180418_205713_widget_cleanup', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f8893d65-e1ed-4a50-819e-658ec62b46ab'),
(92, 'craft', 'm180425_203349_searchable_fields', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '51d9dd0b-5657-423c-b2fd-c44caf342686'),
(93, 'craft', 'm180516_153000_uids_in_field_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '11b8354e-d22d-4c71-939f-27efd5c38e16'),
(94, 'craft', 'm180517_173000_user_photo_volume_to_uid', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'da051ee6-9c7d-4cbd-8ecb-e7232e8149ff'),
(95, 'craft', 'm180518_173000_permissions_to_uid', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '67fa6bc0-18be-42f7-8e2b-fed50355e11b'),
(96, 'craft', 'm180520_173000_matrix_context_to_uids', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '07e452c1-709a-48c3-a641-9f36f2789d92'),
(97, 'craft', 'm180521_172900_project_config_table', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '602cea9e-5132-475a-bff0-46ea896aaa43'),
(98, 'craft', 'm180521_173000_initial_yml_and_snapshot', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '3f4838cd-031e-4cb7-a5d7-c30c98d3bbae'),
(99, 'craft', 'm180731_162030_soft_delete_sites', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '9fd071e3-f4c7-4e58-9478-dc257c899b95'),
(100, 'craft', 'm180810_214427_soft_delete_field_layouts', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '728a66b2-dad9-4153-a104-3e1659f04893'),
(101, 'craft', 'm180810_214439_soft_delete_elements', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '73343fdd-ab0d-4300-b53b-aac1d08f2e82'),
(102, 'craft', 'm180824_193422_case_sensitivity_fixes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '3e2cde5a-eb9a-46cd-a8dc-370e966ae699'),
(103, 'craft', 'm180901_151639_fix_matrixcontent_tables', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'adef3ac0-ed7e-4346-a2c4-f69ab7db5040'),
(104, 'craft', 'm180904_112109_permission_changes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '584bcffa-fea8-4d1d-a379-737777d4daf2'),
(105, 'craft', 'm180910_142030_soft_delete_sitegroups', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '76cc8752-73f7-40fb-a5a8-7851833a42d5'),
(106, 'craft', 'm181011_160000_soft_delete_asset_support', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'abcc3fe4-7907-4fc1-8b54-b8bebf02f8e8'),
(107, 'craft', 'm181016_183648_set_default_user_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '570c9d23-89ce-4be3-b479-b38d649ca5bc'),
(108, 'craft', 'm181017_225222_system_config_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '4e01021f-8a2e-44e3-9d0d-36cbcc12c8da'),
(109, 'craft', 'm181018_222343_drop_userpermissions_from_config', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e12ecf5d-a30a-4974-902a-63837273ed20'),
(110, 'craft', 'm181029_130000_add_transforms_routes_to_config', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '02261b9c-d03f-4495-af48-4179ea182e21'),
(111, 'craft', 'm181112_203955_sequences_table', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'dadd2c06-7a99-477f-a792-06dd0a6c2128'),
(112, 'craft', 'm181121_001712_cleanup_field_configs', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e3f029e8-f183-40cd-bbfb-122d873d15af'),
(113, 'craft', 'm181128_193942_fix_project_config', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '816665d4-ad1c-423a-b17a-96c7c35958a0'),
(114, 'craft', 'm181130_143040_fix_schema_version', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1806ece3-956e-4969-b3e5-95c889568c00'),
(115, 'craft', 'm181211_143040_fix_entry_type_uids', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '3138d4f3-ffa4-43c4-911d-1fe7b7db5f17'),
(116, 'craft', 'm181217_153000_fix_structure_uids', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '27c9e863-0d30-4164-9afd-acc93d073ee7'),
(117, 'craft', 'm190104_152725_store_licensed_plugin_editions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '68a22192-e223-4a92-9895-3efeec83b271'),
(118, 'craft', 'm190108_110000_cleanup_project_config', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '6e49ea3a-c2a8-4b98-a5a6-b4150549148d'),
(119, 'craft', 'm190108_113000_asset_field_setting_change', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '63c7ce89-bf56-4052-8f6b-9c394841faac'),
(120, 'craft', 'm190109_172845_fix_colspan', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'b4ece0e8-b3a8-4178-8841-9ff33c9da75a'),
(121, 'craft', 'm190110_150000_prune_nonexisting_sites', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '13c6b3fa-6e78-42b0-a3af-0c0f645608c3'),
(122, 'craft', 'm190110_214819_soft_delete_volumes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '0e139800-5555-45ae-998a-7a7953836546'),
(123, 'craft', 'm190112_124737_fix_user_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '077866a7-c03a-43cc-8e66-36a87f4f24d0'),
(124, 'craft', 'm190112_131225_fix_field_layouts', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'bb4041de-0494-4bfa-a0ed-c4f054fe8f03'),
(125, 'craft', 'm190112_201010_more_soft_deletes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '76a3780f-e736-4d66-974b-bec7795a174d'),
(126, 'craft', 'm190114_143000_more_asset_field_setting_changes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1a6f20b2-081c-404e-8f8d-8a5be3aadc6d'),
(127, 'craft', 'm190121_120000_rich_text_config_setting', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'dd02fc11-4db1-4787-a990-25f2e00bed71'),
(128, 'craft', 'm190125_191628_fix_email_transport_password', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'a37fc6cb-ec29-450b-b874-2fed8f22de75'),
(129, 'craft', 'm190128_181422_cleanup_volume_folders', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'b17712b1-46ac-49ca-80a5-90bf9d0c036b'),
(130, 'craft', 'm190205_140000_fix_asset_soft_delete_index', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '9e6a840b-191c-491c-b33e-b316c942aaf8'),
(131, 'craft', 'm190218_143000_element_index_settings_uid', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '9368e9e3-878d-44d9-8726-47537bd11242'),
(132, 'craft', 'm190312_152740_element_revisions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '77bff4b3-897e-4622-b2a1-4230b3a93fca'),
(133, 'craft', 'm190327_235137_propagation_method', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '7f94bf70-9fcc-4bee-a59e-fe5d25a6ee49'),
(134, 'craft', 'm190401_223843_drop_old_indexes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '0a130117-82a2-412b-8128-e35a6775a1ed'),
(135, 'craft', 'm190416_014525_drop_unique_global_indexes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '4a26f8b8-0b3e-43c6-afe0-755922d3f622'),
(136, 'craft', 'm190417_085010_add_image_editor_permissions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f0171b39-411c-4e04-9541-5ebe1bf4c645'),
(137, 'craft', 'm190502_122019_store_default_user_group_uid', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '0dcf4e79-83ff-4ca3-9ffd-b7144b9f8d3f'),
(138, 'craft', 'm190504_150349_preview_targets', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '8b1a96ca-5a18-4366-9b17-20cf69e77ecb'),
(139, 'craft', 'm190516_184711_job_progress_label', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'cd457f59-6d26-49c2-9bcb-44746e826139'),
(140, 'craft', 'm190523_190303_optional_revision_creators', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '708b677b-d0a1-44e5-9d3b-94bde854222c'),
(141, 'craft', 'm190529_204501_fix_duplicate_uids', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'a1ef3ca4-baf2-495c-ad3e-ab70a820a9b2'),
(142, 'craft', 'm190605_223807_unsaved_drafts', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '32304353-c045-4073-bf0d-6078e2294461'),
(143, 'craft', 'm190607_230042_entry_revision_error_tables', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'd8132eac-8044-45ba-b88c-2ebddbf71819'),
(144, 'craft', 'm190608_033429_drop_elements_uid_idx', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'c93df2c3-e8cb-43fb-ac7a-682a787d6c2e'),
(145, 'craft', 'm190617_164400_add_gqlschemas_table', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e6d9fccb-be76-4118-8176-edecd91c7cac'),
(146, 'craft', 'm190624_234204_matrix_propagation_method', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '67407063-ef2e-4e3e-bc84-dc47a0232799'),
(147, 'craft', 'm190711_153020_drop_snapshots', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '042f5fcf-f2d4-4f2e-9050-fd67fb1824be'),
(148, 'craft', 'm190712_195914_no_draft_revisions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '436e882e-6586-44c2-9819-4926f46642ed'),
(149, 'craft', 'm190723_140314_fix_preview_targets_column', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'ec7d60c3-ccc2-4f8a-a4e9-a55b67b2ffbb'),
(150, 'craft', 'm190820_003519_flush_compiled_templates', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e817712a-3871-44fb-a24c-98a47f4b638b'),
(151, 'craft', 'm190823_020339_optional_draft_creators', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '34b46ff6-43d9-44b2-8fe1-cc72f8add2b7'),
(152, 'craft', 'm190913_152146_update_preview_targets', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'fa0e0df3-bcdc-4e89-a419-192559bc9b34'),
(153, 'craft', 'm191107_122000_add_gql_project_config_support', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'a20ed991-234d-4df9-b855-1a3cddac7161'),
(154, 'craft', 'm191204_085100_pack_savable_component_settings', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '5fa85b22-1aaf-4bbb-bcfa-4d742942420b'),
(155, 'craft', 'm191206_001148_change_tracking', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '3aaea481-91c5-4f6e-baef-6306ca6ce255'),
(156, 'craft', 'm191216_191635_asset_upload_tracking', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '4a3cbe4b-2201-4e4c-a268-a4e9ea2ff0d6'),
(157, 'craft', 'm191222_002848_peer_asset_permissions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '43244e65-7e49-44ff-aa81-7bdb7fb84a90'),
(158, 'craft', 'm200127_172522_queue_channels', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '9334786d-40af-49ca-b641-8c6f7bda43cb'),
(159, 'craft', 'm200211_175048_truncate_element_query_cache', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '4567223d-658b-481e-ab18-76e770d1172c'),
(160, 'craft', 'm200213_172522_new_elements_index', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '16706120-f8fd-4b10-98cd-8368b2d4edac'),
(161, 'craft', 'm200228_195211_long_deprecation_messages', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '220a21a2-b385-4bd0-a6b7-8574ba7d0364'),
(162, 'craft', 'm200306_054652_disabled_sites', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1c3fcefd-ba19-477a-948d-c1912011d3a7'),
(163, 'craft', 'm200522_191453_clear_template_caches', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '92888c40-80b2-4b7a-b04a-d5c699392882'),
(164, 'craft', 'm200606_231117_migration_tracks', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '35b46fe5-c2e4-4d69-82ac-f19f168d17c7'),
(165, 'craft', 'm200619_215137_title_translation_method', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'da37e90b-feae-41ed-9d92-7f62b248424d'),
(166, 'craft', 'm200620_005028_user_group_descriptions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '36e18442-0a2c-49a4-87c9-25cb1d5a31cf'),
(167, 'craft', 'm200620_230205_field_layout_changes', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '83c60b08-8bd3-48e5-9d4e-f33d0c5644be'),
(168, 'craft', 'm200625_131100_move_entrytypes_to_top_project_config', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '018a96d2-9e8e-4fc9-a665-42e13e30ec57'),
(169, 'craft', 'm200629_112700_remove_project_config_legacy_files', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1fa8f2fe-7fd9-4331-9ab1-00b4f02198f9'),
(170, 'craft', 'm200630_183000_drop_configmap', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'e1ec5ca5-bf0c-4773-be33-45ba31e1d58c'),
(171, 'craft', 'm200715_113400_transform_index_error_flag', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1dce9173-4d5e-4fed-b8aa-d410c57baeb5'),
(172, 'craft', 'm200716_110900_replace_file_asset_permissions', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '460b073c-d1f4-4509-9857-93f429defc6c'),
(173, 'craft', 'm200716_153800_public_token_settings_in_project_config', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'd8562ac2-6c16-44cd-b402-bbe8af08efdb'),
(174, 'craft', 'm200720_175543_drop_unique_constraints', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'c2b9724b-a064-4ea2-9ed3-4404c0ff40d2'),
(175, 'craft', 'm200825_051217_project_config_version', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'f71894b6-ae3c-48dd-a6e5-cf32d777bd19'),
(176, 'craft', 'm201116_190500_asset_title_translation_method', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'ae950fd7-d57f-48aa-9d01-d3ec51d5dba7'),
(177, 'craft', 'm201124_003555_plugin_trials', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', 'b8506c40-6374-4f29-947a-51a0016f6856'),
(178, 'craft', 'm210209_135503_soft_delete_field_groups', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '71c6db7a-ee3f-4a0f-b99d-a9d72048e715'),
(179, 'craft', 'm210212_223539_delete_invalid_drafts', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '150bda3d-ad79-449f-8f71-61c20152ea21'),
(180, 'craft', 'm210214_202731_track_saved_drafts', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 17:18:24', '1465ede1-3c1b-4935-b2a3-3d8e6100c4bf'),
(181, 'plugin:views-work', 'Install', '2021-02-20 17:29:11', '2021-02-20 17:29:11', '2021-02-20 17:29:11', '2da627b8-a9f5-48dd-838e-325a8cc666f0'),
(182, 'plugin:views-work', 'm210214_095743_add_viewrecording_index', '2021-02-20 17:29:11', '2021-02-20 17:29:11', '2021-02-20 17:29:11', 'bc339250-e78b-4712-892a-c8bd14a52702'),
(183, 'plugin:redactor', 'm180430_204710_remove_old_plugins', '2021-02-20 17:56:53', '2021-02-20 17:56:53', '2021-02-20 17:56:53', '90210ef2-634b-4d22-bf0b-372cfa30db4e'),
(184, 'plugin:redactor', 'Install', '2021-02-20 17:56:53', '2021-02-20 17:56:53', '2021-02-20 17:56:53', '8faef876-da34-4b31-b047-a752dcc3aaba'),
(185, 'plugin:redactor', 'm190225_003922_split_cleanup_html_settings', '2021-02-20 17:56:53', '2021-02-20 17:56:53', '2021-02-20 17:56:53', '41b64060-abf4-4a55-9050-8065599b0e98');

-- --------------------------------------------------------

--
-- Table structure for table `craft_plugins`
--

CREATE TABLE `craft_plugins` (
  `id` int(11) NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_plugins`
--

INSERT INTO `craft_plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 'twigpack', '1.2.9', '1.0.0', 'unknown', NULL, '2021-02-20 17:27:27', '2021-02-20 17:27:27', '2021-02-20 17:56:59', '77f45e0d-313b-4d88-928e-a60dc1d6f077'),
(2, 'views-work', '1.3.0.7', '1.0.1', 'invalid', NULL, '2021-02-20 17:29:11', '2021-02-20 17:29:11', '2021-02-20 17:56:59', '30223e07-2fbd-4569-ae24-208829e832c0'),
(3, 'redactor', '2.8.5', '2.3.0', 'unknown', NULL, '2021-02-20 17:56:53', '2021-02-20 17:56:53', '2021-02-20 17:56:59', 'b1e80249-7db7-4789-9d7f-9125605d1def');

-- --------------------------------------------------------

--
-- Table structure for table `craft_projectconfig`
--

CREATE TABLE `craft_projectconfig` (
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_projectconfig`
--

INSERT INTO `craft_projectconfig` (`path`, `value`) VALUES
('dateModified', '1613861575'),
('email.fromEmail', '\"info@24hoursmedia.com\"'),
('email.fromName', '\"Craft Sample Application\"'),
('email.transportType', '\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.autocapitalize', 'true'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.autocomplete', 'false'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.autocorrect', 'true'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.class', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.disabled', 'false'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.id', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.instructions', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.label', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.max', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.min', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.name', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.orientation', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.placeholder', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.readonly', 'false'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.requirable', 'false'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.size', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.step', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.tip', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.title', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.type', '\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.warning', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.0.width', '100'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.1.fieldUid', '\"83f76d5f-153a-4ace-b2c0-71e443bcdbb3\"'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.1.instructions', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.1.label', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.1.required', 'false'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.1.tip', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.1.type', '\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.1.warning', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.elements.1.width', '100'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.name', '\"Content\"'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.fieldLayouts.619652fb-3d35-4958-8570-9488b252b7eb.tabs.0.sortOrder', '1'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.handle', '\"homepage\"'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.hasTitleField', 'true'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.name', '\"Homepage\"'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.section', '\"cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95\"'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.sortOrder', '1'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.titleFormat', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.titleTranslationKeyFormat', 'null'),
('entryTypes.34e49f81-1fe4-44d7-aa04-14dccf40afcd.titleTranslationMethod', '\"site\"'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.autocapitalize', 'true'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.autocomplete', 'false'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.autocorrect', 'true'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.class', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.disabled', 'false'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.id', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.instructions', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.label', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.max', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.min', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.name', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.orientation', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.placeholder', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.readonly', 'false'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.requirable', 'false'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.size', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.step', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.tip', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.title', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.type', '\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.warning', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.0.width', '100'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.1.fieldUid', '\"83f76d5f-153a-4ace-b2c0-71e443bcdbb3\"'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.1.instructions', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.1.label', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.1.required', 'false'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.1.tip', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.1.type', '\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.1.warning', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.elements.1.width', '100'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.name', '\"Content\"'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.fieldLayouts.391fe8d2-d51c-45cc-bc42-4c057eec98eb.tabs.0.sortOrder', '1'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.handle', '\"contents\"'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.hasTitleField', 'true'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.name', '\"Content\"'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.section', '\"e49170ca-a1e3-421b-a7f5-7adb050551f4\"'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.sortOrder', '1'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.titleFormat', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.titleTranslationKeyFormat', 'null'),
('entryTypes.6bba2872-2501-4743-855d-0dc9e788312a.titleTranslationMethod', '\"site\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.autocapitalize', 'true'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.autocomplete', 'false'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.autocorrect', 'true'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.class', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.disabled', 'false'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.id', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.instructions', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.label', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.max', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.min', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.name', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.orientation', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.placeholder', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.readonly', 'false'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.requirable', 'false'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.size', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.step', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.tip', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.title', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.type', '\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.warning', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.0.width', '100'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.1.fieldUid', '\"83f76d5f-153a-4ace-b2c0-71e443bcdbb3\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.1.instructions', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.1.label', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.1.required', 'false'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.1.tip', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.1.type', '\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.1.warning', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.elements.1.width', '100'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.name', '\"Content\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.fieldLayouts.51fa3541-1228-470d-8346-ccffbb033805.tabs.0.sortOrder', '1'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.handle', '\"viewsWork\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.hasTitleField', 'false'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.name', '\"Views Work\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.section', '\"ca9feccf-8f1a-46db-bdd7-09f028ce3c1c\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.sortOrder', '1'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.titleFormat', '\"{section.name|raw}\"'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.titleTranslationKeyFormat', 'null'),
('entryTypes.de411d21-3659-4de8-8c66-1babf1ca22f1.titleTranslationMethod', '\"site\"'),
('fieldGroups.d2c1603a-b601-4cc7-93de-bc643ea0ceaf.name', '\"Common\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.contentColumnType', '\"text\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.fieldGroup', '\"d2c1603a-b601-4cc7-93de-bc643ea0ceaf\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.handle', '\"bodyText\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.instructions', '\"\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.name', '\"Body text\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.searchable', 'false'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.availableTransforms', '\"*\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.availableVolumes', '\"*\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.cleanupHtml', 'true'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.columnType', '\"text\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.configSelectionMode', '\"choose\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.defaultTransform', '\"\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.manualConfig', '\"\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.purifierConfig', '\"\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.purifyHtml', '\"1\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.redactorConfig', '\"\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.removeEmptyTags', '\"1\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.removeInlineStyles', '\"1\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.removeNbsp', '\"1\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.showHtmlButtonForNonAdmins', '\"\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.showUnpermittedFiles', 'false'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.showUnpermittedVolumes', 'false'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.settings.uiMode', '\"enlarged\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.translationKeyFormat', 'null'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.translationMethod', '\"none\"'),
('fields.83f76d5f-153a-4ace-b2c0-71e443bcdbb3.type', '\"craft\\\\redactor\\\\Field\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.contentColumnType', '\"string\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.fieldGroup', '\"d2c1603a-b601-4cc7-93de-bc643ea0ceaf\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.handle', '\"menu\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.instructions', '\"\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.name', '\"Menu\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.searchable', 'false'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.settings.contentTable', '\"{{%matrixcontent_menu}}\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.settings.maxBlocks', '\"\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.settings.minBlocks', '\"\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.settings.propagationMethod', '\"all\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.translationKeyFormat', 'null'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.translationMethod', '\"site\"'),
('fields.afadcb1e-234b-4c7e-b927-9bfaf9c724c8.type', '\"craft\\\\fields\\\\Matrix\"'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.elements.0.fieldUid', '\"afadcb1e-234b-4c7e-b927-9bfaf9c724c8\"'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.elements.0.instructions', 'null'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.elements.0.label', 'null'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.elements.0.required', 'false'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.elements.0.tip', 'null'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.elements.0.type', '\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.elements.0.warning', 'null'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.elements.0.width', '100'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.name', '\"Left menu\"'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.fieldLayouts.7e793981-5737-44a3-b834-04b1a9ce4e70.tabs.0.sortOrder', '1'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.handle', '\"leftMenu\"'),
('globalSets.352f1183-78f1-4868-870f-d09fdd4c0b9a.name', '\"Left menu\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.field', '\"afadcb1e-234b-4c7e-b927-9bfaf9c724c8\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.0.fieldUid', '\"7d0babff-760a-4351-afb1-3e4844e53295\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.0.instructions', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.0.label', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.0.required', 'true'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.0.tip', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.0.type', '\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.0.warning', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.0.width', '100'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.1.fieldUid', '\"70a0d9df-1da6-4ebd-a54a-8ded2d2705f7\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.1.instructions', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.1.label', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.1.required', 'false'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.1.tip', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.1.type', '\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.1.warning', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.elements.1.width', '100'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.name', '\"Content\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fieldLayouts.6027090c-2fa1-4f05-a334-cabdad3b1f18.tabs.0.sortOrder', '1'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.contentColumnType', '\"string\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.fieldGroup', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.handle', '\"entry\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.instructions', '\"\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.name', '\"Entry\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.searchable', 'false'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.allowSelfRelations', 'false'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.limit', '\"1\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.localizeRelations', 'false'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.selectionLabel', '\"\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.showSiteMenu', 'false'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.source', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.sources', '\"*\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.targetSiteId', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.validateRelatedElements', 'false'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.settings.viewMode', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.translationKeyFormat', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.translationMethod', '\"site\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.70a0d9df-1da6-4ebd-a54a-8ded2d2705f7.type', '\"craft\\\\fields\\\\Entries\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.contentColumnType', '\"text\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.fieldGroup', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.handle', '\"label\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.instructions', '\"\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.name', '\"Label\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.searchable', 'false'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.settings.byteLimit', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.settings.charLimit', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.settings.code', '\"\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.settings.columnType', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.settings.initialRows', '\"4\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.settings.multiline', '\"\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.settings.placeholder', '\"\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.settings.uiMode', '\"normal\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.translationKeyFormat', 'null'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.translationMethod', '\"none\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.fields.7d0babff-760a-4351-afb1-3e4844e53295.type', '\"craft\\\\fields\\\\PlainText\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.handle', '\"menuItem\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.name', '\"Menu item\"'),
('matrixBlockTypes.9a81d45f-2bc7-41ef-9785-4ac541ac06a6.sortOrder', '1'),
('plugins.redactor.edition', '\"standard\"'),
('plugins.redactor.enabled', 'true'),
('plugins.redactor.schemaVersion', '\"2.3.0\"'),
('plugins.twigpack.edition', '\"standard\"'),
('plugins.twigpack.enabled', 'true'),
('plugins.twigpack.schemaVersion', '\"1.0.0\"'),
('plugins.views-work.edition', '\"standard\"'),
('plugins.views-work.enabled', 'true'),
('plugins.views-work.licenseKey', '\"NA0EVE0125DTAU3AZS01FYVK\"'),
('plugins.views-work.schemaVersion', '\"1.0.1\"'),
('plugins.views-work.settings.allowUrlReset', '\"1\"'),
('plugins.views-work.settings.allowUrlResetGET', '\"1\"'),
('plugins.views-work.settings.blockByCookieSecret', '\"qKFV3Zt50RF4nsDXIwu8oLplODp0-rU2\"'),
('plugins.views-work.settings.blockByQueryParamSecret', '\"uwqzBoR9GU6cxe271pswjKaQEHUymtsF\"'),
('plugins.views-work.settings.enableExperimentalFeatures', 'false'),
('plugins.views-work.settings.signKey', '\"8nTlHjXilbTCkmj2HKqIZ0zb1lhFXef8\"'),
('plugins.views-work.settings.urlResetSecret', '\"EON6ry41eCEuY0Jp_TVGD3QPyu6HSfxR\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.enableVersioning', 'false'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.handle', '\"viewsWork\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.name', '\"Views Work\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.previewTargets.0.__assoc__.0.0', '\"label\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.previewTargets.0.__assoc__.0.1', '\"Primary entry page\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.previewTargets.0.__assoc__.1.0', '\"urlFormat\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.previewTargets.0.__assoc__.1.1', '\"{url}\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.previewTargets.0.__assoc__.2.0', '\"refresh\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.previewTargets.0.__assoc__.2.1', '\"1\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.propagationMethod', '\"all\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.enabledByDefault', 'true'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.hasUrls', 'true'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.template', '\"views-work/_index\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.uriFormat', '\"views-work\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.enabledByDefault', 'true'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.hasUrls', 'true'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.template', '\"views-work/_index\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.uriFormat', '\"views-work\"'),
('sections.ca9feccf-8f1a-46db-bdd7-09f028ce3c1c.type', '\"single\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.enableVersioning', 'false'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.handle', '\"homepage\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.name', '\"Homepage\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.previewTargets.0.__assoc__.0.0', '\"label\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.previewTargets.0.__assoc__.0.1', '\"Primary entry page\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.previewTargets.0.__assoc__.1.0', '\"urlFormat\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.previewTargets.0.__assoc__.1.1', '\"{url}\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.previewTargets.0.__assoc__.2.0', '\"refresh\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.previewTargets.0.__assoc__.2.1', '\"1\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.propagationMethod', '\"all\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.enabledByDefault', 'true'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.hasUrls', 'true'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.template', '\"homepage/_entry\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.uriFormat', '\"__home__\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.enabledByDefault', 'true'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.hasUrls', 'true'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.template', '\"homepage/_entry\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.uriFormat', '\"__home__\"'),
('sections.cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95.type', '\"single\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.enableVersioning', 'false'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.handle', '\"contents\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.name', '\"Content\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.previewTargets.0.__assoc__.0.0', '\"label\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.previewTargets.0.__assoc__.0.1', '\"Primary entry page\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.previewTargets.0.__assoc__.1.0', '\"urlFormat\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.previewTargets.0.__assoc__.1.1', '\"{url}\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.previewTargets.0.__assoc__.2.0', '\"refresh\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.previewTargets.0.__assoc__.2.1', '\"1\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.propagationMethod', '\"all\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.enabledByDefault', 'true'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.hasUrls', 'true'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.template', '\"content/_entry\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.siteSettings.044d32e7-b363-413c-9a9b-f31af49ff4ab.uriFormat', '\"content/{slug}\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.enabledByDefault', 'true'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.hasUrls', 'true'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.template', '\"content/_entry\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.siteSettings.af522fa9-1c4a-459d-94c1-3564c267eb27.uriFormat', '\"content/{slug}\"'),
('sections.e49170ca-a1e3-421b-a7f5-7adb050551f4.type', '\"channel\"'),
('siteGroups.96ade9d4-07b3-4e20-a5f4-58746e829ca9.name', '\"Craft Sample Application\"'),
('sites.044d32e7-b363-413c-9a9b-f31af49ff4ab.baseUrl', '\"$PRIMARY_SITE_URL\"'),
('sites.044d32e7-b363-413c-9a9b-f31af49ff4ab.handle', '\"default\"'),
('sites.044d32e7-b363-413c-9a9b-f31af49ff4ab.hasUrls', 'true'),
('sites.044d32e7-b363-413c-9a9b-f31af49ff4ab.language', '\"en-US\"'),
('sites.044d32e7-b363-413c-9a9b-f31af49ff4ab.name', '\"Craft Sample Application\"'),
('sites.044d32e7-b363-413c-9a9b-f31af49ff4ab.primary', 'true'),
('sites.044d32e7-b363-413c-9a9b-f31af49ff4ab.siteGroup', '\"96ade9d4-07b3-4e20-a5f4-58746e829ca9\"'),
('sites.044d32e7-b363-413c-9a9b-f31af49ff4ab.sortOrder', '1'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.baseUrl', '\"@web/second\"'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.enabled', 'true'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.handle', '\"secondarySite\"'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.hasUrls', 'true'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.language', '\"en-US\"'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.name', '\"Secondary site\"'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.primary', 'false'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.siteGroup', '\"96ade9d4-07b3-4e20-a5f4-58746e829ca9\"'),
('sites.af522fa9-1c4a-459d-94c1-3564c267eb27.sortOrder', '2'),
('system.edition', '\"pro\"'),
('system.live', 'true'),
('system.name', '\"Craft Sample Application\"'),
('system.schemaVersion', '\"3.6.4\"'),
('system.timeZone', '\"America/Los_Angeles\"'),
('users.allowPublicRegistration', 'false'),
('users.defaultGroup', 'null'),
('users.photoSubpath', 'null'),
('users.photoVolumeUid', 'null'),
('users.requireEmailVerification', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `craft_queue`
--

CREATE TABLE `craft_queue` (
  `id` int(11) NOT NULL,
  `channel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) UNSIGNED NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_relations`
--

CREATE TABLE `craft_relations` (
  `id` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_relations`
--

INSERT INTO `craft_relations` (`id`, `fieldId`, `sourceId`, `sourceSiteId`, `targetId`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 3, 12, NULL, 8, 1, '2021-02-20 22:52:42', '2021-02-20 22:52:42', '3d6fd2f4-eede-47a7-997e-e9b6fc113b6a'),
(2, 3, 13, NULL, 2, 1, '2021-02-21 00:05:35', '2021-02-21 00:05:35', 'd906e8d8-dd88-4876-91f1-82b498590c6c');

-- --------------------------------------------------------

--
-- Table structure for table `craft_resourcepaths`
--

CREATE TABLE `craft_resourcepaths` (
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_resourcepaths`
--

INSERT INTO `craft_resourcepaths` (`hash`, `path`) VALUES
('103527ca', '@lib/vue'),
('150bc008', '@craft/web/assets/craftsupport/dist'),
('1ae6eb7e', '@app/web/assets/dashboard/dist'),
('1d0d77c5', '@craft/web/assets/login/dist'),
('1d81c530', '@app/web/assets/fields/dist'),
('1e4f5889', '@app/web/assets/matrix/dist'),
('23d3f74b', '@lib/axios'),
('2904b702', '@lib/jquery-ui'),
('2a1efd4c', '@craft/web/assets/feed/dist'),
('2df017a4', '@twentyfourhoursmedia/viewswork/assetbundles/viewsworkwidgetwidget/dist'),
('2ec002fe', '@lib/datepicker-i18n'),
('3a40297e', '@app/web/assets/editentry/dist'),
('4961c355', '@craft/redactor/assets/field/dist'),
('4b436b8f', '@lib/fabric'),
('515c76b5', '@app/web/assets/sites/dist'),
('52126d55', '@app/web/assets/editsection/dist'),
('535ddb87', '@craft/web/assets/dashboard/dist'),
('59b2702f', '@lib/element-resize-detector'),
('5e05bfb1', '@lib/garnishjs'),
('62117e9f', '@twentyfourhoursmedia/viewswork/assetbundles/viewswork/build-dev'),
('64b9b4a4', '@lib/jquery-touch-events'),
('67ad2ca7', '@lib/velocity'),
('682fa82e', '@bower/jquery/dist'),
('6db8a837', '@lib/d3'),
('71e9a486', '@craft/redactor/assets/redactor-plugins/dist/fullscreen'),
('72685bad', '@app/web/assets/edituser/dist'),
('7622dbda', '@bower/jquery/dist'),
('7756b68f', '@lib/iframe-resizer'),
('79a05f53', '@lib/velocity'),
('7b8a834f', '@lib/jquery.payment'),
('7bf58998', '@lib/fileupload'),
('8568a5d2', '@lib/timepicker'),
('85de3230', '@craft/web/assets/updater/dist'),
('876b3494', '@app/web/assets/updateswidget/dist'),
('8870faf2', '@lib/axios'),
('89b5b3a3', '@app/web/assets/admintable/dist'),
('8c1d746f', '@craft/web/assets/recententries/dist'),
('973e66ab', '@app/web/assets/updater/dist'),
('a1a2dfed', '@craft/web/assets/pluginstore/dist'),
('a49a8e53', '@lib/xregexp'),
('a5a5b446', '@craft/web/assets/installer/dist'),
('a8d9ef90', '@craft/web/assets/cp/dist'),
('aef6cad9', '@lib/selectize'),
('b091d839', '@lib/jquery-ui'),
('b0fbb92d', '@lib/selectize'),
('b2a73601', '@craft/web/assets/updateswidget/dist'),
('b7556dc5', '@lib/datepicker-i18n'),
('ba17e920', '@app/web/assets/matrixsettings/dist'),
('ba97fda7', '@lib/xregexp'),
('c0271f14', '@lib/element-resize-detector'),
('c0f09473', '@app/web/assets/cp/dist'),
('c790d08a', '@lib/garnishjs'),
('c838130c', '@lib/iframe-resizer-cw'),
('d2d604b4', '@lib/fabric'),
('d8033bcf', '@app/web/assets/userpermissions/dist'),
('de38fb6f', '@craft/redactor/assets/redactor-plugins/dist/video'),
('e21fec74', '@lib/jquery.payment'),
('e260e6a3', '@lib/fileupload'),
('e38543e', '@lib/vue'),
('e48594a9', '@lib/picturefill'),
('e9febbda', '@app/web/assets/pluginstore/dist'),
('ed955d51', '@app/web/assets/craftsupport/dist'),
('eeb8acc0', '@app/web/assets/generalsettings/dist'),
('eec3d9b4', '@lib/iframe-resizer'),
('f42dc70c', '@lib/d3'),
('f690e03d', '@app/web/assets/recententries/dist'),
('f6f8e38f', '@app/web/assets/login/dist'),
('f740bb0f', '@craft/redactor/assets/redactor/dist'),
('f75fe388', '@app/web/assets/fieldsettings/dist'),
('fa88e75d', '@lib/picturefill'),
('fd2cdb9f', '@lib/jquery-touch-events');

-- --------------------------------------------------------

--
-- Table structure for table `craft_revisions`
--

CREATE TABLE `craft_revisions` (
  `id` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_revisions`
--

INSERT INTO `craft_revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`) VALUES
(1, 2, 1, 1, NULL),
(2, 2, 1, 2, NULL),
(3, 8, 1, 1, NULL),
(4, 8, 1, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `craft_searchindex`
--

CREATE TABLE `craft_searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_searchindex`
--

INSERT INTO `craft_searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES
(1, 'email', 0, 1, ' info 24hoursmedia com '),
(1, 'firstname', 0, 1, ''),
(1, 'fullname', 0, 1, ''),
(1, 'lastname', 0, 1, ''),
(1, 'slug', 0, 1, ''),
(1, 'username', 0, 1, ' admin '),
(2, 'slug', 0, 1, ' homepage '),
(2, 'slug', 0, 2, ' homepage '),
(2, 'title', 0, 1, ' homepage '),
(2, 'title', 0, 2, ' homepage '),
(6, 'slug', 0, 1, ' article '),
(6, 'slug', 0, 2, ' article '),
(6, 'title', 0, 1, ' article '),
(6, 'title', 0, 2, ' article '),
(8, 'slug', 0, 1, ' views work '),
(8, 'slug', 0, 2, ' views work '),
(8, 'title', 0, 1, ' views work '),
(8, 'title', 0, 2, ' views work '),
(11, 'slug', 0, 1, ''),
(11, 'slug', 0, 2, ''),
(12, 'slug', 0, 1, ''),
(12, 'slug', 0, 2, ''),
(13, 'slug', 0, 1, ''),
(13, 'slug', 0, 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `craft_sections`
--

CREATE TABLE `craft_sections` (
  `id` int(11) NOT NULL,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('single','channel','structure') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'all',
  `previewTargets` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_sections`
--

INSERT INTO `craft_sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagationMethod`, `previewTargets`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES
(1, NULL, 'Homepage', 'homepage', 'single', 0, 'all', '[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]', '2021-02-20 17:58:28', '2021-02-20 18:00:17', NULL, 'cf4d64f9-20db-4bfa-b517-ebc4f0b0cf95'),
(2, NULL, 'Content', 'contents', 'channel', 0, 'all', '[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]', '2021-02-20 18:00:02', '2021-02-20 18:00:02', NULL, 'e49170ca-a1e3-421b-a7f5-7adb050551f4'),
(3, NULL, 'Views Work', 'viewsWork', 'single', 0, 'all', '[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]', '2021-02-20 22:46:54', '2021-02-20 22:52:55', NULL, 'ca9feccf-8f1a-46db-bdd7-09f028ce3c1c');

-- --------------------------------------------------------

--
-- Table structure for table `craft_sections_sites`
--

CREATE TABLE `craft_sections_sites` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8_unicode_ci,
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_sections_sites`
--

INSERT INTO `craft_sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 1, 1, 1, '__home__', 'homepage/_entry', 1, '2021-02-20 17:58:28', '2021-02-20 17:59:01', 'bb983b2b-0b16-4d9b-a8c8-a3cae2cb4328'),
(2, 1, 2, 1, '__home__', 'homepage/_entry', 1, '2021-02-20 17:58:28', '2021-02-20 17:59:01', '71f4eb37-bf9e-4db4-ba83-f6d09bb46982'),
(3, 2, 1, 1, 'content/{slug}', 'content/_entry', 1, '2021-02-20 18:00:02', '2021-02-20 18:00:02', '6a56b08a-1582-4af8-824f-b386951a03dd'),
(4, 2, 2, 1, 'content/{slug}', 'content/_entry', 1, '2021-02-20 18:00:02', '2021-02-20 18:00:02', 'fdd8b5c7-e4e4-4d20-8483-abf7c3280343'),
(5, 3, 1, 1, 'views-work', 'views-work/_index', 1, '2021-02-20 22:46:54', '2021-02-20 22:46:54', '839ca5bd-ce95-4369-ba1a-cfa3e29f9499'),
(6, 3, 2, 1, 'views-work', 'views-work/_index', 1, '2021-02-20 22:46:54', '2021-02-20 22:46:54', 'caed7eb1-6228-4247-ae34-d584c233aa79');

-- --------------------------------------------------------

--
-- Table structure for table `craft_sequences`
--

CREATE TABLE `craft_sequences` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `next` int(11) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_sessions`
--

CREATE TABLE `craft_sessions` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `token` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_sessions`
--

INSERT INTO `craft_sessions` (`id`, `userId`, `token`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 1, 'm4ox_s-6fu3w2ay8B59WjQzseEGbh2n3zCq1eHEdt4-veeWvCAfeSEzl8X98jGZuAlqO82CY24pBEwwNAYBs8tsLbmHDw0afMFa2', '2021-02-20 17:22:00', '2021-02-20 17:22:16', 'e75320eb-4384-4b30-bf22-71acd4e073d6'),
(2, 1, 'U3kJMD4UH7ZRflVMahmSXRIs0OJ9EarZ12jwFC9bbGOWKbDSbbE1_tw6Shn8_tKok40bJIHlLV0h04X0VNU1UcbEe4fqddutN2R9', '2021-02-20 17:25:04', '2021-02-20 18:30:54', '6b228b35-7372-486f-8fc7-366565135815'),
(3, 1, '7DSO5jxwRDXdbrQGqtKvUSjU0wmWhikU-0XSsme6HsmwsZRqTo5rdPptBo1HFhhJQanalbRkw8lopCjy2BGebP4qjkl3uLgeu-gb', '2021-02-20 22:25:21', '2021-02-21 00:40:01', '84279d6e-2ddc-4809-adcb-e1c0cdc0ecab');

-- --------------------------------------------------------

--
-- Table structure for table `craft_shunnedmessages`
--

CREATE TABLE `craft_shunnedmessages` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_sitegroups`
--

CREATE TABLE `craft_sitegroups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_sitegroups`
--

INSERT INTO `craft_sitegroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES
(1, 'Craft Sample Application', '2021-02-20 17:18:23', '2021-02-20 17:18:23', NULL, '96ade9d4-07b3-4e20-a5f4-58746e829ca9');

-- --------------------------------------------------------

--
-- Table structure for table `craft_sites`
--

CREATE TABLE `craft_sites` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_sites`
--

INSERT INTO `craft_sites` (`id`, `groupId`, `primary`, `enabled`, `name`, `handle`, `language`, `hasUrls`, `baseUrl`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES
(1, 1, 1, 1, 'Craft Sample Application', 'default', 'en-US', 1, '$PRIMARY_SITE_URL', 1, '2021-02-20 17:18:23', '2021-02-20 17:18:23', NULL, '044d32e7-b363-413c-9a9b-f31af49ff4ab'),
(2, 1, 0, 1, 'Secondary site', 'secondarySite', 'en-US', 1, '@web/second', 2, '2021-02-20 17:30:37', '2021-02-20 17:30:37', NULL, 'af522fa9-1c4a-459d-94c1-3564c267eb27');

-- --------------------------------------------------------

--
-- Table structure for table `craft_structureelements`
--

CREATE TABLE `craft_structureelements` (
  `id` int(11) NOT NULL,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) UNSIGNED DEFAULT NULL,
  `lft` int(11) UNSIGNED NOT NULL,
  `rgt` int(11) UNSIGNED NOT NULL,
  `level` smallint(6) UNSIGNED NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_structures`
--

CREATE TABLE `craft_structures` (
  `id` int(11) NOT NULL,
  `maxLevels` smallint(6) UNSIGNED DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_systemmessages`
--

CREATE TABLE `craft_systemmessages` (
  `id` int(11) NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_taggroups`
--

CREATE TABLE `craft_taggroups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_tags`
--

CREATE TABLE `craft_tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_templatecacheelements`
--

CREATE TABLE `craft_templatecacheelements` (
  `id` int(11) NOT NULL,
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_templatecachequeries`
--

CREATE TABLE `craft_templatecachequeries` (
  `id` int(11) NOT NULL,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `query` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_templatecaches`
--

CREATE TABLE `craft_templatecaches` (
  `id` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_tokens`
--

CREATE TABLE `craft_tokens` (
  `id` int(11) NOT NULL,
  `token` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `route` text COLLATE utf8_unicode_ci,
  `usageLimit` tinyint(3) UNSIGNED DEFAULT NULL,
  `usageCount` tinyint(3) UNSIGNED DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_tokens`
--

INSERT INTO `craft_tokens` (`id`, `token`, `route`, `usageLimit`, `usageCount`, `expiryDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, '9SbGUL7FwM9AKY-WCeNZrSRUWntWHXZk', '[\"preview/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"sourceId\":2,\"siteId\":1,\"draftId\":1,\"revisionId\":null}]', NULL, NULL, '2021-02-21 22:27:15', '2021-02-20 22:27:15', '2021-02-20 22:27:15', 'dde06950-9e32-4188-886f-b1fb9f8a85e2');

-- --------------------------------------------------------

--
-- Table structure for table `craft_usergroups`
--

CREATE TABLE `craft_usergroups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_usergroups_users`
--

CREATE TABLE `craft_usergroups_users` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_userpermissions`
--

CREATE TABLE `craft_userpermissions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_userpermissions_usergroups`
--

CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int(11) NOT NULL,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_userpermissions_users`
--

CREATE TABLE `craft_userpermissions_users` (
  `id` int(11) NOT NULL,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_userpreferences`
--

CREATE TABLE `craft_userpreferences` (
  `userId` int(11) NOT NULL,
  `preferences` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_userpreferences`
--

INSERT INTO `craft_userpreferences` (`userId`, `preferences`) VALUES
(1, '{\"language\":\"en-US\",\"locale\":null,\"weekStartDay\":\"1\",\"useShapes\":false,\"underlineLinks\":false,\"showFieldHandles\":false,\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}');

-- --------------------------------------------------------

--
-- Table structure for table `craft_users`
--

CREATE TABLE `craft_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) UNSIGNED DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_users`
--

INSERT INTO `craft_users` (`id`, `username`, `photoId`, `firstName`, `lastName`, `email`, `password`, `admin`, `locked`, `suspended`, `pending`, `lastLoginDate`, `lastLoginAttemptIp`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `hasDashboard`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(1, 'admin', NULL, '', '', 'info@24hoursmedia.com', '$2y$13$e9s5ZJEgHLGx7qbru2PL0uzPaTfOEZg8w1W2vbYz4CWPenep7PkBi', 1, 0, 0, 0, '2021-02-20 22:25:21', NULL, NULL, NULL, '2021-02-20 22:25:10', NULL, 1, NULL, NULL, NULL, 0, '2021-02-20 17:18:24', '2021-02-20 17:18:24', '2021-02-20 22:25:21', '9486f912-a989-4a7c-a47f-64e281309ab0');

-- --------------------------------------------------------

--
-- Table structure for table `craft_viewswork_viewrecording`
--

CREATE TABLE `craft_viewswork_viewrecording` (
  `id` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `siteId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  `viewsTotal` int(11) NOT NULL DEFAULT '0',
  `viewsToday` int(11) NOT NULL DEFAULT '0',
  `viewsThisWeek` int(11) NOT NULL DEFAULT '0',
  `viewsThisMonth` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_viewswork_viewrecording`
--

INSERT INTO `craft_viewswork_viewrecording` (`id`, `dateCreated`, `dateUpdated`, `uid`, `siteId`, `elementId`, `viewsTotal`, `viewsToday`, `viewsThisWeek`, `viewsThisMonth`) VALUES
(1, '2021-02-20 23:09:46', '2021-02-21 16:09:21', 'e42f58ba-8a82-412d-8394-e014c31c65a5', 1, 8, 284, 284, 284, 284),
(2, '2021-02-21 00:17:04', '2021-02-21 16:09:20', '24b7ad11-92f6-41bd-b876-ac8d0263fe6e', 1, 2, 18, 18, 18, 18);

-- --------------------------------------------------------

--
-- Table structure for table `craft_volumefolders`
--

CREATE TABLE `craft_volumefolders` (
  `id` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_volumes`
--

CREATE TABLE `craft_volumes` (
  `id` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titleTranslationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8_unicode_ci,
  `settings` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `craft_widgets`
--

CREATE TABLE `craft_widgets` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) UNSIGNED DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `craft_widgets`
--

INSERT INTO `craft_widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES
(5, 1, 'twentyfourhoursmedia\\viewswork\\widgets\\ViewsWorkWidget', 5, NULL, '{\"count\":\"5\",\"showTotal\":\"\",\"showMonthly\":\"\",\"showWeekly\":\"1\",\"showDaily\":\"\",\"section\":\"*\",\"widgetTitle\":\"Popular this week\",\"allSites\":true,\"siteId\":1}', 1, '2021-02-20 17:29:56', '2021-02-20 17:29:56', '848b6804-7fb0-48d5-b171-ada4b014aa93'),
(6, 1, 'twentyfourhoursmedia\\viewswork\\widgets\\ViewedNowWidget', 6, NULL, '{\"seconds\":\"30\",\"count\":\"5\",\"widgetTitle\":\"\",\"enableAutoRefresh\":\"1\",\"allSites\":\"1\",\"siteId\":\"1\"}', 1, '2021-02-21 00:08:11', '2021-02-21 00:08:11', 'c8c6ad86-8d6a-456c-87fa-9374597aa246');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `craft_assetindexdata`
--
ALTER TABLE `craft_assetindexdata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_ttwbaekthyjencguuxduatnbrmomextdiokq` (`sessionId`,`volumeId`),
  ADD KEY `craft_idx_sdodzbmmbygujktweyilmwsnuulvpxauidpq` (`volumeId`);

--
-- Indexes for table `craft_assets`
--
ALTER TABLE `craft_assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_oanxknztihacbxfhefiriezowberseyaoxkg` (`filename`,`folderId`),
  ADD KEY `craft_idx_rwbvjxibyilsrduxzplcxylwhxyydncumtxc` (`folderId`),
  ADD KEY `craft_idx_uqgjnwamuzagncgscwuuzogtgsjngvggcfkk` (`volumeId`),
  ADD KEY `craft_fk_hookftfsrdwpkuwnpsfbcmenjsgbvugrxsdb` (`uploaderId`);

--
-- Indexes for table `craft_assettransformindex`
--
ALTER TABLE `craft_assettransformindex`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_acyusemgvziypbbjlsriqhuruoemcxnymqpk` (`volumeId`,`assetId`,`location`);

--
-- Indexes for table `craft_assettransforms`
--
ALTER TABLE `craft_assettransforms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_ppxyxaglfxjrnirlmjojrdwwnahuidpbvlzv` (`name`),
  ADD KEY `craft_idx_ighmqveigzudbgkwxlrtbhynmlxzexnjggfo` (`handle`);

--
-- Indexes for table `craft_categories`
--
ALTER TABLE `craft_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_svghetgnjcghtjbmqfdvhtupeoqpuoqznruc` (`groupId`),
  ADD KEY `craft_fk_limprbozhvmdfgfrcgnqdkpmzxdrstgvccpc` (`parentId`);

--
-- Indexes for table `craft_categorygroups`
--
ALTER TABLE `craft_categorygroups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_uoujnbgixnrkfdmbgufxyyruhokzjbqtmqyh` (`name`),
  ADD KEY `craft_idx_szllnahvrldhtgliorjlobzstczbpxuyhpnc` (`handle`),
  ADD KEY `craft_idx_jrtpkriuhosyxyefzktxdehuwrryswtguqoj` (`structureId`),
  ADD KEY `craft_idx_pojlrdiqbdvoadxpjzstdtyryhqcyytyvbbv` (`fieldLayoutId`),
  ADD KEY `craft_idx_xntaharzclviawmqocmnfhpwstuhtgjpduho` (`dateDeleted`);

--
-- Indexes for table `craft_categorygroups_sites`
--
ALTER TABLE `craft_categorygroups_sites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_fbbibbyyxtkylohlzpldfycievbhglrbnzjy` (`groupId`,`siteId`),
  ADD KEY `craft_idx_gvchkqhftasgiuqsaglnygfsnlsimozpmfna` (`siteId`);

--
-- Indexes for table `craft_changedattributes`
--
ALTER TABLE `craft_changedattributes`
  ADD PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  ADD KEY `craft_idx_ewxnofcnpniekkrytzpurtflhavrfxmjuklb` (`elementId`,`siteId`,`dateUpdated`),
  ADD KEY `craft_fk_hubzwrucuzdnoofevtsjgncgumygqkynryau` (`siteId`),
  ADD KEY `craft_fk_rpxtiqlddmkdfutznpstknbsrzssemlsopki` (`userId`);

--
-- Indexes for table `craft_changedfields`
--
ALTER TABLE `craft_changedfields`
  ADD PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  ADD KEY `craft_idx_fomedoydniksnpcquktttoruxkzusxfctudw` (`elementId`,`siteId`,`dateUpdated`),
  ADD KEY `craft_fk_tgaiooynnigfrntohvrwingibuvfyyarvvwc` (`siteId`),
  ADD KEY `craft_fk_jaktbgnfnguglntwrjntfscchxvhapfkunij` (`fieldId`),
  ADD KEY `craft_fk_bdybowkigvcnwamllvdfcsmskftfnbsfkbyy` (`userId`);

--
-- Indexes for table `craft_content`
--
ALTER TABLE `craft_content`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_wbtsruerulmttzebpftxcrliziqdpluwlyhx` (`elementId`,`siteId`),
  ADD KEY `craft_idx_pnupjzegcwvjgduuglwtkurprlyluentnyil` (`siteId`),
  ADD KEY `craft_idx_mvwpqxhhuqhejhqzdkchnyujrthizinqxbyg` (`title`);

--
-- Indexes for table `craft_craftidtokens`
--
ALTER TABLE `craft_craftidtokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_fk_voouzkgrqrtrugqiewszykwxwveyxztcgnhp` (`userId`);

--
-- Indexes for table `craft_deprecationerrors`
--
ALTER TABLE `craft_deprecationerrors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_gwausednmqqkuexjlrlvrpajrlqxrrzapgfl` (`key`,`fingerprint`);

--
-- Indexes for table `craft_drafts`
--
ALTER TABLE `craft_drafts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_qedrukksbgqbpwmanndcnfguhrebjsqsbfbl` (`saved`),
  ADD KEY `craft_fk_arqrlpqnqotwwjomfuiuvusqmgfhncfhhkvz` (`creatorId`),
  ADD KEY `craft_fk_zkqkovlcjhwcqgxjajvovdudharwvemkeppa` (`sourceId`);

--
-- Indexes for table `craft_elementindexsettings`
--
ALTER TABLE `craft_elementindexsettings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_ynvrrqxqwogqmstxzdqoijvlclsewthnskvh` (`type`);

--
-- Indexes for table `craft_elements`
--
ALTER TABLE `craft_elements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_ahapumjfvmozdtcxcyqivvizyfuzyuapwiog` (`dateDeleted`),
  ADD KEY `craft_idx_baihsnpfgyvrojhjlkfsafbefceytqnlttsn` (`fieldLayoutId`),
  ADD KEY `craft_idx_qtbclaycsipinnomzxpuvghymaipjpvbpsqk` (`type`),
  ADD KEY `craft_idx_mlvdfmolkzmoyxxnuqwhzaiuvtocakvqydht` (`enabled`),
  ADD KEY `craft_idx_tukafxvufqtmxpksnhfwmbleevtnzakbzjoc` (`archived`,`dateCreated`),
  ADD KEY `craft_idx_zqvprmqerhiyewqnwyxdunmhboprmthjusdk` (`archived`,`dateDeleted`,`draftId`,`revisionId`),
  ADD KEY `craft_fk_xouleosxedcxykbudtyufjwicoyswnxzqvdx` (`draftId`),
  ADD KEY `craft_fk_zunbeywcxmkubtubcjegawfneystxflzzeuq` (`revisionId`);

--
-- Indexes for table `craft_elements_sites`
--
ALTER TABLE `craft_elements_sites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_bpumzupwbikezqtmdibihzstisaukafhymvq` (`elementId`,`siteId`),
  ADD KEY `craft_idx_fewjqyscdzvqizgsxzayocfirmiwfgtenbep` (`siteId`),
  ADD KEY `craft_idx_zfyzbolsaxrfolkmmtylmmroegnbyzkukpwy` (`slug`,`siteId`),
  ADD KEY `craft_idx_ramnpvjpdombefqhmipxjifszfcoqtzbeyby` (`enabled`),
  ADD KEY `craft_idx_gtsoedkpavaemudllkrvzrwjgajjsgrtonit` (`uri`,`siteId`);

--
-- Indexes for table `craft_entries`
--
ALTER TABLE `craft_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_kqhzctdgnofuskgfsmlzdqqnrrpvmxvssoyi` (`postDate`),
  ADD KEY `craft_idx_cyofmuzuypcoretiercjuoidnrfgjzcbklvo` (`expiryDate`),
  ADD KEY `craft_idx_wkyomayhuypexpywzfnvzjwenwwtrijfehdg` (`authorId`),
  ADD KEY `craft_idx_imyjqjfvlchkrlsdmlegsgvfozuhegdshqvj` (`sectionId`),
  ADD KEY `craft_idx_dsinuyoejxiyjeodzzrkifmzzskrvdwbkydp` (`typeId`),
  ADD KEY `craft_fk_njkxmnxlneukykqsofofnohbktoehnttsctv` (`parentId`);

--
-- Indexes for table `craft_entrytypes`
--
ALTER TABLE `craft_entrytypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_owdubrwrxkalkhiiqpwogfaekwlenicadaqo` (`name`,`sectionId`),
  ADD KEY `craft_idx_ipiuwhulafnwbslagxbrtnipyorhoucvecwx` (`handle`,`sectionId`),
  ADD KEY `craft_idx_lydcrmbrqszchawgrupkbpqbflrfliodecum` (`sectionId`),
  ADD KEY `craft_idx_kqmbvlfmdopysivjwuenvctxcebzgxzlbhgh` (`fieldLayoutId`),
  ADD KEY `craft_idx_uqsnpyyompynzncwoxovbsqfivqogkucobju` (`dateDeleted`);

--
-- Indexes for table `craft_fieldgroups`
--
ALTER TABLE `craft_fieldgroups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_rsydqunbjdabgsskrqcumaejcwwrnrjckfxe` (`name`),
  ADD KEY `craft_idx_isroesxdbgdtlqbbuiicnjvlywhrgrlfemhe` (`dateDeleted`,`name`);

--
-- Indexes for table `craft_fieldlayoutfields`
--
ALTER TABLE `craft_fieldlayoutfields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_vhfucjlcmdgohsgbrpvhtnntbobnuurclrzm` (`layoutId`,`fieldId`),
  ADD KEY `craft_idx_karbrctjtlndzctygpgfekrtrzjzwrpojugs` (`sortOrder`),
  ADD KEY `craft_idx_htsyxzwrkjptaxftzfdmmpgnvswdtjxukthe` (`tabId`),
  ADD KEY `craft_idx_glmozalwtdsgkycinwmksvzjtmcngelansjq` (`fieldId`);

--
-- Indexes for table `craft_fieldlayouts`
--
ALTER TABLE `craft_fieldlayouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_urjexutirbqvrfvqotgxcbvmbswsojcsmvdi` (`dateDeleted`),
  ADD KEY `craft_idx_bayytyxrkrkeqerfoirjwalczpxoqvmodjlo` (`type`);

--
-- Indexes for table `craft_fieldlayouttabs`
--
ALTER TABLE `craft_fieldlayouttabs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_lgzmokdisasfwsgwtqjsdhkmlncqztlalwuq` (`sortOrder`),
  ADD KEY `craft_idx_tbuqivzwtqyqypksthudgsoxytfuiuziiaae` (`layoutId`);

--
-- Indexes for table `craft_fields`
--
ALTER TABLE `craft_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_cgjapjfdtjfzmtfqifwoqqrlpntjijratzry` (`handle`,`context`),
  ADD KEY `craft_idx_avvgybrnuxhwpedrlbyqdvwzbjlarvoqrrmw` (`groupId`),
  ADD KEY `craft_idx_fyzognqtasrmsrlcscnafgverazirkwbaynm` (`context`);

--
-- Indexes for table `craft_globalsets`
--
ALTER TABLE `craft_globalsets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_vavubcrmjwuldeqmzydyshctznqtaeaowdkh` (`name`),
  ADD KEY `craft_idx_yiudivtemoldwuqhwkwqpsjijiccvcroxokj` (`handle`),
  ADD KEY `craft_idx_jsqoewidxotsczttwocfemevlpjqubrnxeit` (`fieldLayoutId`);

--
-- Indexes for table `craft_gqlschemas`
--
ALTER TABLE `craft_gqlschemas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `craft_gqltokens`
--
ALTER TABLE `craft_gqltokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_pvdghcvqdajmtiqubtwzezcauqxhykghyewz` (`accessToken`),
  ADD UNIQUE KEY `craft_idx_hmouzutpzaxlnmvrbwvubxgttmakknrpnzxg` (`name`),
  ADD KEY `craft_fk_uwwyoasdojizxxlgrxzlwkwruljifyiggfwu` (`schemaId`);

--
-- Indexes for table `craft_info`
--
ALTER TABLE `craft_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `craft_matrixblocks`
--
ALTER TABLE `craft_matrixblocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_euzjzphgpidzalbfvcorwgsxxzohijovvnms` (`ownerId`),
  ADD KEY `craft_idx_atlgskiftbrnfplsmermzgapppasffbhigru` (`fieldId`),
  ADD KEY `craft_idx_fjabowrvprjtfitiigbzqzhscxycsxlcalak` (`typeId`),
  ADD KEY `craft_idx_shiqbghemwgnsmgopxmfxrxwltdkbgjegvwr` (`sortOrder`);

--
-- Indexes for table `craft_matrixblocktypes`
--
ALTER TABLE `craft_matrixblocktypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_ajttrevqqjocgoxonokpxuohmchtsxdtdcvf` (`name`,`fieldId`),
  ADD KEY `craft_idx_udylgmpchpzwfeapkjwotflnzwylpyigdlbe` (`handle`,`fieldId`),
  ADD KEY `craft_idx_tocfesipsmwawsbpxeedivlbiqlahqwzhwsc` (`fieldId`),
  ADD KEY `craft_idx_xjyarghjlqcqydlzpzkwowgdmbhidgfhcbbf` (`fieldLayoutId`);

--
-- Indexes for table `craft_matrixcontent_menu`
--
ALTER TABLE `craft_matrixcontent_menu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_uhycocigkozmvoklmcxobqyklysyglagmnga` (`elementId`,`siteId`),
  ADD KEY `craft_fk_bswtuzgmzabcwstftrcehkamkldhfpvpxepk` (`siteId`);

--
-- Indexes for table `craft_migrations`
--
ALTER TABLE `craft_migrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_ybvhsykizizqsnfyoqcorejhbpnwcjeaaann` (`track`,`name`);

--
-- Indexes for table `craft_plugins`
--
ALTER TABLE `craft_plugins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_fhdweeuplltdkjphlmcopyttgpafxrmohlno` (`handle`);

--
-- Indexes for table `craft_projectconfig`
--
ALTER TABLE `craft_projectconfig`
  ADD PRIMARY KEY (`path`);

--
-- Indexes for table `craft_queue`
--
ALTER TABLE `craft_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_haotswxvoicxhrhexioxypqofpmvsfeewtpq` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  ADD KEY `craft_idx_frrkgzfsbltzrtygxgjiujsrzdmbbankdrye` (`channel`,`fail`,`timeUpdated`,`delay`);

--
-- Indexes for table `craft_relations`
--
ALTER TABLE `craft_relations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_zlpwgxodopbdwmzjngabtzaucjqehoirwcuy` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  ADD KEY `craft_idx_pcbsbxiykyqzwtvitxttyuwwczwozlpughoh` (`sourceId`),
  ADD KEY `craft_idx_rkjndqiiljgqpgroinafomaukaovgulxszjk` (`targetId`),
  ADD KEY `craft_idx_digtpmafzuarfryzgsqeoyuiqydehnlkqxsf` (`sourceSiteId`);

--
-- Indexes for table `craft_resourcepaths`
--
ALTER TABLE `craft_resourcepaths`
  ADD PRIMARY KEY (`hash`);

--
-- Indexes for table `craft_revisions`
--
ALTER TABLE `craft_revisions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_jfgvyknxvxfxwkfscdfgvtglrfhiqljeizhl` (`sourceId`,`num`),
  ADD KEY `craft_fk_wnxoaimgnzhcjvnirvinoucesqacwnhflrwt` (`creatorId`);

--
-- Indexes for table `craft_searchindex`
--
ALTER TABLE `craft_searchindex`
  ADD PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`);
ALTER TABLE `craft_searchindex` ADD FULLTEXT KEY `craft_idx_apmyeejngqtzeusrvehbuhiwldxsdrqkbqde` (`keywords`);

--
-- Indexes for table `craft_sections`
--
ALTER TABLE `craft_sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_cksglmxbpndykzpszphywzkhusdlxdvikfec` (`handle`),
  ADD KEY `craft_idx_kcoykkrnbvnmnrgsjgugdyiolbinpdzfyxjs` (`name`),
  ADD KEY `craft_idx_medsosnnryzjovlnhvkyvkjtdghydfdxpvqx` (`structureId`),
  ADD KEY `craft_idx_zdvoigkvfbumosijcjuhfsxmqbabqpohilgp` (`dateDeleted`);

--
-- Indexes for table `craft_sections_sites`
--
ALTER TABLE `craft_sections_sites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_myrirjsfcjpptrreprshmlmgxmxnjoyaitim` (`sectionId`,`siteId`),
  ADD KEY `craft_idx_pteqtqbkuchpkfdppcscvyodjpfbpwqbzrrc` (`siteId`);

--
-- Indexes for table `craft_sequences`
--
ALTER TABLE `craft_sequences`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `craft_sessions`
--
ALTER TABLE `craft_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_nrnrqmxczazodtzcxdmpyfrpnioqmihmvgmz` (`uid`),
  ADD KEY `craft_idx_plddmmgzkntekucsoxdrggmtixmqtpqueyys` (`token`),
  ADD KEY `craft_idx_cwnvnckgnubprkmjpzpxrgyzkttngeqfzwja` (`dateUpdated`),
  ADD KEY `craft_idx_tshiqfhrvwvmfrpdhxdfcsvwqrewjpkndzog` (`userId`);

--
-- Indexes for table `craft_shunnedmessages`
--
ALTER TABLE `craft_shunnedmessages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_lntykoqbmnbikremyldfpyyiygymqzktelgq` (`userId`,`message`);

--
-- Indexes for table `craft_sitegroups`
--
ALTER TABLE `craft_sitegroups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_srqdgsnqqrlphkgezwbpfrtpzkfnqpxyqpcn` (`name`);

--
-- Indexes for table `craft_sites`
--
ALTER TABLE `craft_sites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_hobustioygtswjlvcjrqrrhckkmmbfqdytkm` (`dateDeleted`),
  ADD KEY `craft_idx_eyzkvqbibgfjkecwhpdcfiocfhhjzwhgypro` (`handle`),
  ADD KEY `craft_idx_xqjjzpbnuiczuxekeutjxipapnnkljozukgc` (`sortOrder`),
  ADD KEY `craft_fk_izscquwpfkgdukutlmsfyfcicisrfbfnufmk` (`groupId`);

--
-- Indexes for table `craft_structureelements`
--
ALTER TABLE `craft_structureelements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_imefxsskgpbgujeosdhskzdlkvfmbyzwqomk` (`structureId`,`elementId`),
  ADD KEY `craft_idx_dobuhxqxbodttqlrdtopbigstjkmyqxdmokf` (`root`),
  ADD KEY `craft_idx_lqebgydzbcifmvhiplunuuqusrmkroxhtbhl` (`lft`),
  ADD KEY `craft_idx_xdwrthetfedncfkuttfukixlywdsctuxgjwf` (`rgt`),
  ADD KEY `craft_idx_yrxpiurkhjnnmxhshaatjmrxwrgwyiwhpiaj` (`level`),
  ADD KEY `craft_idx_lpsqmrncrxkeefuiaeirtbljhmeunqnqjwzl` (`elementId`);

--
-- Indexes for table `craft_structures`
--
ALTER TABLE `craft_structures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_tnpjwkvgqmmuzsxmxxnsivlljbapoosutnpm` (`dateDeleted`);

--
-- Indexes for table `craft_systemmessages`
--
ALTER TABLE `craft_systemmessages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_qodwhjafjivhthsqslamiwlbaoegrlbykxyj` (`key`,`language`),
  ADD KEY `craft_idx_qqftqoygxeffjqhlcxiojsscshtyobnsrvuh` (`language`);

--
-- Indexes for table `craft_taggroups`
--
ALTER TABLE `craft_taggroups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_vknjknohqvjixylrdfrhuktiuwwggetfjyuw` (`name`),
  ADD KEY `craft_idx_gzayoiqjtrrenywarihkecvekidbszwmigrv` (`handle`),
  ADD KEY `craft_idx_jkygwuhadhtyyfdgxtyifeshwlyclsautdan` (`dateDeleted`),
  ADD KEY `craft_fk_nepdolnyedpeylsgcjbzekhxgzpbgvmdgqzw` (`fieldLayoutId`);

--
-- Indexes for table `craft_tags`
--
ALTER TABLE `craft_tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_hlmfzqptgwnozdupgjqtqiezjtaspqzaqanv` (`groupId`);

--
-- Indexes for table `craft_templatecacheelements`
--
ALTER TABLE `craft_templatecacheelements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_mufbqrusidcjcvqtofdcfyvyzyhjldskzjne` (`cacheId`),
  ADD KEY `craft_idx_xxcdjrqaxbuxlwkzjsrscotepkusrbrkipzh` (`elementId`);

--
-- Indexes for table `craft_templatecachequeries`
--
ALTER TABLE `craft_templatecachequeries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_pbyphbkjapiaunlwceusstwfnfqnqcyendxt` (`cacheId`),
  ADD KEY `craft_idx_pemmvlltaipnrycpnpaukjegmsjhzbbupqnq` (`type`);

--
-- Indexes for table `craft_templatecaches`
--
ALTER TABLE `craft_templatecaches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_ugddxocypsvesdbzyantgwktplmxrfwnaexi` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  ADD KEY `craft_idx_sfyjryijdngaycfzbvjdrmrwlhistosizflj` (`cacheKey`,`siteId`,`expiryDate`),
  ADD KEY `craft_idx_pwavcebiedvvtnwtltazkwkqrbmsgsnzwbfz` (`siteId`);

--
-- Indexes for table `craft_tokens`
--
ALTER TABLE `craft_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_fchtgozejivfvdlhesfhwzkvyydtetfuendg` (`token`),
  ADD KEY `craft_idx_sfhjryfhlnehhrgkblitsyaqvwhhqsmiwktj` (`expiryDate`);

--
-- Indexes for table `craft_usergroups`
--
ALTER TABLE `craft_usergroups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_btooyzeenyiixymngkldqawtfuvyvtnypebr` (`handle`),
  ADD KEY `craft_idx_drlpbjyumezutdufiusehvwrmyedwpwoamux` (`name`);

--
-- Indexes for table `craft_usergroups_users`
--
ALTER TABLE `craft_usergroups_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_gwfkhomwrrijgkuvvfmmzxckalyrkuyatroh` (`groupId`,`userId`),
  ADD KEY `craft_idx_adzlwvhhaatejzlkueenetcseutqnramffyv` (`userId`);

--
-- Indexes for table `craft_userpermissions`
--
ALTER TABLE `craft_userpermissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_eolgxesqdwjivcmvoswmxcrzksuvivkarurw` (`name`);

--
-- Indexes for table `craft_userpermissions_usergroups`
--
ALTER TABLE `craft_userpermissions_usergroups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_iaytoimvmcukizohzwcbixqdmxxhrlygsuog` (`permissionId`,`groupId`),
  ADD KEY `craft_idx_kajwqmmazrxslldahdjhuckcscgklyagppue` (`groupId`);

--
-- Indexes for table `craft_userpermissions_users`
--
ALTER TABLE `craft_userpermissions_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_pgxvslzevvrwhytxqmaugvdcidhrrwjbycuj` (`permissionId`,`userId`),
  ADD KEY `craft_idx_jihjsggocgvzqlpofzyzhqrzjpnszwisegwn` (`userId`);

--
-- Indexes for table `craft_userpreferences`
--
ALTER TABLE `craft_userpreferences`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `craft_users`
--
ALTER TABLE `craft_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_glzojdfovedsqggvcgznltslfamxzgvnsdzw` (`uid`),
  ADD KEY `craft_idx_xhonmmitxfpexfennihlcetzhgfnsdyxlzew` (`verificationCode`),
  ADD KEY `craft_idx_tevvlzmaweumzmhfleohmxxqekwkdxtcdbnu` (`email`),
  ADD KEY `craft_idx_dqenpuyphhrzxwtseryiqsrhwlfxuohlqtpk` (`username`),
  ADD KEY `craft_fk_ekklvsghrxntqnmgtxjvmmeuzdgypjaroryo` (`photoId`);

--
-- Indexes for table `craft_viewswork_viewrecording`
--
ALTER TABLE `craft_viewswork_viewrecording`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_zxwgnasrmqrugeuxyomifyoupzdkwxfzgpul` (`viewsTotal`),
  ADD KEY `craft_idx_vkhtoebwtpbgqcdbivrytqbzuuvyobjxvezi` (`viewsToday`),
  ADD KEY `craft_idx_evlydvlhmxnmxlreedbobeileioytqmchdxz` (`viewsThisWeek`),
  ADD KEY `craft_idx_ngdzoierktabukrlpqdadgvlegvrbfggakpp` (`viewsThisMonth`),
  ADD KEY `craft_idx_ehibywsjltsltyigzoueijktptpprzlehaow` (`dateUpdated`),
  ADD KEY `craft_fk_psassjzoohssztywenrvncpwwahdhgdnqjgw` (`siteId`),
  ADD KEY `craft_fk_xicxpmlblefkakbiruycfdgrpeabwgkhmjso` (`elementId`);

--
-- Indexes for table `craft_volumefolders`
--
ALTER TABLE `craft_volumefolders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `craft_idx_pbltjdiswyrjvvwkmmyimstnjztlfubdcggo` (`name`,`parentId`,`volumeId`),
  ADD KEY `craft_idx_wsdjjfrzsvsoxmcjcsxmvwcvogfpixghzngq` (`parentId`),
  ADD KEY `craft_idx_cbqyeweqcpsirayrgqhtppgobyexgrvbngoz` (`volumeId`);

--
-- Indexes for table `craft_volumes`
--
ALTER TABLE `craft_volumes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_hskuzgcyczvikpqaydwbvuemzxiahkcwdtcq` (`name`),
  ADD KEY `craft_idx_ugmkruaostrygxeoloxpjxwfbgsmfpeiuiqt` (`handle`),
  ADD KEY `craft_idx_shrgwssixndeeucvtusytcxaarmojxgtcttb` (`fieldLayoutId`),
  ADD KEY `craft_idx_nmnbphjmjdfflfledqiomkmqupyleectghnk` (`dateDeleted`);

--
-- Indexes for table `craft_widgets`
--
ALTER TABLE `craft_widgets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `craft_idx_ycgzurrteqfiabvbykkkunoebjuqwdklhlfk` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `craft_assetindexdata`
--
ALTER TABLE `craft_assetindexdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_assettransformindex`
--
ALTER TABLE `craft_assettransformindex`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_assettransforms`
--
ALTER TABLE `craft_assettransforms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_categorygroups`
--
ALTER TABLE `craft_categorygroups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_categorygroups_sites`
--
ALTER TABLE `craft_categorygroups_sites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_content`
--
ALTER TABLE `craft_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `craft_craftidtokens`
--
ALTER TABLE `craft_craftidtokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_deprecationerrors`
--
ALTER TABLE `craft_deprecationerrors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=400;

--
-- AUTO_INCREMENT for table `craft_drafts`
--
ALTER TABLE `craft_drafts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_elementindexsettings`
--
ALTER TABLE `craft_elementindexsettings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_elements`
--
ALTER TABLE `craft_elements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `craft_elements_sites`
--
ALTER TABLE `craft_elements_sites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `craft_entrytypes`
--
ALTER TABLE `craft_entrytypes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `craft_fieldgroups`
--
ALTER TABLE `craft_fieldgroups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `craft_fieldlayoutfields`
--
ALTER TABLE `craft_fieldlayoutfields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `craft_fieldlayouts`
--
ALTER TABLE `craft_fieldlayouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `craft_fieldlayouttabs`
--
ALTER TABLE `craft_fieldlayouttabs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `craft_fields`
--
ALTER TABLE `craft_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `craft_globalsets`
--
ALTER TABLE `craft_globalsets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `craft_gqlschemas`
--
ALTER TABLE `craft_gqlschemas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_gqltokens`
--
ALTER TABLE `craft_gqltokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_info`
--
ALTER TABLE `craft_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `craft_matrixblocktypes`
--
ALTER TABLE `craft_matrixblocktypes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `craft_matrixcontent_menu`
--
ALTER TABLE `craft_matrixcontent_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `craft_migrations`
--
ALTER TABLE `craft_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;

--
-- AUTO_INCREMENT for table `craft_plugins`
--
ALTER TABLE `craft_plugins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `craft_queue`
--
ALTER TABLE `craft_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_relations`
--
ALTER TABLE `craft_relations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `craft_revisions`
--
ALTER TABLE `craft_revisions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `craft_sections`
--
ALTER TABLE `craft_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `craft_sections_sites`
--
ALTER TABLE `craft_sections_sites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `craft_sessions`
--
ALTER TABLE `craft_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `craft_shunnedmessages`
--
ALTER TABLE `craft_shunnedmessages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_sitegroups`
--
ALTER TABLE `craft_sitegroups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `craft_sites`
--
ALTER TABLE `craft_sites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `craft_structureelements`
--
ALTER TABLE `craft_structureelements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_structures`
--
ALTER TABLE `craft_structures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_systemmessages`
--
ALTER TABLE `craft_systemmessages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_taggroups`
--
ALTER TABLE `craft_taggroups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_templatecacheelements`
--
ALTER TABLE `craft_templatecacheelements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_templatecachequeries`
--
ALTER TABLE `craft_templatecachequeries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_templatecaches`
--
ALTER TABLE `craft_templatecaches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_tokens`
--
ALTER TABLE `craft_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `craft_usergroups`
--
ALTER TABLE `craft_usergroups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_usergroups_users`
--
ALTER TABLE `craft_usergroups_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_userpermissions`
--
ALTER TABLE `craft_userpermissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_userpermissions_usergroups`
--
ALTER TABLE `craft_userpermissions_usergroups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_userpermissions_users`
--
ALTER TABLE `craft_userpermissions_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_userpreferences`
--
ALTER TABLE `craft_userpreferences`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `craft_viewswork_viewrecording`
--
ALTER TABLE `craft_viewswork_viewrecording`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `craft_volumefolders`
--
ALTER TABLE `craft_volumefolders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_volumes`
--
ALTER TABLE `craft_volumes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `craft_widgets`
--
ALTER TABLE `craft_widgets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `craft_assetindexdata`
--
ALTER TABLE `craft_assetindexdata`
  ADD CONSTRAINT `craft_fk_rbpbhlazvkytzvpmramoibbzwopobbmhhafx` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_assets`
--
ALTER TABLE `craft_assets`
  ADD CONSTRAINT `craft_fk_hookftfsrdwpkuwnpsfbcmenjsgbvugrxsdb` FOREIGN KEY (`uploaderId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `craft_fk_liavljjwsvtunjplbduyounvrbvuinshzham` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_qbvqmlyuqiujfxuuoiiuryeldwuqjktbbtur` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_rjgrsfrlyvhvdixzxnwxorfhthraslxtudbv` FOREIGN KEY (`folderId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_categories`
--
ALTER TABLE `craft_categories`
  ADD CONSTRAINT `craft_fk_limprbozhvmdfgfrcgnqdkpmzxdrstgvccpc` FOREIGN KEY (`parentId`) REFERENCES `craft_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `craft_fk_plxkqdcnueidllmnzqifzmijkorraachqdgx` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_tjhpymhyoznncnybswojmsacwjpfuqfnyjig` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_categorygroups`
--
ALTER TABLE `craft_categorygroups`
  ADD CONSTRAINT `craft_fk_iaxtyhgiqvrfmbyodcxusofvhduqpbmzjqkj` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_rbqosqsrnhffekicvvnrwimgrtoekdjruktx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `craft_categorygroups_sites`
--
ALTER TABLE `craft_categorygroups_sites`
  ADD CONSTRAINT `craft_fk_jlvskrrzmswgtwdgisupcpivswjcugksfwzr` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_snvlfjspaambboshirynudsuikksqmgserjq` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `craft_changedattributes`
--
ALTER TABLE `craft_changedattributes`
  ADD CONSTRAINT `craft_fk_hubzwrucuzdnoofevtsjgncgumygqkynryau` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_nihbdemjqofdscuvqjsbprthmjhdbpyoicjm` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_rpxtiqlddmkdfutznpstknbsrzssemlsopki` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `craft_changedfields`
--
ALTER TABLE `craft_changedfields`
  ADD CONSTRAINT `craft_fk_bdybowkigvcnwamllvdfcsmskftfnbsfkbyy` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_iftyhxgytkpsoceqmwrbzvxedjvlihbxdmxg` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_jaktbgnfnguglntwrjntfscchxvhapfkunij` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_tgaiooynnigfrntohvrwingibuvfyyarvvwc` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `craft_content`
--
ALTER TABLE `craft_content`
  ADD CONSTRAINT `craft_fk_fjgriqqsoinqvvlcivokendyzzreahcnphcb` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_tvtwjkcdbnarypyktlpfllkgtfacfthsuzal` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_craftidtokens`
--
ALTER TABLE `craft_craftidtokens`
  ADD CONSTRAINT `craft_fk_voouzkgrqrtrugqiewszykwxwveyxztcgnhp` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_drafts`
--
ALTER TABLE `craft_drafts`
  ADD CONSTRAINT `craft_fk_arqrlpqnqotwwjomfuiuvusqmgfhncfhhkvz` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `craft_fk_zkqkovlcjhwcqgxjajvovdudharwvemkeppa` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_elements`
--
ALTER TABLE `craft_elements`
  ADD CONSTRAINT `craft_fk_xouleosxedcxykbudtyufjwicoyswnxzqvdx` FOREIGN KEY (`draftId`) REFERENCES `craft_drafts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_yqhilvqwnpgaplxjmjinxastjvijxafhaqki` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `craft_fk_zunbeywcxmkubtubcjegawfneystxflzzeuq` FOREIGN KEY (`revisionId`) REFERENCES `craft_revisions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_elements_sites`
--
ALTER TABLE `craft_elements_sites`
  ADD CONSTRAINT `craft_fk_oxrcnscfhcazbdlnfukjmkipgywpfdijetgr` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_yxriuvfyvdzxfdhrtzegdupftvjvsgjtnkce` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `craft_entries`
--
ALTER TABLE `craft_entries`
  ADD CONSTRAINT `craft_fk_dfnillrbgeedzprqkuispwookvgsxdhdxnyu` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_njkxmnxlneukykqsofofnohbktoehnttsctv` FOREIGN KEY (`parentId`) REFERENCES `craft_entries` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `craft_fk_wlhqqdfzdunwfasicshpuualtjydravakadn` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_xlztqhczeelpujrmhkifkyjuttcwnaulwwvo` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_yiowbfbbrlvfyivircjccrvagdmvlyzgysdr` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_entrytypes`
--
ALTER TABLE `craft_entrytypes`
  ADD CONSTRAINT `craft_fk_giwtjqbjuxzajvmxtptdidxepyahriwncfyj` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_qvwxajghdjmdwznfvsvuadqmbvdkigxxesgj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `craft_fieldlayoutfields`
--
ALTER TABLE `craft_fieldlayoutfields`
  ADD CONSTRAINT `craft_fk_hfticdrwswphgzzkzwcqknidocqvzoozpwyx` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_lqdavaozxrraoijhqxqroahkntkgurcbaakf` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_upjjksfxntgfuqaveomgrqfjrogpofqnlpgo` FOREIGN KEY (`tabId`) REFERENCES `craft_fieldlayouttabs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_fieldlayouttabs`
--
ALTER TABLE `craft_fieldlayouttabs`
  ADD CONSTRAINT `craft_fk_jplizllpjecugzhwnttfnppvtbyqftxchgyb` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_fields`
--
ALTER TABLE `craft_fields`
  ADD CONSTRAINT `craft_fk_feukauuocptyvyekrzdsubxtblerebzgkxyq` FOREIGN KEY (`groupId`) REFERENCES `craft_fieldgroups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_globalsets`
--
ALTER TABLE `craft_globalsets`
  ADD CONSTRAINT `craft_fk_pzwthuxywdyvcffndkutbzxzwwtmcczubyca` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `craft_fk_ypthmbtarldosidojrbxxaopluwdcknprcmk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_gqltokens`
--
ALTER TABLE `craft_gqltokens`
  ADD CONSTRAINT `craft_fk_uwwyoasdojizxxlgrxzlwkwruljifyiggfwu` FOREIGN KEY (`schemaId`) REFERENCES `craft_gqlschemas` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `craft_matrixblocks`
--
ALTER TABLE `craft_matrixblocks`
  ADD CONSTRAINT `craft_fk_lhcbzxlxctygalsvmbbofffoprhyrgfytyzw` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_mcjafhidgtmkbcuviyxgynxvebgfydqgeoff` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_mfmbszfwczsewkrikywkzrpvnkssnlyotmth` FOREIGN KEY (`typeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_zwzbbjrucuulxplumetykwngdvvcvyilxxyq` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_matrixblocktypes`
--
ALTER TABLE `craft_matrixblocktypes`
  ADD CONSTRAINT `craft_fk_losfusewwukbxptuzamnnpyotfaogrpoeaic` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_yaxrppvrftilrqokhrmowahvsctzjkyoaokf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `craft_matrixcontent_menu`
--
ALTER TABLE `craft_matrixcontent_menu`
  ADD CONSTRAINT `craft_fk_bswtuzgmzabcwstftrcehkamkldhfpvpxepk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_vzyyxkflfvlrggqcvhuyrwtvqodzeqngkrew` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_relations`
--
ALTER TABLE `craft_relations`
  ADD CONSTRAINT `craft_fk_igvigsvulwtgywyhjivcsyfwbrdmdqtunowz` FOREIGN KEY (`targetId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_mmxnjbnnqsaqfbfcpghiyacpcmgwopprqwde` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_nfkhaxllvqmdwhumefrumnnpigmyvlmpmbfy` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_umcssvfowbncmqijfcwiczeqdqxcepycbkxm` FOREIGN KEY (`sourceSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `craft_revisions`
--
ALTER TABLE `craft_revisions`
  ADD CONSTRAINT `craft_fk_ogpsyhokegwlhaxybnmfblgojrfwigxzoppv` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_wnxoaimgnzhcjvnirvinoucesqacwnhflrwt` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `craft_sections`
--
ALTER TABLE `craft_sections`
  ADD CONSTRAINT `craft_fk_wpzrogkscatyhxsxccooojprufrwiawjjsev` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `craft_sections_sites`
--
ALTER TABLE `craft_sections_sites`
  ADD CONSTRAINT `craft_fk_cxpqbhvcxhfoucwjajbydnuyyyfdssddznpn` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_vulimhjhexrleibzihuhfaoflxnpydkqbhfm` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_sessions`
--
ALTER TABLE `craft_sessions`
  ADD CONSTRAINT `craft_fk_tswlgbwgzxkmfhgwbwohhxwoxjboarvjzgsk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_shunnedmessages`
--
ALTER TABLE `craft_shunnedmessages`
  ADD CONSTRAINT `craft_fk_ljdxwagypdostecudploqfehwezeojualrsr` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_sites`
--
ALTER TABLE `craft_sites`
  ADD CONSTRAINT `craft_fk_izscquwpfkgdukutlmsfyfcicisrfbfnufmk` FOREIGN KEY (`groupId`) REFERENCES `craft_sitegroups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_structureelements`
--
ALTER TABLE `craft_structureelements`
  ADD CONSTRAINT `craft_fk_hvuoxdbahpnubqdgwlzbdwozwtefjfuipuos` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_zqcfnebdclyxofbttdexkwmdmahopeifobia` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_taggroups`
--
ALTER TABLE `craft_taggroups`
  ADD CONSTRAINT `craft_fk_nepdolnyedpeylsgcjbzekhxgzpbgvmdgqzw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `craft_tags`
--
ALTER TABLE `craft_tags`
  ADD CONSTRAINT `craft_fk_doxtncllvzjbyfutslhkbyiyunwgludmvhgu` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_frrizhynaflqhhylxzsnillqfucdgwlxjfzj` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_templatecacheelements`
--
ALTER TABLE `craft_templatecacheelements`
  ADD CONSTRAINT `craft_fk_sazvodvctyuyobrocavnnfccilsgcgpmtwri` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_tlhpkuhchkeucjspjojdaiydwuwksyvpsuwb` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_templatecachequeries`
--
ALTER TABLE `craft_templatecachequeries`
  ADD CONSTRAINT `craft_fk_lbpjfnnewvdsnxufuvinvfepxonkujjyuaiq` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_templatecaches`
--
ALTER TABLE `craft_templatecaches`
  ADD CONSTRAINT `craft_fk_fpjgvcjzodkpafxvkiglxfsjgxakapqdkddz` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `craft_usergroups_users`
--
ALTER TABLE `craft_usergroups_users`
  ADD CONSTRAINT `craft_fk_hnfyutuukiutnixqmpdxomnnwcdkkmxvusmi` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_ujjrdqhwisbvyvlaluorlssxqqgalnuomyzc` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_userpermissions_usergroups`
--
ALTER TABLE `craft_userpermissions_usergroups`
  ADD CONSTRAINT `craft_fk_irtfsvxmywjfpxgkgeqtbvtkqhagoxjyhztm` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_pqdgtxegtljzadxksbtwvbsxgzjlcghiiqwa` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_userpermissions_users`
--
ALTER TABLE `craft_userpermissions_users`
  ADD CONSTRAINT `craft_fk_bnzxsqsgzqcflxulmdmmbbvfvxvfewyvekwu` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_bqvbhgmfyccedcpkunvxswphoybitcrzjtgo` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_userpreferences`
--
ALTER TABLE `craft_userpreferences`
  ADD CONSTRAINT `craft_fk_yctrjtdiyoqmoypbmloqvimrciwdsjeslois` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_users`
--
ALTER TABLE `craft_users`
  ADD CONSTRAINT `craft_fk_ekklvsghrxntqnmgtxjvmmeuzdgypjaroryo` FOREIGN KEY (`photoId`) REFERENCES `craft_assets` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `craft_fk_vibblyfcqwshcehybvplwyijafhccskeyjin` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_viewswork_viewrecording`
--
ALTER TABLE `craft_viewswork_viewrecording`
  ADD CONSTRAINT `craft_fk_psassjzoohssztywenrvncpwwahdhgdnqjgw` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `craft_fk_xicxpmlblefkakbiruycfdgrpeabwgkhmjso` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `craft_volumefolders`
--
ALTER TABLE `craft_volumefolders`
  ADD CONSTRAINT `craft_fk_haoybnhtsgdqhgujmtimhdishphpqjamoqru` FOREIGN KEY (`parentId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `craft_fk_yyhvnwiejmisllzzrshyrdnjuknlhpjmuizr` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `craft_volumes`
--
ALTER TABLE `craft_volumes`
  ADD CONSTRAINT `craft_fk_hkkixvofuenagvbmzgjghryreimdaqhuaqod` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `craft_widgets`
--
ALTER TABLE `craft_widgets`
  ADD CONSTRAINT `craft_fk_hivolhdyqrnvntaisobwzttdfvpdytkjolho` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
