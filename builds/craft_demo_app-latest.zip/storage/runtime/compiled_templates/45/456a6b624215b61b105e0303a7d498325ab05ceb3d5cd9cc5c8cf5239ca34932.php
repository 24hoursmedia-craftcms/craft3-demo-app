<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/element */
class __TwigTemplate_ae84066d9536a28a890fc3eff7aec475b0311e099635eb4b114662fbc67e24a6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'contextMenu' => [$this, 'block_contextMenu'],
            'actionButton' => [$this, 'block_actionButton'],
            'main' => [$this, 'block_main'],
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
            'meta' => [$this, 'block_meta'],
            'settings' => [$this, 'block_settings'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 29
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/element");
        // line 30
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_layouts/element", 30)->unwrap();
        // line 32
        $context["saveSourceAction"] = (($context["saveSourceAction"]) ?? (null));
        // line 33
        $context["duplicateSourceAction"] = (($context["duplicateSourceAction"]) ?? (null));
        // line 34
        $context["deleteSourceAction"] = (($context["deleteSourceAction"]) ?? (null));
        // line 35
        $context["deleteForSiteAction"] = (($context["deleteForSiteAction"]) ?? (null));
        // line 36
        $context["revertSourceAction"] = (($context["revertSourceAction"]) ?? (null));
        // line 37
        $context["saveDraftAction"] = (($context["saveDraftAction"]) ?? (null));
        // line 38
        $context["publishDraftAction"] = (($context["publishDraftAction"]) ?? ((($context["applyDraftAction"]) ?? (null))));
        // line 39
        $context["deleteDraftAction"] = (($context["deleteDraftAction"]) ?? (null));
        // line 41
        $context["isDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 41, $this->source); })()), "getIsDraft", [], "method");
        // line 42
        $context["isRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 42, $this->source); })()), "getIsRevision", [], "method");
        // line 43
        $context["isCurrent"] = ( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 43, $this->source); })()) &&  !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 43, $this->source); })()));
        // line 44
        $context["allSites"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 44, $this->source); })()), "app", []), "isMultiSite", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 44, $this->source); })()), "getSupportedSites", [], "method")) : ([0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 44, $this->source); })()), "siteId", [])]));
        // line 45
        $context["allEditableSiteIds"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 45, $this->source); })()), "app", []), "sites", []), "getEditableSiteIds", [], "method");
        // line 46
        $context["propSiteIds"] = craft\helpers\ArrayHelper::getColumn($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, (isset($context["allSites"]) || array_key_exists("allSites", $context) ? $context["allSites"] : (function () { throw new RuntimeError('Variable "allSites" does not exist.', 46, $this->source); })()), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [])) : (true)); }), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])) : ((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 46, $this->source); })()))); });
        // line 47
        $context["propEditableSiteIds"] = array_intersect((isset($context["propSiteIds"]) || array_key_exists("propSiteIds", $context) ? $context["propSiteIds"] : (function () { throw new RuntimeError('Variable "propSiteIds" does not exist.', 47, $this->source); })()), (isset($context["allEditableSiteIds"]) || array_key_exists("allEditableSiteIds", $context) ? $context["allEditableSiteIds"] : (function () { throw new RuntimeError('Variable "allEditableSiteIds" does not exist.', 47, $this->source); })()));
        // line 48
        $context["isMultiSiteElement"] = (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 48, $this->source); })()), "app", []), "isMultiSite", []) && (twig_length_filter($this->env, (isset($context["allSites"]) || array_key_exists("allSites", $context) ? $context["allSites"] : (function () { throw new RuntimeError('Variable "allSites" does not exist.', 48, $this->source); })())) > 1));
        // line 49
        $context["addlEditableSiteIds"] = array_intersect(array_diff(craft\helpers\ArrayHelper::getColumn((isset($context["allSites"]) || array_key_exists("allSites", $context) ? $context["allSites"] : (function () { throw new RuntimeError('Variable "allSites" does not exist.', 49, $this->source); })()), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])) : ((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 49, $this->source); })()))); }), (isset($context["propSiteIds"]) || array_key_exists("propSiteIds", $context) ? $context["propSiteIds"] : (function () { throw new RuntimeError('Variable "propSiteIds" does not exist.', 49, $this->source); })())), (isset($context["allEditableSiteIds"]) || array_key_exists("allEditableSiteIds", $context) ? $context["allEditableSiteIds"] : (function () { throw new RuntimeError('Variable "allEditableSiteIds" does not exist.', 49, $this->source); })()));
        // line 50
        $context["canEditMultipleSites"] = ((isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 50, $this->source); })()) && ((twig_length_filter($this->env, (isset($context["propEditableSiteIds"]) || array_key_exists("propEditableSiteIds", $context) ? $context["propEditableSiteIds"] : (function () { throw new RuntimeError('Variable "propEditableSiteIds" does not exist.', 50, $this->source); })())) > 1) || twig_length_filter($this->env, (isset($context["addlEditableSiteIds"]) || array_key_exists("addlEditableSiteIds", $context) ? $context["addlEditableSiteIds"] : (function () { throw new RuntimeError('Variable "addlEditableSiteIds" does not exist.', 50, $this->source); })()))));
        // line 51
        $context["isUnpublishedDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 51, $this->source); })()), "getIsUnpublishedDraft", [], "method");
        // line 54
        if ((isset($context["isUnpublishedDraft"]) || array_key_exists("isUnpublishedDraft", $context) ? $context["isUnpublishedDraft"] : (function () { throw new RuntimeError('Variable "isUnpublishedDraft" does not exist.', 54, $this->source); })())) {
            // line 55
            $context["isNewlySupportedSite"] = true;
        } elseif (        // line 56
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 56, $this->source); })())) {
            // line 57
            $context["isNewlySupportedSite"] =  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 57, $this->source); })()), "find", [], "method"), "id", [0 => craft\helpers\Template::attribute($this->env, $this->source,             // line 58
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 58, $this->source); })()), "getSourceId", [], "method")], "method"), "siteId", [0 => craft\helpers\Template::attribute($this->env, $this->source,             // line 59
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 59, $this->source); })()), "siteId", [])], "method"), "anyStatus", [], "method"), "exists", [], "method");
        } else {
            // line 63
            $context["isNewlySupportedSite"] = false;
        }
        // line 66
        $context["previewTargets"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 66, $this->source); })()), "getPreviewTargets", [], "method");
        // line 67
        $context["enablePreview"] = ((isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 67, $this->source); })()) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 67, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method"));
        // line 69
        $context["canDeleteDraft"] = (((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 69, $this->source); })()) && ((($context["canDeleteDraft"]) ?? (false)) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 69, $this->source); })()), "creatorId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 69, $this->source); })()), "id", [])))) && (isset($context["deleteDraftAction"]) || array_key_exists("deleteDraftAction", $context) ? $context["deleteDraftAction"] : (function () { throw new RuntimeError('Variable "deleteDraftAction" does not exist.', 69, $this->source); })()));
        // line 70
        $context["canUpdateSource"] = (($context["canUpdateSource"]) ?? (false));
        // line 71
        $context["canDuplicateSource"] = (($context["canDuplicateSource"]) ?? (false));
        // line 72
        $context["canAddAnother"] = (($context["canAddAnother"]) ?? (false));
        // line 73
        $context["canDeleteSource"] = (($context["canDeleteSource"]) ?? (false));
        // line 74
        $context["canDeleteForSite"] = ((((((($context["canDeleteForSite"]) ?? (false)) && (isset($context["deleteForSiteAction"]) || array_key_exists("deleteForSiteAction", $context) ? $context["deleteForSiteAction"] : (function () { throw new RuntimeError('Variable "deleteForSiteAction" does not exist.', 74, $this->source); })())) &&         // line 75
(isset($context["canDeleteForSite"]) || array_key_exists("canDeleteForSite", $context) ? $context["canDeleteForSite"] : (function () { throw new RuntimeError('Variable "canDeleteForSite" does not exist.', 75, $this->source); })())) && (isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 75, $this->source); })())) && (twig_length_filter($this->env, (isset($context["propSiteIds"]) || array_key_exists("propSiteIds", $context) ? $context["propSiteIds"] : (function () { throw new RuntimeError('Variable "propSiteIds" does not exist.', 75, $this->source); })())) > 1)) && ((        // line 76
(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 76, $this->source); })()) && (isset($context["canDeleteSource"]) || array_key_exists("canDeleteSource", $context) ? $context["canDeleteSource"] : (function () { throw new RuntimeError('Variable "canDeleteSource" does not exist.', 76, $this->source); })())) || (((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 76, $this->source); })()) && (isset($context["canDeleteDraft"]) || array_key_exists("canDeleteDraft", $context) ? $context["canDeleteDraft"] : (function () { throw new RuntimeError('Variable "canDeleteDraft" does not exist.', 76, $this->source); })())) && (isset($context["isNewlySupportedSite"]) || array_key_exists("isNewlySupportedSite", $context) ? $context["isNewlySupportedSite"] : (function () { throw new RuntimeError('Variable "isNewlySupportedSite" does not exist.', 76, $this->source); })()))));
        // line 77
        $context["canEdit"] = (($context["canEdit"]) ?? (((((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 77, $this->source); })()) || (isset($context["canDuplicateSource"]) || array_key_exists("canDuplicateSource", $context) ? $context["canDuplicateSource"] : (function () { throw new RuntimeError('Variable "canDuplicateSource" does not exist.', 77, $this->source); })())) || (isset($context["canAddAnother"]) || array_key_exists("canAddAnother", $context) ? $context["canAddAnother"] : (function () { throw new RuntimeError('Variable "canAddAnother" does not exist.', 77, $this->source); })())) || (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 77, $this->source); })()))));
        // line 79
        $context["redirectUrl"] = (($context["redirectUrl"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 79, $this->source); })()), "app", []), "config", []), "general", []), "getPostCpLoginRedirect", [], "method")));
        // line 80
        $context["addAnotherRedirectUrl"] = (($context["addAnotherRedirectUrl"]) ?? (null));
        // line 81
        $context["hashedCpEditUrl"] = call_user_func_array($this->env->getFilter('hash')->getCallable(), ["{cpEditUrl}"]);
        // line 83
        if ( !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 83, $this->source); })())) {
            // line 84
            $context["fullPageForm"] = true;
        }
        // line 87
        if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 87, $this->source); })())) {
            // line 88
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 88, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewDraft:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 88, $this->source); })()), "draftId", []))], "method");
        } elseif (        // line 89
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 89, $this->source); })())) {
            // line 90
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 90, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewRevision:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 90, $this->source); })()), "revisionId", []))], "method");
        } else {
            // line 92
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 92, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewElement:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 92, $this->source); })()), "id", []))], "method");
        }
        // line 97
        $context["showStatusToggles"] = (((($context["showStatusToggles"]) ?? (true)) && craft\helpers\Template::attribute($this->env, $this->source,         // line 98
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 98, $this->source); })()), "hasStatuses", [], "method")) && ( !        // line 99
(isset($context["isUnpublishedDraft"]) || array_key_exists("isUnpublishedDraft", $context) ? $context["isUnpublishedDraft"] : (function () { throw new RuntimeError('Variable "isUnpublishedDraft" does not exist.', 99, $this->source); })()) || (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 99, $this->source); })())));
        // line 101
        if (( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 101, $this->source); })()) &&  !(isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 101, $this->source); })()))) {
            // line 102
            $context["saveShortcut"] = false;
        } elseif ((        // line 103
(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 103, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 103, $this->source); })()))) {
            // line 104
            $context["saveShortcutRedirect"] = "{cpEditUrl}";
        }
        // line 107
        $context["form"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 107, $this->source); })()), "getFieldLayout", [], "method"), "createForm", [0 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 107, $this->source); })()), 1 => ((isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 107, $this->source); })()) ||  !(isset($context["canEdit"]) || array_key_exists("canEdit", $context) ? $context["canEdit"] : (function () { throw new RuntimeError('Variable "canEdit" does not exist.', 107, $this->source); })()))], "method");
        // line 109
        if ( !(isset($context["tabs"]) || array_key_exists("tabs", $context))) {
            // line 110
            $context["tabs"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 110, $this->source); })()), "getTabMenu", [], "method");
        }
        // line 113
        $context["settingsHtml"] = twig_trim_filter(((        $this->hasBlock("settings", $context, $blocks)) ? (        $this->renderBlock("settings", $context, $blocks)) : ("")));
        // line 115
        $context["formActions"] = [];
        // line 116
        if ((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 116, $this->source); })())) {
            // line 117
            if (((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 117, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 117, $this->source); })()))) {
                // line 118
                $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 118, $this->source); })()), ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "redirect" =>                 // line 120
(isset($context["hashedCpEditUrl"]) || array_key_exists("hashedCpEditUrl", $context) ? $context["hashedCpEditUrl"] : (function () { throw new RuntimeError('Variable "hashedCpEditUrl" does not exist.', 120, $this->source); })()), "shortcut" => true, "retainScroll" => true]);
                // line 124
                if ((isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 124, $this->source); })())) {
                    // line 125
                    $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 125, $this->source); })()), ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and add another", "app"), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [                    // line 127
(isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 127, $this->source); })())]), "shortcut" => true, "shift" => true]);
                }
                // line 132
                if (((isset($context["canDuplicateSource"]) || array_key_exists("canDuplicateSource", $context) ? $context["canDuplicateSource"] : (function () { throw new RuntimeError('Variable "canDuplicateSource" does not exist.', 132, $this->source); })()) && (isset($context["duplicateSourceAction"]) || array_key_exists("duplicateSourceAction", $context) ? $context["duplicateSourceAction"] : (function () { throw new RuntimeError('Variable "duplicateSourceAction" does not exist.', 132, $this->source); })()))) {
                    // line 133
                    $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 133, $this->source); })()), ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a new {type}", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 135
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 135, $this->source); })()), "lowerDisplayName", [], "method")]), "action" =>                     // line 137
(isset($context["duplicateSourceAction"]) || array_key_exists("duplicateSourceAction", $context) ? $context["duplicateSourceAction"] : (function () { throw new RuntimeError('Variable "duplicateSourceAction" does not exist.', 137, $this->source); })()), "redirect" =>                     // line 138
(isset($context["hashedCpEditUrl"]) || array_key_exists("hashedCpEditUrl", $context) ? $context["hashedCpEditUrl"] : (function () { throw new RuntimeError('Variable "hashedCpEditUrl" does not exist.', 138, $this->source); })())]);
                }
            }
            // line 142
            if ((isset($context["canDeleteForSite"]) || array_key_exists("canDeleteForSite", $context) ? $context["canDeleteForSite"] : (function () { throw new RuntimeError('Variable "canDeleteForSite" does not exist.', 142, $this->source); })())) {
                // line 143
                $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 143, $this->source); })()), ["destructive" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Delete {type} for this site", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 146
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 146, $this->source); })()), "lowerDisplayName", [], "method")]), "action" =>                 // line 148
(isset($context["deleteForSiteAction"]) || array_key_exists("deleteForSiteAction", $context) ? $context["deleteForSiteAction"] : (function () { throw new RuntimeError('Variable "deleteForSiteAction" does not exist.', 148, $this->source); })()), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [(                // line 149
(isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 149, $this->source); })()) . "#")]), "confirm" => $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to delete the {type} for this site?", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 151
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 151, $this->source); })()), "lowerDisplayName", [], "method")])]);
            }
            // line 155
            if (((isset($context["canDeleteSource"]) || array_key_exists("canDeleteSource", $context) ? $context["canDeleteSource"] : (function () { throw new RuntimeError('Variable "canDeleteSource" does not exist.', 155, $this->source); })()) && (isset($context["deleteSourceAction"]) || array_key_exists("deleteSourceAction", $context) ? $context["deleteSourceAction"] : (function () { throw new RuntimeError('Variable "deleteSourceAction" does not exist.', 155, $this->source); })()))) {
                // line 156
                $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 156, $this->source); })()), ["destructive" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Delete {type}", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 159
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 159, $this->source); })()), "lowerDisplayName", [], "method")]), "action" =>                 // line 161
(isset($context["deleteSourceAction"]) || array_key_exists("deleteSourceAction", $context) ? $context["deleteSourceAction"] : (function () { throw new RuntimeError('Variable "deleteSourceAction" does not exist.', 161, $this->source); })()), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [(                // line 162
(isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 162, $this->source); })()) . "#")]), "confirm" => $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to delete this {type}?", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 164
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 164, $this->source); })()), "lowerDisplayName", [], "method")])]);
            }
        } elseif (        // line 168
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 168, $this->source); })())) {
            // line 169
            if ((isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 169, $this->source); })())) {
                // line 170
                $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 170, $this->source); })()), ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "action" =>                 // line 172
(isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 172, $this->source); })()), "shortcut" => true, "retainScroll" => true]);
            }
            // line 177
            if ((((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 177, $this->source); })()) && (isset($context["publishDraftAction"]) || array_key_exists("publishDraftAction", $context) ? $context["publishDraftAction"] : (function () { throw new RuntimeError('Variable "publishDraftAction" does not exist.', 177, $this->source); })())) && (isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 177, $this->source); })()))) {
                // line 178
                $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 178, $this->source); })()), ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Publish and add another", "app"), "action" =>                 // line 180
(isset($context["publishDraftAction"]) || array_key_exists("publishDraftAction", $context) ? $context["publishDraftAction"] : (function () { throw new RuntimeError('Variable "publishDraftAction" does not exist.', 180, $this->source); })()), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [                // line 181
(isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 181, $this->source); })())]), "shortcut" => true, "shift" => true, "data" => ["autosave" => false]]);
            }
            // line 189
            if ((isset($context["canDeleteDraft"]) || array_key_exists("canDeleteDraft", $context) ? $context["canDeleteDraft"] : (function () { throw new RuntimeError('Variable "canDeleteDraft" does not exist.', 189, $this->source); })())) {
                // line 190
                if ((isset($context["canDeleteForSite"]) || array_key_exists("canDeleteForSite", $context) ? $context["canDeleteForSite"] : (function () { throw new RuntimeError('Variable "canDeleteForSite" does not exist.', 190, $this->source); })())) {
                    // line 191
                    $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 191, $this->source); })()), ["destructive" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Delete draft for this site", "app"), "action" =>                     // line 194
(isset($context["deleteForSiteAction"]) || array_key_exists("deleteForSiteAction", $context) ? $context["deleteForSiteAction"] : (function () { throw new RuntimeError('Variable "deleteForSiteAction" does not exist.', 194, $this->source); })()), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [(                    // line 195
(isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 195, $this->source); })()) . "#")]), "confirm" => $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to delete the draft for this site?", "app")]);
                }
                // line 199
                $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 199, $this->source); })()), ["destructive" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Delete draft", "app"), "action" =>                 // line 202
(isset($context["deleteDraftAction"]) || array_key_exists("deleteDraftAction", $context) ? $context["deleteDraftAction"] : (function () { throw new RuntimeError('Variable "deleteDraftAction" does not exist.', 202, $this->source); })()), "redirect" => ((                // line 203
(isset($context["isUnpublishedDraft"]) || array_key_exists("isUnpublishedDraft", $context) ? $context["isUnpublishedDraft"] : (function () { throw new RuntimeError('Variable "isUnpublishedDraft" does not exist.', 203, $this->source); })())) ? (call_user_func_array($this->env->getFilter('hash')->getCallable(), [(isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 203, $this->source); })())])) : ((isset($context["hashedCpEditUrl"]) || array_key_exists("hashedCpEditUrl", $context) ? $context["hashedCpEditUrl"] : (function () { throw new RuntimeError('Variable "hashedCpEditUrl" does not exist.', 203, $this->source); })()))), "confirm" => $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to delete this draft?", "app")]);
            }
        }
        // line 448
        if (((isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 448, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 448, $this->source); })()), "enabled", []))) {
            // line 450
            $context["siteStatusesQuery"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 450, $this->source); })()), "find", [], "method"), "select", [0 => [0 => "elements_sites.siteId", 1 => "elements_sites.enabled"]], "method"), "id", [0 => craft\helpers\Template::attribute($this->env, $this->source,             // line 452
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 452, $this->source); })()), "id", [])], "method"), "siteId", [0 =>             // line 453
(isset($context["propEditableSiteIds"]) || array_key_exists("propEditableSiteIds", $context) ? $context["propEditableSiteIds"] : (function () { throw new RuntimeError('Variable "propEditableSiteIds" does not exist.', 453, $this->source); })())], "method"), "anyStatus", [], "method"), "asArray", [], "method");
            // line 456
            if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 456, $this->source); })())) {
                // line 457
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 457, $this->source); })()), "drafts", [], "method");
            } elseif (            // line 458
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 458, $this->source); })())) {
                // line 459
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 459, $this->source); })()), "revisions", [], "method");
            }
            // line 461
            $context["siteStatuses"] = twig_array_map($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 461, $this->source); })()), "pairs", [], "method"),             // line 462
function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 462, $this->source); })())) ? (true) : (false)); });
        } elseif (        // line 463
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 463, $this->source); })())) {
            // line 464
            $context["siteStatusValues"] = [];
            // line 465
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["propEditableSiteIds"]) || array_key_exists("propEditableSiteIds", $context) ? $context["propEditableSiteIds"] : (function () { throw new RuntimeError('Variable "propEditableSiteIds" does not exist.', 465, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["siteId"]) {
                // line 466
                $context["siteStatusValues"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteStatusValues"]) || array_key_exists("siteStatusValues", $context) ? $context["siteStatusValues"] : (function () { throw new RuntimeError('Variable "siteStatusValues" does not exist.', 466, $this->source); })()), [0 => false]);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['siteId'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 468
            $context["siteStatuses"] = array_combine((isset($context["propEditableSiteIds"]) || array_key_exists("propEditableSiteIds", $context) ? $context["propEditableSiteIds"] : (function () { throw new RuntimeError('Variable "propEditableSiteIds" does not exist.', 468, $this->source); })()), (isset($context["siteStatusValues"]) || array_key_exists("siteStatusValues", $context) ? $context["siteStatusValues"] : (function () { throw new RuntimeError('Variable "siteStatusValues" does not exist.', 468, $this->source); })()));
        } else {
            // line 470
            $context["siteStatuses"] = [craft\helpers\Template::attribute($this->env, $this->source,             // line 471
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 471, $this->source); })()), "siteId", []) => ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 471, $this->source); })()), "enabled", [])) ? (true) : (false))];
        }
        // line 475
        $context["settings"] = ["elementType" => get_class(        // line 476
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 476, $this->source); })())), "sourceId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 477
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 477, $this->source); })()), "getSourceId", [], "method"), "siteId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 478
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 478, $this->source); })()), "siteId", []), "isUnpublishedDraft" =>         // line 479
(isset($context["isUnpublishedDraft"]) || array_key_exists("isUnpublishedDraft", $context) ? $context["isUnpublishedDraft"] : (function () { throw new RuntimeError('Variable "isUnpublishedDraft" does not exist.', 479, $this->source); })()), "enabled" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 480
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 480, $this->source); })()), "enabled", [])) ? (true) : (false)), "enabledForSite" => (craft\helpers\Template::attribute($this->env, $this->source,         // line 481
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 481, $this->source); })()), "enabled", []) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 481, $this->source); })()), "getEnabledForSite", [], "method")), "isLive" => (((        // line 482
(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 482, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 482, $this->source); })()), "enabled", [])) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 482, $this->source); })()), "getEnabledForSite", [], "method")) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 482, $this->source); })()), "getRoute", [], "method")), "siteStatuses" =>         // line 483
(isset($context["siteStatuses"]) || array_key_exists("siteStatuses", $context) ? $context["siteStatuses"] : (function () { throw new RuntimeError('Variable "siteStatuses" does not exist.', 483, $this->source); })()), "addlSiteIds" => array_values(        // line 484
(isset($context["addlEditableSiteIds"]) || array_key_exists("addlEditableSiteIds", $context) ? $context["addlEditableSiteIds"] : (function () { throw new RuntimeError('Variable "addlEditableSiteIds" does not exist.', 484, $this->source); })())), "cpEditUrl" => craft\helpers\Template::attribute($this->env, $this->source,         // line 485
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 485, $this->source); })()), "cpEditUrl", []), "draftId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 486
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 486, $this->source); })()), "draftId", []), "revisionId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 487
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 487, $this->source); })()), "revisionId", []), "draftName" => ((        // line 488
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 488, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 488, $this->source); })()), "draftName", [])) : (null)), "canEditMultipleSites" =>         // line 489
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 489, $this->source); })()), "canUpdateSource" =>         // line 490
(isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 490, $this->source); })()), "saveDraftAction" =>         // line 491
(isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 491, $this->source); })()), "deleteDraftAction" =>         // line 492
(isset($context["deleteDraftAction"]) || array_key_exists("deleteDraftAction", $context) ? $context["deleteDraftAction"] : (function () { throw new RuntimeError('Variable "deleteDraftAction" does not exist.', 492, $this->source); })()), "publishDraftAction" =>         // line 493
(isset($context["publishDraftAction"]) || array_key_exists("publishDraftAction", $context) ? $context["publishDraftAction"] : (function () { throw new RuntimeError('Variable "publishDraftAction" does not exist.', 493, $this->source); })()), "hashedCpEditUrl" =>         // line 494
(isset($context["hashedCpEditUrl"]) || array_key_exists("hashedCpEditUrl", $context) ? $context["hashedCpEditUrl"] : (function () { throw new RuntimeError('Variable "hashedCpEditUrl" does not exist.', 494, $this->source); })()), "hashedAddAnotherRedirectUrl" => ((        // line 495
(isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 495, $this->source); })())) ? (call_user_func_array($this->env->getFilter('hash')->getCallable(), [(isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 495, $this->source); })())])) : (null)), "enablePreview" =>         // line 496
(isset($context["enablePreview"]) || array_key_exists("enablePreview", $context) ? $context["enablePreview"] : (function () { throw new RuntimeError('Variable "enablePreview" does not exist.', 496, $this->source); })()), "previewTargets" =>         // line 497
(isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 497, $this->source); })()), "siteToken" => (( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 498
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 498, $this->source); })()), "getSite", [], "method"), "enabled", [])) ? (call_user_func_array($this->env->getFilter('hash')->getCallable(), [craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 498, $this->source); })()), "siteId", [])])) : (""))];
        // line 500
        ob_start();
        // line 501
        echo "    window.draftEditor = new Craft.DraftEditor(";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 501, $this->source); })()));
        echo ");
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 29
        $this->parent = $this->loadTemplate("_layouts/cp", "_layouts/element", 29);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_layouts/element");
    }

    // line 209
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "header");
        // line 210
        echo "    <div class=\"flex flex-nowrap\">
        ";
        // line 211
        $this->displayBlock("pageTitle", $context, $blocks);
        echo "
        ";
        // line 212
        $this->displayBlock("contextMenu", $context, $blocks);
        echo "
    </div>
    <div class=\"flex\" id=\"action-buttons\">
        ";
        // line 215
        if ((isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 215, $this->source); })())) {
            // line 216
            echo "            <div class=\"btngroup\">
                ";
            // line 217
            if ((isset($context["enablePreview"]) || array_key_exists("enablePreview", $context) ? $context["enablePreview"] : (function () { throw new RuntimeError('Variable "enablePreview" does not exist.', 217, $this->source); })())) {
                // line 218
                echo "                    <button type=\"button\" id=\"preview-btn\" class=\"btn\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Preview", "app"), "html", null, true);
                echo "</button>
                ";
            }
            // line 220
            echo "                <button type=\"button\" id=\"share-btn\" class=\"btn\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("View", "app"), "html", null, true);
            echo "</button>
            </div>
        ";
        }
        // line 223
        echo "
        ";
        // line 224
        if (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 224, $this->source); })()) && (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 224, $this->source); })()))) {
            // line 225
            echo "            <div id=\"save-draft-btn-container\">
                ";
            // line 226
            if (((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 226, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 226, $this->source); })()))) {
                // line 227
                echo "                    <button type=\"button\" id=\"save-draft-btn\" class=\"btn\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a draft", "app"), "html", null, true);
                echo "</button>
                ";
            } else {
                // line 229
                echo "                    <button type=\"submit\" id=\"save-draft-btn\" class=\"btn submit\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a draft", "app"), "html", null, true);
                echo "</button>
                    ";
                // line 230
                if (twig_length_filter($this->env, (isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 230, $this->source); })()))) {
                    // line 231
                    echo "                        <button type=\"button\" class=\"btn menubtn\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"), "html", null, true);
                    echo "\" data-icon=\"settings\"></button>
                        ";
                    // line 232
                    $this->loadTemplate("_layouts/components/form-action-menu", "_layouts/element", 232)->display($context);
                    // line 233
                    echo "                    ";
                }
                // line 234
                echo "                ";
            }
            // line 235
            echo "            </div>
        ";
        } elseif (((        // line 236
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 236, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 236, $this->source); })())) && (isset($context["publishDraftAction"]) || array_key_exists("publishDraftAction", $context) ? $context["publishDraftAction"] : (function () { throw new RuntimeError('Variable "publishDraftAction" does not exist.', 236, $this->source); })()))) {
            // line 237
            echo "            <div id=\"publish-draft-btn-container\">
                ";
            // line 238
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "button", "class" => [0 => "btn", 1 => "secondary", 2 => "formsubmit"], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Publish draft", "app"), "title" => twig_call_macro($macros["forms"], "macro_shortcutText", ["S", false, true], 242, $context, $this->getSourceContext()), "data" => ["action" =>             // line 244
(isset($context["publishDraftAction"]) || array_key_exists("publishDraftAction", $context) ? $context["publishDraftAction"] : (function () { throw new RuntimeError('Variable "publishDraftAction" does not exist.', 244, $this->source); })()), "redirect" =>             // line 245
(isset($context["hashedCpEditUrl"]) || array_key_exists("hashedCpEditUrl", $context) ? $context["hashedCpEditUrl"] : (function () { throw new RuntimeError('Variable "hashedCpEditUrl" does not exist.', 245, $this->source); })())]]);
            // line 247
            echo "
            </div>
        ";
        } elseif (((        // line 249
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 249, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 249, $this->source); })())) && (isset($context["revertSourceAction"]) || array_key_exists("revertSourceAction", $context) ? $context["revertSourceAction"] : (function () { throw new RuntimeError('Variable "revertSourceAction" does not exist.', 249, $this->source); })()))) {
            // line 250
            echo "            <form method=\"post\" accept-charset=\"UTF-8\">
                ";
            // line 251
            echo craft\helpers\Html::csrfInput();
            echo "
                ";
            // line 252
            echo craft\helpers\Html::actionInput((isset($context["revertSourceAction"]) || array_key_exists("revertSourceAction", $context) ? $context["revertSourceAction"] : (function () { throw new RuntimeError('Variable "revertSourceAction" does not exist.', 252, $this->source); })()));
            echo "
                ";
            // line 253
            echo craft\helpers\Html::redirectInput("{cpEditUrl}");
            echo "
                ";
            // line 254
            echo craft\helpers\Html::hiddenInput("revisionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 254, $this->source); })()), "revisionId", []));
            echo "
                <div class=\"secondary-buttons\">
                    <button type=\"button\" class=\"btn secondary formsubmit\">";
            // line 256
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Revert {type} to this revision", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 256, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
            echo "</button>
                </div>
            </form>
        ";
        }
        // line 260
        echo "
        ";
        // line 261
        $this->displayBlock("actionButton", $context, $blocks);
        echo "
    </div>
";
        craft\helpers\Template::endProfile("block", "header");
    }

    // line 265
    public function block_contextMenu($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "contextMenu");
        // line 266
        echo "    ";
        if ((((isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 266, $this->source); })()) || (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 266, $this->source); })())) || craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 266, $this->source); })()), "find", [], "method"), "revisionOf", [0 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 266, $this->source); })())], "method"), "exists", [], "method"))) {
            // line 267
            echo "        ";
            $this->loadTemplate("_includes/revisionmenu", "_layouts/element", 267)->display(twig_array_merge($context, ["supportedSiteIds" =>             // line 268
(isset($context["propSiteIds"]) || array_key_exists("propSiteIds", $context) ? $context["propSiteIds"] : (function () { throw new RuntimeError('Variable "propSiteIds" does not exist.', 268, $this->source); })()), "canHaveDrafts" =>  !twig_test_empty(            // line 269
(isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 269, $this->source); })()))]));
            // line 271
            echo "    ";
        }
        craft\helpers\Template::endProfile("block", "contextMenu");
    }

    // line 274
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 275
        echo "    ";
        if ((((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 275, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 275, $this->source); })())) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 275, $this->source); })()))) {
            // line 276
            echo "        <div id=\"save-btn-container\" class=\"btngroup submit\">
            ";
            // line 277
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "submit", "class" => [0 => "btn", 1 => "submit"], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app")]);
            // line 281
            echo "
            <button type=\"button\" class=\"btn submit menubtn\"></button>
            ";
            // line 283
            $this->loadTemplate("_layouts/components/form-action-menu", "_layouts/element", 283)->display($context);
            // line 284
            echo "        </div>
    ";
        } elseif (        // line 285
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 285, $this->source); })())) {
            // line 286
            echo "        <div id=\"save-btn-container\" class=\"btngroup submit\">
            <button type=\"submit\" class=\"btn submit\">";
            // line 287
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save draft", "app"), "html", null, true);
            echo "</button>
            ";
            // line 288
            if ((isset($context["canDeleteDraft"]) || array_key_exists("canDeleteDraft", $context) ? $context["canDeleteDraft"] : (function () { throw new RuntimeError('Variable "canDeleteDraft" does not exist.', 288, $this->source); })())) {
                // line 289
                echo "                <button type=\"button\" class=\"btn submit menubtn\"></button>
                ";
                // line 290
                $this->loadTemplate("_layouts/components/form-action-menu", "_layouts/element", 290)->display($context);
                // line 291
                echo "            ";
            }
            // line 292
            echo "        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 296
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 297
        echo "    ";
        if ( !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 297, $this->source); })())) {
            // line 298
            echo "        ";
            // line 299
            echo "        ";
            if ((((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 299, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 299, $this->source); })())) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 299, $this->source); })()))) {
                // line 300
                echo "            ";
                // line 301
                echo "            ";
                echo craft\helpers\Html::actionInput((isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 301, $this->source); })()), ["id" => "action"]);
                echo "
        ";
            } elseif ((            // line 302
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 302, $this->source); })()) && (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 302, $this->source); })()))) {
                // line 303
                echo "            ";
                echo craft\helpers\Html::actionInput((isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 303, $this->source); })()), ["id" => "action"]);
                echo "
        ";
            }
            // line 305
            echo "        ";
            echo craft\helpers\Html::redirectInput((isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 305, $this->source); })()));
            echo "

        ";
            // line 308
            echo "        ";
            if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 308, $this->source); })()), "app", []), "isMultiSite", [])) {
                // line 309
                echo "            ";
                echo craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 309, $this->source); })()), "siteId", []));
                echo "
        ";
            }
            // line 311
            echo "
        ";
            // line 313
            echo "        ";
            if (((isset($context["isUnpublishedDraft"]) || array_key_exists("isUnpublishedDraft", $context) ? $context["isUnpublishedDraft"] : (function () { throw new RuntimeError('Variable "isUnpublishedDraft" does not exist.', 313, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 313, $this->source); })()), "app", []), "request", []), "getQueryParam", [0 => "fresh"], "method"))) {
                // line 314
                echo "            ";
                echo craft\helpers\Html::hiddenInput("propagateAll", "1");
                echo "
        ";
            }
            // line 316
            echo "    ";
        }
        // line 317
        echo "    ";
        $this->displayParentBlock("main", $context, $blocks);
        echo "
";
        craft\helpers\Template::endProfile("block", "main");
    }

    // line 320
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 321
        echo "    ";
        if ( !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 321, $this->source); })())) {
            // line 322
            echo "        ";
            echo craft\helpers\Html::hiddenInput("sourceId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 322, $this->source); })()), "getSourceId", [], "method"));
            echo "
    ";
        } else {
            // line 324
            echo "        ";
            echo craft\helpers\Html::hiddenInput("revisionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 324, $this->source); })()), "revisionId", []));
            echo "
    ";
        }
        // line 326
        echo "
    <div id=\"fields\">
        ";
        // line 328
        echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 328, $this->source); })()), "render", [], "method");
        echo "
    </div>
";
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 332
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 333
        echo "    ";
        if ((isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 333, $this->source); })())) {
            // line 334
            echo "        <div id=\"settings\" class=\"meta\">
            ";
            // line 335
            echo (isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 335, $this->source); })());
            echo "
        </div>
    ";
        }
        // line 338
        echo "
    ";
        // line 339
        if (((isset($context["showStatusToggles"]) || array_key_exists("showStatusToggles", $context) ? $context["showStatusToggles"] : (function () { throw new RuntimeError('Variable "showStatusToggles" does not exist.', 339, $this->source); })()) && (isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 339, $this->source); })()))) {
            // line 340
            echo "        <div class=\"meta\">
            ";
            // line 341
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 342
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 342, $this->source); })()), "getAttributeStatus", [0 => "enabled"], "method"), "label" => ($this->extensions['craft\web\twig\Extension']->translateFilter("Enabled for {site}", "app", ["site" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 343
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 343, $this->source); })()), "site", []), "name", []), "site"))]) . ((            // line 344
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 344, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "button", "id" => "expand-status-btn", "class" => [0 => "btn"], "data" => ["icon" => "ellipsis"]])) : (""))), "id" => ("enabledForSite-" . craft\helpers\Template::attribute($this->env, $this->source,             // line 352
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 352, $this->source); })()), "siteId", [])), "name" => (("enabledForSite[" . craft\helpers\Template::attribute($this->env, $this->source,             // line 353
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 353, $this->source); })()), "siteId", [])) . "]"), "on" => (craft\helpers\Template::attribute($this->env, $this->source,             // line 354
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 354, $this->source); })()), "enabled", []) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 354, $this->source); })()), "getEnabledForSite", [], "method")), "disabled" =>             // line 355
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 355, $this->source); })())]], 341, $context, $this->getSourceContext());
            // line 356
            echo "
        </div>
    ";
        }
        // line 359
        echo "
    <div id=\"meta-details\" class=\"meta read-only\">
        ";
        // line 361
        $this->displayBlock('meta', $context, $blocks);
        // line 399
        echo "    </div>

    ";
        // line 401
        if ((((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 401, $this->source); })()) && (($context["hasRevisions"]) ?? (false))) || (isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 401, $this->source); })()))) {
            // line 402
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_textarea", [["id" => "notes", "class" => [0 => "nicetext"], "name" => "notes", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Notes about your changes", "app"), "value" => ((            // line 407
(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 407, $this->source); })())) ? ((($context["notes"]) ?? (null))) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 407, $this->source); })()), "draftNotes", []))), "inputAttributes" => ["aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Notes about your changes", "app")]]]], 402, $context, $this->getSourceContext());
            // line 413
            echo "
    ";
        }
        // line 415
        echo "
    ";
        // line 416
        if (((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 416, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 416, $this->source); })()), "getIsOutdated", [], "method"))) {
            // line 417
            echo "        ";
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 417, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("mergeDraftSourceChanges:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 417, $this->source); })()), "draftId", []))], "method");
            // line 418
            echo "        <div class=\"meta read-only warning\">
            <p>";
            // line 419
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("The source {type} has been updated recently.", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 419, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
            echo "</p>
            <div class=\"flex flex-nowrap\">
                ";
            // line 421
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 421, $this->source); })()), "trackChanges", [])) {
                // line 422
                echo "                    ";
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "button", "id" => "merge-changes-btn", "class" => [0 => "btn"], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Merge changes into draft", "app")]);
                // line 427
                echo "
                    <div id=\"merge-changes-spinner\" class=\"spinner hidden\"></div>
                ";
            }
            // line 430
            echo "            </div>
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "details");
    }

    // line 361
    public function block_meta($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "meta");
        // line 362
        echo "            ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 362, $this->source); })()), "hasStatuses", [], "method")) {
            // line 363
            echo "                ";
            if ((isset($context["isUnpublishedDraft"]) || array_key_exists("isUnpublishedDraft", $context) ? $context["isUnpublishedDraft"] : (function () { throw new RuntimeError('Variable "isUnpublishedDraft" does not exist.', 363, $this->source); })())) {
                // line 364
                echo "                    ";
                $context["statusColor"] = "white";
                // line 365
                echo "                    ";
                $context["statusLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Draft", "app");
                // line 366
                echo "                ";
            } else {
                // line 367
                echo "                    ";
                $context["status"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 367, $this->source); })()), "getStatus", [], "method");
                // line 368
                echo "                    ";
                $context["statusDef"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 368, $this->source); })()), [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 368, $this->source); })()), [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 368, $this->source); })()), [], "array")) : (null));
                // line 369
                echo "                    ";
                $context["statusColor"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [])) : ((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 369, $this->source); })())));
                // line 370
                echo "                    ";
                $context["statusLabel"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [])) : ((($context["statusDef"]) ?? ($this->extensions['craft\web\twig\Extension']->ucfirstFilter((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 370, $this->source); })()))))));
                // line 371
                echo "                ";
            }
            // line 372
            echo "                <div class=\"data\">
                    <h5 class=\"heading\">";
            // line 373
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Status", "app"), "html", null, true);
            echo "</h5>
                    <div id=\"status-value\" class=\"value\"><span class=\"status ";
            // line 374
            echo twig_escape_filter($this->env, (isset($context["statusColor"]) || array_key_exists("statusColor", $context) ? $context["statusColor"] : (function () { throw new RuntimeError('Variable "statusColor" does not exist.', 374, $this->source); })()), "html", null, true);
            echo "\"></span>";
            echo twig_escape_filter($this->env, (isset($context["statusLabel"]) || array_key_exists("statusLabel", $context) ? $context["statusLabel"] : (function () { throw new RuntimeError('Variable "statusLabel" does not exist.', 374, $this->source); })()), "html", null, true);
            echo "</div>
                </div>
            ";
        }
        // line 377
        echo "            <div class=\"data\">
                <h5 class=\"heading\">";
        // line 378
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Created at", "app"), "html", null, true);
        echo "</h5>
                <div id=\"date-created-value\" class=\"value\">";
        // line 379
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 379, $this->source); })()), "dateCreated", []), "short"), "html", null, true);
        echo "</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">";
        // line 382
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Updated at", "app"), "html", null, true);
        echo "</h5>
                <div id=\"date-updated-value\" class=\"value\">";
        // line 383
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 383, $this->source); })()), "dateUpdated", []), "short"), "html", null, true);
        echo "</div>
            </div>
            ";
        // line 385
        if ((isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 385, $this->source); })())) {
            // line 386
            echo "                ";
            $context["revisionNotes"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 386, $this->source); })()), "revisionNotes", []);
            // line 387
            echo "            ";
        } elseif (( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 387, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 387, $this->source); })()), "currentRevision", []))) {
            // line 388
            echo "                ";
            $context["revisionNotes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 388, $this->source); })()), "currentRevision", []), "revisionNotes", []);
            // line 389
            echo "            ";
        } else {
            // line 390
            echo "                ";
            $context["revisionNotes"] = null;
            // line 391
            echo "            ";
        }
        // line 392
        echo "            ";
        if ((isset($context["revisionNotes"]) || array_key_exists("revisionNotes", $context) ? $context["revisionNotes"] : (function () { throw new RuntimeError('Variable "revisionNotes" does not exist.', 392, $this->source); })())) {
            // line 393
            echo "                <div class=\"data\">
                    <h5 class=\"heading\">";
            // line 394
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Notes", "app"), "html", null, true);
            echo "</h5>
                    <div class=\"value\">";
            // line 395
            echo twig_escape_filter($this->env, (isset($context["revisionNotes"]) || array_key_exists("revisionNotes", $context) ? $context["revisionNotes"] : (function () { throw new RuntimeError('Variable "revisionNotes" does not exist.', 395, $this->source); })()), "html", null, true);
            echo "</div>
                </div>
            ";
        }
        // line 398
        echo "        ";
        craft\helpers\Template::endProfile("block", "meta");
    }

    // line 435
    public function block_settings($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "settings");
        // line 436
        echo "    ";
        if (((isset($context["showStatusToggles"]) || array_key_exists("showStatusToggles", $context) ? $context["showStatusToggles"] : (function () { throw new RuntimeError('Variable "showStatusToggles" does not exist.', 436, $this->source); })()) &&  !(isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 436, $this->source); })()))) {
            // line 437
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 438
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 438, $this->source); })()), "getAttributeStatus", [0 => "enabled"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "id" => "enabled", "name" => "enabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,             // line 442
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 442, $this->source); })()), "enabled", []), "disabled" =>             // line 443
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 443, $this->source); })())]], 437, $context, $this->getSourceContext());
            // line 444
            echo "
    ";
        }
        craft\helpers\Template::endProfile("block", "settings");
    }

    public function getTemplateName()
    {
        return "_layouts/element";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  834 => 444,  832 => 443,  831 => 442,  830 => 438,  828 => 437,  825 => 436,  820 => 435,  815 => 398,  809 => 395,  805 => 394,  802 => 393,  799 => 392,  796 => 391,  793 => 390,  790 => 389,  787 => 388,  784 => 387,  781 => 386,  779 => 385,  774 => 383,  770 => 382,  764 => 379,  760 => 378,  757 => 377,  749 => 374,  745 => 373,  742 => 372,  739 => 371,  736 => 370,  733 => 369,  730 => 368,  727 => 367,  724 => 366,  721 => 365,  718 => 364,  715 => 363,  712 => 362,  707 => 361,  699 => 430,  694 => 427,  691 => 422,  689 => 421,  684 => 419,  681 => 418,  678 => 417,  676 => 416,  673 => 415,  669 => 413,  667 => 407,  665 => 402,  663 => 401,  659 => 399,  657 => 361,  653 => 359,  648 => 356,  646 => 355,  645 => 354,  644 => 353,  643 => 352,  642 => 344,  641 => 343,  640 => 342,  639 => 341,  636 => 340,  634 => 339,  631 => 338,  625 => 335,  622 => 334,  619 => 333,  614 => 332,  606 => 328,  602 => 326,  596 => 324,  590 => 322,  587 => 321,  582 => 320,  574 => 317,  571 => 316,  565 => 314,  562 => 313,  559 => 311,  553 => 309,  550 => 308,  544 => 305,  538 => 303,  536 => 302,  531 => 301,  529 => 300,  526 => 299,  524 => 298,  521 => 297,  516 => 296,  509 => 292,  506 => 291,  504 => 290,  501 => 289,  499 => 288,  495 => 287,  492 => 286,  490 => 285,  487 => 284,  485 => 283,  481 => 281,  479 => 277,  476 => 276,  473 => 275,  468 => 274,  462 => 271,  460 => 269,  459 => 268,  457 => 267,  454 => 266,  449 => 265,  441 => 261,  438 => 260,  431 => 256,  426 => 254,  422 => 253,  418 => 252,  414 => 251,  411 => 250,  409 => 249,  405 => 247,  403 => 245,  402 => 244,  401 => 238,  398 => 237,  396 => 236,  393 => 235,  390 => 234,  387 => 233,  385 => 232,  380 => 231,  378 => 230,  373 => 229,  367 => 227,  365 => 226,  362 => 225,  360 => 224,  357 => 223,  350 => 220,  344 => 218,  342 => 217,  339 => 216,  337 => 215,  331 => 212,  327 => 211,  324 => 210,  319 => 209,  313 => 29,  307 => 501,  305 => 500,  303 => 498,  302 => 497,  301 => 496,  300 => 495,  299 => 494,  298 => 493,  297 => 492,  296 => 491,  295 => 490,  294 => 489,  293 => 488,  292 => 487,  291 => 486,  290 => 485,  289 => 484,  288 => 483,  287 => 482,  286 => 481,  285 => 480,  284 => 479,  283 => 478,  282 => 477,  281 => 476,  280 => 475,  277 => 471,  276 => 470,  273 => 468,  267 => 466,  263 => 465,  261 => 464,  259 => 463,  257 => 462,  256 => 461,  253 => 459,  251 => 458,  249 => 457,  247 => 456,  245 => 453,  244 => 452,  243 => 450,  241 => 448,  237 => 203,  236 => 202,  235 => 199,  232 => 195,  231 => 194,  230 => 191,  228 => 190,  226 => 189,  223 => 181,  222 => 180,  221 => 178,  219 => 177,  216 => 172,  215 => 170,  213 => 169,  211 => 168,  208 => 164,  207 => 162,  206 => 161,  205 => 159,  204 => 156,  202 => 155,  199 => 151,  198 => 149,  197 => 148,  196 => 146,  195 => 143,  193 => 142,  189 => 138,  188 => 137,  187 => 135,  186 => 133,  184 => 132,  181 => 127,  180 => 125,  178 => 124,  176 => 120,  175 => 118,  173 => 117,  171 => 116,  169 => 115,  167 => 113,  164 => 110,  162 => 109,  160 => 107,  157 => 104,  155 => 103,  153 => 102,  151 => 101,  149 => 99,  148 => 98,  147 => 97,  144 => 92,  141 => 90,  139 => 89,  137 => 88,  135 => 87,  132 => 84,  130 => 83,  128 => 81,  126 => 80,  124 => 79,  122 => 77,  120 => 76,  119 => 75,  118 => 74,  116 => 73,  114 => 72,  112 => 71,  110 => 70,  108 => 69,  106 => 67,  104 => 66,  101 => 63,  98 => 59,  97 => 58,  96 => 57,  94 => 56,  92 => 55,  90 => 54,  88 => 51,  86 => 50,  84 => 49,  82 => 48,  80 => 47,  78 => 46,  76 => 45,  74 => 44,  72 => 43,  70 => 42,  68 => 41,  66 => 39,  64 => 38,  62 => 37,  60 => 36,  58 => 35,  56 => 34,  54 => 33,  52 => 32,  50 => 30,  42 => 29,);
    }

    public function getSourceContext()
    {
        return new Source("{#
    \"Edit Element\" layout template

    The following variables should be defined by the sub-template:

    - element: the source element or one of its drafts/revisions
    - hasRevisions: whether the element has revisions, which will determine whether the revision notes field should be displayed.
    - canDeleteDraft (optional): whether the current user is allowed to delete the draft (if it is one).
      If the current user created the draft, then it will be deletable regardless.
    - canUpdateSource (optional): whether the current user is allowed to update the source element
      (e.g. by publishing a draft or reverting the element to a prior revision)
    - canDuplicateSource: whether the current user is allowed to duplicate the source element
    - canAddAnother: whether the current user is allowed to create another source element after saving the current one
    - canDeleteSource: whether the current user is allowed to delete the source element
    - canDeleteForSite: whether the current user is allowed to delete the source element for the current site
    - redirectUrl: the URL that the user should be redirected to after saving the source element
    - addAnotherRedirectUrl: the URL that the user should be redirected to after opting to save and add another
    - saveSourceAction: the controller action that should be used to save the source element
    - duplicateSourceAction: the controller action that should be used to duplicate the source element
    - deleteSourceAction: the controller action that should be used to delete the source element
    - deleteForSiteAction: the controller action that should be used to delete the source element for the current site
    - saveDraftAction: the controller action that should be used to save a draft
    - deleteDraftAction: the controller action that should be used to delete a draft
    - publishDraftAction: the controller action that should be used to apply a draft onto the source element
    - revertSourceAction: the controller action that should be used to revert the source element to a revision
    - showStatusToggles: whether the “Enabled” / “Enabled” for <Site>” fields should be added to the details pane
#}

{% extends '_layouts/cp' %}
{% import '_includes/forms' as forms %}

{% set saveSourceAction = saveSourceAction ?? null %}
{% set duplicateSourceAction = duplicateSourceAction ?? null %}
{% set deleteSourceAction = deleteSourceAction ?? null %}
{% set deleteForSiteAction = deleteForSiteAction ?? null %}
{% set revertSourceAction = revertSourceAction ?? null %}
{% set saveDraftAction = saveDraftAction ?? null %}
{% set publishDraftAction = publishDraftAction ?? applyDraftAction ?? null %}
{% set deleteDraftAction = deleteDraftAction ?? null %}

{% set isDraft = element.getIsDraft() %}
{% set isRevision = element.getIsRevision() %}
{% set isCurrent = not isDraft and not isRevision %}
{% set allSites = craft.app.isMultiSite ? element.getSupportedSites() : [element.siteId] %}
{% set allEditableSiteIds = craft.app.sites.getEditableSiteIds() %}
{% set propSiteIds = allSites|filter(s => s.propagate ?? true)|column(s => s.siteId ?? s) %}
{% set propEditableSiteIds = propSiteIds|intersect(allEditableSiteIds) %}
{% set isMultiSiteElement = craft.app.isMultiSite and allSites|length > 1 %}
{% set addlEditableSiteIds = allSites|column(s => s.siteId ?? s)|diff(propSiteIds)|intersect(allEditableSiteIds) %}
{% set canEditMultipleSites = isMultiSiteElement and (propEditableSiteIds|length > 1 or addlEditableSiteIds|length) %}
{% set isUnpublishedDraft = element.getIsUnpublishedDraft() %}

{# See if this is a new site that isn’t supported by the source element yet #}
{% if isUnpublishedDraft %}
    {% set isNewlySupportedSite = true %}
{% elseif isDraft %}
    {% set isNewlySupportedSite = not element.find()
        .id(element.getSourceId())
        .siteId(element.siteId)
        .anyStatus()
        .exists() %}
{% else %}
    {% set isNewlySupportedSite = false %}
{% endif %}

{% set previewTargets = element.getPreviewTargets() %}
{% set enablePreview = previewTargets and not craft.app.request.isMobileBrowser(true) %}

{% set canDeleteDraft = isDraft and ((canDeleteDraft ?? false) or element.creatorId == currentUser.id) and deleteDraftAction %}
{% set canUpdateSource = canUpdateSource ?? false %}
{% set canDuplicateSource = canDuplicateSource ?? false %}
{% set canAddAnother = canAddAnother ?? false %}
{% set canDeleteSource = canDeleteSource ?? false %}
{% set canDeleteForSite = (canDeleteForSite ?? false) and deleteForSiteAction and
    canDeleteForSite and isMultiSiteElement and propSiteIds|length > 1 and
    ((isCurrent and canDeleteSource) or (isDraft and canDeleteDraft and isNewlySupportedSite)) %}
{% set canEdit = canEdit ?? (canUpdateSource or canDuplicateSource or canAddAnother or saveDraftAction) %}

{% set redirectUrl = redirectUrl ?? craft.app.config.general.getPostCpLoginRedirect() %}
{% set addAnotherRedirectUrl = addAnotherRedirectUrl ?? null %}
{% set hashedCpEditUrl = '{cpEditUrl}'|hash %}

{% if not isRevision %}
    {% set fullPageForm = true %}
{% endif %}

{% if isDraft %}
    {% do craft.app.session.authorize('previewDraft:' ~ element.draftId) %}
{% elseif isRevision %}
    {% do craft.app.session.authorize('previewRevision:' ~ element.revisionId) %}
{% else %}
    {% do craft.app.session.authorize('previewElement:' ~ element.id) %}
{% endif %}

{# If this is an unpublished draft, then we should only show status toggles if the
   user actually has permission to publish chanegs #}
{% set showStatusToggles = (showStatusToggles ?? true) and
    element.hasStatuses() and
    (not isUnpublishedDraft or canUpdateSource) %}

{% if not isDraft and not canUpdateSource %}
    {% set saveShortcut = false %}
{% elseif isCurrent and canUpdateSource %}
    {% set saveShortcutRedirect = '{cpEditUrl}' %}
{% endif %}

{% set form = element.getFieldLayout().createForm(element, isRevision or not canEdit) %}

{% if tabs is not defined %}
    {% set tabs = form.getTabMenu() %}
{% endif %}

{% set settingsHtml = (block('settings') ?? '')|trim %}

{% set formActions = [] %}
{% if isCurrent %}
    {% if canUpdateSource and saveSourceAction %}
        {% set formActions = formActions|push({
            label: 'Save and continue editing'|t('app'),
            redirect: hashedCpEditUrl,
            shortcut: true,
            retainScroll: true,
        }) %}
        {% if addAnotherRedirectUrl %}
            {% set formActions = formActions|push({
                label: 'Save and add another'|t('app'),
                redirect: addAnotherRedirectUrl|hash,
                shortcut: true,
                shift: true,
            }) %}
        {% endif %}
        {% if canDuplicateSource and duplicateSourceAction %}
            {% set formActions = formActions|push({
                label: 'Save as a new {type}'|t('app', {
                    type: element.lowerDisplayName(),
                }),
                action: duplicateSourceAction,
                redirect: hashedCpEditUrl,
            }) %}
        {% endif %}
    {% endif %}
    {% if canDeleteForSite %}
        {% set formActions = formActions|push({
            destructive: true,
            label: 'Delete {type} for this site'|t('app', {
                type: element.lowerDisplayName()
            }),
            action: deleteForSiteAction,
            redirect: (redirectUrl ~ '#')|hash,
            confirm: 'Are you sure you want to delete the {type} for this site?'|t('app', {
                type: element.lowerDisplayName(),
            }),
        }) %}
    {% endif %}
    {% if canDeleteSource and deleteSourceAction %}
        {% set formActions = formActions|push({
            destructive: true,
            label: 'Delete {type}'|t('app', {
                type: element.lowerDisplayName()
            }),
            action: deleteSourceAction,
            redirect: (redirectUrl ~ '#')|hash,
            confirm: 'Are you sure you want to delete this {type}?'|t('app', {
                type: element.lowerDisplayName(),
            }),
        }) %}
    {% endif %}
{% elseif isDraft %}
    {% if saveDraftAction %}
        {% set formActions = formActions|push({
            label: 'Save and continue editing'|t('app'),
            action: saveDraftAction,
            shortcut: true,
            retainScroll: true,
        }) %}
    {% endif %}
    {% if canUpdateSource and publishDraftAction and addAnotherRedirectUrl %}
        {% set formActions = formActions|push({
            label: 'Publish and add another'|t('app'),
            action: publishDraftAction,
            redirect: addAnotherRedirectUrl|hash,
            shortcut: true,
            shift: true,
            data: {
                autosave: false,
            },
        }) %}
    {% endif %}
    {% if canDeleteDraft %}
        {% if canDeleteForSite %}
            {% set formActions = formActions|push({
                destructive: true,
                label: 'Delete draft for this site'|t('app'),
                action: deleteForSiteAction,
                redirect: (redirectUrl ~ '#')|hash,
                confirm: 'Are you sure you want to delete the draft for this site?'|t('app'),
            }) %}
        {% endif %}
        {% set formActions = formActions|push({
            destructive: true,
            label: 'Delete draft'|t('app'),
            action: deleteDraftAction,
            redirect: isUnpublishedDraft ? redirectUrl|hash : hashedCpEditUrl,
            confirm: 'Are you sure you want to delete this draft?'|t('app'),
        }) %}
    {% endif %}
{% endif %}

{% block header %}
    <div class=\"flex flex-nowrap\">
        {{ block('pageTitle') }}
        {{ block('contextMenu') }}
    </div>
    <div class=\"flex\" id=\"action-buttons\">
        {% if previewTargets %}
            <div class=\"btngroup\">
                {% if enablePreview %}
                    <button type=\"button\" id=\"preview-btn\" class=\"btn\">{{ \"Preview\"|t('app') }}</button>
                {% endif %}
                <button type=\"button\" id=\"share-btn\" class=\"btn\">{{ 'View'|t('app') }}</button>
            </div>
        {% endif %}

        {% if isCurrent and saveDraftAction %}
            <div id=\"save-draft-btn-container\">
                {% if canUpdateSource and saveSourceAction %}
                    <button type=\"button\" id=\"save-draft-btn\" class=\"btn\">{{ 'Save as a draft'|t('app') }}</button>
                {% else %}
                    <button type=\"submit\" id=\"save-draft-btn\" class=\"btn submit\">{{ 'Save as a draft'|t('app') }}</button>
                    {% if formActions|length %}
                        <button type=\"button\" class=\"btn menubtn\" aria-label=\"{{ 'Actions'|t('app') }}\" data-icon=\"settings\"></button>
                        {% include '_layouts/components/form-action-menu' %}
                    {% endif %}
                {% endif %}
            </div>
        {% elseif isDraft and canUpdateSource and publishDraftAction %}
            <div id=\"publish-draft-btn-container\">
                {{ tag('button', {
                    type: 'button',
                    class: ['btn', 'secondary', 'formsubmit'],
                    text: 'Publish draft'|t('app'),
                    title: forms.shortcutText('S', false, true),
                    data: {
                        action: publishDraftAction,
                        redirect: hashedCpEditUrl,
                    },
                }) }}
            </div>
        {% elseif isRevision and canUpdateSource and revertSourceAction %}
            <form method=\"post\" accept-charset=\"UTF-8\">
                {{ csrfInput() }}
                {{ actionInput(revertSourceAction) }}
                {{ redirectInput('{cpEditUrl}') }}
                {{ hiddenInput('revisionId', element.revisionId) }}
                <div class=\"secondary-buttons\">
                    <button type=\"button\" class=\"btn secondary formsubmit\">{{ 'Revert {type} to this revision'|t('app', { type: element.lowerDisplayName() }) }}</button>
                </div>
            </form>
        {% endif %}

        {{ block('actionButton') }}
    </div>
{% endblock %}

{% block contextMenu %}
    {% if isMultiSiteElement or saveDraftAction or element.find().revisionOf(element).exists() %}
        {% include \"_includes/revisionmenu\" with {
            supportedSiteIds: propSiteIds,
            canHaveDrafts: saveDraftAction is not empty,
        } %}
    {% endif %}
{% endblock %}

{% block actionButton %}
    {% if isCurrent and canUpdateSource and saveSourceAction %}
        <div id=\"save-btn-container\" class=\"btngroup submit\">
            {{ tag('button', {
                type: 'submit',
                class: ['btn', 'submit'],
                text: 'Save'|t('app'),
            }) }}
            <button type=\"button\" class=\"btn submit menubtn\"></button>
            {% include '_layouts/components/form-action-menu' %}
        </div>
    {% elseif isDraft %}
        <div id=\"save-btn-container\" class=\"btngroup submit\">
            <button type=\"submit\" class=\"btn submit\">{{ 'Save draft'|t('app') }}</button>
            {% if canDeleteDraft %}
                <button type=\"button\" class=\"btn submit menubtn\"></button>
                {% include '_layouts/components/form-action-menu' %}
            {% endif %}
        </div>
    {% endif %}
{% endblock %}

{% block main %}
    {% if not isRevision %}
        {# action and redirect params #}
        {% if isCurrent and canUpdateSource and saveSourceAction %}
            {# current revision -- user can update source #}
            {{ actionInput(saveSourceAction, {id: 'action'}) }}
        {% elseif isDraft and saveDraftAction %}
            {{ actionInput(saveDraftAction, {id: 'action'}) }}
        {% endif %}
        {{ redirectInput(redirectUrl) }}

        {# siteId param #}
        {% if craft.app.isMultiSite %}
            {{ hiddenInput('siteId', element.siteId) }}
        {% endif %}

        {# propagateAll param #}
        {% if isUnpublishedDraft and craft.app.request.getQueryParam('fresh') %}
            {{ hiddenInput('propagateAll', '1') }}
        {% endif %}
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block content %}
    {% if not isRevision %}
        {{ hiddenInput('sourceId', element.getSourceId()) }}
    {% else %}
        {{ hiddenInput('revisionId', entry.revisionId) }}
    {% endif %}

    <div id=\"fields\">
        {{ form.render()|raw }}
    </div>
{% endblock %}

{% block details %}
    {% if settingsHtml %}
        <div id=\"settings\" class=\"meta\">
            {{ settingsHtml|raw }}
        </div>
    {% endif %}

    {% if showStatusToggles and isMultiSiteElement %}
        <div class=\"meta\">
            {{ forms.lightswitchField({
                status: element.getAttributeStatus('enabled'),
                label: 'Enabled for {site}'|t('app', { site: element.site.name|t('site')|e }) ~
                    (canEditMultipleSites ? tag('button', {
                        type: 'button',
                        id: 'expand-status-btn',
                        class: ['btn'],
                        data: {
                            icon: 'ellipsis',
                        },
                    })),
                id: \"enabledForSite-#{element.siteId}\",
                name: \"enabledForSite[#{element.siteId}]\",
                on: element.enabled and element.getEnabledForSite(),
                disabled: isRevision,
            }) }}
        </div>
    {% endif %}

    <div id=\"meta-details\" class=\"meta read-only\">
        {% block meta %}
            {% if element.hasStatuses() %}
                {% if isUnpublishedDraft %}
                    {% set statusColor = 'white' %}
                    {% set statusLabel = 'Draft'|t('app') %}
                {% else %}
                    {% set status = element.getStatus() %}
                    {% set statusDef = element.statuses()[status] ?? null %}
                    {% set statusColor = statusDef.color ?? status %}
                    {% set statusLabel = statusDef.label ?? statusDef ?? status|ucfirst %}
                {% endif %}
                <div class=\"data\">
                    <h5 class=\"heading\">{{ 'Status'|t('app') }}</h5>
                    <div id=\"status-value\" class=\"value\"><span class=\"status {{ statusColor }}\"></span>{{ statusLabel }}</div>
                </div>
            {% endif %}
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Created at\"|t('app') }}</h5>
                <div id=\"date-created-value\" class=\"value\">{{ element.dateCreated|datetime('short') }}</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Updated at\"|t('app') }}</h5>
                <div id=\"date-updated-value\" class=\"value\">{{ element.dateUpdated|datetime('short') }}</div>
            </div>
            {% if isRevision %}
                {% set revisionNotes = element.revisionNotes %}
            {% elseif not isDraft and element.currentRevision %}
                {% set revisionNotes = element.currentRevision.revisionNotes %}
            {% else %}
                {% set revisionNotes = null %}
            {% endif %}
            {% if revisionNotes %}
                <div class=\"data\">
                    <h5 class=\"heading\">{{ \"Notes\"|t('app') }}</h5>
                    <div class=\"value\">{{ revisionNotes }}</div>
                </div>
            {% endif %}
        {% endblock %}
    </div>

    {% if (isCurrent and (hasRevisions ?? false)) or isDraft %}
        {{ forms.textarea({
            id: 'notes',
            class: ['nicetext'],
            name: 'notes',
            placeholder: 'Notes about your changes'|t('app'),
            value: isCurrent ? (notes ?? null) : element.draftNotes,
            inputAttributes: {
                aria: {
                    label: 'Notes about your changes'|t('app'),
                },
            },
        }) }}
    {% endif %}

    {% if isDraft and element.getIsOutdated() %}
        {% do craft.app.session.authorize('mergeDraftSourceChanges:' ~ element.draftId) %}
        <div class=\"meta read-only warning\">
            <p>{{ 'The source {type} has been updated recently.'|t('app', {type: element.lowerDisplayName()}) }}</p>
            <div class=\"flex flex-nowrap\">
                {% if element.trackChanges %}
                    {{ tag('button', {
                        type: 'button',
                        id: 'merge-changes-btn',
                        class: ['btn'],
                        text: 'Merge changes into draft'|t('app'),
                    }) }}
                    <div id=\"merge-changes-spinner\" class=\"spinner hidden\"></div>
                {% endif %}
            </div>
        </div>
    {% endif %}
{% endblock %}

{% block settings %}
    {% if showStatusToggles and not isMultiSiteElement %}
        {{ forms.lightswitchField({
            status: element.getAttributeStatus('enabled'),
            label: 'Enabled'|t('app'),
            id: 'enabled',
            name: 'enabled',
            on: element.enabled,
            disabled: isRevision,
        }) }}
    {% endif %}
{% endblock %}

{% if canEditMultipleSites and element.enabled %}
    {# get the element's statuses across all sites #}
    {% set siteStatusesQuery = element.find()
        .select(['elements_sites.siteId', 'elements_sites.enabled'])
        .id(element.id)
        .siteId(propEditableSiteIds)
        .anyStatus()
        .asArray() %}
    {% if isDraft %}
        {% do siteStatusesQuery.drafts() %}
    {% elseif isRevision %}
        {% do siteStatusesQuery.revisions() %}
    {% endif %}
    {% set siteStatuses = siteStatusesQuery
        .pairs()|map(s => s ? true : false) %}
{% elseif canEditMultipleSites %}
    {% set siteStatusValues = {} %}
    {% for siteId in propEditableSiteIds %}
        {% set siteStatusValues = siteStatusValues|merge([false]) %}
    {% endfor %}
    {% set siteStatuses = combine(propEditableSiteIds, siteStatusValues) %}
{% else %}
    {% set siteStatuses = {
        (\"#{element.siteId}\"): element.enabled ? true : false
    } %}
{% endif %}

{% set settings = {
    elementType: className(element),
    sourceId: element.getSourceId(),
    siteId: element.siteId,
    isUnpublishedDraft: isUnpublishedDraft,
    enabled: element.enabled ? true : false,
    enabledForSite: element.enabled and element.getEnabledForSite(),
    isLive: isCurrent and element.enabled and element.getEnabledForSite() and element.getRoute(),
    siteStatuses: siteStatuses,
    addlSiteIds: addlEditableSiteIds|values,
    cpEditUrl: element.cpEditUrl,
    draftId: element.draftId,
    revisionId: element.revisionId,
    draftName: isDraft ? element.draftName : null,
    canEditMultipleSites: canEditMultipleSites,
    canUpdateSource: canUpdateSource,
    saveDraftAction: saveDraftAction,
    deleteDraftAction: deleteDraftAction,
    publishDraftAction: publishDraftAction,
    hashedCpEditUrl: hashedCpEditUrl,
    hashedAddAnotherRedirectUrl: addAnotherRedirectUrl ? addAnotherRedirectUrl|hash : null,
    enablePreview: enablePreview,
    previewTargets: previewTargets,
    siteToken: not element.getSite().enabled ? element.siteId|hash,
} %}
{% js %}
    window.draftEditor = new Craft.DraftEditor({{ settings|json_encode|raw }});
{% endjs %}
", "_layouts/element", "/var/www/html/vendor/craftcms/cms/src/templates/_layouts/element.html");
    }
}
