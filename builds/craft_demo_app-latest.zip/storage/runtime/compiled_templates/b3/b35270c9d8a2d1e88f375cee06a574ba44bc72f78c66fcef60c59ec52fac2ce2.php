<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/select */
class __TwigTemplate_ad7c3a8ff091db19388f5dc0479d31199b0a6e7cbfc9cf5893ffd633a2cbf0f4 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/select");
        // line 1
        $context["class"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "select", 1 => ((((        // line 3
$context["disabled"]) ?? (false))) ? ("disabled") : (null))]));
        // line 6
        $context["options"] = (($context["options"]) ?? ([]));
        // line 7
        $context["value"] = (($context["value"]) ?? (null));
        // line 8
        $context["hasOptgroups"] = false;
        // line 10
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 11
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 11, $this->source); })())], ((        // line 12
$context["containerAttributes"]) ?? ([])), true);
        // line 14
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 15
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 15, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 17
        echo "
";
        // line 18
        $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => ((        // line 19
$context["id"]) ?? (false)), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((((        // line 21
$context["toggle"]) ?? (false))) ? ("fieldtoggle") : (null))]), "name" => ((        // line 23
$context["name"]) ?? (false)), "autofocus" => (((        // line 24
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 24, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method")), "disabled" => ((        // line 25
$context["disabled"]) ?? (false)), "aria" => ["describedby" => ((        // line 27
$context["instructionsId"]) ?? (false))], "data" => ["target-prefix" => ((((        // line 30
$context["toggle"]) ?? (false))) ? ((($context["targetPrefix"]) ?? (""))) : (false))]], ((        // line 32
$context["inputAttributes"]) ?? ([])), true);
        // line 33
        echo "
";
        // line 34
        ob_start();
        // line 35
        echo "    ";
        ob_start();
        // line 36
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 36, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["option"]) {
            // line 37
            echo "            ";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "optgroup", [], "any", true, true)) {
                // line 38
                echo "                ";
                if ((isset($context["hasOptgroups"]) || array_key_exists("hasOptgroups", $context) ? $context["hasOptgroups"] : (function () { throw new RuntimeError('Variable "hasOptgroups" does not exist.', 38, $this->source); })())) {
                    // line 39
                    echo "                    </optgroup>
                ";
                } else {
                    // line 41
                    echo "                    ";
                    $context["hasOptgroups"] = true;
                    // line 42
                    echo "                ";
                }
                // line 43
                echo "                <optgroup label=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "optgroup", []), "html", null, true);
                echo "\">
            ";
            } else {
                // line 45
                echo "                ";
                $context["optionLabel"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "label", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "label", [])) : ($context["option"]));
                // line 46
                echo "                ";
                $context["optionValue"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [])) : ($context["key"]));
                // line 47
                echo "                ";
                $context["optionDisabled"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "disabled", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "disabled", [])) : (false));
                // line 48
                echo "                <option value=\"";
                echo twig_escape_filter($this->env, (isset($context["optionValue"]) || array_key_exists("optionValue", $context) ? $context["optionValue"] : (function () { throw new RuntimeError('Variable "optionValue" does not exist.', 48, $this->source); })()), "html", null, true);
                echo "\"";
                if ((((isset($context["optionValue"]) || array_key_exists("optionValue", $context) ? $context["optionValue"] : (function () { throw new RuntimeError('Variable "optionValue" does not exist.', 48, $this->source); })()) . "") === ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 48, $this->source); })()) . ""))) {
                    echo " selected";
                }
                if ((isset($context["optionDisabled"]) || array_key_exists("optionDisabled", $context) ? $context["optionDisabled"] : (function () { throw new RuntimeError('Variable "optionDisabled" does not exist.', 48, $this->source); })())) {
                    echo " disabled";
                }
                echo ">";
                echo twig_escape_filter($this->env, (isset($context["optionLabel"]) || array_key_exists("optionLabel", $context) ? $context["optionLabel"] : (function () { throw new RuntimeError('Variable "optionLabel" does not exist.', 48, $this->source); })()), "html", null, true);
                echo "</option>
            ";
            }
            // line 50
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "        ";
        if ((isset($context["hasOptgroups"]) || array_key_exists("hasOptgroups", $context) ? $context["hasOptgroups"] : (function () { throw new RuntimeError('Variable "hasOptgroups" does not exist.', 51, $this->source); })())) {
            // line 52
            echo "            </optgroup>
        ";
        }
        // line 54
        echo "    ";
        echo craft\helpers\Html::tag("select", ob_get_clean(),         // line 35
(isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 35, $this->source); })()));
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 34
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 34, $this->source); })()));
        craft\helpers\Template::endProfile("template", "_includes/forms/select");
    }

    public function getTemplateName()
    {
        return "_includes/forms/select";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 34,  143 => 35,  141 => 54,  137 => 52,  134 => 51,  128 => 50,  113 => 48,  110 => 47,  107 => 46,  104 => 45,  98 => 43,  95 => 42,  92 => 41,  88 => 39,  85 => 38,  82 => 37,  77 => 36,  74 => 35,  72 => 34,  69 => 33,  67 => 32,  66 => 30,  65 => 27,  64 => 25,  63 => 24,  62 => 23,  61 => 21,  60 => 19,  59 => 18,  56 => 17,  53 => 15,  51 => 14,  49 => 12,  48 => 11,  47 => 10,  45 => 8,  43 => 7,  41 => 6,  39 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set class = (class ?? [])|explodeClass|merge([
    'select',
    (disabled ?? false) ? 'disabled' : null,
]|filter) %}

{%- set options = options ?? [] %}
{%- set value = value ?? null %}
{%- set hasOptgroups = false -%}

{%- set containerAttributes = {
    class: class,
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% set inputAttributes = {
    id: id ?? false,
    class: [
        (toggle ?? false) ? 'fieldtoggle' : null,
    ]|filter,
    name: name ?? false,
    autofocus: (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
    disabled: disabled ?? false,
    aria: {
        describedby: instructionsId ?? false,
    },
    data: {
        'target-prefix': (toggle ?? false) ? (targetPrefix ?? '') : false,
    },
}|merge(inputAttributes ?? [], recursive=true) %}

{% tag 'div' with containerAttributes %}
    {% tag 'select' with inputAttributes %}
        {% for key, option in options %}
            {% if option.optgroup is defined %}
                {% if hasOptgroups %}
                    </optgroup>
                {% else %}
                    {% set hasOptgroups = true %}
                {% endif %}
                <optgroup label=\"{{ option.optgroup }}\">
            {% else %}
                {% set optionLabel = (option.label is defined ? option.label : option) %}
                {% set optionValue = (option.value is defined ? option.value : key) %}
                {% set optionDisabled = (option.disabled is defined ? option.disabled : false) %}
                <option value=\"{{ optionValue }}\"{% if (optionValue~'') is same as (value~'') %} selected{% endif %}{% if optionDisabled %} disabled{% endif %}>{{ optionLabel }}</option>
            {% endif %}
        {% endfor %}
        {% if hasOptgroups %}
            </optgroup>
        {% endif %}
    {% endtag %}
{% endtag %}
", "_includes/forms/select", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/select.html");
    }
}
