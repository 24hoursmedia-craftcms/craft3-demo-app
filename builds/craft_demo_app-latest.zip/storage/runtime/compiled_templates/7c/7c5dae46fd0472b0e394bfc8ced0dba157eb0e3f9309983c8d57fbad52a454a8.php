<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/widgets/Feed/body */
class __TwigTemplate_49bf53b223dbd55c413618501ce9534c049c0c5d88b1a487da1aad84fc0890ad extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/widgets/Feed/body");
        // line 1
        echo "<table class=\"fullwidth\" dir=\"";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["feed"]) || array_key_exists("feed", $context) ? $context["feed"] : (function () { throw new RuntimeError('Variable "feed" does not exist.', 1, $this->source); })()), "direction", []), "html", null, true);
        echo "\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["feed"]) || array_key_exists("feed", $context) ? $context["feed"] : (function () { throw new RuntimeError('Variable "feed" does not exist.', 2, $this->source); })()), "items", []));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 3
            echo "        <tr>
            <td>
                ";
            // line 5
            if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "permalink", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "permalink", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "permalink", [])) : (false))) {
                // line 6
                echo "                    ";
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["href" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 7
$context["item"], "permalink", []), "target" => "_blank", "rel" => "noopener", "text" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 10
$context["item"], "title", [])]);
                // line 11
                echo "
                    ";
                // line 12
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "date", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "date", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "date", [])) : (false))) {
                    // line 13
                    echo "                        ";
                    echo $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "light nowrap", "text" => $this->extensions['craft\web\twig\Extension']->timestampFilter(craft\helpers\Template::attribute($this->env, $this->source,                     // line 15
$context["item"], "date", []), "short")]);
                    // line 16
                    echo "
                    ";
                }
                // line 18
                echo "                ";
            } else {
                // line 19
                echo "                    &nbsp;
                ";
            }
            // line 21
            echo "            </td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "</table>
";
        craft\helpers\Template::endProfile("template", "_components/widgets/Feed/body");
    }

    public function getTemplateName()
    {
        return "_components/widgets/Feed/body";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 24,  78 => 21,  74 => 19,  71 => 18,  67 => 16,  65 => 15,  63 => 13,  61 => 12,  58 => 11,  56 => 10,  55 => 7,  53 => 6,  51 => 5,  47 => 3,  43 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<table class=\"fullwidth\" dir=\"{{ feed.direction }}\">
    {% for item in feed.items %}
        <tr>
            <td>
                {% if item.permalink ?? false %}
                    {{ tag('a', {
                        href: item.permalink,
                        target: '_blank',
                        rel: 'noopener',
                        text: item.title,
                    }) }}
                    {% if item.date ?? false %}
                        {{ tag('span', {
                            class: 'light nowrap',
                            text: item.date|timestamp('short'),
                        }) }}
                    {% endif %}
                {% else %}
                    &nbsp;
                {% endif %}
            </td>
        </tr>
    {% endfor %}
</table>
", "_components/widgets/Feed/body", "/var/www/html/vendor/craftcms/cms/src/templates/_components/widgets/Feed/body.html");
    }
}
