<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/sitemenu */
class __TwigTemplate_e349a43514f1cd081cb95e5aabe18454170f29b3a3af09e9b5687866c27da649 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/sitemenu");
        // line 1
        $context["siteIds"] = (($context["siteIds"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "app", []), "sites", []), "getEditableSiteIds", [], "method")));
        // line 2
        if (twig_length_filter($this->env, (isset($context["siteIds"]) || array_key_exists("siteIds", $context) ? $context["siteIds"] : (function () { throw new RuntimeError('Variable "siteIds" does not exist.', 2, $this->source); })()))) {
            // line 3
            echo "    ";
            if ( !(isset($context["selectedSiteId"]) || array_key_exists("selectedSiteId", $context))) {
                // line 4
                echo "        ";
                if (twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", []), "sites", []), "currentSite", []), "id", []), (isset($context["siteIds"]) || array_key_exists("siteIds", $context) ? $context["siteIds"] : (function () { throw new RuntimeError('Variable "siteIds" does not exist.', 4, $this->source); })()))) {
                    // line 5
                    echo "            ";
                    $context["selectedSiteId"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", []), "sites", []), "currentSite", []), "id", []);
                    // line 6
                    echo "        ";
                } else {
                    // line 7
                    echo "            ";
                    $context["selectedSiteId"] = twig_first($this->env, (isset($context["siteIds"]) || array_key_exists("siteIds", $context) ? $context["siteIds"] : (function () { throw new RuntimeError('Variable "siteIds" does not exist.', 7, $this->source); })()));
                    // line 8
                    echo "        ";
                }
                // line 9
                echo "    ";
            }
            // line 10
            echo "    ";
            $context["groups"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", []), "sites", []), "getAllGroups", [], "method");
            // line 11
            echo "    <div>
        <button type=\"button\" id=\"context-btn\" class=\"btn menubtn sitemenubtn\" data-icon=\"world\">";
            // line 12
            (((isset($context["selectedSiteId"]) || array_key_exists("selectedSiteId", $context) ? $context["selectedSiteId"] : (function () { throw new RuntimeError('Variable "selectedSiteId" does not exist.', 12, $this->source); })())) ? (print (twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "app", []), "sites", []), "getSiteById", [0 => (isset($context["selectedSiteId"]) || array_key_exists("selectedSiteId", $context) ? $context["selectedSiteId"] : (function () { throw new RuntimeError('Variable "selectedSiteId" does not exist.', 12, $this->source); })())], "method"), "name", []), "site"), "html", null, true))) : (print ("")));
            echo "</button>
        <div class=\"menu\">
            ";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new RuntimeError('Variable "groups" does not exist.', 14, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
                // line 15
                echo "                ";
                $context["groupSiteIds"] = array_intersect(craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "getSiteIds", [], "method"), (isset($context["siteIds"]) || array_key_exists("siteIds", $context) ? $context["siteIds"] : (function () { throw new RuntimeError('Variable "siteIds" does not exist.', 15, $this->source); })()));
                // line 16
                echo "                ";
                if ((isset($context["groupSiteIds"]) || array_key_exists("groupSiteIds", $context) ? $context["groupSiteIds"] : (function () { throw new RuntimeError('Variable "groupSiteIds" does not exist.', 16, $this->source); })())) {
                    // line 17
                    echo "                    ";
                    if ((twig_length_filter($this->env, (isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new RuntimeError('Variable "groups" does not exist.', 17, $this->source); })())) > 1)) {
                        echo "<h6>";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "name", []), "site"), "html", null, true);
                        echo "</h6>";
                    }
                    // line 18
                    echo "                    <ul class=\"padded\">
                        ";
                    // line 19
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["groupSiteIds"]) || array_key_exists("groupSiteIds", $context) ? $context["groupSiteIds"] : (function () { throw new RuntimeError('Variable "groupSiteIds" does not exist.', 19, $this->source); })()));
                    foreach ($context['_seq'] as $context["_key"] => $context["siteId"]) {
                        // line 20
                        echo "                            ";
                        $context["site"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 20, $this->source); })()), "app", []), "sites", []), "getSiteById", [0 => $context["siteId"]], "method");
                        // line 21
                        echo "                            ";
                        $context["url"] = (((isset($context["urlFormat"]) || array_key_exists("urlFormat", $context))) ? (craft\helpers\UrlHelper::url($this->extensions['craft\web\twig\Extension']->replaceFilter((isset($context["urlFormat"]) || array_key_exists("urlFormat", $context) ? $context["urlFormat"] : (function () { throw new RuntimeError('Variable "urlFormat" does not exist.', 21, $this->source); })()), ["{id}" =>                         // line 22
$context["siteId"], "{handle}" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 23
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 23, $this->source); })()), "handle", [])]))) : (""));
                        // line 25
                        echo "                            <li><a";
                        if (((isset($context["selectedSiteId"]) || array_key_exists("selectedSiteId", $context) ? $context["selectedSiteId"] : (function () { throw new RuntimeError('Variable "selectedSiteId" does not exist.', 25, $this->source); })()) && ($context["siteId"] == (isset($context["selectedSiteId"]) || array_key_exists("selectedSiteId", $context) ? $context["selectedSiteId"] : (function () { throw new RuntimeError('Variable "selectedSiteId" does not exist.', 25, $this->source); })())))) {
                            echo " class=\"sel\"";
                        }
                        echo " data-site-id=\"";
                        echo twig_escape_filter($this->env, $context["siteId"], "html", null, true);
                        echo "\"";
                        if ((isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 25, $this->source); })())) {
                            echo " href=\"";
                            echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 25, $this->source); })()), "html", null, true);
                            echo "\"";
                        }
                        echo ">";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 25, $this->source); })()), "name", []), "site"), "html", null, true);
                        echo "</a></li>
                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['siteId'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 27
                    echo "                    </ul>
                ";
                }
                // line 29
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            echo "        </div>
    </div>
";
        }
        craft\helpers\Template::endProfile("template", "_elements/sitemenu");
    }

    public function getTemplateName()
    {
        return "_elements/sitemenu";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 30,  131 => 29,  127 => 27,  106 => 25,  104 => 23,  103 => 22,  101 => 21,  98 => 20,  94 => 19,  91 => 18,  84 => 17,  81 => 16,  78 => 15,  74 => 14,  69 => 12,  66 => 11,  63 => 10,  60 => 9,  57 => 8,  54 => 7,  51 => 6,  48 => 5,  45 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set siteIds = siteIds ?? craft.app.sites.getEditableSiteIds() %}
{% if siteIds|length %}
    {% if selectedSiteId is not defined %}
        {% if craft.app.sites.currentSite.id in siteIds %}
            {% set selectedSiteId = craft.app.sites.currentSite.id %}
        {% else %}
            {% set selectedSiteId = siteIds|first %}
        {% endif %}
    {% endif %}
    {% set groups = craft.app.sites.getAllGroups() %}
    <div>
        <button type=\"button\" id=\"context-btn\" class=\"btn menubtn sitemenubtn\" data-icon=\"world\">{{ selectedSiteId ? craft.app.sites.getSiteById(selectedSiteId).name|t('site') }}</button>
        <div class=\"menu\">
            {% for group in groups %}
                {% set groupSiteIds = group.getSiteIds()|intersect(siteIds) %}
                {% if groupSiteIds %}
                    {% if groups|length > 1 %}<h6>{{ group.name|t('site') }}</h6>{% endif %}
                    <ul class=\"padded\">
                        {% for siteId in groupSiteIds %}
                            {% set site = craft.app.sites.getSiteById(siteId) %}
                            {% set url = urlFormat is defined ? url(urlFormat|replace({
                                '{id}': siteId,
                                '{handle}': site.handle
                            })) %}
                            <li><a{% if selectedSiteId and siteId == selectedSiteId %} class=\"sel\"{% endif %} data-site-id=\"{{ siteId }}\"{% if url %} href=\"{{ url }}\"{% endif %}>{{ site.name|t('site') }}</a></li>
                        {% endfor %}
                    </ul>
                {% endif %}
            {% endfor %}
        </div>
    </div>
{% endif %}
", "_elements/sitemenu", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/sitemenu.html");
    }
}
