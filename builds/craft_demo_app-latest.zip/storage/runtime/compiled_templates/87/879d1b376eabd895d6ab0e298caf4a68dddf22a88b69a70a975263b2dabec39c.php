<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/comments_work/xhr_comment_form.twig */
class __TwigTemplate_056254cb21d47c14765b54795cfe90e8a37461026cf6af7e86e58bf2588f2072 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/comments_work/xhr_comment_form.twig");
        // line 7
        echo "
";
        // line 10
        echo "
";
        // line 12
        $context["commentsWork"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "commentsWork", []), "service", []);
        // line 13
        $context["justPosted"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["commentsWork"]) || array_key_exists("commentsWork", $context) ? $context["commentsWork"] : (function () { throw new RuntimeError('Variable "commentsWork" does not exist.', 13, $this->source); })()), "checkJustPosted", [], "method");
        // line 14
        echo "
<a name=\"comment_form\"></a>

";
        // line 17
        if ((isset($context["justPosted"]) || array_key_exists("justPosted", $context) ? $context["justPosted"] : (function () { throw new RuntimeError('Variable "justPosted" does not exist.', 17, $this->source); })())) {
            // line 18
            echo "
    <div class=\"bg-gray-300 rounded p-2\">
        <p>Thanks for your post.</p>
    </div>

";
        } else {
            // line 24
            echo "
    <div class=\"bg-gray-300 rounded p-2\">
        <form method=\"post\" action=\"";
            // line 26
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::actionUrl("/comments-work/default/post-comment"), "html", null, true);
            echo "#comment_form\"
              class=\"js-xhr-comments-form\"
              data-xhr-comments-action=\"";
            // line 28
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::actionUrl("/comments-work/default/xhr-post-comment"), "html", null, true);
            echo "\"
              data-xhr-comments-selector=\"";
            // line 29
            echo twig_escape_filter($this->env, (isset($context["comments_selector"]) || array_key_exists("comments_selector", $context) ? $context["comments_selector"] : (function () { throw new RuntimeError('Variable "comments_selector" does not exist.', 29, $this->source); })()), "html", null, true);
            echo "\"
        >
            ";
            // line 31
            echo craft\helpers\Html::csrfInput();
            echo "
            ";
            // line 32
            echo $this->extensions['twentyfourhoursmedia\commentswork\twigextensions\CommentsWorkTwigExtension']->signForm((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 32, $this->source); })()));
            echo "
           
            <input name=\"elementId\" value=\"";
            // line 34
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 34, $this->source); })()), "id", []), "html", null, true);
            echo "\" type=\"hidden\"/>
            <input name=\"siteId\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 35, $this->source); })()), "siteId", []), "html", null, true);
            echo "\" type=\"hidden\"/>
            <input name=\"commentFormat\" value=\"text\" type=\"hidden\"/>

            <p>Leave a comment here...</p>

            <div class=\"grid grid-cols-2 gap-2\">
                <div>
                    <label for=\"comment-title\">Title</label>
                </div>
                <div>
                    <input name=\"title\" id=\"comment-title\" type=\"text\" class=\"w-full\"/>
                </div>

                <div>
                    <label for=\"comment-content\">Comment</label>
                </div>
                <div>
                    <textarea name=\"comment\" rows=\"5\" id=\"comment-content\" class=\"w-full\"></textarea>
                </div>

                <div class=\"col-span-2 text-right\">
                    <input type=\"submit\" class=\"bg-blue-600 text-white rounded p-2\" value=\"Post comment\"/>
                </div>
            </div>
        </form>
    </div>

";
        }
        craft\helpers\Template::endProfile("template", "_components/comments_work/xhr_comment_form.twig");
    }

    public function getTemplateName()
    {
        return "_components/comments_work/xhr_comment_form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 35,  90 => 34,  85 => 32,  81 => 31,  76 => 29,  72 => 28,  67 => 26,  63 => 24,  55 => 18,  53 => 17,  48 => 14,  46 => 13,  44 => 12,  41 => 10,  38 => 7,);
    }

    public function getSourceContext()
    {
        return new Source("{#
Shows a form where users can enter a comment to an entry

Example:
{% include '_components/comments_worl/comment_form.twig' with {entry: entry} only %}
#}

{# @param entry                         the entry to show the comment form for #}
{# @param comments_selector   dom selector of the container that holds the comments #}

{# check if the user has just posted a comment and provide feedback #}
{% set commentsWork = craft.commentsWork.service %}
{% set justPosted = commentsWork.checkJustPosted() %}

<a name=\"comment_form\"></a>

{% if justPosted %}

    <div class=\"bg-gray-300 rounded p-2\">
        <p>Thanks for your post.</p>
    </div>

{% else %}

    <div class=\"bg-gray-300 rounded p-2\">
        <form method=\"post\" action=\"{{ actionUrl('/comments-work/default/post-comment') }}#comment_form\"
              class=\"js-xhr-comments-form\"
              data-xhr-comments-action=\"{{ actionUrl('/comments-work/default/xhr-post-comment') }}\"
              data-xhr-comments-selector=\"{{ comments_selector }}\"
        >
            {{ csrfInput() }}
            {{ signCommentForm(entry) }}
           
            <input name=\"elementId\" value=\"{{ entry.id }}\" type=\"hidden\"/>
            <input name=\"siteId\" value=\"{{ entry.siteId }}\" type=\"hidden\"/>
            <input name=\"commentFormat\" value=\"text\" type=\"hidden\"/>

            <p>Leave a comment here...</p>

            <div class=\"grid grid-cols-2 gap-2\">
                <div>
                    <label for=\"comment-title\">Title</label>
                </div>
                <div>
                    <input name=\"title\" id=\"comment-title\" type=\"text\" class=\"w-full\"/>
                </div>

                <div>
                    <label for=\"comment-content\">Comment</label>
                </div>
                <div>
                    <textarea name=\"comment\" rows=\"5\" id=\"comment-content\" class=\"w-full\"></textarea>
                </div>

                <div class=\"col-span-2 text-right\">
                    <input type=\"submit\" class=\"bg-blue-600 text-white rounded p-2\" value=\"Post comment\"/>
                </div>
            </div>
        </form>
    </div>

{% endif %}", "_components/comments_work/xhr_comment_form.twig", "/var/www/html/templates/_components/comments_work/xhr_comment_form.twig");
    }
}
