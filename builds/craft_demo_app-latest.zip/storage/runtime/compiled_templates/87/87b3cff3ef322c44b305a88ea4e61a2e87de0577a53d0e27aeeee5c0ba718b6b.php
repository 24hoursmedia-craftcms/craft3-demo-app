<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/toolbar */
class __TwigTemplate_aa34676c41f3cedddcaa246fcf5d8c66d0e820ac59ca5726b5aefa51cb9de9d7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/toolbar");
        // line 1
        $macros["__internal_27c4241c75d7044e6dfb3cb3b770aa5917f427742c9b9e2379914a01d8f482d1"] = $this->macros["__internal_27c4241c75d7044e6dfb3cb3b770aa5917f427742c9b9e2379914a01d8f482d1"] = $this->loadTemplate("_includes/forms", "_elements/toolbar", 1)->unwrap();
        // line 6
        echo "
";
        // line 7
        $macros["__internal_cc42f7926504f1d824558d566385533910323e547d90dc143c19ab5def09bd12"] = $this->macros["__internal_cc42f7926504f1d824558d566385533910323e547d90dc143c19ab5def09bd12"] = $this;
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Sort by {attribute}", 1 => "Score", 2 => "Structure", 3 => "Display in a table", 4 => "Display hierarchically", 5 => "Display as thumbnails"]], "method");
        // line 16
        echo "
";
        // line 17
        $context["elementInstance"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "app", []), "elements", []), "createElement", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 17, $this->source); })())], "method");
        // line 18
        $context["context"] = (((isset($context["context"]) || array_key_exists("context", $context))) ? ((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 18, $this->source); })())) : ("index"));
        // line 19
        $context["showStatusMenu"] = ((((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context)) && ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 19, $this->source); })()) != "auto"))) ? ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 19, $this->source); })())) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 19, $this->source); })()), "hasStatuses", [], "method")));
        // line 20
        $context["showSiteMenu"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 20, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) ? ((($context["showSiteMenu"]) ?? ("auto"))) : (false));
        // line 21
        if (((isset($context["showSiteMenu"]) || array_key_exists("showSiteMenu", $context) ? $context["showSiteMenu"] : (function () { throw new RuntimeError('Variable "showSiteMenu" does not exist.', 21, $this->source); })()) == "auto")) {
            // line 22
            echo "    ";
            $context["showSiteMenu"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 22, $this->source); })()), "isLocalized", [], "method");
        }
        // line 24
        $context["sortOptions"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 24, $this->source); })()), "sortOptions", [], "method");
        // line 25
        echo "
";
        // line 26
        if (((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 26, $this->source); })()) || ((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 26, $this->source); })()) == "index"))) {
            // line 27
            echo "    <div>
        <button type=\"button\" class=\"btn menubtn statusmenubtn\"><span class=\"status\"></span>";
            // line 28
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
            echo "</button>
        <div class=\"menu\">
            <ul class=\"padded\">
                <li><a data-status=\"\" class=\"sel\"><span class=\"status\"></span>";
            // line 31
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
            echo "</a></li>
                ";
            // line 32
            if ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 32, $this->source); })())) {
                // line 33
                echo "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 33, $this->source); })()), "statuses", [], "method"));
                foreach ($context['_seq'] as $context["status"] => $context["info"]) {
                    // line 34
                    echo "                        ";
                    $context["label"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [])) : ($context["info"]));
                    // line 35
                    echo "                        ";
                    $context["color"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [])) : (""));
                    // line 36
                    echo "                        <li><a data-status=\"";
                    echo twig_escape_filter($this->env, $context["status"], "html", null, true);
                    echo "\"><span class=\"status ";
                    echo twig_escape_filter($this->env, $context["status"], "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 36, $this->source); })()), "html", null, true);
                    echo "\"></span>";
                    echo twig_escape_filter($this->env, (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 36, $this->source); })()), "html", null, true);
                    echo "</a></li>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['status'], $context['info'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 38
                echo "                ";
            }
            // line 39
            echo "            </ul>
            ";
            // line 40
            if (((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 40, $this->source); })()) == "index")) {
                // line 41
                echo "                ";
                if ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 41, $this->source); })())) {
                    echo "<hr class=\"padded\">";
                }
                // line 42
                echo "                <ul class=\"padded\">
                    ";
                // line 43
                if ((($context["canHaveDrafts"]) ?? (false))) {
                    // line 44
                    echo "                        <li><a data-drafts><span class=\"icon\" data-icon=\"draft\" aria-hidden=\"true\"></span>";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Drafts", "app"), "html", null, true);
                    echo "</a></li>
                    ";
                }
                // line 46
                echo "                    <li><a data-trashed><span class=\"icon\" data-icon=\"trash\" aria-hidden=\"true\"></span>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Trashed", "app"), "html", null, true);
                echo "</a></li>
                </ul>
            ";
            }
            // line 49
            echo "        </div>
    </div>
";
        }
        // line 52
        if ((isset($context["showSiteMenu"]) || array_key_exists("showSiteMenu", $context) ? $context["showSiteMenu"] : (function () { throw new RuntimeError('Variable "showSiteMenu" does not exist.', 52, $this->source); })())) {
            // line 53
            echo "    ";
            $this->loadTemplate("_elements/sitemenu", "_elements/toolbar", 53)->display($context);
        }
        // line 55
        echo "<div class=\"flex-grow texticon search icon clearable\">
    ";
        // line 56
        echo twig_call_macro($macros["__internal_27c4241c75d7044e6dfb3cb3b770aa5917f427742c9b9e2379914a01d8f482d1"], "macro_text", [["placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app"), "inputAttributes" => ["aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app")]]]], 56, $context, $this->getSourceContext());
        // line 63
        echo "
    <div class=\"clear hidden\" title=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Clear", "app"), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Clear", "app"), "html", null, true);
        echo "\"></div>
</div>
<div>
    <button type=\"button\" class=\"btn menubtn sortmenubtn\"";
        // line 67
        if ((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 67, $this->source); })())) {
            echo " title=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sort by {attribute}", "app", ["attribute" => twig_call_macro($macros["__internal_cc42f7926504f1d824558d566385533910323e547d90dc143c19ab5def09bd12"], "macro_sortOptionLabel", [twig_first($this->env, (isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 67, $this->source); })()))], 67, $context, $this->getSourceContext())]), "html", null, true);
            echo "\"";
        }
        echo " data-icon=\"asc\">";
        echo (((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 67, $this->source); })())) ? (twig_call_macro($macros["__internal_cc42f7926504f1d824558d566385533910323e547d90dc143c19ab5def09bd12"], "macro_sortOptionLabel", [twig_first($this->env, (isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 67, $this->source); })()))], 67, $context, $this->getSourceContext())) : (""));
        echo "</button>
    <div class=\"menu\">
        <ul class=\"padded sort-attributes\">
            ";
        // line 70
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 70, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["sortOption"]) {
            // line 71
            echo "                <li>
                    ";
            // line 72
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["class" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 73
$context["loop"], "first", [])) ? ("sel") : ("")), "text" => twig_call_macro($macros["__internal_cc42f7926504f1d824558d566385533910323e547d90dc143c19ab5def09bd12"], "macro_sortOptionLabel", [            // line 74
$context["sortOption"]], 74, $context, $this->getSourceContext()), "data" => ["attr" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 76
$context["sortOption"], "attribute", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "attribute", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "attribute", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [])) : ($context["key"])))), "default-dir" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 77
$context["sortOption"], "defaultDir", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "defaultDir", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "defaultDir", [])) : (false))]]);
            // line 79
            echo "
                </li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['sortOption'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 82
        echo "        </ul>
        <hr>
        <ul class=\"padded sort-directions\">
            <li><a data-dir=\"asc\" class=\"sel\">";
        // line 85
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Ascending", "app"), "html", null, true);
        echo "</a></li>
            <li><a data-dir=\"desc\">";
        // line 86
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Descending", "app"), "html", null, true);
        echo "</a></li>
        </ul>
    </div>
</div>
";
        craft\helpers\Template::endProfile("template", "_elements/toolbar");
    }

    // line 3
    public function macro_sortOptionLabel($__sortOption__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "sortOption" => $__sortOption__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "sortOptionLabel");
            // line 4
            echo "    ";
            echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [])) : ((isset($context["sortOption"]) || array_key_exists("sortOption", $context) ? $context["sortOption"] : (function () { throw new RuntimeError('Variable "sortOption" does not exist.', 4, $this->source); })()))), "html", null, true);
            echo "
";
            craft\helpers\Template::endProfile("macro", "sortOptionLabel");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_elements/toolbar";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 4,  243 => 3,  233 => 86,  229 => 85,  224 => 82,  208 => 79,  206 => 77,  205 => 76,  204 => 74,  203 => 73,  202 => 72,  199 => 71,  182 => 70,  170 => 67,  162 => 64,  159 => 63,  157 => 56,  154 => 55,  150 => 53,  148 => 52,  143 => 49,  136 => 46,  130 => 44,  128 => 43,  125 => 42,  120 => 41,  118 => 40,  115 => 39,  112 => 38,  97 => 36,  94 => 35,  91 => 34,  86 => 33,  84 => 32,  80 => 31,  74 => 28,  71 => 27,  69 => 26,  66 => 25,  64 => 24,  60 => 22,  58 => 21,  56 => 20,  54 => 19,  52 => 18,  50 => 17,  47 => 16,  45 => 8,  43 => 7,  40 => 6,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from \"_includes/forms\" import text -%}

{% macro sortOptionLabel(sortOption) %}
    {{ sortOption.label ?? sortOption }}
{% endmacro %}

{% from _self import sortOptionLabel %}
{% do view.registerTranslations('app', [
    \"Sort by {attribute}\",
    \"Score\",
    \"Structure\",
    \"Display in a table\",
    \"Display hierarchically\",
    \"Display as thumbnails\",
]) %}

{% set elementInstance = craft.app.elements.createElement(elementType) %}
{% set context = context is defined ? context : 'index' %}
{% set showStatusMenu = (showStatusMenu is defined and showStatusMenu != 'auto' ? showStatusMenu : elementInstance.hasStatuses()) %}
{% set showSiteMenu = (craft.app.getIsMultiSite() ? (showSiteMenu ?? 'auto') : false) %}
{% if showSiteMenu == 'auto' %}
    {% set showSiteMenu = elementInstance.isLocalized() %}
{% endif %}
{% set sortOptions = elementInstance.sortOptions() %}

{% if showStatusMenu or context == 'index' %}
    <div>
        <button type=\"button\" class=\"btn menubtn statusmenubtn\"><span class=\"status\"></span>{{ \"All\"|t('app') }}</button>
        <div class=\"menu\">
            <ul class=\"padded\">
                <li><a data-status=\"\" class=\"sel\"><span class=\"status\"></span>{{ \"All\"|t('app') }}</a></li>
                {% if showStatusMenu %}
                    {% for status, info in elementInstance.statuses() %}
                        {% set label = info.label ?? info %}
                        {% set color = info.color ?? '' %}
                        <li><a data-status=\"{{ status }}\"><span class=\"status {{ status }} {{ color }}\"></span>{{ label }}</a></li>
                    {% endfor %}
                {% endif %}
            </ul>
            {% if context == 'index' %}
                {% if showStatusMenu %}<hr class=\"padded\">{% endif %}
                <ul class=\"padded\">
                    {% if canHaveDrafts ?? false %}
                        <li><a data-drafts><span class=\"icon\" data-icon=\"draft\" aria-hidden=\"true\"></span>{{ 'Drafts'|t('app') }}</a></li>
                    {% endif %}
                    <li><a data-trashed><span class=\"icon\" data-icon=\"trash\" aria-hidden=\"true\"></span>{{ \"Trashed\"|t('app') }}</a></li>
                </ul>
            {% endif %}
        </div>
    </div>
{% endif %}
{% if showSiteMenu %}
    {% include \"_elements/sitemenu\" %}
{% endif %}
<div class=\"flex-grow texticon search icon clearable\">
    {{ text({
        placeholder: \"Search\"|t('app'),
        inputAttributes: {
            aria: {
                label: 'Search'|t('app'),
            },
        },
    }) }}
    <div class=\"clear hidden\" title=\"{{ 'Clear'|t('app') }}\" aria-label=\"{{ 'Clear'|t('app') }}\"></div>
</div>
<div>
    <button type=\"button\" class=\"btn menubtn sortmenubtn\"{% if sortOptions %} title=\"{{ 'Sort by {attribute}'|t('app', { attribute: sortOptionLabel(sortOptions|first) }) }}\"{% endif %} data-icon=\"asc\">{{ sortOptions ? sortOptionLabel(sortOptions|first) }}</button>
    <div class=\"menu\">
        <ul class=\"padded sort-attributes\">
            {% for key, sortOption in sortOptions %}
                <li>
                    {{ tag('a', {
                        class: loop.first ? 'sel',
                        text: sortOptionLabel(sortOption),
                        data: {
                            attr: sortOption.attribute ?? sortOption.orderBy ?? key,
                            'default-dir': sortOption.defaultDir ?? false,
                        }
                    }) }}
                </li>
            {% endfor %}
        </ul>
        <hr>
        <ul class=\"padded sort-directions\">
            <li><a data-dir=\"asc\" class=\"sel\">{{ \"Ascending\"|t('app') }}</a></li>
            <li><a data-dir=\"desc\">{{ \"Descending\"|t('app') }}</a></li>
        </ul>
    </div>
</div>
", "_elements/toolbar", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/toolbar.html");
    }
}
