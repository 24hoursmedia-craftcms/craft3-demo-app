<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* comments-work/settings */
class __TwigTemplate_1d003b08d01634ab800ba3fe34b32985f20e9125fd2ca4feeacc28b98f28e6fe extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "comments-work/settings");
        // line 15
        echo "
";
        // line 16
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "comments-work/settings", 16)->unwrap();
        // line 17
        echo "
";
        // line 18
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 18, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\commentswork\\assetbundles\\commentswork\\CommentsWorkAsset"], "method");
        // line 19
        echo "

<p>Read setup and integration documentation
    <a href=\"https://github.com/24hoursmedia-craftcms/comments-work/blob/master/README.md\"  target=\"_blank\">here</a>
    or a quickstart <a
            href=\"https://github.com/24hoursmedia-craftcms/comments-work/blob/master/docs/quickstart.md\" target=\"_blank\">here</a>.</p>
<hr/>

";
        // line 27
        echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Auto approve comments", "comments-work"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether to set automatically approve and publish submitted comments.", "comments-work"), "id" => "autoApproveSwitch", "name" => "autoApprove", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 32
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 32, $this->source); })()), "autoApprove", [], "array")]], 27, $context, $this->getSourceContext());
        // line 33
        echo "

";
        // line 35
        echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow anonymous comments", "comments-work"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow anonymous users to post comments. Note: this may result in spam comments!", "comments-work"), "id" => "allowAnonymousSwitch", "name" => "allowAnonymous", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 40
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 40, $this->source); })()), "allowAnonymous", [], "array")]], 35, $context, $this->getSourceContext());
        craft\helpers\Template::endProfile("template", "comments-work/settings");
    }

    public function getTemplateName()
    {
        return "comments-work/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 40,  65 => 35,  61 => 33,  59 => 32,  58 => 27,  48 => 19,  46 => 18,  43 => 17,  41 => 16,  38 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * Comments Work plugin for Craft CMS 3.x
 *
 * Comments Work Settings.twig
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2018 24hoursmedia
 * @link      https://www.24hoursmedia.com
 * @package   CommentsWork
 * @since     1.0.0
 */
#}

{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\commentswork\\\\assetbundles\\\\commentswork\\\\CommentsWorkAsset\") %}


<p>Read setup and integration documentation
    <a href=\"https://github.com/24hoursmedia-craftcms/comments-work/blob/master/README.md\"  target=\"_blank\">here</a>
    or a quickstart <a
            href=\"https://github.com/24hoursmedia-craftcms/comments-work/blob/master/docs/quickstart.md\" target=\"_blank\">here</a>.</p>
<hr/>

{{ forms.lightswitchField({
    label: 'Auto approve comments' | t('comments-work'),
    instructions: 'Whether to set automatically approve and publish submitted comments.' | t('comments-work'),
    id: 'autoApproveSwitch',
    name: 'autoApprove',
    on: settings['autoApprove'],
}) }}

{{ forms.lightswitchField({
    label: 'Allow anonymous comments' | t('comments-work'),
    instructions: 'Allow anonymous users to post comments. Note: this may result in spam comments!' | t('comments-work'),
    id: 'allowAnonymousSwitch',
    name: 'allowAnonymous',
    on: settings['allowAnonymous'],
}) }}", "comments-work/settings", "/var/www/html/vendor/twentyfourhoursmedia/comments-work/src/templates/settings.twig");
    }
}
