<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/general/_index */
class __TwigTemplate_32bdc4ac8072148359d34c787f643e39a98f7f3483ebdc97e2f86396bd09a060 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/general/_index");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/general/_index", 2)->unwrap();
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("General Settings", "app");
        // line 4
        $context["fullPageForm"] = true;
        // line 6
        $context["crumbs"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 17
        $macros["__internal_0758d2b2e7c30819b59ce49f1c2736310ce242ef62d636491e77bdf31fa01285"] = $this->macros["__internal_0758d2b2e7c30819b59ce49f1c2736310ce242ef62d636491e77bdf31fa01285"] = $this;
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/general/_index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/general/_index");
    }

    // line 20
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 21
        echo "    ";
        echo craft\helpers\Html::actionInput("system-settings/save-general-settings");
        echo "
    ";
        // line 22
        echo craft\helpers\Html::redirectInput("settings");
        echo "

    ";
        // line 24
        echo twig_call_macro($macros["forms"], "macro_autosuggestField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("System Name", "app"), "id" => "name", "suggestEnvVars" => true, "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 30
(isset($context["system"]) || array_key_exists("system", $context) ? $context["system"] : (function () { throw new RuntimeError('Variable "system" does not exist.', 30, $this->source); })()), "name", [])]], 24, $context, $this->getSourceContext());
        // line 31
        echo "

    ";
        // line 33
        echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("System Status", "app"), "warning" => ((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 35
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 35, $this->source); })()), "app", []), "config", []), "general", []), "isSystemLive", []) === true) || (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 35, $this->source); })()), "app", []), "config", []), "general", []), "isSystemLive", []) === false))) ? (twig_call_macro($macros["__internal_0758d2b2e7c30819b59ce49f1c2736310ce242ef62d636491e77bdf31fa01285"], "macro_configWarning", ["isSystemLive"], 35, $context, $this->getSourceContext())) : ("")), "id" => "live", "name" => "live", "onLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Online", "app"), "offLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Offline", "app"), "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 40
(isset($context["system"]) || array_key_exists("system", $context) ? $context["system"] : (function () { throw new RuntimeError('Variable "system" does not exist.', 40, $this->source); })()), "live", [])]], 33, $context, $this->getSourceContext());
        // line 41
        echo "

    ";
        // line 43
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Retry Duration", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The number of seconds that the `Retry-After` HTTP header should be set to for 503 responses when the system is offline.", "app"), "id" => "retry-duration", "name" => "retryDuration", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 48
($context["system"] ?? null), "retryDuration", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["system"] ?? null), "retryDuration", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["system"] ?? null), "retryDuration", [])) : (null)), "inputmode" => "numeric", "size" => 4]], 43, $context, $this->getSourceContext());
        // line 51
        echo "

    ";
        // line 53
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Time Zone", "app"), "warning" => ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 55
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 55, $this->source); })()), "app", []), "config", []), "general", []), "timezone", [])) ? (twig_call_macro($macros["__internal_0758d2b2e7c30819b59ce49f1c2736310ce242ef62d636491e77bdf31fa01285"], "macro_configWarning", ["timezone"], 55, $context, $this->getSourceContext())) : ("")), "id" => "time-zone", "name" => "timeZone", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 58
(isset($context["system"]) || array_key_exists("system", $context) ? $context["system"] : (function () { throw new RuntimeError('Variable "system" does not exist.', 58, $this->source); })()), "timeZone", []), "options" =>         // line 59
(isset($context["timezoneOptions"]) || array_key_exists("timezoneOptions", $context) ? $context["timezoneOptions"] : (function () { throw new RuntimeError('Variable "timezoneOptions" does not exist.', 59, $this->source); })())]], 53, $context, $this->getSourceContext());
        // line 60
        echo "

    ";
        // line 62
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 62, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 62, $this->source); })()))) {
            // line 63
            echo "        <hr>

        ";
            // line 65
            craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 65, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Are you sure you want to delete the logo?"]], "method");
            // line 68
            echo "
        ";
            // line 69
            craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 69, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\fileupload\\FileUploadAsset"], "method");
            // line 70
            echo "
        ";
            // line 71
            echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Login Page Logo", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("SVG file recommended. The logo will be displayed at {size} wide.", "app", ["size" => "300px"])], twig_include($this->env, $context, "settings/general/_images/logo")], 71, $context, $this->getSourceContext());
            // line 74
            echo "

        ";
            // line 76
            echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site Icon", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Square SVG file recommended. The logo will be displayed at {size} by {size}.", "app", ["size" => "32px"])], twig_include($this->env, $context, "settings/general/_images/icon")], 76, $context, $this->getSourceContext());
            // line 79
            echo "

        <div class=\"clear\"></div>
    ";
        }
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 11
    public function macro_configWarning($__setting__ = null, $__file__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "setting" => $__setting__,
            "file" => $__file__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "configWarning");
            // line 12
            echo $this->extensions['craft\web\twig\Extension']->translateFilter("This is being overridden by the {setting} config setting.", "app", ["setting" => (((("<a href=\"https://craftcms.com/docs/3.x/config/config-settings.html#-" . twig_lower_filter($this->env,             // line 13
(isset($context["setting"]) || array_key_exists("setting", $context) ? $context["setting"] : (function () { throw new RuntimeError('Variable "setting" does not exist.', 13, $this->source); })()))) . "\" rel=\"noopener\" target=\"_blank\">") . (isset($context["setting"]) || array_key_exists("setting", $context) ? $context["setting"] : (function () { throw new RuntimeError('Variable "setting" does not exist.', 13, $this->source); })())) . "</a>")]);
            craft\helpers\Template::endProfile("macro", "configWarning");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "settings/general/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 13,  153 => 12,  138 => 11,  129 => 79,  127 => 76,  123 => 74,  121 => 71,  118 => 70,  116 => 69,  113 => 68,  111 => 65,  107 => 63,  105 => 62,  101 => 60,  99 => 59,  98 => 58,  97 => 55,  96 => 53,  92 => 51,  90 => 48,  89 => 43,  85 => 41,  83 => 40,  82 => 35,  81 => 33,  77 => 31,  75 => 30,  74 => 24,  69 => 22,  64 => 21,  59 => 20,  53 => 1,  51 => 17,  49 => 6,  47 => 4,  45 => 3,  43 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% import \"_includes/forms\" as forms %}
{% set title = \"General Settings\"|t('app') %}
{% set fullPageForm = true %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}


{% macro configWarning(setting, file) -%}
    {{ \"This is being overridden by the {setting} config setting.\"|t('app', {
        setting: '<a href=\"https://craftcms.com/docs/3.x/config/config-settings.html#-'~setting|lower~'\" rel=\"noopener\" target=\"_blank\">'~setting~'</a>'
    })|raw }}
{%- endmacro %}

{% from _self import configWarning %}


{% block content %}
    {{ actionInput('system-settings/save-general-settings') }}
    {{ redirectInput('settings') }}

    {{ forms.autosuggestField({
        first: true,
        label: \"System Name\"|t('app'),
        id: 'name',
        suggestEnvVars: true,
        name: 'name',
        value: system.name
    }) }}

    {{ forms.lightswitchField({
        label: \"System Status\"|t('app'),
        warning: (craft.app.config.general.isSystemLive is same as(true) or craft.app.config.general.isSystemLive is same as(false) ? configWarning('isSystemLive')),
        id: 'live',
        name: 'live',
        onLabel: 'Online'|t('app'),
        offLabel: 'Offline'|t('app'),
        on: system.live
    }) }}

    {{ forms.textField({
        label: 'Retry Duration'|t('app'),
        instructions: 'The number of seconds that the `Retry-After` HTTP header should be set to for 503 responses when the system is offline.'|t('app'),
        id: 'retry-duration',
        name: 'retryDuration',
        value: system.retryDuration ?? null,
        inputmode: 'numeric',
        size: 4,
    }) }}

    {{ forms.selectField({
        label: \"Time Zone\"|t('app'),
        warning: (craft.app.config.general.timezone ? configWarning('timezone')),
        id: 'time-zone',
        name: 'timeZone',
        value: system.timeZone,
        options: timezoneOptions
    }) }}

    {% if CraftEdition == CraftPro %}
        <hr>

        {% do view.registerTranslations('app', [
            \"Are you sure you want to delete the logo?\",
        ]) %}

        {% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fileupload\\\\FileUploadAsset\") %}

        {{ forms.field({
            label: \"Login Page Logo\"|t('app'),
            instructions: \"SVG file recommended. The logo will be displayed at {size} wide.\"|t('app', { size: '300px' })
        }, include('settings/general/_images/logo')) }}

        {{ forms.field({
            label: \"Site Icon\"|t('app'),
            instructions: \"Square SVG file recommended. The logo will be displayed at {size} by {size}.\"|t('app', { size: '32px' })
        }, include('settings/general/_images/icon')) }}

        <div class=\"clear\"></div>
    {% endif %}
{% endblock %}
", "settings/general/_index", "/var/www/html/vendor/craftcms/cms/src/templates/settings/general/_index.html");
    }
}
