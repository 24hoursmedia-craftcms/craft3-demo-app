<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _partials/top_nav.twig */
class __TwigTemplate_c96b505c849cd394a4a2da29826af72175817a53e3fe74587652a39f0a578030 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_partials/top_nav.twig");
        // line 1
        echo "<div class=\"text-white text-xs hidden sm:block\">

    <span class=\"bg-gray-900 p-2 rounded mr-2\">Current site: ";
        // line 3
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentSite"]) || array_key_exists("currentSite", $context) ? $context["currentSite"] : (function () { throw new RuntimeError('Variable "currentSite" does not exist.', 3, $this->source); })()), "name", []), "html", null, true);
        echo "</span>

    ";
        // line 5
        $context["sites"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", []), "sites", []), "getAllSites", [], "method");
        // line 6
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 6, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
            // line 7
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "baseUrl", []), "html", null, true);
            echo "\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "html", null, true);
            echo "</a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "
</div>";
        craft\helpers\Template::endProfile("template", "_partials/top_nav.twig");
    }

    public function getTemplateName()
    {
        return "_partials/top_nav.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 9,  54 => 7,  49 => 6,  47 => 5,  42 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"text-white text-xs hidden sm:block\">

    <span class=\"bg-gray-900 p-2 rounded mr-2\">Current site: {{ currentSite.name }}</span>

    {% set sites = craft.app.sites.getAllSites() %}
    {% for site in sites %}
    <a href=\"{{ site.baseUrl }}\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer\">{{ site.name }}</a>
    {% endfor %}

</div>", "_partials/top_nav.twig", "/var/www/html/templates/_partials/top_nav.twig");
    }
}
