<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/fieldLayoutDesigner */
class __TwigTemplate_786c557a0a5adfa68210828c3b7d4ee809aa71f14e10485820146275240094c7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $macros["_self"] = $this->macros["_self"] = $this;
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/fieldLayoutDesigner");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_includes/forms/fieldLayoutDesigner", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        $context["customizableTabs"] = (($context["customizableTabs"]) ?? (true));
        // line 4
        $context["customizableUi"] = (($context["customizableUi"]) ?? (true));
        // line 5
        $context["pretendTabName"] = (($context["pretendTabName"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Content", "app")));
        // line 6
        $context["fieldLayout"] = (($context["fieldLayout"]) ?? (Craft::createObject("craft\\models\\FieldLayout")));
        // line 7
        echo "
";
        // line 8
        $context["groups"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 8, $this->source); })()), "app", []), "fields", []), "getAllGroups", [], "method");
        // line 9
        echo "
";
        // line 10
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 10, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Apply", 1 => "Delete", 2 => "Give your tab a name.", 3 => "Move to the left", 4 => "Move to the right", 5 => "Remove", 6 => "Rename", 7 => "Required", 8 => "{pct} width"]], "method");
        // line 21
        echo "
";
        // line 39
        echo "
";
        // line 65
        echo "
";
        // line 79
        echo "
";
        // line 80
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 80, $this->source); })()), "id", [])) {
            // line 81
            echo "    ";
            echo craft\helpers\Html::hiddenInput("fieldLayoutId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 81, $this->source); })()), "id", []));
            echo "
";
        }
        // line 83
        echo "
<div id=\"fieldlayoutform\" class=\"layoutdesigner\">
    <div class=\"fld-workspace\">
        <div class=\"fld-tabs\">
            ";
        // line 87
        if ((isset($context["customizableTabs"]) || array_key_exists("customizableTabs", $context) ? $context["customizableTabs"] : (function () { throw new RuntimeError('Variable "customizableTabs" does not exist.', 87, $this->source); })())) {
            // line 88
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 88, $this->source); })()), "getTabs", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["tab"]) {
                // line 89
                echo "                    ";
                echo twig_call_macro($macros["_self"], "macro_tab", [craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "name", []), craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "elements", []), $context], 89, $context, $this->getSourceContext());
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tab'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 91
            echo "            ";
        } else {
            // line 92
            echo "                ";
            $context["elements"] = [];
            // line 93
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 93, $this->source); })()), "getTabs", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["tab"]) {
                // line 94
                echo "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "elements", []));
                foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
                    // line 95
                    echo "                        ";
                    $context["elements"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 95, $this->source); })()), $context["element"]);
                    // line 96
                    echo "                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 97
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tab'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 98
            echo "                ";
            echo twig_call_macro($macros["_self"], "macro_tab", [(isset($context["pretendTabName"]) || array_key_exists("pretendTabName", $context) ? $context["pretendTabName"] : (function () { throw new RuntimeError('Variable "pretendTabName" does not exist.', 98, $this->source); })()), (isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 98, $this->source); })()), $context], 98, $context, $this->getSourceContext());
            echo "
            ";
        }
        // line 100
        echo "        </div>

        ";
        // line 102
        if ((isset($context["customizableTabs"]) || array_key_exists("customizableTabs", $context) ? $context["customizableTabs"] : (function () { throw new RuntimeError('Variable "customizableTabs" does not exist.', 102, $this->source); })())) {
            // line 103
            echo "            <button type=\"button\" class=\"fld-new-tab-btn btn add icon\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New Tab", "app"), "html", null, true);
            echo "</button>
        ";
        }
        // line 105
        echo "    </div>

    <div class=\"fld-sidebar\">
        ";
        // line 108
        if ((isset($context["customizableUi"]) || array_key_exists("customizableUi", $context) ? $context["customizableUi"] : (function () { throw new RuntimeError('Variable "customizableUi" does not exist.', 108, $this->source); })())) {
            // line 109
            echo "            <div class=\"btngroup small fullwidth\" role=\"listbox\" aria-label=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Layout element types", "app"), "html", null, true);
            echo "\" tabindex=\"0\">
                <button type=\"button\" class=\"btn small active\" role=\"option\" aria-selected=\"true\" data-library=\"field\" tabindex=\"-1\">";
            // line 110
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Fields", "app"), "html", null, true);
            echo "</button>
                <button type=\"button\" class=\"btn small\" role=\"option\" aria-selected=\"false\" data-library=\"ui\" tabindex=\"-1\">";
            // line 111
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("UI Elements", "app"), "html", null, true);
            echo "</button>
            </div>
        ";
        }
        // line 114
        echo "
        <div class=\"fld-field-library\">
            <div class=\"texticon search icon clearable\">
                ";
        // line 117
        echo twig_call_macro($macros["forms"], "macro_text", [["class" => "fullwidth", "inputmode" => "search", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app")]], 117, $context, $this->getSourceContext());
        // line 121
        echo "
                <div class=\"clear hidden\" title=\"";
        // line 122
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Clear", "app"), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Clear", "app"), "html", null, true);
        echo "\"></div>
            </div>

            ";
        // line 125
        echo twig_call_macro($macros["_self"], "macro_fieldSelectors", [$this->extensions['craft\web\twig\Extension']->translateFilter("Standard Fields", "app"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 125, $this->source); })()), "getAvailableStandardFields", [], "method"), $context], 125, $context, $this->getSourceContext());
        echo "

            ";
        // line 127
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 127, $this->source); })()), "getAvailableCustomFields", [], "method"));
        foreach ($context['_seq'] as $context["groupName"] => $context["groupFields"]) {
            // line 128
            echo "                ";
            echo twig_call_macro($macros["_self"], "macro_fieldSelectors", [$context["groupName"], $context["groupFields"], $context], 128, $context, $this->getSourceContext());
            echo "
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['groupName'], $context['groupFields'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 130
        echo "        </div>

        ";
        // line 132
        if ((isset($context["customizableUi"]) || array_key_exists("customizableUi", $context) ? $context["customizableUi"] : (function () { throw new RuntimeError('Variable "customizableUi" does not exist.', 132, $this->source); })())) {
            // line 133
            echo "            <div class=\"fld-ui-library hidden\">
                ";
            // line 134
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldLayout"]) || array_key_exists("fieldLayout", $context) ? $context["fieldLayout"] : (function () { throw new RuntimeError('Variable "fieldLayout" does not exist.', 134, $this->source); })()), "getAvailableUiElements", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
                // line 135
                echo "                    ";
                echo twig_call_macro($macros["_self"], "macro_elementSelector", [$context["element"], true], 135, $context, $this->getSourceContext());
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 137
            echo "            </div>
        ";
        }
        // line 139
        echo "    </div>
</div>

";
        // line 142
        $context["jsSettings"] = ["customizableTabs" =>         // line 143
(isset($context["customizableTabs"]) || array_key_exists("customizableTabs", $context) ? $context["customizableTabs"] : (function () { throw new RuntimeError('Variable "customizableTabs" does not exist.', 143, $this->source); })()), "customizableUi" =>         // line 144
(isset($context["customizableUi"]) || array_key_exists("customizableUi", $context) ? $context["customizableUi"] : (function () { throw new RuntimeError('Variable "customizableUi" does not exist.', 144, $this->source); })()), "elementPlacementInputName" => call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), ["elementPlacements[__TAB_NAME__][]"]), "elementConfigInputName" => call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), ["elementConfigs[__ELEMENT_KEY__]"])];
        // line 148
        echo "
";
        // line 149
        ob_start();
        // line 150
        echo "    var initFLD = function() {
        new Craft.FieldLayoutDesigner(\"#";
        // line 151
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["fieldlayoutform"]), "html", null, true);
        echo "\", ";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["jsSettings"]) || array_key_exists("jsSettings", $context) ? $context["jsSettings"] : (function () { throw new RuntimeError('Variable "jsSettings" does not exist.', 151, $this->source); })()));
        echo ");
    };

    ";
        // line 154
        if ((isset($context["tab"]) || array_key_exists("tab", $context))) {
            // line 155
            echo "        var \$fldTab = \$('#";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [("tab-" . (isset($context["tab"]) || array_key_exists("tab", $context) ? $context["tab"] : (function () { throw new RuntimeError('Variable "tab" does not exist.', 155, $this->source); })()))]), "html", null, true);
            echo "');

        if (\$fldTab.hasClass('sel')) {
            initFLD();
        } else {
            \$fldTab.on('activate.fld', function() {
                initFLD();
                \$fldTab.off('activate.fld');
            });
        }
    ";
        } else {
            // line 166
            echo "        initFLD();
    ";
        }
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/fieldLayoutDesigner");
    }

    // line 22
    public function macro_tab($__tabName__ = null, $__elements__ = null, $__context__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "tabName" => $__tabName__,
            "elements" => $__elements__,
            "context" => $__context__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "tab");
            // line 23
            echo "    <div class=\"fld-tab\">
        <div class=\"tabs\">
            <div class=\"tab sel";
            // line 25
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 25, $this->source); })()), "customizableTabs", [])) {
                echo " draggable";
            }
            echo "\">
                <span>";
            // line 26
            echo twig_escape_filter($this->env, (isset($context["tabName"]) || array_key_exists("tabName", $context) ? $context["tabName"] : (function () { throw new RuntimeError('Variable "tabName" does not exist.', 26, $this->source); })()), "html", null, true);
            echo "</span>
                ";
            // line 27
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 27, $this->source); })()), "customizableTabs", [])) {
                // line 28
                echo "                    <a class=\"settings icon\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Edit", "app"), "html", null, true);
                echo "\" aria-label=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Edit", "app"), "html", null, true);
                echo "\"></a>
                ";
            }
            // line 30
            echo "            </div>
        </div>
        <div class=\"fld-tabcontent\">
            ";
            // line 33
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 33, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
                // line 34
                echo "                ";
                echo twig_call_macro($macros["_self"], "macro_elementSelector", [$context["element"], false], 34, $context, $this->getSourceContext());
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "        </div>
    </div>
";
            craft\helpers\Template::endProfile("macro", "tab");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 40
    public function macro_elementSelector($__element__ = null, $__forLibrary__ = null, $__attr__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "element" => $__element__,
            "forLibrary" => $__forLibrary__,
            "attr" => $__attr__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "elementSelector");
            // line 41
            echo "    ";
            if (call_user_func_array($this->env->getTest('instance of')->getCallable(), [(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 41, $this->source); })()), "craft\\fieldlayoutelements\\BaseField"])) {
                // line 42
                echo "        ";
                $context["attr"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((( !                // line 44
(isset($context["forLibrary"]) || array_key_exists("forLibrary", $context) ? $context["forLibrary"] : (function () { throw new RuntimeError('Variable "forLibrary" does not exist.', 44, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 44, $this->source); })()), "required", []))) ? ("fld-required") : (null))]), "data" => ["keywords" => ((                // line 47
(isset($context["forLibrary"]) || array_key_exists("forLibrary", $context) ? $context["forLibrary"] : (function () { throw new RuntimeError('Variable "forLibrary" does not exist.', 47, $this->source); })())) ? (twig_lower_filter($this->env, twig_join_filter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 47, $this->source); })()), "keywords", [], "method"), " "))) : (false))]], ((                // line 49
$context["attr"]) ?? ([])), true);
                // line 50
                echo "    ";
            }
            // line 51
            echo "    ";
            $context["settingsHtml"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 51, $this->source); })()), "settingsHtml", [], "method");
            // line 52
            echo "    ";
            echo $this->extensions['craft\web\twig\Extension']->attrFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 52, $this->source); })()), "selectorHtml", [], "method"), $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "fld-element", 1 => ((            // line 55
(isset($context["forLibrary"]) || array_key_exists("forLibrary", $context) ? $context["forLibrary"] : (function () { throw new RuntimeError('Variable "forLibrary" does not exist.', 55, $this->source); })())) ? ("unused") : (null))]), "data" => ["type" => get_class(            // line 58
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 58, $this->source); })())), "config" => craft\helpers\Template::attribute($this->env, $this->source,             // line 59
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 59, $this->source); })()), "toArray", [], "method"), "has-custom-width" => craft\helpers\Template::attribute($this->env, $this->source,             // line 60
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 60, $this->source); })()), "hasCustomWidth", [], "method"), "settings-html" => ((((            // line 61
(isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 61, $this->source); })())) ? (craft\helpers\Html::namespaceAttributes((isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 61, $this->source); })()), ("element" . twig_random($this->env)))) : (null))) ? ((((isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 61, $this->source); })())) ? (craft\helpers\Html::namespaceAttributes((isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 61, $this->source); })()), ("element" . twig_random($this->env)))) : (null))) : (false))]], ((            // line 63
$context["attr"]) ?? ([])), true));
            echo "
";
            craft\helpers\Template::endProfile("macro", "elementSelector");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 66
    public function macro_fieldSelectors($__groupName__ = null, $__groupFields__ = null, $__context__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "groupName" => $__groupName__,
            "groupFields" => $__groupFields__,
            "context" => $__context__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "fieldSelectors");
            // line 67
            echo "    ";
            $context["showGroup"] = craft\helpers\ArrayHelper::contains((isset($context["groupFields"]) || array_key_exists("groupFields", $context) ? $context["groupFields"] : (function () { throw new RuntimeError('Variable "groupFields" does not exist.', 67, $this->source); })()), function ($__f__) use ($context, $macros) { $context["f"] = $__f__; return  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 67, $this->source); })()), "fieldLayout", []), "isFieldIncluded", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["f"]) || array_key_exists("f", $context) ? $context["f"] : (function () { throw new RuntimeError('Variable "f" does not exist.', 67, $this->source); })()), "attribute", [], "method")], "method"); });
            // line 68
            echo "    <div class=\"fld-field-group";
            if ( !(isset($context["showGroup"]) || array_key_exists("showGroup", $context) ? $context["showGroup"] : (function () { throw new RuntimeError('Variable "showGroup" does not exist.', 68, $this->source); })())) {
                echo " hidden";
            }
            echo "\" data-name=\"";
            echo twig_escape_filter($this->env, twig_lower_filter($this->env, $this->extensions['craft\web\twig\Extension']->replaceFilter((isset($context["groupName"]) || array_key_exists("groupName", $context) ? $context["groupName"] : (function () { throw new RuntimeError('Variable "groupName" does not exist.', 68, $this->source); })()), "\"", "")), "html", null, true);
            echo "\">
        <h6>";
            // line 69
            echo twig_escape_filter($this->env, (isset($context["groupName"]) || array_key_exists("groupName", $context) ? $context["groupName"] : (function () { throw new RuntimeError('Variable "groupName" does not exist.', 69, $this->source); })()), "html", null, true);
            echo "</h6>
        ";
            // line 70
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["groupFields"]) || array_key_exists("groupFields", $context) ? $context["groupFields"] : (function () { throw new RuntimeError('Variable "groupFields" does not exist.', 70, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 71
                echo "            ";
                echo twig_call_macro($macros["_self"], "macro_elementSelector", [$context["field"], true, ["class" => [0 => ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,                 // line 73
(isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 73, $this->source); })()), "fieldLayout", []), "isFieldIncluded", [0 => craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "attribute", [], "method")], "method")) ? ("hidden") : (null))]]], 71, $context, $this->getSourceContext());
                // line 75
                echo "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 77
            echo "    </div>
";
            craft\helpers\Template::endProfile("macro", "fieldSelectors");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms/fieldLayoutDesigner";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  454 => 77,  447 => 75,  445 => 73,  443 => 71,  439 => 70,  435 => 69,  426 => 68,  423 => 67,  407 => 66,  395 => 63,  394 => 61,  393 => 60,  392 => 59,  391 => 58,  390 => 55,  388 => 52,  385 => 51,  382 => 50,  380 => 49,  379 => 47,  378 => 44,  376 => 42,  373 => 41,  357 => 40,  345 => 36,  336 => 34,  332 => 33,  327 => 30,  319 => 28,  317 => 27,  313 => 26,  307 => 25,  303 => 23,  287 => 22,  279 => 166,  264 => 155,  262 => 154,  254 => 151,  251 => 150,  249 => 149,  246 => 148,  244 => 144,  243 => 143,  242 => 142,  237 => 139,  233 => 137,  224 => 135,  220 => 134,  217 => 133,  215 => 132,  211 => 130,  202 => 128,  198 => 127,  193 => 125,  185 => 122,  182 => 121,  180 => 117,  175 => 114,  169 => 111,  165 => 110,  160 => 109,  158 => 108,  153 => 105,  147 => 103,  145 => 102,  141 => 100,  135 => 98,  129 => 97,  123 => 96,  120 => 95,  115 => 94,  110 => 93,  107 => 92,  104 => 91,  95 => 89,  90 => 88,  88 => 87,  82 => 83,  76 => 81,  74 => 80,  71 => 79,  68 => 65,  65 => 39,  62 => 21,  60 => 10,  57 => 9,  55 => 8,  52 => 7,  50 => 6,  48 => 5,  46 => 4,  44 => 3,  41 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import '_includes/forms' as forms %}

{% set customizableTabs = customizableTabs ?? true %}
{% set customizableUi = customizableUi ?? true %}
{% set pretendTabName = pretendTabName ?? 'Content'|t('app') %}
{% set fieldLayout = fieldLayout ?? create('craft\\\\models\\\\FieldLayout') %}

{% set groups = craft.app.fields.getAllGroups() %}

{% do view.registerTranslations('app', [
    'Apply',
    'Delete',
    'Give your tab a name.',
    'Move to the left',
    'Move to the right',
    'Remove',
    'Rename',
    'Required',
    '{pct} width',
]) %}

{% macro tab(tabName, elements, context) %}
    <div class=\"fld-tab\">
        <div class=\"tabs\">
            <div class=\"tab sel{% if context.customizableTabs %} draggable{% endif %}\">
                <span>{{ tabName }}</span>
                {% if context.customizableTabs %}
                    <a class=\"settings icon\" title=\"{{ 'Edit'|t('app') }}\" aria-label=\"{{ 'Edit'|t('app') }}\"></a>
                {% endif %}
            </div>
        </div>
        <div class=\"fld-tabcontent\">
            {% for element in elements %}
                {{ _self.elementSelector(element, false) }}
            {% endfor %}
        </div>
    </div>
{% endmacro %}

{% macro elementSelector(element, forLibrary, attr) %}
    {% if element is instance of('craft\\\\fieldlayoutelements\\\\BaseField') %}
        {% set attr = {
            class: [
                not forLibrary and element.required ? 'fld-required' : null,
            ]|filter,
            data: {
                keywords: forLibrary ? element.keywords()|join(' ')|lower : false,
            },
        }|merge(attr ?? {}, recursive=true) %}
    {% endif %}
    {% set settingsHtml = element.settingsHtml() %}
    {{ element.selectorHtml()|attr({
        class: [
            'fld-element',
            forLibrary ? 'unused' : null,
        ]|filter,
        data: {
            type: className(element),
            config: element.toArray(),
            'has-custom-width': element.hasCustomWidth(),
            'settings-html': (settingsHtml ? settingsHtml|namespaceAttributes(\"element#{random()}\") : null) ?: false,
        },
    }|merge(attr ?? {}, recursive=true)) }}
{% endmacro %}

{% macro fieldSelectors(groupName, groupFields, context) %}
    {% set showGroup = groupFields|contains(f => not context.fieldLayout.isFieldIncluded(f.attribute())) %}
    <div class=\"fld-field-group{% if not showGroup %} hidden{% endif %}\" data-name=\"{{ groupName|replace('\"', '')|lower }}\">
        <h6>{{ groupName }}</h6>
        {% for field in groupFields %}
            {{ _self.elementSelector(field, true, {
                class: [
                    context.fieldLayout.isFieldIncluded(field.attribute()) ? 'hidden' : null,
                ],
            }) }}
        {% endfor %}
    </div>
{% endmacro %}

{% if fieldLayout.id %}
    {{ hiddenInput('fieldLayoutId', fieldLayout.id) }}
{% endif %}

<div id=\"fieldlayoutform\" class=\"layoutdesigner\">
    <div class=\"fld-workspace\">
        <div class=\"fld-tabs\">
            {% if customizableTabs %}
                {% for tab in fieldLayout.getTabs() %}
                    {{ _self.tab(tab.name, tab.elements, _context) }}
                {% endfor %}
            {% else %}
                {% set elements = [] %}
                {% for tab in fieldLayout.getTabs() %}
                    {% for element in tab.elements %}
                        {% set elements = elements|push(element) %}
                    {% endfor %}
                {% endfor %}
                {{ _self.tab(pretendTabName, elements, _context) }}
            {% endif %}
        </div>

        {% if customizableTabs %}
            <button type=\"button\" class=\"fld-new-tab-btn btn add icon\">{{ \"New Tab\"|t('app') }}</button>
        {% endif %}
    </div>

    <div class=\"fld-sidebar\">
        {% if customizableUi %}
            <div class=\"btngroup small fullwidth\" role=\"listbox\" aria-label=\"{{ 'Layout element types'|t('app') }}\" tabindex=\"0\">
                <button type=\"button\" class=\"btn small active\" role=\"option\" aria-selected=\"true\" data-library=\"field\" tabindex=\"-1\">{{ 'Fields'|t('app') }}</button>
                <button type=\"button\" class=\"btn small\" role=\"option\" aria-selected=\"false\" data-library=\"ui\" tabindex=\"-1\">{{ 'UI Elements'|t('app') }}</button>
            </div>
        {% endif %}

        <div class=\"fld-field-library\">
            <div class=\"texticon search icon clearable\">
                {{ forms.text({
                    class: 'fullwidth',
                    inputmode: 'search',
                    placeholder: \"Search\"|t('app')
                }) }}
                <div class=\"clear hidden\" title=\"{{ 'Clear'|t('app') }}\" aria-label=\"{{ 'Clear'|t('app') }}\"></div>
            </div>

            {{ _self.fieldSelectors('Standard Fields'|t('app'), fieldLayout.getAvailableStandardFields(), _context) }}

            {% for groupName, groupFields in fieldLayout.getAvailableCustomFields() %}
                {{ _self.fieldSelectors(groupName, groupFields, _context) }}
            {% endfor %}
        </div>

        {% if customizableUi %}
            <div class=\"fld-ui-library hidden\">
                {% for element in fieldLayout.getAvailableUiElements() %}
                    {{ _self.elementSelector(element, true) }}
                {% endfor %}
            </div>
        {% endif %}
    </div>
</div>

{% set jsSettings = {
    customizableTabs: customizableTabs,
    customizableUi: customizableUi,
    elementPlacementInputName: 'elementPlacements[__TAB_NAME__][]'|namespaceInputName,
    elementConfigInputName: 'elementConfigs[__ELEMENT_KEY__]'|namespaceInputName,
} %}

{% js %}
    var initFLD = function() {
        new Craft.FieldLayoutDesigner(\"#{{ 'fieldlayoutform'|namespaceInputId }}\", {{ jsSettings|json_encode|raw }});
    };

    {% if tab is defined %}
        var \$fldTab = \$('#{{ \"tab-#{tab}\"|namespaceInputId }}');

        if (\$fldTab.hasClass('sel')) {
            initFLD();
        } else {
            \$fldTab.on('activate.fld', function() {
                initFLD();
                \$fldTab.off('activate.fld');
            });
        }
    {% else %}
        initFLD();
    {% endif %}
{% endjs %}
", "_includes/forms/fieldLayoutDesigner", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/fieldLayoutDesigner.html");
    }
}
