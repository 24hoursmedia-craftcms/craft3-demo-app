<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_components/fields/ViewsWorkField_settings */
class __TwigTemplate_eb5a53fe40a826cf1c5c19873cf5ca7ba871e63184b122fa31f692386bd1cbb1 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_components/fields/ViewsWorkField_settings");
        // line 15
        echo "
";
        // line 16
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "views-work/_components/fields/ViewsWorkField_settings", 16)->unwrap();
        // line 17
        echo "
";
        // line 18
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 18, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\viewswork\\assetbundles\\viewswork\\ViewsWorkAsset"], "method");
        craft\helpers\Template::endProfile("template", "views-work/_components/fields/ViewsWorkField_settings");
    }

    public function getTemplateName()
    {
        return "views-work/_components/fields/ViewsWorkField_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 18,  43 => 17,  41 => 16,  38 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * ViewsWork plugin for Craft CMS
 *
 * ViewsWorkField Field Settings
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2020 24hoursmedia
 * @link      https://www.24hoursmedia.com
 * @package   ViewsWork
 * @since     1.0.0
 */
#}

{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\viewswork\\\\assetbundles\\\\viewswork\\\\ViewsWorkAsset\") %}
{#
{{ forms.textField({
    label: 'Some Attribute',
    instructions: 'Enter some attribute here.',
    id: 'someAttribute',
    name: 'someAttribute',
    value: field['someAttribute']})
}}
#}", "views-work/_components/fields/ViewsWorkField_settings", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_components/fields/ViewsWorkField_settings.twig");
    }
}
