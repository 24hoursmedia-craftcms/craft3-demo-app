<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Table/settings */
class __TwigTemplate_0d410a8e73e6099e0e75167befd06f1da48c46781b688c7e23a6d2a1df7ec37b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Table/settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Table/settings", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        echo (isset($context["columnsField"]) || array_key_exists("columnsField", $context) ? $context["columnsField"] : (function () { throw new RuntimeError('Variable "columnsField" does not exist.', 3, $this->source); })());
        echo "
";
        // line 4
        echo (isset($context["defaultsField"]) || array_key_exists("defaultsField", $context) ? $context["defaultsField"] : (function () { throw new RuntimeError('Variable "defaultsField" does not exist.', 4, $this->source); })());
        echo "

";
        // line 6
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Min Rows", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The minimum number of rows the field is allowed to have.", "app"), "id" => "minRows", "name" => "minRows", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 11
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 11, $this->source); })()), "minRows", []), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 13
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 13, $this->source); })()), "getErrors", [0 => "minRows"], "method")]], 6, $context, $this->getSourceContext());
        // line 14
        echo "

";
        // line 16
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Rows", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of rows the field is allowed to have.", "app"), "id" => "maxRows", "name" => "maxRows", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 21, $this->source); })()), "maxRows", []), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 23
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 23, $this->source); })()), "getErrors", [0 => "maxRows"], "method")]], 16, $context, $this->getSourceContext());
        // line 24
        echo "

";
        // line 26
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Add Row Label", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Insert the button label for adding a new row to the table.", "app"), "id" => "addRowLabel", "name" => "addRowLabel", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 31
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 31, $this->source); })()), "addRowLabel", []), "size" => 20, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 33
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 33, $this->source); })()), "getErrors", [0 => "addRowLabel"], "method")]], 26, $context, $this->getSourceContext());
        // line 34
        echo "

";
        // line 36
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 36, $this->source); })()), "app", []), "db", []), "isMysql", [])) {
            // line 37
            echo "    <hr>
    <a class=\"fieldtoggle\" data-target=\"advanced\">";
            // line 38
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Advanced", "app"), "html", null, true);
            echo "</a>
    <div id=\"advanced\" class=\"hidden\">
        ";
            // line 40
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Column Type", "app"), "id" => "column-type", "name" => "columnType", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The type of column this field should get in the database.", "app"), "options" => [0 => ["value" => "text", "label" => "text (~64KB)"], 1 => ["value" => "mediumtext", "label" => "mediumtext (~16MB)"]], "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 49
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 49, $this->source); })()), "columnType", []), "warning" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 50
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 50, $this->source); })()), "id", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : (""))]], 40, $context, $this->getSourceContext());
            // line 51
            echo "
    </div>
";
        }
        // line 54
        echo "
";
        // line 55
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 55, $this->source); })()), "columns", []));
        foreach ($context['_seq'] as $context["colId"] => $context["column"]) {
            // line 56
            echo "    ";
            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["column"], "type", []) == "select")) {
                // line 57
                echo "        ";
                echo craft\helpers\Html::hiddenInput((("columns[" . $context["colId"]) . "][options]"), $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["column"], "options", [])));
                echo "
    ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['colId'], $context['column'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Table/settings");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Table/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 57,  102 => 56,  98 => 55,  95 => 54,  90 => 51,  88 => 50,  87 => 49,  86 => 40,  81 => 38,  78 => 37,  76 => 36,  72 => 34,  70 => 33,  69 => 31,  68 => 26,  64 => 24,  62 => 23,  61 => 21,  60 => 16,  56 => 14,  54 => 13,  53 => 11,  52 => 6,  47 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import '_includes/forms' as forms %}

{{ columnsField|raw }}
{{ defaultsField|raw }}

{{ forms.textField({
    label: \"Min Rows\"|t('app'),
    instructions: \"The minimum number of rows the field is allowed to have.\"|t('app'),
    id: 'minRows',
    name: 'minRows',
    value: field.minRows,
    size: 3,
    errors: field.getErrors('minRows')
}) }}

{{ forms.textField({
    label: \"Max Rows\"|t('app'),
    instructions: \"The maximum number of rows the field is allowed to have.\"|t('app'),
    id: 'maxRows',
    name: 'maxRows',
    value: field.maxRows,
    size: 3,
    errors: field.getErrors('maxRows')
}) }}

{{ forms.textField({
    label: \"Add Row Label\"|t('app'),
    instructions: \"Insert the button label for adding a new row to the table.\"|t('app'),
    id: 'addRowLabel',
    name: 'addRowLabel',
    value: field.addRowLabel,
    size: 20,
    errors: field.getErrors('addRowLabel')
}) }}

{% if craft.app.db.isMysql %}
    <hr>
    <a class=\"fieldtoggle\" data-target=\"advanced\">{{ \"Advanced\"|t('app') }}</a>
    <div id=\"advanced\" class=\"hidden\">
        {{ forms.selectField({
            label: \"Column Type\"|t('app'),
            id: 'column-type',
            name: 'columnType',
            instructions: \"The type of column this field should get in the database.\"|t('app'),
            options: [
                { value: 'text', label: 'text (~64KB)' },
                { value: 'mediumtext', label: 'mediumtext (~16MB)' },
            ],
            value: field.columnType,
            warning: (field.id ? \"Changing this may result in data loss.\"|t('app')),
        }) }}
    </div>
{% endif %}

{% for colId, column in field.columns %}
    {% if column.type == 'select' %}
        {{ hiddenInput(\"columns[#{colId}][options]\", column.options|json_encode) }}
    {% endif %}
{% endfor %}
", "_components/fieldtypes/Table/settings", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/Table/settings.html");
    }
}
