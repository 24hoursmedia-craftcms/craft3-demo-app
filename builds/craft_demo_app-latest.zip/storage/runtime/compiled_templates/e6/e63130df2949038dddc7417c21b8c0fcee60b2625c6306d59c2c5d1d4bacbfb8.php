<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/date */
class __TwigTemplate_62d0bb8ef5ddf0dbda5e9f8a5a4ae6bfedb3dcba98d31c16d8f0511e646c1e5b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/date");
        // line 1
        $context["id"] = ((($context["id"]) ?? (("date" . twig_random($this->env)))) . "-date");
        // line 2
        $context["name"] = (($context["name"]) ?? (null));
        // line 3
        $context["value"] = (((($context["value"]) ?? (false))) ? (twig_date_converter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 3, $this->source); })()), false)) : (null));
        // line 5
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->mergeFilter([0 => "datewrapper"], craft\helpers\Html::explodeClass(((        // line 6
$context["class"]) ?? ([]))))], ((        // line 7
$context["containerAttributes"]) ?? ([])), true);
        // line 9
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 10
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 10, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 12
        echo "
";
        // line 13
        ob_start();
        // line 14
        $this->loadTemplate("_includes/forms/text", "_includes/forms/date", 14)->display(twig_array_merge($context, ["name" => ((        // line 15
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 15, $this->source); })())) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 15, $this->source); })()) . "[date]")) : (null)), "autocomplete" => false, "size" => 10, "placeholder" => " ", "value" => ((        // line 19
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 19, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->dateFilter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 19, $this->source); })()), "short")) : (""))]));
        // line 21
        echo "<div data-icon=\"date\"></div>
    ";
        // line 22
        if ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 22, $this->source); })())) {
            // line 23
            echo craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 23, $this->source); })()) . "[timezone]"), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 23, $this->source); })()), "app", []), "getTimeZone", [], "method"));
        }
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 13
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 13, $this->source); })()));
        // line 27
        ob_start();
        // line 28
        echo "    \$('#";
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 28, $this->source); })())]), "js"), "html", null, true);
        echo "').datepicker(\$.extend({
        defaultDate: new Date(";
        // line 29
        if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 29, $this->source); })())) {
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 29, $this->source); })()), "format", [0 => "Y"], "method"), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 29, $this->source); })()), "format", [0 => "n"], "method") - 1), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 29, $this->source); })()), "format", [0 => "j"], "method"), "html", null, true);
        }
        echo ")
    }, Craft.datepickerOptions));";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/date");
    }

    public function getTemplateName()
    {
        return "_includes/forms/date";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 29,  74 => 28,  72 => 27,  70 => 13,  67 => 23,  65 => 22,  62 => 21,  60 => 19,  59 => 15,  58 => 14,  56 => 13,  53 => 12,  50 => 10,  48 => 9,  46 => 7,  45 => 6,  44 => 5,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set id = (id ?? \"date#{random()}\") ~ '-date' -%}
{% set name = name ?? null -%}
{% set value = (value ?? false) ? date(value, false) : null -%}

{% set containerAttributes = {
    class: ['datewrapper']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% tag 'div' with containerAttributes %}
    {%- include \"_includes/forms/text\" with {
        name: name ? \"#{name}[date]\" : null,
        autocomplete: false,
        size: 10,
        placeholder: ' ',
        value: value ? value|date('short') : '',
    } -%}
    <div data-icon=\"date\"></div>
    {% if name -%}
        {{ hiddenInput(\"#{name}[timezone]\", craft.app.getTimeZone()) }}
    {%- endif -%}
{% endtag %}

{%- js %}
    \$('#{{ id|namespaceInputId|e('js') }}').datepicker(\$.extend({
        defaultDate: new Date({% if value %}{{ value.format('Y') }}, {{ value.format('n')-1 }}, {{ value.format('j') }}{% endif %})
    }, Craft.datepickerOptions));
{%- endjs %}
", "_includes/forms/date", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/date.html");
    }
}
