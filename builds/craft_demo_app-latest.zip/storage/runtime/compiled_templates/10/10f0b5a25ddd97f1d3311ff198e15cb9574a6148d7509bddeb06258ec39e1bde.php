<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* login */
class __TwigTemplate_fea568fbeaaf35a4ab9ea93fa8a194cd99bf60022ee444d8acb7e25f50a96deb extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/basecp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "login");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "login", 2)->unwrap();
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Login", "app");
        // line 4
        $context["bodyClass"] = "login";
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\login\\LoginAsset"], "method");
        // line 7
        $context["username"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "app", []), "config", []), "general", []), "rememberUsernameDuration", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "app", []), "user", []), "getRememberedUsername", [], "method")) : (""));
        // line 8
        $context["showRememberMe"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 8, $this->source); })()), "app", []), "config", []), "general", []), "rememberedUserSessionDuration", []);
        // line 10
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", []), "config", []), "general", []), "useEmailAsUsername", [])) {
            // line 11
            $context["usernameLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Email", "app");
            // line 12
            $context["usernameType"] = "email";
        } else {
            // line 14
            $context["usernameLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Username or Email", "app");
            // line 15
            $context["usernameType"] = "text";
        }
        // line 18
        $context["hasLogo"] = (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 18, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 18, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 18, $this->source); })()), "rebrand", []), "isLogoUploaded", []));
        // line 20
        $context["formAttributes"] = ["id" => "login-form", "method" => "post", "class" => ((        // line 23
(isset($context["showRememberMe"]) || array_key_exists("showRememberMe", $context) ? $context["showRememberMe"] : (function () { throw new RuntimeError('Variable "showRememberMe" does not exist.', 23, $this->source); })())) ? ("remember-me") : ("")), "accept-charset" => "UTF-8"];
        // line 27
        if ((isset($context["hasLogo"]) || array_key_exists("hasLogo", $context) ? $context["hasLogo"] : (function () { throw new RuntimeError('Variable "hasLogo" does not exist.', 27, $this->source); })())) {
            // line 28
            $context["logo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 28, $this->source); })()), "rebrand", []), "logo", []);
        }
        // line 31
        ob_start();
        // line 32
        echo "    <main>
        <div id=\"login\">

            <h1>
                ";
        // line 36
        if ((isset($context["hasLogo"]) || array_key_exists("hasLogo", $context) ? $context["hasLogo"] : (function () { throw new RuntimeError('Variable "hasLogo" does not exist.', 36, $this->source); })())) {
            // line 37
            echo "                    ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("img", ["id" => "login-logo", "src" => craft\helpers\Template::attribute($this->env, $this->source,             // line 39
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 39, $this->source); })()), "url", []), "alt" =>             // line 40
(isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 40, $this->source); })()), "width" => craft\helpers\Template::attribute($this->env, $this->source,             // line 41
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 41, $this->source); })()), "width", []), "height" => craft\helpers\Template::attribute($this->env, $this->source,             // line 42
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 42, $this->source); })()), "height", [])]);
            // line 43
            echo "
                ";
        } else {
            // line 45
            echo "                    ";
            echo twig_escape_filter($this->env, (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 45, $this->source); })()), "html", null, true);
            echo "
                ";
        }
        // line 47
        echo "            </h1>

            <form ";
        // line 49
        echo craft\helpers\Html::renderTagAttributes((isset($context["formAttributes"]) || array_key_exists("formAttributes", $context) ? $context["formAttributes"] : (function () { throw new RuntimeError('Variable "formAttributes" does not exist.', 49, $this->source); })()));
        echo ">

                <div id=\"login-form-top\">
                    ";
        // line 52
        echo twig_call_macro($macros["forms"], "macro_textField", [["id" => "loginName", "name" => "username", "placeholder" =>         // line 55
(isset($context["usernameLabel"]) || array_key_exists("usernameLabel", $context) ? $context["usernameLabel"] : (function () { throw new RuntimeError('Variable "usernameLabel" does not exist.', 55, $this->source); })()), "value" =>         // line 56
(isset($context["username"]) || array_key_exists("username", $context) ? $context["username"] : (function () { throw new RuntimeError('Variable "username" does not exist.', 56, $this->source); })()), "autocomplete" => "username", "type" =>         // line 58
(isset($context["usernameType"]) || array_key_exists("usernameType", $context) ? $context["usernameType"] : (function () { throw new RuntimeError('Variable "usernameType" does not exist.', 58, $this->source); })()), "inputAttributes" => ["aria" => ["label" =>         // line 61
(isset($context["usernameLabel"]) || array_key_exists("usernameLabel", $context) ? $context["usernameLabel"] : (function () { throw new RuntimeError('Variable "usernameLabel" does not exist.', 61, $this->source); })()), "required" => "true"]]]], 52, $context, $this->getSourceContext());
        // line 65
        echo "
                    ";
        // line 66
        echo twig_call_macro($macros["forms"], "macro_passwordField", [["id" => "password", "name" => "password", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app"), "autocomplete" => "current-password", "inputAttributes" => ["aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app"), "required" => "true"]]]], 66, $context, $this->getSourceContext());
        // line 77
        echo "
                </div>

                <div id=\"login-form-bottom\">
                    ";
        // line 81
        if ((isset($context["showRememberMe"]) || array_key_exists("showRememberMe", $context) ? $context["showRememberMe"] : (function () { throw new RuntimeError('Variable "showRememberMe" does not exist.', 81, $this->source); })())) {
            // line 82
            echo "                        ";
            echo twig_call_macro($macros["forms"], "macro_checkboxField", [["id" => "rememberMe", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Keep me logged in", "app")]], 82, $context, $this->getSourceContext());
            echo "
                    ";
        }
        // line 84
        echo "                    <button id=\"forgot-password\" type=\"button\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Forgot your password?", "app"), "html", null, true);
        echo "</button>
                    <button id=\"remember-password\" type=\"button\">";
        // line 85
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Remember your password?", "app"), "html", null, true);
        echo "</button>
                </div>

                <div class=\"buttons\">
                    <button id=\"submit\" class=\"btn submit\" type=\"submit\">";
        // line 89
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Login", "app"), "html", null, true);
        echo "</button>
                    <div id=\"spinner\" class=\"spinner over-bg hidden\"></div>
                </div>
            </form>

            <div id=\"login-errors\" role=\"alert\">
            </div>

            <a id=\"poweredby\" href=\"http://craftcms.com/\" title=\"";
        // line 97
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Powered by Craft CMS", "app"), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Powered by Craft CMS", "app"), "html", null, true);
        echo "\">
                ";
        // line 98
        echo $this->extensions['craft\web\twig\Extension']->svgFunction("@app/web/assets/cp/dist/images/craftcms.svg");
        echo "
            </a>

        </div>

    </main>
";
        $context["formHtml"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 106
        ob_start();
        // line 107
        echo "    <main>
        <div class=\"message-container no-access\">
            <div class=\"pane notice\">
                <p>";
        // line 110
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Cookies must be enabled to access the Craft CMS control panel.", "app"), "html", null, true);
        echo "</p>
            </div>
        </div>
    </main>
";
        $context["noCookiesHtml"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent = $this->loadTemplate("_layouts/basecp", "login", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "login");
    }

    // line 116
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 117
        echo "    <script type=\"text/javascript\">
        var cookieTest = 'CraftCookieTest='+Math.floor(Math.random() * 1000000);
        document.cookie = cookieTest;
        if (document.cookie.search(cookieTest) != -1) {
            document.cookie = cookieTest + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            document.write(";
        // line 122
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["formHtml"]) || array_key_exists("formHtml", $context) ? $context["formHtml"] : (function () { throw new RuntimeError('Variable "formHtml" does not exist.', 122, $this->source); })()));
        echo ");

            ";
        // line 124
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 124, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method")) {
            // line 125
            echo "                document.getElementById(\"";
            echo (((isset($context["username"]) || array_key_exists("username", $context) ? $context["username"] : (function () { throw new RuntimeError('Variable "username" does not exist.', 125, $this->source); })())) ? ("password") : ("loginName"));
            echo "\").focus();
            ";
        }
        // line 127
        echo "        } else {
            document.write(";
        // line 128
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["noCookiesHtml"]) || array_key_exists("noCookiesHtml", $context) ? $context["noCookiesHtml"] : (function () { throw new RuntimeError('Variable "noCookiesHtml" does not exist.', 128, $this->source); })()));
        echo ");
        }
    </script>
";
        craft\helpers\Template::endProfile("block", "body");
    }

    public function getTemplateName()
    {
        return "login";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  227 => 128,  224 => 127,  218 => 125,  216 => 124,  211 => 122,  204 => 117,  199 => 116,  193 => 1,  185 => 110,  180 => 107,  178 => 106,  168 => 98,  162 => 97,  151 => 89,  144 => 85,  139 => 84,  133 => 82,  131 => 81,  125 => 77,  123 => 66,  120 => 65,  118 => 61,  117 => 58,  116 => 56,  115 => 55,  114 => 52,  108 => 49,  104 => 47,  98 => 45,  94 => 43,  92 => 42,  91 => 41,  90 => 40,  89 => 39,  87 => 37,  85 => 36,  79 => 32,  77 => 31,  74 => 28,  72 => 27,  70 => 23,  69 => 20,  67 => 18,  64 => 15,  62 => 14,  59 => 12,  57 => 11,  55 => 10,  53 => 8,  51 => 7,  49 => 5,  47 => 4,  45 => 3,  43 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/basecp\" %}
{% import \"_includes/forms\" as forms %}
{% set title = \"Login\"|t('app') %}
{% set bodyClass = 'login' %}
{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\login\\\\LoginAsset\") %}

{% set username = craft.app.config.general.rememberUsernameDuration ? craft.app.user.getRememberedUsername(): '' %}
{% set showRememberMe = craft.app.config.general.rememberedUserSessionDuration %}

{% if craft.app.config.general.useEmailAsUsername %}
    {% set usernameLabel = 'Email'|t('app') %}
    {% set usernameType = 'email' %}
{% else %}
    {% set usernameLabel = 'Username or Email'|t('app') %}
    {% set usernameType = 'text' %}
{% endif %}

{% set hasLogo = CraftEdition == CraftPro and craft.rebrand.isLogoUploaded %}

{% set formAttributes = {
    id: 'login-form',
    method: 'post',
    class: showRememberMe ? 'remember-me' : '',
    'accept-charset': 'UTF-8',
} %}

{% if hasLogo %}
    {% set logo = craft.rebrand.logo %}
{% endif %}

{% set formHtml %}
    <main>
        <div id=\"login\">

            <h1>
                {% if hasLogo %}
                    {{ tag('img', {
                        id: 'login-logo',
                        src: logo.url,
                        alt: systemName,
                        width: logo.width,
                        height: logo.height,
                    }) }}
                {% else %}
                    {{ systemName }}
                {% endif %}
            </h1>

            <form {{ attr(formAttributes) }}>

                <div id=\"login-form-top\">
                    {{ forms.textField({
                        id: 'loginName',
                        name: 'username',
                        placeholder: usernameLabel,
                        value: username,
                        autocomplete: 'username',
                        type: usernameType,
                        inputAttributes: {
                            aria: {
                                label: usernameLabel,
                                required: 'true',
                            },
                        },
                    }) }}
                    {{ forms.passwordField({
                        id: 'password',
                        name: 'password',
                        placeholder: 'Password'|t('app'),
                        autocomplete: 'current-password',
                        inputAttributes: {
                            aria: {
                                label: 'Password'|t('app'),
                                required: 'true',
                            },
                        },
                    }) }}
                </div>

                <div id=\"login-form-bottom\">
                    {% if showRememberMe %}
                        {{ forms.checkboxField({ id: 'rememberMe', label: 'Keep me logged in'|t('app') }) }}
                    {% endif %}
                    <button id=\"forgot-password\" type=\"button\">{{ 'Forgot your password?'|t('app') }}</button>
                    <button id=\"remember-password\" type=\"button\">{{ 'Remember your password?'|t('app') }}</button>
                </div>

                <div class=\"buttons\">
                    <button id=\"submit\" class=\"btn submit\" type=\"submit\">{{ 'Login'|t('app') }}</button>
                    <div id=\"spinner\" class=\"spinner over-bg hidden\"></div>
                </div>
            </form>

            <div id=\"login-errors\" role=\"alert\">
            </div>

            <a id=\"poweredby\" href=\"http://craftcms.com/\" title=\"{{ 'Powered by Craft CMS'|t('app') }}\" aria-label=\"{{ 'Powered by Craft CMS'|t('app') }}\">
                {{ svg('@app/web/assets/cp/dist/images/craftcms.svg') }}
            </a>

        </div>

    </main>
{% endset %}

{% set noCookiesHtml %}
    <main>
        <div class=\"message-container no-access\">
            <div class=\"pane notice\">
                <p>{{ 'Cookies must be enabled to access the Craft CMS control panel.'|t('app') }}</p>
            </div>
        </div>
    </main>
{% endset %}

{% block body %}
    <script type=\"text/javascript\">
        var cookieTest = 'CraftCookieTest='+Math.floor(Math.random() * 1000000);
        document.cookie = cookieTest;
        if (document.cookie.search(cookieTest) != -1) {
            document.cookie = cookieTest + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            document.write({{ formHtml|json_encode|raw }});

            {% if not craft.app.request.isMobileBrowser(true) %}
                document.getElementById(\"{{ (username ? 'password' : 'loginName') }}\").focus();
            {% endif %}
        } else {
            document.write({{ noCookiesHtml|json_encode|raw }});
        }
    </script>
{% endblock %}
", "login", "/var/www/html/vendor/craftcms/cms/src/templates/login.html");
    }
}
