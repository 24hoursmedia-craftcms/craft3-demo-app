<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/permissions */
class __TwigTemplate_6e53c741709c5172464dc3e7a674258e1dcf24926782f7e41e28462ad102b5ac extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/permissions");
        // line 1
        if (\Craft::$app->getEdition() < (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 1, $this->source); })()))
        {
            throw new yii\web\NotFoundHttpException;
        }
        // line 2
        echo "
";
        // line 3
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 3, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Select All", 1 => "Deselect All"]], "method");
        // line 7
        echo "
";
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\userpermissions\\UserPermissionsAsset"], "method");
        // line 9
        echo "
";
        // line 57
        echo "
";
        // line 58
        $macros["__internal_b2e6800aa1d44fc6989229ef32f0982641a99023c8d2e1a038892e38f11464de"] = $this->macros["__internal_b2e6800aa1d44fc6989229ef32f0982641a99023c8d2e1a038892e38f11464de"] = $this;
        // line 59
        echo "
";
        // line 60
        $context["user"] = ((((isset($context["userOrGroup"]) || array_key_exists("userOrGroup", $context) ? $context["userOrGroup"] : (function () { throw new RuntimeError('Variable "userOrGroup" does not exist.', 60, $this->source); })()) && (get_class((isset($context["userOrGroup"]) || array_key_exists("userOrGroup", $context) ? $context["userOrGroup"] : (function () { throw new RuntimeError('Variable "userOrGroup" does not exist.', 60, $this->source); })())) == "craftelementsUser"))) ? ((isset($context["userOrGroup"]) || array_key_exists("userOrGroup", $context) ? $context["userOrGroup"] : (function () { throw new RuntimeError('Variable "userOrGroup" does not exist.', 60, $this->source); })())) : (null));
        // line 61
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 61, $this->source); })()), "app", []), "userPermissions", []), "getAssignablePermissions", [0 => (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 61, $this->source); })())], "method"));
        foreach ($context['_seq'] as $context["category"] => $context["catPermissions"]) {
            // line 62
            echo "    <div class=\"user-permissions\">
        <h3>";
            // line 63
            echo twig_escape_filter($this->env, $context["category"], "html", null, true);
            echo "</h3>
        <div class=\"select-all\"></div>

        ";
            // line 66
            echo twig_call_macro($macros["__internal_b2e6800aa1d44fc6989229ef32f0982641a99023c8d2e1a038892e38f11464de"], "macro_permissionList", [$context, $context["catPermissions"]], 66, $context, $this->getSourceContext());
            echo "
    </div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['category'], $context['catPermissions'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        craft\helpers\Template::endProfile("template", "_includes/permissions");
    }

    // line 10
    public function macro_permissionList($__context__ = null, $__permissions__ = null, $__id__ = null, $__disabled__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "context" => $__context__,
            "permissions" => $__permissions__,
            "id" => $__id__,
            "disabled" => $__disabled__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "permissionList");
            // line 11
            echo "    ";
            $macros["__internal_7a7e15fc754168ba33fdf0ababb70b4ec8f477492ec66c2a5106e14b5b825a62"] = $this->loadTemplate("_includes/forms", "_includes/permissions", 11)->unwrap();
            // line 12
            echo "    ";
            $macros["__internal_606341ad68a768209634a97c3b47b07c9d1414096aa20819cab6d5b9bfe2e570"] = $this;
            // line 13
            echo "
    <ul";
            // line 14
            if ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 14, $this->source); })())) {
                echo " id=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->replaceFilter((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 14, $this->source); })()), ":", "-"), "html", null, true);
                echo "\"";
            }
            echo ">
        ";
            // line 15
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["permissions"]) || array_key_exists("permissions", $context) ? $context["permissions"] : (function () { throw new RuntimeError('Variable "permissions" does not exist.', 15, $this->source); })()));
            foreach ($context['_seq'] as $context["permissionName"] => $context["props"]) {
                // line 16
                echo "            ";
                $context["isInGroupPermissions"] = (craft\helpers\Template::attribute($this->env, $this->source, ($context["context"] ?? null), "groupPermissions", [], "any", true, true) && twig_in_filter(twig_lower_filter($this->env, $context["permissionName"]), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 16, $this->source); })()), "groupPermissions", [])));
                // line 17
                echo "
            ";
                // line 18
                if ((isset($context["isInGroupPermissions"]) || array_key_exists("isInGroupPermissions", $context) ? $context["isInGroupPermissions"] : (function () { throw new RuntimeError('Variable "isInGroupPermissions" does not exist.', 18, $this->source); })())) {
                    // line 19
                    echo "                ";
                    $context["checked"] = true;
                    // line 20
                    echo "            ";
                } else {
                    // line 21
                    echo "                ";
                    if ( !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 21, $this->source); })()), "userOrGroup", []))) {
                        // line 22
                        echo "                    ";
                        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 22, $this->source); })()), "app", []), "request", []), "isPost", [])) {
                            // line 23
                            echo "                        ";
                            $context["checked"] = twig_in_filter($context["permissionName"], craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 23, $this->source); })()), "app", []), "request", []), "getBodyParam", [0 => "permissions", 1 => []], "method"));
                            // line 24
                            echo "                    ";
                        } else {
                            // line 25
                            echo "                        ";
                            $context["checked"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 25, $this->source); })()), "userOrGroup", []), "can", [0 => $context["permissionName"]], "method");
                            // line 26
                            echo "                    ";
                        }
                        // line 27
                        echo "                ";
                    } else {
                        // line 28
                        echo "                    ";
                        $context["checked"] = false;
                        // line 29
                        echo "                ";
                    }
                    // line 30
                    echo "            ";
                }
                // line 31
                echo "
            <li>
                ";
                // line 33
                echo twig_call_macro($macros["__internal_7a7e15fc754168ba33fdf0ababb70b4ec8f477492ec66c2a5106e14b5b825a62"], "macro_checkbox", [["label" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 34
$context["props"], "label", []), "name" => "permissions[]", "value" =>                 // line 36
$context["permissionName"], "checked" =>                 // line 37
(isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 37, $this->source); })()), "class" => ((                // line 38
(isset($context["isInGroupPermissions"]) || array_key_exists("isInGroupPermissions", $context) ? $context["isInGroupPermissions"] : (function () { throw new RuntimeError('Variable "isInGroupPermissions" does not exist.', 38, $this->source); })())) ? ("group-permission") : ("")), "disabled" => (                // line 39
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 39, $this->source); })()) || (isset($context["isInGroupPermissions"]) || array_key_exists("isInGroupPermissions", $context) ? $context["isInGroupPermissions"] : (function () { throw new RuntimeError('Variable "isInGroupPermissions" does not exist.', 39, $this->source); })()))]], 33, $context, $this->getSourceContext());
                // line 40
                echo "

                ";
                // line 42
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [])) : (false))) {
                    // line 43
                    echo "                    <div class=\"info\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", []), "html", null, true);
                    echo "</div>
                ";
                }
                // line 45
                echo "
                ";
                // line 46
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [])) : (false))) {
                    // line 47
                    echo "                    <div class=\"info warning\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", []), "html", null, true);
                    echo "</div>
                ";
                }
                // line 49
                echo "
                ";
                // line 50
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [])) : (false))) {
                    // line 51
                    echo "                    ";
                    echo twig_call_macro($macros["__internal_606341ad68a768209634a97c3b47b07c9d1414096aa20819cab6d5b9bfe2e570"], "macro_permissionList", [(isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 51, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", []), ($context["permissionName"] . "-nested"),  !(isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 51, $this->source); })())], 51, $context, $this->getSourceContext());
                    echo "
                ";
                }
                // line 53
                echo "            </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['permissionName'], $context['props'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 55
            echo "    </ul>
";
            craft\helpers\Template::endProfile("macro", "permissionList");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_includes/permissions";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  225 => 55,  218 => 53,  212 => 51,  210 => 50,  207 => 49,  201 => 47,  199 => 46,  196 => 45,  190 => 43,  188 => 42,  184 => 40,  182 => 39,  181 => 38,  180 => 37,  179 => 36,  178 => 34,  177 => 33,  173 => 31,  170 => 30,  167 => 29,  164 => 28,  161 => 27,  158 => 26,  155 => 25,  152 => 24,  149 => 23,  146 => 22,  143 => 21,  140 => 20,  137 => 19,  135 => 18,  132 => 17,  129 => 16,  125 => 15,  117 => 14,  114 => 13,  111 => 12,  108 => 11,  91 => 10,  79 => 66,  73 => 63,  70 => 62,  66 => 61,  64 => 60,  61 => 59,  59 => 58,  56 => 57,  53 => 9,  51 => 8,  48 => 7,  46 => 3,  43 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% requireEdition CraftPro %}

{% do view.registerTranslations('app', [
    \"Select All\",
    \"Deselect All\",
]) %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\userpermissions\\\\UserPermissionsAsset\") %}

{% macro permissionList(context, permissions, id, disabled) %}
    {% from \"_includes/forms\" import checkbox %}
    {% from _self import permissionList %}

    <ul{% if id %} id=\"{{ id|replace(':', '-') }}\"{% endif %}>
        {% for permissionName, props in permissions %}
            {% set isInGroupPermissions = (context.groupPermissions is defined and permissionName|lower in context.groupPermissions) %}

            {% if (isInGroupPermissions) %}
                {% set checked = true %}
            {% else %}
                {% if context.userOrGroup is not empty %}
                    {% if craft.app.request.isPost %}
                        {% set checked = permissionName in craft.app.request.getBodyParam('permissions', []) %}
                    {% else %}
                        {% set checked = context.userOrGroup.can(permissionName) %}
                    {% endif %}
                {% else %}
                    {% set checked = false %}
                {% endif %}
            {% endif %}

            <li>
                {{ checkbox({
                    label: props.label,
                    name: 'permissions[]',
                    value: permissionName,
                    checked: checked,
                    class: isInGroupPermissions ? 'group-permission',
                    disabled: disabled or isInGroupPermissions,
                }) }}

                {% if props.info ?? false %}
                    <div class=\"info\">{{ props.info }}</div>
                {% endif %}

                {% if props.warning ?? false %}
                    <div class=\"info warning\">{{ props.warning }}</div>
                {% endif %}

                {% if props.nested ?? false %}
                    {{ permissionList(context, props.nested, permissionName~'-nested', not checked) }}
                {% endif %}
            </li>
        {% endfor %}
    </ul>
{% endmacro %}

{% from _self import permissionList %}

{% set user = userOrGroup and className(userOrGroup) == 'craft\\elements\\User' ? userOrGroup : null %}
{% for category, catPermissions in craft.app.userPermissions.getAssignablePermissions(user) %}
    <div class=\"user-permissions\">
        <h3>{{ category }}</h3>
        <div class=\"select-all\"></div>

        {{ permissionList(_context, catPermissions) }}
    </div>
{% endfor %}
", "_includes/permissions", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/permissions.html");
    }
}
