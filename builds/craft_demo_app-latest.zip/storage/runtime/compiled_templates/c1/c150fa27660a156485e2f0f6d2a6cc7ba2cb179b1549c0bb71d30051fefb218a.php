<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/cp/_partials/dashboard/integration.twig */
class __TwigTemplate_e3dbd89e316a4ff8f6c4912fd741517df45b612ec29164fed365c5407bf1b8f8 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/cp/_partials/dashboard/integration.twig");
        // line 1
        $macros["vcp"] = $this->macros["vcp"] = $this->loadTemplate("views-work/_macros.twig", "views-work/cp/_partials/dashboard/integration.twig", 1)->unwrap();
        // line 2
        echo "
<div class=\"content-pane vw-mt-3\">
    <h2>";
        // line 4
        echo twig_call_macro($macros["vcp"], "macro_t", ["Quick start"], 4, $context, $this->getSourceContext());
        echo "</h2>

    <h3>";
        // line 6
        echo twig_call_macro($macros["vcp"], "macro_t", ["Measurement pixel"], 6, $context, $this->getSourceContext());
        echo "</h3>
    <p>
        ";
        // line 8
        echo twig_call_macro($macros["vcp"], "macro_t", ["Include the following tag on your pages. It will create a small pixel image to measure the views for your `entry`."], 8, $context, $this->getSourceContext());
        echo "
    </p>
    <pre class=\"vw-bg-gray-100 vw-p-2 vw-overflow-auto\"><code>";
        // line 10
        echo "{{ entry | views_work_image }}";
        echo "</code></pre>

    <h3>";
        // line 12
        echo twig_call_macro($macros["vcp"], "macro_t", ["Retrieving popular items"], 12, $context, $this->getSourceContext());
        echo "</h3>
    <p>
        ";
        // line 14
        echo twig_call_macro($macros["vcp"], "macro_t", ["To retrieve the 5 most popular items viewed today, you can simply do in twig:"], 14, $context, $this->getSourceContext());
        echo "
    <pre class=\"vw-bg-gray-100 vw-p-2 vw-mt-2 vw-mb-2 vw-overflow-auto\"><code>";
        // line 15
        echo "{% set popularEntries = craft.entries.orderByPopular('day', 1).limit(5).all %}";
        echo "</code></pre>

    ";
        // line 17
        echo twig_call_macro($macros["vcp"], "macro_t", ["Instead of `day`, you can also use `total`, `week` or `month`:"], 17, $context, $this->getSourceContext());
        echo "
    <pre class=\"vw-bg-gray-100 vw-p-2 vw-mt-2 vw-mb-2 vw-overflow-auto\"><code>";
        // line 18
        echo "{% set popularEntries = craft.entries.orderByPopular('total', 1).limit(5).all %}";
        echo "</code></pre>
    ";
        // line 19
        echo twig_call_macro($macros["vcp"], "macro_t", ["(the number 1 is the minimum number of times viewed.)"], 19, $context, $this->getSourceContext());
        echo "
    </p>

    <h3>";
        // line 22
        echo twig_call_macro($macros["vcp"], "macro_t", ["Showing view counts for an element"], 22, $context, $this->getSourceContext());
        echo "</h3>
    <pre class=\"vw-bg-gray-100 vw-p-2 vw-mt-2 vw-mb-2 vw-overflow-auto\"><code>";
        // line 26
        echo "{{ entry.viewsWork.total }}
{{ entry.viewsWork.thisMonth }}
{{ entry.viewsWork.thisWeek }}
{{ entry.viewsWork.today }}";
        echo "</code></pre>

</div>";
        craft\helpers\Template::endProfile("template", "views-work/cp/_partials/dashboard/integration.twig");
    }

    public function getTemplateName()
    {
        return "views-work/cp/_partials/dashboard/integration.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 26,  92 => 22,  86 => 19,  82 => 18,  78 => 17,  73 => 15,  69 => 14,  64 => 12,  59 => 10,  54 => 8,  49 => 6,  44 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import 'views-work/_macros.twig' as vcp %}

<div class=\"content-pane vw-mt-3\">
    <h2>{{ vcp.t('Quick start') }}</h2>

    <h3>{{ vcp.t('Measurement pixel') }}</h3>
    <p>
        {{ vcp.t('Include the following tag on your pages. It will create a small pixel image to measure the views for your `entry`.') }}
    </p>
    <pre class=\"vw-bg-gray-100 vw-p-2 vw-overflow-auto\"><code>{% verbatim %}{{ entry | views_work_image }}{% endverbatim %}</code></pre>

    <h3>{{ vcp.t('Retrieving popular items') }}</h3>
    <p>
        {{ vcp.t('To retrieve the 5 most popular items viewed today, you can simply do in twig:') }}
    <pre class=\"vw-bg-gray-100 vw-p-2 vw-mt-2 vw-mb-2 vw-overflow-auto\"><code>{% verbatim %}{% set popularEntries = craft.entries.orderByPopular('day', 1).limit(5).all %}{% endverbatim %}</code></pre>

    {{ vcp.t('Instead of `day`, you can also use `total`, `week` or `month`:') }}
    <pre class=\"vw-bg-gray-100 vw-p-2 vw-mt-2 vw-mb-2 vw-overflow-auto\"><code>{% verbatim %}{% set popularEntries = craft.entries.orderByPopular('total', 1).limit(5).all %}{% endverbatim %}</code></pre>
    {{ vcp.t('(the number 1 is the minimum number of times viewed.)') }}
    </p>

    <h3>{{ vcp.t('Showing view counts for an element') }}</h3>
    <pre class=\"vw-bg-gray-100 vw-p-2 vw-mt-2 vw-mb-2 vw-overflow-auto\"><code>{% verbatim %}{{ entry.viewsWork.total }}
{{ entry.viewsWork.thisMonth }}
{{ entry.viewsWork.thisWeek }}
{{ entry.viewsWork.today }}{% endverbatim %}</code></pre>

</div>", "views-work/cp/_partials/dashboard/integration.twig", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/cp/_partials/dashboard/integration.twig");
    }
}
