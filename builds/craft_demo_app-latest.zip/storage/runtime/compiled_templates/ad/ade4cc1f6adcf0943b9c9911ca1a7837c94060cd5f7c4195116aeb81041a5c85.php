<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_components/widgets/reactive/viewed_now_widget_content */
class __TwigTemplate_0d6b0932b28f9826f03ebe97e8b15a7da15c5277ee9fe6cff07cd8e3476cfd62 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_components/widgets/reactive/viewed_now_widget_content");
        // line 1
        $macros["cpmacros"] = $this->macros["cpmacros"] = $this->loadTemplate("views-work/_macros", "views-work/_components/widgets/reactive/viewed_now_widget_content", 1)->unwrap();
        // line 2
        $macros["_macros"] = $this->macros["_macros"] = $this;
        // line 3
        echo "
<div class=\"vw-pb-2\">
";
        // line 5
        if (((isset($context["total"]) || array_key_exists("total", $context) ? $context["total"] : (function () { throw new RuntimeError('Variable "total" does not exist.', 5, $this->source); })()) > 0)) {
            // line 6
            echo "    <span class=\"vw-badge vw-badge-circle vw-badge-info\">";
            echo twig_escape_filter($this->env, (isset($context["total"]) || array_key_exists("total", $context) ? $context["total"] : (function () { throw new RuntimeError('Variable "total" does not exist.', 6, $this->source); })()), "html", null, true);
            echo "</span> ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("items being viewed.", "views-work"), "html", null, true);
            echo "
";
        } else {
            // line 8
            echo "    ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No items being viewed.", "views-work"), "html", null, true);
            echo "
";
        }
        // line 10
        echo "</div>


";
        // line 13
        if ((twig_length_filter($this->env, (isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new RuntimeError('Variable "items" does not exist.', 13, $this->source); })())) > 0)) {
            // line 14
            echo "    <div class=\"vw-grid vw-grid-cols-12 vw-gap-1 vw-pb-2\">
        ";
            // line 15
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["items"]) || array_key_exists("items", $context) ? $context["items"] : (function () { throw new RuntimeError('Variable "items" does not exist.', 15, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 16
                echo "            ";
                $context["views"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 16, $this->source); })()), "views_work_cp", []), "recording", [0 => $context["item"]], "method");
                // line 17
                echo "            ";
                // line 18
                echo "            ";
                $context["url"] = craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "cpEditUrl", []);
                // line 19
                echo "
            <div class=\"vw-col-span-10\">
                ";
                // line 21
                if (twig_test_empty((isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 21, $this->source); })()))) {
                    // line 22
                    echo "                    <div class=\"vw-overflow-ellipsis vw-truncate\"><span>";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
                    echo "</span></div>
                ";
                } else {
                    // line 24
                    echo "                    <div class=\"vw-overflow-ellipsis vw-truncate\">
                        <a href=\"";
                    // line 25
                    echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 25, $this->source); })()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
                    echo "</a>
                    </div>

                ";
                }
                // line 29
                echo "            </div>
            <div class=\"vw-col-span-2\">
                <div class=\"vw-ml-1 vw-text-right\">
                    ";
                // line 32
                $context["url"] = twig_trim_filter(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", []));
                // line 33
                echo "                    ";
                if ( !twig_test_empty((isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 33, $this->source); })()))) {
                    // line 34
                    echo "                        ";
                    $context["url"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 34, $this->source); })()), "views_work_cp", []), "addBlockParamToUrl", [0 => (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 34, $this->source); })())], "method");
                    // line 35
                    echo "                        <a href=\"";
                    echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 35, $this->source); })()), "html", null, true);
                    echo "\" target=\"_blank\" data-icon=\"world\"></a>
                    ";
                }
                // line 37
                echo "                </div>
            </div>

        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 41
            echo "    </div>
";
        }
        craft\helpers\Template::endProfile("template", "views-work/_components/widgets/reactive/viewed_now_widget_content");
    }

    public function getTemplateName()
    {
        return "views-work/_components/widgets/reactive/viewed_now_widget_content";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 41,  127 => 37,  121 => 35,  118 => 34,  115 => 33,  113 => 32,  108 => 29,  99 => 25,  96 => 24,  90 => 22,  88 => 21,  84 => 19,  81 => 18,  79 => 17,  76 => 16,  72 => 15,  69 => 14,  67 => 13,  62 => 10,  56 => 8,  48 => 6,  46 => 5,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import 'views-work/_macros' as cpmacros %}
{% import _self as _macros %}

<div class=\"vw-pb-2\">
{% if total > 0 %}
    <span class=\"vw-badge vw-badge-circle vw-badge-info\">{{ total }}</span> {{ 'items being viewed.' | t('views-work') }}
{% else %}
    {{ 'No items being viewed.' | t('views-work') }}
{% endif %}
</div>


{% if items | length > 0 %}
    <div class=\"vw-grid vw-grid-cols-12 vw-gap-1 vw-pb-2\">
        {% for item in items %}
            {% set views = craft.views_work_cp.recording(item) %}
            {# views \\twentyfourhoursmedia\\viewswork\\models\\ViewRecording #}
            {% set url = item.cpEditUrl %}

            <div class=\"vw-col-span-10\">
                {% if url is empty %}
                    <div class=\"vw-overflow-ellipsis vw-truncate\"><span>{{ item.title }}</span></div>
                {% else %}
                    <div class=\"vw-overflow-ellipsis vw-truncate\">
                        <a href=\"{{ url }}\">{{ item.title }}</a>
                    </div>

                {% endif %}
            </div>
            <div class=\"vw-col-span-2\">
                <div class=\"vw-ml-1 vw-text-right\">
                    {% set url = item.url | trim %}
                    {% if url is not empty %}
                        {% set url = craft.views_work_cp.addBlockParamToUrl(url) %}
                        <a href=\"{{ url }}\" target=\"_blank\" data-icon=\"world\"></a>
                    {% endif %}
                </div>
            </div>

        {% endfor %}
    </div>
{% endif %}", "views-work/_components/widgets/reactive/viewed_now_widget_content", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_components/widgets/reactive/viewed_now_widget_content.twig");
    }
}
