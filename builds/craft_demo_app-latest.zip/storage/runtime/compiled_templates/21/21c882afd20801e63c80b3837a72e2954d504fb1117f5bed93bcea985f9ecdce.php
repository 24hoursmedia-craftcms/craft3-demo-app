<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* users */
class __TwigTemplate_9118f010ff5e707212868e93f9486ff2edf243fbebddafede76273a4fa13dd69 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 7
        return "_layouts/elementindex";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "users");
        // line 1
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 1, $this->source); })()) != (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 1, $this->source); })()))) {
            // line 2
            throw new yii\web\NotFoundHttpException();
        }
        // line 5
        \Craft::$app->controller->requirePermission("editUsers");
        // line 8
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Users", "app");
        // line 9
        $context["elementType"] = "craft\\elements\\User";
        // line 7
        $this->parent = $this->loadTemplate("_layouts/elementindex", "users", 7);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "users");
    }

    // line 11
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 12
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 12, $this->source); })()), "can", [0 => "registerUsers"], "method")) {
            // line 13
            echo "        <a class=\"btn submit add icon\" href=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("users/new"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New user", "app"), "html", null, true);
            echo "</a>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    public function getTemplateName()
    {
        return "users";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 13,  65 => 12,  60 => 11,  54 => 7,  52 => 9,  50 => 8,  48 => 5,  45 => 2,  43 => 1,  35 => 7,);
    }

    public function getSourceContext()
    {
        return new Source("{% if CraftEdition != CraftPro %}
    {% exit 404 %}
{% endif %}

{% requirePermission 'editUsers' %}

{% extends \"_layouts/elementindex\" %}
{% set title = \"Users\"|t('app') %}
{% set elementType = 'craft\\\\elements\\\\User' %}

{% block actionButton %}
    {% if currentUser.can('registerUsers') %}
        <a class=\"btn submit add icon\" href=\"{{ url('users/new') }}\">{{ \"New user\"|t('app') }}</a>
    {% endif %}
{% endblock %}
", "users", "/var/www/html/vendor/craftcms/cms/src/templates/users/index.html");
    }
}
