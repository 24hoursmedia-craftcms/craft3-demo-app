<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/cards/simple_card.html.twig */
class __TwigTemplate_277cba9fcf77610e77daba5c78af1426301f94b2ed01035f8fdcf4b9e94d09b9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/cards/simple_card.html.twig");
        // line 1
        echo "<div class=\"max-w rounded-lg overflow-hidden shadow-lg bg-white\">
    <div class=\"flex flex-col\">
        <div class=\"px-6 py-4 border-b\">
            <div class=\"text-lg text-center\">";
        // line 4
        $this->displayBlock('heading', $context, $blocks);
        echo "</div>
        </div>
        <div class=\"px-6 py-10 flex-grow\">
            ";
        // line 7
        $this->displayBlock('content', $context, $blocks);
        // line 9
        echo "        </div>
    </div>
</div>";
        craft\helpers\Template::endProfile("template", "_components/cards/simple_card.html.twig");
    }

    // line 4
    public function block_heading($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "heading");
        craft\helpers\Template::endProfile("block", "heading");
    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 8
        echo "            ";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "_components/cards/simple_card.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  73 => 8,  68 => 7,  60 => 4,  53 => 9,  51 => 7,  45 => 4,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"max-w rounded-lg overflow-hidden shadow-lg bg-white\">
    <div class=\"flex flex-col\">
        <div class=\"px-6 py-4 border-b\">
            <div class=\"text-lg text-center\">{% block heading %}{% endblock %}</div>
        </div>
        <div class=\"px-6 py-10 flex-grow\">
            {% block content %}
            {% endblock %}
        </div>
    </div>
</div>", "_components/cards/simple_card.html.twig", "/var/www/html/templates/_components/cards/simple_card.html.twig");
    }
}
