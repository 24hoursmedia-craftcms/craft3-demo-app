<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/cp/_partials/dashboard/blocking.twig */
class __TwigTemplate_1e7c3237592be793b2ac174ec1221a4c7f860650e010c84e0c301528bd8f1b5f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/cp/_partials/dashboard/blocking.twig");
        // line 1
        $macros["vcp"] = $this->macros["vcp"] = $this->loadTemplate("views-work/_macros.twig", "views-work/cp/_partials/dashboard/blocking.twig", 1)->unwrap();
        // line 2
        $context["status"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 2, $this->source); })()), "views_work_cp", []), "blockStatus", []);
        // line 3
        echo "
<div class=\"content-pane vw-mt-3\">
    <h2>";
        // line 5
        echo twig_call_macro($macros["vcp"], "macro_t", ["Block registrations"], 5, $context, $this->getSourceContext());
        echo "</h2>

    <p>";
        // line 7
        echo twig_call_macro($macros["vcp"], "macro_t", ["To exclude yourself or others from view registrations, you can visit one of the following links. You need to enable/disable blocking on a per domain basis."], 7, $context, $this->getSourceContext());
        echo "</p>


    ";
        // line 10
        $context["sites"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", []), "sites", []), "allSites", []);
        // line 11
        echo "    <div class=\"vw-grid vw-grid-cols-5 vw-gap-1\">
        <div>
            <strong>";
        // line 13
        echo twig_call_macro($macros["vcp"], "macro_t", ["Site"], 13, $context, $this->getSourceContext());
        echo "</strong>
        </div>
        <div>
            <strong>";
        // line 16
        echo twig_call_macro($macros["vcp"], "macro_t", ["Disable registration url"], 16, $context, $this->getSourceContext());
        echo "</strong>
        </div>
        <div>
            <strong>";
        // line 19
        echo twig_call_macro($macros["vcp"], "macro_t", ["Re-enable url"], 19, $context, $this->getSourceContext());
        echo "</strong>
        </div>
        <div></div>
        <div></div>

        ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
            // line 25
            echo "            ";
            $context["block_url"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 25, $this->source); })()), "views_work_cp", []), "cookieblockUrl", [0 => craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [])], "method");
            // line 26
            echo "            ";
            $context["unblock_url"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 26, $this->source); })()), "views_work_cp", []), "cookieUnblockUrl", [0 => craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [])], "method");
            // line 27
            echo "            ";
            $context["status_url"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 27, $this->source); })()), "views_work_cp", []), "cookieBlockStatusUrl", [0 => craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", [])], "method");
            // line 28
            echo "            <div>
                ";
            // line 29
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "html", null, true);
            echo "
            </div>
            <div class=\"vw-pb-1 vw-pr-3\">
                <input type=\"text\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, (isset($context["block_url"]) || array_key_exists("block_url", $context) ? $context["block_url"] : (function () { throw new RuntimeError('Variable "block_url" does not exist.', 32, $this->source); })()), "html", null, true);
            echo "\" class=\"vw-w-full vw-border vw-border-opacity-50 vw-border-solid vw-border-info\" onclick=\"this.select();\" readonly=\"readonly\">
            </div>
            <div class=\"vw-pb-1 vw-pr-3\">
                <input type=\"text\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, (isset($context["unblock_url"]) || array_key_exists("unblock_url", $context) ? $context["unblock_url"] : (function () { throw new RuntimeError('Variable "unblock_url" does not exist.', 35, $this->source); })()), "html", null, true);
            echo "\" class=\"vw-w-full vw-border vw-border-opacity-50 vw-border-solid vw-border-info\" onclick=\"this.select();\" readonly=\"readonly\">
            </div>
            <div>
                <a href=\"";
            // line 38
            echo twig_escape_filter($this->env, (isset($context["block_url"]) || array_key_exists("block_url", $context) ? $context["block_url"] : (function () { throw new RuntimeError('Variable "block_url" does not exist.', 38, $this->source); })()), "html", null, true);
            echo "\" target=\"_blank\"
                   class=\"vw-badge vw-badge-danger\">";
            // line 39
            echo twig_call_macro($macros["vcp"], "macro_t", ["DISABLE REG. NOW"], 39, $context, $this->getSourceContext());
            echo "</a>
            </div>
            <div>
                <a href=\"";
            // line 42
            echo twig_escape_filter($this->env, (isset($context["status_url"]) || array_key_exists("status_url", $context) ? $context["status_url"] : (function () { throw new RuntimeError('Variable "status_url" does not exist.', 42, $this->source); })()), "html", null, true);
            echo "\" target=\"vw_blk\"  class=\"vw-badge vw-badge-info\">";
            echo twig_call_macro($macros["vcp"], "macro_t", ["status"], 42, $context, $this->getSourceContext());
            echo "</a>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "    </div>

    <p>
        <span class=\"vw-text-xs\">";
        // line 48
        echo twig_call_macro($macros["vcp"], "macro_t", ["Note: after visiting the block/unblock urls, you need to reload this page to view the right status"], 48, $context, $this->getSourceContext());
        echo "</span>
    </p>
</div>";
        craft\helpers\Template::endProfile("template", "views-work/cp/_partials/dashboard/blocking.twig");
    }

    public function getTemplateName()
    {
        return "views-work/cp/_partials/dashboard/blocking.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 48,  138 => 45,  127 => 42,  121 => 39,  117 => 38,  111 => 35,  105 => 32,  99 => 29,  96 => 28,  93 => 27,  90 => 26,  87 => 25,  83 => 24,  75 => 19,  69 => 16,  63 => 13,  59 => 11,  57 => 10,  51 => 7,  46 => 5,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import 'views-work/_macros.twig' as vcp %}
{% set status = craft.views_work_cp.blockStatus %}

<div class=\"content-pane vw-mt-3\">
    <h2>{{ vcp.t('Block registrations') }}</h2>

    <p>{{ vcp.t('To exclude yourself or others from view registrations, you can visit one of the following links. You need to enable/disable blocking on a per domain basis.') }}</p>


    {% set sites = craft.app.sites.allSites %}
    <div class=\"vw-grid vw-grid-cols-5 vw-gap-1\">
        <div>
            <strong>{{ vcp.t('Site') }}</strong>
        </div>
        <div>
            <strong>{{ vcp.t('Disable registration url') }}</strong>
        </div>
        <div>
            <strong>{{ vcp.t('Re-enable url') }}</strong>
        </div>
        <div></div>
        <div></div>

        {% for site in sites %}
            {% set block_url = craft.views_work_cp.cookieblockUrl(site.id) %}
            {% set unblock_url = craft.views_work_cp.cookieUnblockUrl(site.id) %}
            {% set status_url = craft.views_work_cp.cookieBlockStatusUrl(site.id) %}
            <div>
                {{ site.name }}
            </div>
            <div class=\"vw-pb-1 vw-pr-3\">
                <input type=\"text\" value=\"{{ block_url }}\" class=\"vw-w-full vw-border vw-border-opacity-50 vw-border-solid vw-border-info\" onclick=\"this.select();\" readonly=\"readonly\">
            </div>
            <div class=\"vw-pb-1 vw-pr-3\">
                <input type=\"text\" value=\"{{ unblock_url }}\" class=\"vw-w-full vw-border vw-border-opacity-50 vw-border-solid vw-border-info\" onclick=\"this.select();\" readonly=\"readonly\">
            </div>
            <div>
                <a href=\"{{ block_url }}\" target=\"_blank\"
                   class=\"vw-badge vw-badge-danger\">{{ vcp.t('DISABLE REG. NOW') }}</a>
            </div>
            <div>
                <a href=\"{{ status_url }}\" target=\"vw_blk\"  class=\"vw-badge vw-badge-info\">{{ vcp.t('status') }}</a>
            </div>
        {% endfor %}
    </div>

    <p>
        <span class=\"vw-text-xs\">{{ vcp.t('Note: after visiting the block/unblock urls, you need to reload this page to view the right status') }}</span>
    </p>
</div>", "views-work/cp/_partials/dashboard/blocking.twig", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/cp/_partials/dashboard/blocking.twig");
    }
}
