<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _partials/left_nav.twig */
class __TwigTemplate_bc0fadceccf40ce0c2f3f5a48a9ce15ee5c24c27f0af7fbc70c27378b55c4224 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_partials/left_nav.twig");
        // line 1
        echo "<div class=\"flex flex-col justify-between h-screen p-4 bg-gray-800\">
    <div class=\"text-sm\">
        ";
        // line 3
        $context["current_url"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "request", []), "url", []);
        // line 4
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["leftMenu"]) || array_key_exists("leftMenu", $context) ? $context["leftMenu"] : (function () { throw new RuntimeError('Variable "leftMenu" does not exist.', 4, $this->source); })()), "menu", []), "all", []));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 5
            echo "            ";
            $context["url"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "entry", []), "one", []), "url", []);
            // line 6
            echo "            ";
            $context["active"] = ((isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 6, $this->source); })()) == (isset($context["current_url"]) || array_key_exists("current_url", $context) ? $context["current_url"] : (function () { throw new RuntimeError('Variable "current_url" does not exist.', 6, $this->source); })()));
            // line 7
            echo "            ";
            if ((isset($context["active"]) || array_key_exists("active", $context) ? $context["active"] : (function () { throw new RuntimeError('Variable "active" does not exist.', 7, $this->source); })())) {
                // line 8
                echo "                <div class=\"bg-gray-700 text-blue-300 p-2 rounded mt-2 cursor-default\">
                    ";
                // line 9
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "label", []), "html", null, true);
                echo "
                </div>
            ";
            } else {
                // line 12
                echo "                <a href=\"";
                echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 12, $this->source); })()), "html", null, true);
                echo "\" class=\"block w-full bg-gray-900 text-white p-2 rounded mt-2 cursor-pointer hover:bg-gray-700 hover:text-blue-300\">
                    ";
                // line 13
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "label", []), "html", null, true);
                echo "
                </a>
            ";
            }
            // line 16
            echo "
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "    </div>
</div>";
        craft\helpers\Template::endProfile("template", "_partials/left_nav.twig");
    }

    public function getTemplateName()
    {
        return "_partials/left_nav.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 18,  78 => 16,  72 => 13,  67 => 12,  61 => 9,  58 => 8,  55 => 7,  52 => 6,  49 => 5,  44 => 4,  42 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"flex flex-col justify-between h-screen p-4 bg-gray-800\">
    <div class=\"text-sm\">
        {% set current_url = craft.request.url %}
        {% for item in leftMenu.menu.all %}
            {% set url = item.entry.one.url %}
            {% set active = url == current_url %}
            {% if active %}
                <div class=\"bg-gray-700 text-blue-300 p-2 rounded mt-2 cursor-default\">
                    {{ item.label }}
                </div>
            {% else %}
                <a href=\"{{ url }}\" class=\"block w-full bg-gray-900 text-white p-2 rounded mt-2 cursor-pointer hover:bg-gray-700 hover:text-blue-300\">
                    {{ item.label }}
                </a>
            {% endif %}

        {% endfor %}
    </div>
</div>", "_partials/left_nav.twig", "/var/www/html/templates/_partials/left_nav.twig");
    }
}
