<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_components/widgets/ViewsWorkWidget_settings */
class __TwigTemplate_5a3fa7f716111a3bcac71e41c38bae0b01b8359db94b61630905ca90230fe527 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_components/widgets/ViewsWorkWidget_settings");
        // line 15
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "views-work/_components/widgets/ViewsWorkWidget_settings", 15)->unwrap();
        // line 16
        $macros["cpmacros"] = $this->macros["cpmacros"] = $this->loadTemplate("views-work/_macros", "views-work/_components/widgets/ViewsWorkWidget_settings", 16)->unwrap();
        // line 17
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 17, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\viewswork\\assetbundles\\viewswork\\ViewsWorkAsset"], "method");
        // line 18
        echo "
";
        // line 19
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 19, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 20
            echo "    ";
            $context["editableSites"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 20, $this->source); })()), "app", []), "sites", []), "getEditableSites", [], "method");
            // line 21
            echo "

    ";
            // line 23
            if ((twig_length_filter($this->env, (isset($context["editableSites"]) || array_key_exists("editableSites", $context) ? $context["editableSites"] : (function () { throw new RuntimeError('Variable "editableSites" does not exist.', 23, $this->source); })())) > 1)) {
                // line 24
                echo "        ";
                ob_start();
                // line 25
                echo "            <div class=\"select\">
                <select id=\"site-id\" name=\"siteId\">
                    ";
                // line 27
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["editableSites"]) || array_key_exists("editableSites", $context) ? $context["editableSites"] : (function () { throw new RuntimeError('Variable "editableSites" does not exist.', 27, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                    // line 28
                    echo "                        <option value=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), "html", null, true);
                    echo "\"";
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 28, $this->source); })()), "siteId", []))) {
                        echo " selected";
                    }
                    echo ">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "site"), "html", null, true);
                    echo "</option>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 30
                echo "                </select>
            </div>
        ";
                $context["siteInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
                // line 33
                echo "
        ";
                // line 34
                echo twig_call_macro($macros["forms"], "macro_field", [["id" => "site-id", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app")],                 // line 37
(isset($context["siteInput"]) || array_key_exists("siteInput", $context) ? $context["siteInput"] : (function () { throw new RuntimeError('Variable "siteInput" does not exist.', 37, $this->source); })())], 34, $context, $this->getSourceContext());
                echo "


        ";
                // line 40
                echo twig_call_macro($macros["forms"], "macro_lightswitch", [["label" => "Ignore selected site and use all sites", "id" => "allSites", "name" => "allSites", "on" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 44
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 44, $this->source); })()), "allSites", [], "array")]], 40, $context, $this->getSourceContext());
                // line 45
                echo "
    ";
            }
        }
        // line 48
        echo "
";
        // line 49
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => "Widget title", "instructions" => "Title to display on the widget", "id" => "widgetTitle", "name" => "widgetTitle", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 54, $this->source); })()), "widgetTitle", [], "array")]], 49, $context, $this->getSourceContext());
        // line 55
        echo "

";
        // line 57
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => "Number of items", "instructions" => "Number of popular items to show", "id" => "count", "name" => "count", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 62
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 62, $this->source); })()), "count", [], "array")]], 57, $context, $this->getSourceContext());
        // line 63
        echo "

";
        // line 65
        ob_start();
        // line 66
        echo "    <div class=\"select\">
        <select id=\"section\" name=\"section\">
            <option value=\"*\">";
        // line 68
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
        echo "</option>
            ";
        // line 69
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 69, $this->source); })()), "app", []), "sections", []), "getAllSections", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 70
            echo "                ";
            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["section"], "type", []) != "single")) {
                // line 71
                echo "                    <option value=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["section"], "id", []), "html", null, true);
                echo "\"";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["section"], "id", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 71, $this->source); })()), "section", []))) {
                    echo " selected";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["section"], "name", []), "site"), "html", null, true);
                echo "</option>
                ";
            }
            // line 73
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 74
        echo "        </select>
    </div>
";
        $context["sectionInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 77
        echo "
";
        // line 78
        echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Section", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which section do you want to pull popular entries from?", "views-work"), "id" => "section"],         // line 82
(isset($context["sectionInput"]) || array_key_exists("sectionInput", $context) ? $context["sectionInput"] : (function () { throw new RuntimeError('Variable "sectionInput" does not exist.', 82, $this->source); })())], 78, $context, $this->getSourceContext());
        echo "


<br/>

";
        // line 87
        echo twig_call_macro($macros["forms"], "macro_lightswitch", [["label" => "Show all time", "id" => "showTotal", "name" => "showTotal", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 91
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 91, $this->source); })()), "showTotal", [], "array")]], 87, $context, $this->getSourceContext());
        // line 92
        echo "

<br/>

";
        // line 96
        echo twig_call_macro($macros["forms"], "macro_lightswitch", [["label" => "Show monthly", "id" => "showMonthly", "name" => "showMonthly", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 100
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 100, $this->source); })()), "showMonthly", [], "array")]], 96, $context, $this->getSourceContext());
        // line 101
        echo "

<br/>

";
        // line 105
        echo twig_call_macro($macros["forms"], "macro_lightswitch", [["label" => "Show weekly", "id" => "showWekly", "name" => "showWeekly", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 109
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 109, $this->source); })()), "showWeekly", [], "array")]], 105, $context, $this->getSourceContext());
        // line 110
        echo "

<br/>

";
        // line 114
        echo twig_call_macro($macros["forms"], "macro_lightswitch", [["label" => "Show daily", "id" => "showDaily", "name" => "showDaily", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 118
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 118, $this->source); })()), "showDaily", [], "array")]], 114, $context, $this->getSourceContext());
        craft\helpers\Template::endProfile("template", "views-work/_components/widgets/ViewsWorkWidget_settings");
    }

    public function getTemplateName()
    {
        return "views-work/_components/widgets/ViewsWorkWidget_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  204 => 118,  203 => 114,  197 => 110,  195 => 109,  194 => 105,  188 => 101,  186 => 100,  185 => 96,  179 => 92,  177 => 91,  176 => 87,  168 => 82,  167 => 78,  164 => 77,  159 => 74,  153 => 73,  141 => 71,  138 => 70,  134 => 69,  130 => 68,  126 => 66,  124 => 65,  120 => 63,  118 => 62,  117 => 57,  113 => 55,  111 => 54,  110 => 49,  107 => 48,  102 => 45,  100 => 44,  99 => 40,  93 => 37,  92 => 34,  89 => 33,  84 => 30,  69 => 28,  65 => 27,  61 => 25,  58 => 24,  56 => 23,  52 => 21,  49 => 20,  47 => 19,  44 => 18,  42 => 17,  40 => 16,  38 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * Views Work plugin for Craft CMS
 *
 * ViewsWorkWidget Widget Settings
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2018 24hoursmedia
 * @link      http://www.24hoursmedia.com
 * @package   ViewsWork
 * @since     1.0.0
 */
#}
{% import \"_includes/forms\" as forms %}
{% import 'views-work/_macros' as cpmacros %}
{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\viewswork\\\\assetbundles\\\\viewswork\\\\ViewsWorkAsset\") %}

{% if craft.app.getIsMultiSite() %}
    {% set editableSites = craft.app.sites.getEditableSites() %}


    {% if editableSites|length > 1 %}
        {% set siteInput %}
            <div class=\"select\">
                <select id=\"site-id\" name=\"siteId\">
                    {% for site in editableSites %}
                        <option value=\"{{ site.id }}\"{% if site.id == widget.siteId %} selected{% endif %}>{{ site.name|t('site') }}</option>
                    {% endfor %}
                </select>
            </div>
        {% endset %}

        {{ forms.field({
            id: 'site-id',
            label: \"Site\"|t('app')
        }, siteInput) }}


        {{ forms.lightswitch({
            label: 'Ignore selected site and use all sites',
            id: 'allSites',
            name: 'allSites',
            on: widget['allSites']})
        }}
    {% endif %}
{% endif %}

{{ forms.textField({
    label: 'Widget title',
    instructions: 'Title to display on the widget',
    id: 'widgetTitle',
    name: 'widgetTitle',
    value: widget['widgetTitle']})
}}

{{ forms.textField({
    label: 'Number of items',
    instructions: 'Number of popular items to show',
    id: 'count',
    name: 'count',
    value: widget['count']})
}}

{% set sectionInput %}
    <div class=\"select\">
        <select id=\"section\" name=\"section\">
            <option value=\"*\">{{ \"All\"|t('app') }}</option>
            {% for section in craft.app.sections.getAllSections() %}
                {% if section.type != 'single' %}
                    <option value=\"{{ section.id }}\"{% if section.id == widget.section %} selected{% endif %}>{{ section.name|t('site') }}</option>
                {% endif %}
            {% endfor %}
        </select>
    </div>
{% endset %}

{{ forms.field({
    label: \"Section\"|t('app'),
    instructions: \"Which section do you want to pull popular entries from?\"|t('views-work'),
    id: 'section',
}, sectionInput) }}


<br/>

{{ forms.lightswitch({
    label: 'Show all time',
    id: 'showTotal',
    name: 'showTotal',
    on: widget['showTotal']})
}}

<br/>

{{ forms.lightswitch({
    label: 'Show monthly',
    id: 'showMonthly',
    name: 'showMonthly',
    on: widget['showMonthly']})
}}

<br/>

{{ forms.lightswitch({
    label: 'Show weekly',
    id: 'showWekly',
    name: 'showWeekly',
    on: widget['showWeekly']})
}}

<br/>

{{ forms.lightswitch({
    label: 'Show daily',
    id: 'showDaily',
    name: 'showDaily',
    on: widget['showDaily']})
}}", "views-work/_components/widgets/ViewsWorkWidget_settings", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_components/widgets/ViewsWorkWidget_settings.twig");
    }
}
