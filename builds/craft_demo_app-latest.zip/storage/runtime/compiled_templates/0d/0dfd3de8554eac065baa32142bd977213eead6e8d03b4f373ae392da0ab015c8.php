<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/cp/_partials/dashboard/widgets.twig */
class __TwigTemplate_ada6c8dc37d0ef173bb3b82836abcaeb132ed22a22188a675cc8e592de2a67aa extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/cp/_partials/dashboard/widgets.twig");
        // line 1
        $macros["vcp"] = $this->macros["vcp"] = $this->loadTemplate("views-work/_macros.twig", "views-work/cp/_partials/dashboard/widgets.twig", 1)->unwrap();
        // line 2
        echo "
<div class=\"content-pane vw-mt-3\">
    <h2>";
        // line 4
        echo twig_call_macro($macros["vcp"], "macro_t", ["Widgets"], 4, $context, $this->getSourceContext());
        echo "</h2>
    <p>
        ";
        // line 6
        echo twig_call_macro($macros["vcp"], "macro_t", ["Widgets available in the Craft Dashboard:"], 6, $context, $this->getSourceContext());
        echo "
    </p>
    <p>
        <strong class=\"vw-text-info\">";
        // line 9
        echo twig_call_macro($macros["vcp"], "macro_t", ["Viewed Now"], 9, $context, $this->getSourceContext());
        echo "</strong>:<br/>
        ";
        // line 10
        echo twig_call_macro($macros["vcp"], "macro_t", ["A widget that shows entries that are being currently viewed in near real time."], 10, $context, $this->getSourceContext());
        echo "
    </p>
    <p>
        <strong class=\"vw-text-info\">";
        // line 13
        echo twig_call_macro($macros["vcp"], "macro_t", ["Popular content"], 13, $context, $this->getSourceContext());
        echo "</strong>:<br/>
        ";
        // line 14
        echo twig_call_macro($macros["vcp"], "macro_t", ["A widget that shows entries that are most viewed today, this week, this month or all time."], 14, $context, $this->getSourceContext());
        echo "
    </p>
</div>";
        craft\helpers\Template::endProfile("template", "views-work/cp/_partials/dashboard/widgets.twig");
    }

    public function getTemplateName()
    {
        return "views-work/cp/_partials/dashboard/widgets.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 14,  65 => 13,  59 => 10,  55 => 9,  49 => 6,  44 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import 'views-work/_macros.twig' as vcp %}

<div class=\"content-pane vw-mt-3\">
    <h2>{{ vcp.t('Widgets') }}</h2>
    <p>
        {{ vcp.t('Widgets available in the Craft Dashboard:') }}
    </p>
    <p>
        <strong class=\"vw-text-info\">{{ vcp.t('Viewed Now') }}</strong>:<br/>
        {{ vcp.t('A widget that shows entries that are being currently viewed in near real time.') }}
    </p>
    <p>
        <strong class=\"vw-text-info\">{{ vcp.t('Popular content') }}</strong>:<br/>
        {{ vcp.t('A widget that shows entries that are most viewed today, this week, this month or all time.') }}
    </p>
</div>", "views-work/cp/_partials/dashboard/widgets.twig", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/cp/_partials/dashboard/widgets.twig");
    }
}
