<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* homepage/_entry */
class __TwigTemplate_1ec77d1f28cc9dec4f243b070d6fa3b77a44737dbb69796b756f456ba810df1e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "homepage/_entry");
        $this->parent = $this->loadTemplate("_layout.html.twig", "homepage/_entry", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "homepage/_entry");
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 4
        echo "
    <div class=\"app-content\">
        <h1>";
        // line 6
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 6, $this->source); })()), "title", []), "html", null, true);
        echo "</h1>
        ";
        // line 7
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 7, $this->source); })()), "bodyText", []), "html", null, true);
        echo "

        <h2>Content Index</h2>
        <p>In the content items below, you'll see the plugins demonstrated.</p>
        ";
        // line 11
        $context["articles"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "entries", []), "section", [0 => "contents"], "method"), "limit", [0 => 50], "method"), "all", []);
        // line 12
        echo "        <ul>
        ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["articles"]) || array_key_exists("articles", $context) ? $context["articles"] : (function () { throw new RuntimeError('Variable "articles" does not exist.', 13, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["article"]) {
            // line 14
            echo "            <li><a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["article"], "url", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["article"], "title", []), "html", null, true);
            echo "</a></li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['article'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "        </ul>

    </div>

    ";
        // line 21
        echo "    ";
        echo $this->extensions['twentyfourhoursmedia\viewswork\twigextensions\ViewsWorkTwigExtension']->viewsWorkImage((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 21, $this->source); })()));
        echo "

";
        craft\helpers\Template::endProfile("block", "body");
    }

    public function getTemplateName()
    {
        return "homepage/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 21,  88 => 16,  77 => 14,  73 => 13,  70 => 12,  68 => 11,  61 => 7,  57 => 6,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '_layout.html.twig' %}

{% block body %}

    <div class=\"app-content\">
        <h1>{{ entry.title }}</h1>
        {{ entry.bodyText }}

        <h2>Content Index</h2>
        <p>In the content items below, you'll see the plugins demonstrated.</p>
        {% set articles = craft.entries.section('contents').limit(50).all %}
        <ul>
        {% for article in articles %}
            <li><a href=\"{{ article.url }}\">{{ article.title }}</a></li>
        {% endfor %}
        </ul>

    </div>

    {# Register the pageview with a registration pixel #}
    {{ entry | views_work_image }}

{% endblock %}", "homepage/_entry", "/var/www/html/templates/homepage/_entry.twig");
    }
}
