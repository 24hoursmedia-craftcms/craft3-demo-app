<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/checkboxSelect */
class __TwigTemplate_52353e10f5d4fa4d24164e7cee1dcb30577e8cd0cb977661968f2fd1375135df extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/checkboxSelect");
        // line 1
        $context["options"] = (($context["options"]) ?? ([]));
        // line 2
        $context["values"] = (($context["values"]) ?? ([]));
        // line 4
        $context["showAllOption"] = (($context["showAllOption"]) ?? (false));
        // line 5
        if ((isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 5, $this->source); })())) {
            // line 6
            $context["allLabel"] = (($context["allLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("All", "app")));
            // line 7
            $context["allValue"] = (($context["allValue"]) ?? ("*"));
            // line 8
            $context["allChecked"] = ((isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 8, $this->source); })()) == (isset($context["allValue"]) || array_key_exists("allValue", $context) ? $context["allValue"] : (function () { throw new RuntimeError('Variable "allValue" does not exist.', 8, $this->source); })()));
        }
        // line 10
        echo "
";
        // line 11
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->mergeFilter([0 => "checkbox-select"], craft\helpers\Html::explodeClass(((        // line 12
$context["class"]) ?? ([]))))], ((        // line 13
$context["containerAttributes"]) ?? ([])), true);
        // line 15
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 16
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 16, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 18
        echo "
";
        // line 19
        ob_start();
        // line 20
        if ((isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 20, $this->source); })())) {
            // line 21
            echo "        <div>
            ";
            // line 22
            $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/checkboxSelect", 22)->display(twig_to_array(["id" => ((            // line 23
$context["id"]) ?? (null)), "instructionsId" => ((            // line 24
$context["instructionsId"]) ?? (false)), "class" => "all", "label" => craft\helpers\Template::raw((("<b>" .             // line 26
(isset($context["allLabel"]) || array_key_exists("allLabel", $context) ? $context["allLabel"] : (function () { throw new RuntimeError('Variable "allLabel" does not exist.', 26, $this->source); })())) . "</b>")), "name" => ((            // line 27
$context["name"]) ?? (null)), "value" =>             // line 28
(isset($context["allValue"]) || array_key_exists("allValue", $context) ? $context["allValue"] : (function () { throw new RuntimeError('Variable "allValue" does not exist.', 28, $this->source); })()), "checked" =>             // line 29
(isset($context["allChecked"]) || array_key_exists("allChecked", $context) ? $context["allChecked"] : (function () { throw new RuntimeError('Variable "allChecked" does not exist.', 29, $this->source); })()), "autofocus" => (((            // line 30
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 30, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method"))]));
            // line 32
            echo "        </div>";
        }
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 34, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["option"]) {
            // line 35
            if ( !twig_test_iterable($context["option"])) {
                // line 36
                $context["option"] = ["label" => $context["option"], "value" => $context["key"]];
            }
            // line 38
            echo "        ";
            if ((( !(isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 38, $this->source); })()) ||  !craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", true, true)) || (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", []) != (isset($context["allValue"]) || array_key_exists("allValue", $context) ? $context["allValue"] : (function () { throw new RuntimeError('Variable "allValue" does not exist.', 38, $this->source); })())))) {
                // line 39
                echo "            <div>
                ";
                // line 40
                $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/checkboxSelect", 40)->display(twig_to_array($this->extensions['craft\web\twig\Extension']->mergeFilter(["name" => ((((                // line 41
$context["name"]) ?? (false))) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 41, $this->source); })()) . "[]")) : (null)), "checked" => ((                // line 42
(isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 42, $this->source); })()) && (isset($context["allChecked"]) || array_key_exists("allChecked", $context) ? $context["allChecked"] : (function () { throw new RuntimeError('Variable "allChecked" does not exist.', 42, $this->source); })())) || (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", true, true) && twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", []), (isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 42, $this->source); })())))), "disabled" => (                // line 43
(isset($context["showAllOption"]) || array_key_exists("showAllOption", $context) ? $context["showAllOption"] : (function () { throw new RuntimeError('Variable "showAllOption" does not exist.', 43, $this->source); })()) && (isset($context["allChecked"]) || array_key_exists("allChecked", $context) ? $context["allChecked"] : (function () { throw new RuntimeError('Variable "allChecked" does not exist.', 43, $this->source); })()))],                 // line 44
$context["option"])));
                // line 45
                echo "            </div>
        ";
            }
            // line 47
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo craft\helpers\Html::tag("fieldset", ob_get_clean(),         // line 19
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 19, $this->source); })()));
        craft\helpers\Template::endProfile("template", "_includes/forms/checkboxSelect");
    }

    public function getTemplateName()
    {
        return "_includes/forms/checkboxSelect";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 19,  112 => 47,  108 => 45,  106 => 44,  105 => 43,  104 => 42,  103 => 41,  102 => 40,  99 => 39,  96 => 38,  93 => 36,  91 => 35,  87 => 34,  84 => 32,  82 => 30,  81 => 29,  80 => 28,  79 => 27,  78 => 26,  77 => 24,  76 => 23,  75 => 22,  72 => 21,  70 => 20,  68 => 19,  65 => 18,  62 => 16,  60 => 15,  58 => 13,  57 => 12,  56 => 11,  53 => 10,  50 => 8,  48 => 7,  46 => 6,  44 => 5,  42 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set options = options ?? [] %}
{%- set values = values ?? [] -%}

{%- set showAllOption = showAllOption ?? false %}
{%- if showAllOption %}
    {%- set allLabel = allLabel ?? \"All\"|t('app') %}
    {%- set allValue = allValue ?? '*' %}
    {%- set allChecked = (values == allValue) %}
{%- endif %}

{% set containerAttributes = {
    class: ['checkbox-select']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% tag 'fieldset' with containerAttributes %}
    {%- if showAllOption %}
        <div>
            {% include \"_includes/forms/checkbox\" with {
                id: id ?? null,
                instructionsId: instructionsId ?? false,
                class: 'all',
                label: raw(\"<b>#{allLabel}</b>\"),
                name: name ?? null,
                value: allValue,
                checked: allChecked,
                autofocus: (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
            } only %}
        </div>
    {%- endif %}
    {%- for key, option in options %}
        {%- if option is not iterable %}
            {%- set option = {label: option, value: key} %}
        {%- endif %}
        {% if not showAllOption or option.value is not defined or option.value != allValue %}
            <div>
                {% include \"_includes/forms/checkbox\" with {
                    name: (name ?? false) ? \"#{name}[]\" : null,
                    checked: ((showAllOption and allChecked) or (option.value is defined and option.value in values)),
                    disabled: (showAllOption and allChecked)
                }|merge(option) only %}
            </div>
        {% endif %}
    {% endfor %}
{% endtag %}
", "_includes/forms/checkboxSelect", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/checkboxSelect.html");
    }
}
