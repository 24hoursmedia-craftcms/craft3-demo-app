<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* content/_entry */
class __TwigTemplate_576ba66d922dd373333bd807962fac61a1b42229ba6ad11cc10aaa9bb85de007 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "content/_entry");
        $this->parent = $this->loadTemplate("_layout.html.twig", "content/_entry", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "content/_entry");
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 4
        echo "
    ";
        // line 6
        echo "    ";
        echo $this->extensions['twentyfourhoursmedia\viewswork\twigextensions\ViewsWorkTwigExtension']->viewsWorkImage((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 6, $this->source); })()));
        echo "

    ";
        // line 8
        $this->loadTemplate("_components/common/prevnext.twig", "content/_entry", 8)->display(twig_to_array(["entry" => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 8, $this->source); })())]));
        // line 9
        echo "
    <div class=\"app-content\">

        <div class=\"grid grid-cols-2\">
            <div>
                <h1>";
        // line 14
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 14, $this->source); })()), "title", []), "html", null, true);
        echo "</h1>
                ";
        // line 15
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 15, $this->source); })()), "bodyText", []), "html", null, true);
        echo "

                <hr/>
                ";
        // line 18
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 18, $this->source); })()), "enableCommenting", [])) {
            // line 19
            echo "                    ";
            $this->loadTemplate("_components/comments_work/comment_form.twig", "content/_entry", 19)->display(twig_to_array(["entry" => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 19, $this->source); })())]));
            // line 20
            echo "                ";
        }
        // line 21
        echo "
                ";
        // line 22
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 22, $this->source); })()), "showComments", []) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 22, $this->source); })()), "enableCommenting", []))) {
            // line 23
            echo "                    ";
            $this->loadTemplate("_components/comments_work/comments.twig", "content/_entry", 23)->display(twig_to_array(["entry" =>             // line 24
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 24, $this->source); })())]));
            // line 26
            echo "                ";
        }
        // line 27
        echo "

                ";
        // line 30
        echo "                ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 30, $this->source); })()), "enableCommenting", [])) {
            // line 31
            echo "                    ";
            $this->loadTemplate("_components/comments_work/xhr_comment_form.twig", "content/_entry", 31)->display(twig_to_array(["entry" =>             // line 32
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 32, $this->source); })()), "comments_selector" => "#comments_container"]));
            // line 35
            echo "                ";
        }
        // line 36
        echo "
                ";
        // line 37
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 37, $this->source); })()), "showComments", []) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 37, $this->source); })()), "enableCommenting", []))) {
            // line 38
            echo "                <div id=\"comments_container\" class=\"js-xhr-comments\" data-xhr-comments-url=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::siteUrl("/comments-work/xhr/comments", ["id" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 38, $this->source); })()), "id", [])]), "html", null, true);
            echo "\">
                </div>
                ";
        }
        // line 41
        echo "
            </div>
            <div>
                ";
        // line 44
        $this->loadTemplate("_components/views_work/view_counts.twig", "content/_entry", 44)->display(twig_to_array(["entry" => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 44, $this->source); })())]));
        // line 45
        echo "            </div>
        </div>


    </div>

";
        craft\helpers\Template::endProfile("block", "body");
    }

    public function getTemplateName()
    {
        return "content/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 45,  132 => 44,  127 => 41,  120 => 38,  118 => 37,  115 => 36,  112 => 35,  110 => 32,  108 => 31,  105 => 30,  101 => 27,  98 => 26,  96 => 24,  94 => 23,  92 => 22,  89 => 21,  86 => 20,  83 => 19,  81 => 18,  75 => 15,  71 => 14,  64 => 9,  62 => 8,  56 => 6,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '_layout.html.twig' %}

{% block body %}

    {# Register the pageview with a registration pixel #}
    {{ entry | views_work_image }}

    {% include '_components/common/prevnext.twig' with {entry: entry} only %}

    <div class=\"app-content\">

        <div class=\"grid grid-cols-2\">
            <div>
                <h1>{{ entry.title }}</h1>
                {{ entry.bodyText }}

                <hr/>
                {% if entry.enableCommenting %}
                    {% include '_components/comments_work/comment_form.twig' with {entry: entry} only %}
                {% endif %}

                {% if entry.showComments or entry.enableCommenting %}
                    {% include '_components/comments_work/comments.twig' with {
                        entry: entry
                    } only %}
                {% endif %}


                {# ajax variant #}
                {% if entry.enableCommenting %}
                    {% include '_components/comments_work/xhr_comment_form.twig' with {
                        entry: entry,
                        comments_selector: '#comments_container'
                    } only %}
                {% endif %}

                {% if entry.showComments or entry.enableCommenting %}
                <div id=\"comments_container\" class=\"js-xhr-comments\" data-xhr-comments-url=\"{{ siteUrl('/comments-work/xhr/comments', {id: entry.id}) }}\">
                </div>
                {% endif %}

            </div>
            <div>
                {% include '_components/views_work/view_counts.twig' with {entry: entry} only %}
            </div>
        </div>


    </div>

{% endblock %}", "content/_entry", "/var/www/html/templates/content/_entry.twig");
    }
}
