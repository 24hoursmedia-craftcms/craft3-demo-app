<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/cp/_partials/dashboard/documentation.twig */
class __TwigTemplate_5e4a308218431f770bb5c98ec0e562220bec8e4b6393295f92e2010d84b71bd6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/cp/_partials/dashboard/documentation.twig");
        // line 1
        $macros["vcp"] = $this->macros["vcp"] = $this->loadTemplate("views-work/_macros.twig", "views-work/cp/_partials/dashboard/documentation.twig", 1)->unwrap();
        // line 2
        echo "
<div class=\"content-pane vw-mt-3\">
    <h2>";
        // line 4
        echo twig_call_macro($macros["vcp"], "macro_t", ["Resources"], 4, $context, $this->getSourceContext());
        echo "</h2>

    <p>
        ";
        // line 7
        echo twig_call_macro($macros["vcp"], "macro_t", ["For more information, visit the views-work plugin page at"], 7, $context, $this->getSourceContext());
        echo "
        <a href=\"https://io.24hoursmedia.com/views-work\" target=\"_blank\">io.24hoursmedia.com ";
        // line 8
        echo twig_call_macro($macros["vcp"], "macro_icon_arrow", [], 8, $context, $this->getSourceContext());
        echo "</a>

    </p>

</div>";
        craft\helpers\Template::endProfile("template", "views-work/cp/_partials/dashboard/documentation.twig");
    }

    public function getTemplateName()
    {
        return "views-work/cp/_partials/dashboard/documentation.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 8,  50 => 7,  44 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import 'views-work/_macros.twig' as vcp %}

<div class=\"content-pane vw-mt-3\">
    <h2>{{ vcp.t('Resources') }}</h2>

    <p>
        {{ vcp.t('For more information, visit the views-work plugin page at') }}
        <a href=\"https://io.24hoursmedia.com/views-work\" target=\"_blank\">io.24hoursmedia.com {{ vcp.icon_arrow() }}</a>

    </p>

</div>", "views-work/cp/_partials/dashboard/documentation.twig", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/cp/_partials/dashboard/documentation.twig");
    }
}
