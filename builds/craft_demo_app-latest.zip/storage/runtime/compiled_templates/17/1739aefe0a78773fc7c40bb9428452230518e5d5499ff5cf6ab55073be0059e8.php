<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/views_work/view_counts.twig */
class __TwigTemplate_d068873e3245a325786da2e0492f04c698a160ea0380d2de87e279d01fdfc8e5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/views_work/view_counts.twig");
        // line 9
        echo "
";
        // line 11
        echo "
<div class=\"flex\">
    <div class=\"pr-3\">
        Views for this entry:
    </div>
    <div>
        <button class=\"app-badge bg-blue-600 cursor-default\">
            Views today
            <span>";
        // line 19
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 19, $this->source); })()), "viewsWork", []), "today", []), "html", null, true);
        echo "</span>
        </button>
    </div>
    <div>
        <button class=\"app-badge bg-green-600 cursor-default\">
            This week
            <span>";
        // line 25
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 25, $this->source); })()), "viewsWork", []), "thisWeek", []), "html", null, true);
        echo "</span>
        </button>
    </div>
    <div>
        <button class=\"app-badge bg-yellow-600 cursor-default\">
            This month
            <span>";
        // line 31
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 31, $this->source); })()), "viewsWork", []), "thisMonth", []), "html", null, true);
        echo "</span>
        </button>
    </div>
    <div>
        <button class=\"app-badge bg-red-600 cursor-default\">
            All time
            <span>";
        // line 37
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 37, $this->source); })()), "viewsWork", []), "total", []), "html", null, true);
        echo "</span>
        </button>
    </div>
</div>
";
        craft\helpers\Template::endProfile("template", "_components/views_work/view_counts.twig");
    }

    public function getTemplateName()
    {
        return "_components/views_work/view_counts.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 37,  69 => 31,  60 => 25,  51 => 19,  41 => 11,  38 => 9,);
    }

    public function getSourceContext()
    {
        return new Source("{#
    Show a flexbox with view counts for an entry

    Example (twig):

    {% include '_components/views_work/view_counts.twig' with {entry: entry} %}

#}

{# @param entry     the entry to show the view counts for #}

<div class=\"flex\">
    <div class=\"pr-3\">
        Views for this entry:
    </div>
    <div>
        <button class=\"app-badge bg-blue-600 cursor-default\">
            Views today
            <span>{{ entry.viewsWork.today }}</span>
        </button>
    </div>
    <div>
        <button class=\"app-badge bg-green-600 cursor-default\">
            This week
            <span>{{ entry.viewsWork.thisWeek }}</span>
        </button>
    </div>
    <div>
        <button class=\"app-badge bg-yellow-600 cursor-default\">
            This month
            <span>{{ entry.viewsWork.thisMonth }}</span>
        </button>
    </div>
    <div>
        <button class=\"app-badge bg-red-600 cursor-default\">
            All time
            <span>{{ entry.viewsWork.total }}</span>
        </button>
    </div>
</div>
", "_components/views_work/view_counts.twig", "/var/www/html/templates/_components/views_work/view_counts.twig");
    }
}
