<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_components/widgets/ViewedNowWidget_body */
class __TwigTemplate_53697bc3a544596213f1a13851217fa9d9d20f6e55931de1662fc68b7ff5acd0 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_components/widgets/ViewedNowWidget_body");
        // line 1
        $macros["cpmacros"] = $this->macros["cpmacros"] = $this->loadTemplate("views-work/_macros", "views-work/_components/widgets/ViewedNowWidget_body", 1)->unwrap();
        // line 2
        $macros["_macros"] = $this->macros["_macros"] = $this;
        // line 3
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\viewswork\\assetbundles\\viewswork\\ViewsWorkAsset"], "method");
        // line 4
        $context["container_id"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "views_work_cp", []), "uniqid", [0 => "viewednow_container_"], "method");
        // line 5
        echo "<div id=\"";
        echo twig_escape_filter($this->env, (isset($context["container_id"]) || array_key_exists("container_id", $context) ? $context["container_id"] : (function () { throw new RuntimeError('Variable "container_id" does not exist.', 5, $this->source); })()), "html", null, true);
        echo "\">

    ";
        // line 7
        if ((isset($context["enableAutoRefresh"]) || array_key_exists("enableAutoRefresh", $context) ? $context["enableAutoRefresh"] : (function () { throw new RuntimeError('Variable "enableAutoRefresh" does not exist.', 7, $this->source); })())) {
            // line 8
            echo "    <div class=\"vw-load-indicator vw-absolute vw--top-9 vw-right-5\" style=\"padding-top: 1px\">
        <svg class=\"vw-spinner\" fill=\"none\" viewBox=\"0 0 24 24\">
            <circle class=\"vw-opacity-25\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" stroke-width=\"4\"></circle>
            <path class=\"vw-opacity-75\" fill=\"currentColor\" d=\"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z\"></path>
        </svg>
    </div>
    ";
        }
        // line 15
        echo "
    <div
            class=\"vw-js-rx-refresh\"
            data-vw-rx-refresh-uri=\"";
        // line 18
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::actionUrl("views-work/viewed-now-widget/content", ["count" =>         // line 19
(isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 19, $this->source); })()), "seconds" =>         // line 20
(isset($context["seconds"]) || array_key_exists("seconds", $context) ? $context["seconds"] : (function () { throw new RuntimeError('Variable "seconds" does not exist.', 20, $this->source); })()), "siteId" =>         // line 21
(isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 21, $this->source); })()), "allSites" => ((        // line 22
(isset($context["allSites"]) || array_key_exists("allSites", $context) ? $context["allSites"] : (function () { throw new RuntimeError('Variable "allSites" does not exist.', 22, $this->source); })())) ? ("true") : ("false"))]), "html", null, true);
        // line 23
        echo "\"
            data-vw-rx-refresh-state-container=\"#";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["container_id"]) || array_key_exists("container_id", $context) ? $context["container_id"] : (function () { throw new RuntimeError('Variable "container_id" does not exist.', 24, $this->source); })()), "html", null, true);
        echo "\"
            data-vw-rx-refresh-autostart=\"";
        // line 25
        echo (((isset($context["enableAutoRefresh"]) || array_key_exists("enableAutoRefresh", $context) ? $context["enableAutoRefresh"] : (function () { throw new RuntimeError('Variable "enableAutoRefresh" does not exist.', 25, $this->source); })())) ? ("true") : ("false"));
        echo "\"
    >
    </div>


</div>

";
        // line 32
        $this->loadTemplate("views-work/_partials/widget_footer.twig", "views-work/_components/widgets/ViewedNowWidget_body", 32)->display($context);
        craft\helpers\Template::endProfile("template", "views-work/_components/widgets/ViewedNowWidget_body");
    }

    public function getTemplateName()
    {
        return "views-work/_components/widgets/ViewedNowWidget_body";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 32,  81 => 25,  77 => 24,  74 => 23,  72 => 22,  71 => 21,  70 => 20,  69 => 19,  68 => 18,  63 => 15,  54 => 8,  52 => 7,  46 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import 'views-work/_macros' as cpmacros %}
{% import _self as _macros %}
{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\viewswork\\\\assetbundles\\\\viewswork\\\\ViewsWorkAsset\") %}
{% set container_id = craft.views_work_cp.uniqid('viewednow_container_') %}
<div id=\"{{ container_id }}\">

    {% if enableAutoRefresh %}
    <div class=\"vw-load-indicator vw-absolute vw--top-9 vw-right-5\" style=\"padding-top: 1px\">
        <svg class=\"vw-spinner\" fill=\"none\" viewBox=\"0 0 24 24\">
            <circle class=\"vw-opacity-25\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" stroke-width=\"4\"></circle>
            <path class=\"vw-opacity-75\" fill=\"currentColor\" d=\"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z\"></path>
        </svg>
    </div>
    {% endif %}

    <div
            class=\"vw-js-rx-refresh\"
            data-vw-rx-refresh-uri=\"{{ actionUrl('views-work/viewed-now-widget/content', {
                count: count,
                seconds: seconds,
                siteId: siteId,
                allSites: allSites ? 'true' : 'false'
            }) }}\"
            data-vw-rx-refresh-state-container=\"#{{ container_id }}\"
            data-vw-rx-refresh-autostart=\"{{ enableAutoRefresh ? 'true' : 'false' }}\"
    >
    </div>


</div>

{% include 'views-work/_partials/widget_footer.twig' %}", "views-work/_components/widgets/ViewedNowWidget_body", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_components/widgets/ViewedNowWidget_body.twig");
    }
}
