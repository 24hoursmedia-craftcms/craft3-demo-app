<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/common/prevnext.twig */
class __TwigTemplate_48029f58b53521810d48c141b92623a3ba89490de1b6c484e5d8d2e251d0863d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/common/prevnext.twig");
        // line 8
        echo "
";
        // line 9
        $context["prev"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 9, $this->source); })()), "prevSibling", []);
        // line 10
        echo "    ";
        $context["next"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 10, $this->source); })()), "nextSibling", []);
        // line 11
        echo "
<div class=\"mb-2 flex text-sm\">
    <div>
        ";
        // line 14
        if ((isset($context["prev"]) || array_key_exists("prev", $context) ? $context["prev"] : (function () { throw new RuntimeError('Variable "prev" does not exist.', 14, $this->source); })())) {
            // line 15
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["prev"]) || array_key_exists("prev", $context) ? $context["prev"] : (function () { throw new RuntimeError('Variable "prev" does not exist.', 15, $this->source); })()), "url", []), "html", null, true);
            echo "\">&laquo; Previous</a>
        ";
        }
        // line 17
        echo "    </div>
    <div class=\"flex-grow\"></div>
    <div>
        ";
        // line 20
        if ((isset($context["next"]) || array_key_exists("next", $context) ? $context["next"] : (function () { throw new RuntimeError('Variable "next" does not exist.', 20, $this->source); })())) {
            // line 21
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["next"]) || array_key_exists("next", $context) ? $context["next"] : (function () { throw new RuntimeError('Variable "next" does not exist.', 21, $this->source); })()), "url", []), "html", null, true);
            echo "\">Next &raquo;</a>
        ";
        }
        // line 23
        echo "    </div>
</div>



";
        craft\helpers\Template::endProfile("template", "_components/common/prevnext.twig");
    }

    public function getTemplateName()
    {
        return "_components/common/prevnext.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 23,  66 => 21,  64 => 20,  59 => 17,  53 => 15,  51 => 14,  46 => 11,  43 => 10,  41 => 9,  38 => 8,);
    }

    public function getSourceContext()
    {
        return new Source("{#
    Shows previous / next items for entries in a structure

    Example:
    {% include '_components/common/prevnext.twig' with {entry: entry} only %}
#}
{# @param entry     the entry to show the view counts for #}

{% set prev = entry.prevSibling %}
    {% set next = entry.nextSibling %}

<div class=\"mb-2 flex text-sm\">
    <div>
        {% if prev %}
            <a href=\"{{ prev.url }}\">&laquo; Previous</a>
        {% endif %}
    </div>
    <div class=\"flex-grow\"></div>
    <div>
        {% if next %}
            <a href=\"{{ next.url }}\">Next &raquo;</a>
        {% endif %}
    </div>
</div>



", "_components/common/prevnext.twig", "/var/www/html/templates/_components/common/prevnext.twig");
    }
}
