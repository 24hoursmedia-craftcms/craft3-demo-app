<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_partials/widget_license_issue.twig */
class __TwigTemplate_6ddc0f55b332852d34af06d42a8c08da6e2d28425c311f7af7f5113519f76528 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_partials/widget_license_issue.twig");
        // line 1
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "views_work_cp", []), "licenseIssue", [])) {
            // line 2
            echo "    ";
            $macros["vcp"] = $this->macros["vcp"] = $this->loadTemplate("views-work/_macros.twig", "views-work/_partials/widget_license_issue.twig", 2)->unwrap();
            // line 3
            echo "    <div class=\"vw-alert vw-alert-danger vw-text-xs vw-mb-4\">
        ⚠ ";
            // line 4
            echo twig_call_macro($macros["vcp"], "macro_t", ["Please help support the development of this plugin by acquiring a valid license."], 4, $context, $this->getSourceContext());
            echo "
        <a href=\"";
            // line 5
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "views_work_cp", []), "buyLicenseUrl", []), "html", null, true);
            echo "\" class=\"vw-underline\">";
            echo twig_call_macro($macros["vcp"], "macro_t", ["Acquire now"], 5, $context, $this->getSourceContext());
            echo "</a> ";
            echo twig_call_macro($macros["vcp"], "macro_icon_arrow", [], 5, $context, $this->getSourceContext());
            echo ".
    </div>
";
        }
        craft\helpers\Template::endProfile("template", "views-work/_partials/widget_license_issue.twig");
    }

    public function getTemplateName()
    {
        return "views-work/_partials/widget_license_issue.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 5,  46 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if craft.views_work_cp.licenseIssue %}
    {% import 'views-work/_macros.twig' as vcp %}
    <div class=\"vw-alert vw-alert-danger vw-text-xs vw-mb-4\">
        ⚠ {{ vcp.t('Please help support the development of this plugin by acquiring a valid license.') }}
        <a href=\"{{ craft.views_work_cp.buyLicenseUrl }}\" class=\"vw-underline\">{{ vcp.t('Acquire now') }}</a> {{ vcp.icon_arrow() }}.
    </div>
{% endif %}", "views-work/_partials/widget_license_issue.twig", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_partials/widget_license_issue.twig");
    }
}
