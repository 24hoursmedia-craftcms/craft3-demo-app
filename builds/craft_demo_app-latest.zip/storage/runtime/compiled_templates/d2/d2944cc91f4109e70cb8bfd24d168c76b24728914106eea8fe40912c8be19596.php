<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_components/fields/ViewsWorkField_column */
class __TwigTemplate_3996ca08c982e628081596937dcf770503660a12d3cd6c22f380fd8b4f36d428 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_components/fields/ViewsWorkField_column");
        // line 2
        echo "<div style=\"width: 100%; text-align: right\">
    <span style=\"white-space: nowrap\">Total: ";
        // line 3
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["recording"]) || array_key_exists("recording", $context) ? $context["recording"] : (function () { throw new RuntimeError('Variable "recording" does not exist.', 3, $this->source); })()), "total", []), "html", null, true);
        echo " </span>
    <span style=\"white-space: nowrap\">Month: ";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["recording"]) || array_key_exists("recording", $context) ? $context["recording"] : (function () { throw new RuntimeError('Variable "recording" does not exist.', 4, $this->source); })()), "thisMonth", []), "html", null, true);
        echo " </span>
    <span style=\"white-space: nowrap\">Week: ";
        // line 5
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["recording"]) || array_key_exists("recording", $context) ? $context["recording"] : (function () { throw new RuntimeError('Variable "recording" does not exist.', 5, $this->source); })()), "thisWeek", []), "html", null, true);
        echo " </span>
    <span style=\"white-space: nowrap\">Day: ";
        // line 6
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["recording"]) || array_key_exists("recording", $context) ? $context["recording"] : (function () { throw new RuntimeError('Variable "recording" does not exist.', 6, $this->source); })()), "today", []), "html", null, true);
        echo " </span>
</div>";
        craft\helpers\Template::endProfile("template", "views-work/_components/fields/ViewsWorkField_column");
    }

    public function getTemplateName()
    {
        return "views-work/_components/fields/ViewsWorkField_column";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 6,  49 => 5,  45 => 4,  41 => 3,  38 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# recording \\twentyfourhoursmedia\\viewswork\\models\\ViewRecording #}
<div style=\"width: 100%; text-align: right\">
    <span style=\"white-space: nowrap\">Total: {{ recording.total }} </span>
    <span style=\"white-space: nowrap\">Month: {{ recording.thisMonth }} </span>
    <span style=\"white-space: nowrap\">Week: {{ recording.thisWeek }} </span>
    <span style=\"white-space: nowrap\">Day: {{ recording.today }} </span>
</div>", "views-work/_components/fields/ViewsWorkField_column", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_components/fields/ViewsWorkField_column.twig");
    }
}
