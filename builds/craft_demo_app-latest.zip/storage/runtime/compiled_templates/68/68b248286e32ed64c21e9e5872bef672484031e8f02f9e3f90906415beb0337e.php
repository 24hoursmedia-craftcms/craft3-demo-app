<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_partials/widget_footer.twig */
class __TwigTemplate_1e09d46350f8c956dcf1a3452d883ac931f55e94ebcaf9b4faca3c8355accc17 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_partials/widget_footer.twig");
        // line 1
        $this->loadTemplate("views-work/_partials/widget_license_issue.twig", "views-work/_partials/widget_footer.twig", 1)->display($context);
        // line 2
        echo "
<div class=\"vw-widget-footer\">
    &copy;  <a href=\"https://www.24hoursmedia.com/en\" target=\"_blank\" class=\"vw-whitespace-nowrap\">24hoursmedia <span data-icon=\"circlerarr\"></span></a>.
    <a href=\"https://io.24hoursmedia.com/views-work\" target=\"_blank\" class=\"vw-whitespace-nowrap\">visit plugin page <span data-icon=\"circlerarr\"></span></a>
</div>";
        craft\helpers\Template::endProfile("template", "views-work/_partials/widget_footer.twig");
    }

    public function getTemplateName()
    {
        return "views-work/_partials/widget_footer.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'views-work/_partials/widget_license_issue.twig' %}

<div class=\"vw-widget-footer\">
    &copy;  <a href=\"https://www.24hoursmedia.com/en\" target=\"_blank\" class=\"vw-whitespace-nowrap\">24hoursmedia <span data-icon=\"circlerarr\"></span></a>.
    <a href=\"https://io.24hoursmedia.com/views-work\" target=\"_blank\" class=\"vw-whitespace-nowrap\">visit plugin page <span data-icon=\"circlerarr\"></span></a>
</div>", "views-work/_partials/widget_footer.twig", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_partials/widget_footer.twig");
    }
}
