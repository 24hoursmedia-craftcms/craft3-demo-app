<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/cp/_index */
class __TwigTemplate_894069137ec623bdd432d69ad6394bb86ae0587cd9d70e9399cb5b40f3d2fe4e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'sidebar' => [$this, 'block_sidebar'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "views-work/cp/_layouts";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/cp/_index");
        // line 2
        $context["title"] = "Views Work";
        // line 3
        $context["selectedSubnavItem"] = "index";
        // line 1
        $this->parent = $this->loadTemplate("views-work/cp/_layouts", "views-work/cp/_index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "views-work/cp/_index");
    }

    // line 6
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 7
        echo "
";
        craft\helpers\Template::endProfile("block", "sidebar");
    }

    // line 11
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 12
        echo "
    ";
        // line 13
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 13, $this->source); })()), "views_work_cp", []), "licenseIssue", [])) {
            // line 14
            echo "        ";
            $macros["vcp"] = $this->loadTemplate("views-work/_macros.twig", "views-work/cp/_index", 14)->unwrap();
            // line 15
            echo "        <div class=\"vw-alert vw-alert-danger vw-mb-4\">
            <p>
            <strong>⚠ ";
            // line 17
            echo twig_call_macro($macros["vcp"], "macro_t", ["Please help support the development of this plugin by acquiring a valid license."], 17, $context, $this->getSourceContext());
            echo "</strong>
            ";
            // line 18
            echo twig_call_macro($macros["vcp"], "macro_t", ["There's a lot of work in maintaining and developing a Craft plugin, and we'd love to be able to add more features."], 18, $context, $this->getSourceContext());
            echo "
            </p>

            <a href=\"";
            // line 21
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 21, $this->source); })()), "views_work_cp", []), "buyLicenseUrl", []), "html", null, true);
            echo "\" class=\"vw-underline\">";
            echo twig_call_macro($macros["vcp"], "macro_t", ["Acquire a valid license now"], 21, $context, $this->getSourceContext());
            echo "</a> ";
            echo twig_call_macro($macros["vcp"], "macro_icon_arrow", [], 21, $context, $this->getSourceContext());
            echo ".
            ";
            // line 22
            echo twig_call_macro($macros["vcp"], "macro_t", ["These messages will disappear with a valid license."], 22, $context, $this->getSourceContext());
            echo ".
        </div>
    ";
        }
        // line 25
        echo "

    <div class=\"vw-grid vw-grid-flow-row vw-grid-cols-2 vw-auto-rows-fr vw-gap-3\">
        <div>
            ";
        // line 29
        $this->loadTemplate("views-work/cp/_partials/dashboard/integration.twig", "views-work/cp/_index", 29)->display($context);
        // line 30
        echo "            ";
        $this->loadTemplate("views-work/cp/_partials/dashboard/documentation.twig", "views-work/cp/_index", 30)->display($context);
        // line 31
        echo "        </div>
        <div>
            ";
        // line 33
        $this->loadTemplate("views-work/cp/_partials/dashboard/widgets.twig", "views-work/cp/_index", 33)->display($context);
        // line 34
        echo "            ";
        $this->loadTemplate("views-work/cp/_partials/dashboard/blocking.twig", "views-work/cp/_index", 34)->display($context);
        // line 35
        echo "            ";
        $this->loadTemplate("views-work/cp/_partials/dashboard/reset_url.twig", "views-work/cp/_index", 35)->display($context);
        // line 36
        echo "        </div>
    </div>

";
        craft\helpers\Template::endProfile("block", "main");
    }

    public function getTemplateName()
    {
        return "views-work/cp/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 36,  126 => 35,  123 => 34,  121 => 33,  117 => 31,  114 => 30,  112 => 29,  106 => 25,  100 => 22,  92 => 21,  86 => 18,  82 => 17,  78 => 15,  75 => 14,  73 => 13,  70 => 12,  65 => 11,  59 => 7,  54 => 6,  48 => 1,  46 => 3,  44 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'views-work/cp/_layouts' %}
{% set title = 'Views Work' %}
{% set selectedSubnavItem = 'index' %}


{% block sidebar %}

{% endblock %}


{% block main %}

    {% if craft.views_work_cp.licenseIssue %}
        {% import 'views-work/_macros.twig' as vcp %}
        <div class=\"vw-alert vw-alert-danger vw-mb-4\">
            <p>
            <strong>⚠ {{ vcp.t('Please help support the development of this plugin by acquiring a valid license.') }}</strong>
            {{ vcp.t('There\\'s a lot of work in maintaining and developing a Craft plugin, and we\\'d love to be able to add more features.') }}
            </p>

            <a href=\"{{ craft.views_work_cp.buyLicenseUrl }}\" class=\"vw-underline\">{{ vcp.t('Acquire a valid license now') }}</a> {{ vcp.icon_arrow() }}.
            {{ vcp.t('These messages will disappear with a valid license.') }}.
        </div>
    {% endif %}


    <div class=\"vw-grid vw-grid-flow-row vw-grid-cols-2 vw-auto-rows-fr vw-gap-3\">
        <div>
            {% include 'views-work/cp/_partials/dashboard/integration.twig' %}
            {% include 'views-work/cp/_partials/dashboard/documentation.twig' %}
        </div>
        <div>
            {% include 'views-work/cp/_partials/dashboard/widgets.twig' %}
            {% include 'views-work/cp/_partials/dashboard/blocking.twig' %}
            {% include 'views-work/cp/_partials/dashboard/reset_url.twig' %}
        </div>
    </div>

{% endblock %}
", "views-work/cp/_index", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/cp/_index.twig");
    }
}
