<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* users/_accountfields */
class __TwigTemplate_74cd9cd8d6f3a594ffecac0c68e8607ca5d0978a8e5e13641d2aecd036a40582 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "users/_accountfields");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "users/_accountfields", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", []), "config", []), "general", []), "useEmailAsUsername", [])) {
            // line 4
            echo "    ";
            echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Username", "app"), "id" => "username", "name" => "username", "value" => ((            // line 9
(isset($context["user"]) || array_key_exists("user", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 9, $this->source); })()), "username", [])) : (null)), "autofocus" => true, "autocomplete" => false, "required" => (((            // line 12
(isset($context["isNewUser"]) || array_key_exists("isNewUser", $context) ? $context["isNewUser"] : (function () { throw new RuntimeError('Variable "isNewUser" does not exist.', 12, $this->source); })()) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 12, $this->source); })()), "admin", []) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 12, $this->source); })()), "getIsCurrent", [], "method")))) ? (true) : (false)), "disabled" => (((            // line 13
(isset($context["isNewUser"]) || array_key_exists("isNewUser", $context) ? $context["isNewUser"] : (function () { throw new RuntimeError('Variable "isNewUser" does not exist.', 13, $this->source); })()) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 13, $this->source); })()), "admin", []) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 13, $this->source); })()), "getIsCurrent", [], "method")))) ? (false) : (true)), "errors" => ((            // line 14
(isset($context["user"]) || array_key_exists("user", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 14, $this->source); })()), "getErrors", [0 => "username"], "method")) : (null)), "inputAttributes" => ["data" => ["lpignore" => "true"]]]], 4, $context, $this->getSourceContext());
            // line 18
            echo "
";
        }
        // line 20
        echo "
";
        // line 21
        echo twig_call_macro($macros["forms"], "macro_textField", [["fieldClass" => "width-50", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("First Name", "app"), "id" => "firstName", "name" => "firstName", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 26
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 26, $this->source); })()), "firstName", []), "autocomplete" => false, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 28
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 28, $this->source); })()), "getErrors", [0 => "firstName"], "method"), "autofocus" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 29
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 29, $this->source); })()), "app", []), "config", []), "general", []), "useEmailAsUsername", []), "inputAttributes" => ["data" => ["lpignore" => "true"]]]], 21, $context, $this->getSourceContext());
        // line 33
        echo "

";
        // line 35
        echo twig_call_macro($macros["forms"], "macro_textField", [["fieldClass" => "width-50", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Last Name", "app"), "id" => "lastName", "name" => "lastName", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 40
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 40, $this->source); })()), "lastName", []), "autocomplete" => false, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 42
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 42, $this->source); })()), "getErrors", [0 => "lastName"], "method"), "inputAttributes" => ["data" => ["lpignore" => "true"]]]], 35, $context, $this->getSourceContext());
        // line 46
        echo "
";
        craft\helpers\Template::endProfile("template", "users/_accountfields");
    }

    public function getTemplateName()
    {
        return "users/_accountfields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 46,  70 => 42,  69 => 40,  68 => 35,  64 => 33,  62 => 29,  61 => 28,  60 => 26,  59 => 21,  56 => 20,  52 => 18,  50 => 14,  49 => 13,  48 => 12,  47 => 9,  45 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% if not craft.app.config.general.useEmailAsUsername %}
    {{ forms.textField({
        first: true,
        label: \"Username\"|t('app'),
        id: 'username',
        name: 'username',
        value: (user is defined ? user.username : null),
        autofocus: true,
        autocomplete: false,
        required: (isNewUser or (currentUser.admin or user.getIsCurrent()) ? true : false),
        disabled: (isNewUser or (currentUser.admin or user.getIsCurrent()) ? false : true),
        errors: (user is defined ? user.getErrors('username') : null),
        inputAttributes: {
            data: {lpignore: 'true'},
        },
    }) }}
{% endif %}

{{ forms.textField({
    fieldClass: 'width-50',
    label: \"First Name\"|t('app'),
    id: 'firstName',
    name: 'firstName',
    value: user.firstName,
    autocomplete: false,
    errors: user.getErrors('firstName'),
    autofocus: craft.app.config.general.useEmailAsUsername,
    inputAttributes: {
        data: {lpignore: 'true'},
    },
}) }}

{{ forms.textField({
    fieldClass: 'width-50',
    label: \"Last Name\"|t('app'),
    id: 'lastName',
    name: 'lastName',
    value: user.lastName,
    autocomplete: false,
    errors: user.getErrors('lastName'),
    inputAttributes: {
        data: {lpignore: 'true'},
    },
}) }}
", "users/_accountfields", "/var/www/html/vendor/craftcms/cms/src/templates/users/_accountfields.html");
    }
}
