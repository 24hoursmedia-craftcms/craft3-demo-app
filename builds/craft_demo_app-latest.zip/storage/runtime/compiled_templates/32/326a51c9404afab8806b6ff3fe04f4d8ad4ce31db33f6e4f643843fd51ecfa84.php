<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* content/_entry */
class __TwigTemplate_b1138484923a295198313540d0a002764d878d136e659b27c93fd571b704e42a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "content/_entry");
        $this->parent = $this->loadTemplate("_layout.html.twig", "content/_entry", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "content/_entry");
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 4
        echo "
    ";
        // line 6
        echo "    ";
        echo $this->extensions['twentyfourhoursmedia\viewswork\twigextensions\ViewsWorkTwigExtension']->viewsWorkImage((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 6, $this->source); })()));
        echo "

    <div class=\"app-content\">

        <div class=\"grid grid-cols-2\">
            <div >
                <h1>";
        // line 12
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 12, $this->source); })()), "title", []), "html", null, true);
        echo "</h1>



                ";
        // line 16
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 16, $this->source); })()), "bodyText", []), "html", null, true);
        echo "
            </div>
            <div >
                ";
        // line 19
        $this->loadTemplate("_components/views_work/view_counts.twig", "content/_entry", 19)->display(twig_array_merge($context, ["entry" => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 19, $this->source); })())]));
        // line 20
        echo "            </div>
        </div>


    </div>

";
        craft\helpers\Template::endProfile("block", "body");
    }

    public function getTemplateName()
    {
        return "content/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 20,  79 => 19,  73 => 16,  66 => 12,  56 => 6,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '_layout.html.twig' %}

{% block body %}

    {# Register the pageview with a registration pixel #}
    {{ entry | views_work_image }}

    <div class=\"app-content\">

        <div class=\"grid grid-cols-2\">
            <div >
                <h1>{{ entry.title }}</h1>



                {{ entry.bodyText }}
            </div>
            <div >
                {% include '_components/views_work/view_counts.twig' with {entry: entry} %}
            </div>
        </div>


    </div>

{% endblock %}", "content/_entry", "/var/www/html/templates/content/_entry.twig");
    }
}
