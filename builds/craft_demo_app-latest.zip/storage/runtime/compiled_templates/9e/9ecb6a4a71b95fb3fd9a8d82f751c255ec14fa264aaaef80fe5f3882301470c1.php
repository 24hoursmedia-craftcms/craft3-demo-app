<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plugin-store/_index */
class __TwigTemplate_863b9c766133f5c89758e0ecf1a22a4feadecf64fbe2c36b3d32f5eb7ea5b08b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "plugin-store/_index");
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Plugin Store", "app");
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Active installs", 1 => "Active Trials", 2 => "Active trials added to the cart.", 3 => "Add all to cart", 4 => "Add to cart", 5 => "Added to cart", 6 => "Address Line 1", 7 => "Address Line 2", 8 => "Already in your cart", 9 => "Ascending", 10 => "Back", 11 => "Billing", 12 => "Business Name", 13 => "Business Tax ID", 14 => "Buy later", 15 => "Buy now for {price}", 16 => "Buy now", 17 => "Card number", 18 => "Cart", 19 => "Categories", 20 => "Changelog", 21 => "Checkout", 22 => "City", 23 => "Cloud Storage Integration", 24 => "Community Support (Slack, Stack Exchange)", 25 => "Compatibility", 26 => "Connect to your Craft ID", 27 => "Contact", 28 => "Content Modeling", 29 => "Continue as guest", 30 => "Continue", 31 => "Copy the package’s name for this plugin.", 32 => "Couldn’t load active trials.", 33 => "Couldn’t load CMS editions.", 34 => "Coupon Code", 35 => "CVC", 36 => "Descending", 37 => "Description", 38 => "Developer Support", 39 => "Documentation", 40 => "Features", 41 => "First Name", 42 => "For when you’re building a website for yourself or a friend.", 43 => "For when you’re building something professionally for a client or team.", 44 => "Free", 45 => "Go to Dashboard", 46 => "Information", 47 => "Install", 48 => "Installed as a trial", 49 => "Installed", 50 => "Item", 51 => "Items in your cart", 52 => "Last Name", 53 => "Last update", 54 => "Last Update", 55 => "Less", 56 => "License", 57 => "Licensed", 58 => "Loading Plugin Store…", 59 => "Manage plugins", 60 => "MM / YY", 61 => "More", 62 => "Multi-site Multi-lingual", 63 => "Name", 64 => "Only up to {version} is compatible with your version of Craft.", 65 => "Package Name", 66 => "Page not found.", 67 => "Pay", 68 => "Payment Method", 69 => "Payment", 70 => "Plugin Store", 71 => "Popularity", 72 => "Price includes 1 year of updates.", 73 => "Pro Rate Discount", 74 => "Reactivate", 75 => "Remove", 76 => "Renewal price", 77 => "Report an issue", 78 => "Save as my new credit card", 79 => "Screenshots", 80 => "Search plugins", 81 => "Security & Bug Fixes", 82 => "See all", 83 => "Showing results for “{searchQuery}”", 84 => "Staff Picks", 85 => "Subtotal", 86 => "Support", 87 => "System Branding", 88 => "Thank You!", 89 => "The Plugin Store is not available, please try again later.", 90 => "This plugin isn’t compatible with your version of Craft.", 91 => "Total Price", 92 => "Total", 93 => "Try for free", 94 => "Try", 95 => "Try", 96 => "Updates until {date} ({sign}{price})", 97 => "Updates until {date}", 98 => "Updates", 99 => "Upgrade Craft CMS", 100 => "Use a new credit card", 101 => "Use card {cardDetails}", 102 => "Use your Craft ID", 103 => "User Accounts", 104 => "Version {version}", 105 => "Version", 106 => "Website", 107 => "Your order has been processed successfully.", 108 => "Zip Code", 109 => "{price} plus {renewalPrice}/year for updates", 110 => "{price}/year", 111 => "{renewalPrice}/year per site for updates after that.", 112 => "Your are currently using the {currentEdition} edition, and your licensed edition is {licensedEdition}.", 113 => "This license is tied to another Craft install. Purchase a license for this install.", 114 => "Your license key is invalid.", 115 => "Critical", 116 => "Couldn’t add all items to the cart.", 117 => "No results.", 118 => "This license is tied to another Craft install. Visit {accountLink} to detach it, or buy a new license."]], "method");
        // line 161
        $context["content"] = ('' === $tmp = "    <div id=\"app\"></div>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "plugin-store/_index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "plugin-store/_index");
    }

    // line 128
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 129
        echo "    <div id=\"pluginstore-actions-spinner\" class=\"spinner lg hidden\"></div>

    <div id=\"pluginstore-actions\" class=\"hidden\">

        <a id=\"cart-button\" role=\"button\" tabindex=\"0\">";
        // line 133
        echo $this->extensions['craft\web\twig\Extension']->svgFunction("@appicons/shopping-cart.svg", null, true);
        echo " <span class=\"badge\">0</span></a>

        <a id=\"craftid-account\" class=\"menubtn hidden\"><span class=\"photo\">";
        // line 135
        echo $this->extensions['craft\web\twig\Extension']->svgFunction("@appicons/craftid.svg", null, true);
        echo "</span><span class=\"label\">Account</span></a>

        <div class=\"menu\">
            <ul>
                <li><a href=\"";
        // line 139
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 139, $this->source); })()), "cp", []), "craftIdAccountUrl", [], "method"), "html", null, true);
        echo "\" rel=\"noopener\" target=\"_blank\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Manage your Craft ID", "app"), "html", null, true);
        echo "</a></li>
                <li>
                    <form method=\"post\" id=\"disconnect\">
                        ";
        // line 142
        echo craft\helpers\Html::csrfInput();
        echo "
                        ";
        // line 143
        echo craft\helpers\Html::actionInput("plugin-store/disconnect");
        echo "
                        <a onclick=\"document.getElementById('disconnect').submit();\">";
        // line 144
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign out from Craft ID", "app"), "html", null, true);
        echo "</a>
                    </form>
                </li>
            </ul>
        </div>

        <form id=\"craftid-connect-form\" method=\"post\">
            ";
        // line 151
        echo craft\helpers\Html::csrfInput();
        echo "
            ";
        // line 152
        echo craft\helpers\Html::actionInput("plugin-store/connect");
        echo "
            <div class=\"ssl-status light\" title=\"";
        // line 153
        echo twig_escape_filter($this->env, ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 153, $this->source); })()), "app", []), "request", []), "isSecureConnection", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Your connection is secure", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Your connection is insecure", "app"))), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 153, $this->source); })()), "app", []), "request", []), "isSecureConnection", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Your connection is secure", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Your connection is insecure", "app"))), "html", null, true);
        echo "\">
                <i class=\"";
        // line 154
        echo ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 154, $this->source); })()), "app", []), "request", []), "isSecureConnection", [])) ? ("secure") : ("insecure"));
        echo " icon\"></i>
            </div>
            <a onclick=\"document.getElementById('craftid-connect-form').submit();\">";
        // line 156
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign into Craft ID", "app"), "html", null, true);
        echo "</a>
        </form>
    </div>
";
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    public function getTemplateName()
    {
        return "plugin-store/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 156,  119 => 154,  113 => 153,  109 => 152,  105 => 151,  95 => 144,  91 => 143,  87 => 142,  79 => 139,  72 => 135,  67 => 133,  61 => 129,  56 => 128,  50 => 1,  47 => 161,  45 => 5,  43 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set title = 'Plugin Store'|t('app') %}

{% do view.registerTranslations('app', [
    \"Active installs\",
    \"Active Trials\",
    \"Active trials added to the cart.\",
    \"Add all to cart\",
    \"Add to cart\",
    \"Added to cart\",
    \"Address Line 1\",
    \"Address Line 2\",
    \"Already in your cart\",
    \"Ascending\",
    \"Back\",
    \"Billing\",
    \"Business Name\",
    \"Business Tax ID\",
    \"Buy later\",
    \"Buy now for {price}\",
    \"Buy now\",
    \"Card number\",
    \"Cart\",
    \"Categories\",
    \"Changelog\",
    \"Checkout\",
    \"City\",
    \"Cloud Storage Integration\",
    \"Community Support (Slack, Stack Exchange)\",
    \"Compatibility\",
    \"Connect to your Craft ID\",
    \"Contact\",
    \"Content Modeling\",
    \"Continue as guest\",
    \"Continue\",
    \"Copy the package’s name for this plugin.\",
    \"Couldn’t load active trials.\",
    \"Couldn’t load CMS editions.\",
    \"Coupon Code\",
    \"CVC\",
    \"Descending\",
    \"Description\",
    \"Developer Support\",
    \"Documentation\",
    \"Features\",
    \"First Name\",
    \"For when you’re building a website for yourself or a friend.\",
    \"For when you’re building something professionally for a client or team.\",
    \"Free\",
    \"Go to Dashboard\",
    \"Information\",
    \"Install\",
    \"Installed as a trial\",
    \"Installed\",
    \"Item\",
    \"Items in your cart\",
    \"Last Name\",
    \"Last update\",
    \"Last Update\",
    \"Less\",
    \"License\",
    \"Licensed\",
    \"Loading Plugin Store…\",
    \"Manage plugins\",
    \"MM / YY\",
    \"More\",
    \"Multi-site Multi-lingual\",
    \"Name\",
    \"Only up to {version} is compatible with your version of Craft.\",
    \"Package Name\",
    \"Page not found.\",
    \"Pay\",
    \"Payment Method\",
    \"Payment\",
    \"Plugin Store\",
    \"Popularity\",
    \"Price includes 1 year of updates.\",
    \"Pro Rate Discount\",
    \"Reactivate\",
    \"Remove\",
    \"Renewal price\",
    \"Report an issue\",
    \"Save as my new credit card\",
    \"Screenshots\",
    \"Search plugins\",
    \"Security & Bug Fixes\",
    \"See all\",
    \"Showing results for “{searchQuery}”\",
    \"Staff Picks\",
    \"Subtotal\",
    \"Support\",
    \"System Branding\",
    \"Thank You!\",
    \"The Plugin Store is not available, please try again later.\",
    \"This plugin isn’t compatible with your version of Craft.\",
    \"Total Price\",
    \"Total\",
    \"Try for free\",
    \"Try\",
    \"Try\",
    \"Updates until {date} ({sign}{price})\",
    \"Updates until {date}\",
    \"Updates\",
    \"Upgrade Craft CMS\",
    \"Use a new credit card\",
    \"Use card {cardDetails}\",
    \"Use your Craft ID\",
    \"User Accounts\",
    \"Version {version}\",
    \"Version\",
    \"Website\",
    \"Your order has been processed successfully.\",
    \"Zip Code\",
    \"{price} plus {renewalPrice}/year for updates\",
    \"{price}/year\",
    \"{renewalPrice}/year per site for updates after that.\",
    \"Your are currently using the {currentEdition} edition, and your licensed edition is {licensedEdition}.\",
    \"This license is tied to another Craft install. Purchase a license for this install.\",
    \"Your license key is invalid.\",
    \"Critical\",
    \"Couldn’t add all items to the cart.\",
    \"No results.\",
    \"This license is tied to another Craft install. Visit {accountLink} to detach it, or buy a new license.\",

]) %}

{% block actionButton %}
    <div id=\"pluginstore-actions-spinner\" class=\"spinner lg hidden\"></div>

    <div id=\"pluginstore-actions\" class=\"hidden\">

        <a id=\"cart-button\" role=\"button\" tabindex=\"0\">{{ svg('@appicons/shopping-cart.svg', namespace=true) }} <span class=\"badge\">0</span></a>

        <a id=\"craftid-account\" class=\"menubtn hidden\"><span class=\"photo\">{{ svg('@appicons/craftid.svg', namespace=true) }}</span><span class=\"label\">Account</span></a>

        <div class=\"menu\">
            <ul>
                <li><a href=\"{{ craft.cp.craftIdAccountUrl() }}\" rel=\"noopener\" target=\"_blank\">{{ \"Manage your Craft ID\"|t('app') }}</a></li>
                <li>
                    <form method=\"post\" id=\"disconnect\">
                        {{ csrfInput() }}
                        {{ actionInput('plugin-store/disconnect') }}
                        <a onclick=\"document.getElementById('disconnect').submit();\">{{ \"Sign out from Craft ID\"|t('app') }}</a>
                    </form>
                </li>
            </ul>
        </div>

        <form id=\"craftid-connect-form\" method=\"post\">
            {{ csrfInput() }}
            {{ actionInput('plugin-store/connect') }}
            <div class=\"ssl-status light\" title=\"{{ craft.app.request.isSecureConnection ? \"Your connection is secure\"|t('app') : \"Your connection is insecure\"|t('app') }}\" aria-label=\"{{ craft.app.request.isSecureConnection ? \"Your connection is secure\"|t('app') : \"Your connection is insecure\"|t('app') }}\">
                <i class=\"{{ craft.app.request.isSecureConnection ? \"secure\" : \"insecure\" }} icon\"></i>
            </div>
            <a onclick=\"document.getElementById('craftid-connect-form').submit();\">{{ 'Sign into Craft ID'|t('app') }}</a>
        </form>
    </div>
{% endblock %}

{% set content %}
    <div id=\"app\"></div>
{% endset %}
", "plugin-store/_index", "/var/www/html/vendor/craftcms/cms/src/templates/plugin-store/_index.html");
    }
}
