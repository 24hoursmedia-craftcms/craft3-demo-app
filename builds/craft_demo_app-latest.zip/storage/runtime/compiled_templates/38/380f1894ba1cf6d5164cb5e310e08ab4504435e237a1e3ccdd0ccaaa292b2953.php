<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/cp/_layouts */
class __TwigTemplate_5f303ee54a9f1f96a7266b2469a807e8b9bac07bdab195ba46651871f3f4039f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/cp/_layouts");
        // line 3
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\viewswork\\assetbundles\\viewswork\\ViewsWorkAsset"], "method");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "views-work/cp/_layouts", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "views-work/cp/_layouts");
    }

    // line 5
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 6
        echo "    ";
        $this->loadTemplate("views-work/cp/_partials/check_settings.twig", "views-work/cp/_layouts", 6)->display($context);
        // line 7
        echo "    ";
        $this->displayParentBlock("main", $context, $blocks);
        echo "
";
        craft\helpers\Template::endProfile("block", "main");
    }

    public function getTemplateName()
    {
        return "views-work/cp/_layouts";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 7,  56 => 6,  51 => 5,  45 => 1,  43 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '_layouts/cp' %}

{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\viewswork\\\\assetbundles\\\\viewswork\\\\ViewsWorkAsset\") %}

{% block main %}
    {% include 'views-work/cp/_partials/check_settings.twig' %}
    {{ parent() }}
{% endblock %}", "views-work/cp/_layouts", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/cp/_layouts/index.twig");
    }
}
