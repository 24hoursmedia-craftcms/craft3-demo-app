<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sites/index */
class __TwigTemplate_fdcc743f3b38db5c81e07e1da46eea70e558e54f2abbb4d7624783396b82ddca extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'sidebar' => [$this, 'block_sidebar'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/sites/index");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Sites", "app");
        // line 4
        $context["multiple"] = (twig_length_filter($this->env, (isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 4, $this->source); })())) > 1);
        // line 5
        $context["canSort"] = ((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 5, $this->source); })()) && (isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 5, $this->source); })()));
        // line 94
        ob_start();
        // line 95
        echo "    new Craft.SitesAdmin();

    new Craft.SiteAdminTable({
        tableSelector: '#sites',
        minItems: 1,
        sortable: true,
        reorderAction: 'sites/reorder-sites',
        deleteAction: 'sites/delete-site',
    });
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 4]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sites/index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/sites/index");
    }

    // line 8
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 9
        echo "    ";
        $context["newSiteUrl"] = craft\helpers\UrlHelper::url("settings/sites/new", (((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 9, $this->source); })())) ? (["groupId" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 9, $this->source); })()), "id", [])]) : (null)));
        // line 10
        echo "    <a href=\"";
        echo twig_escape_filter($this->env, (isset($context["newSiteUrl"]) || array_key_exists("newSiteUrl", $context) ? $context["newSiteUrl"] : (function () { throw new RuntimeError('Variable "newSiteUrl" does not exist.', 10, $this->source); })()), "html", null, true);
        echo "\" class=\"btn submit add icon\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New site", "app"), "html", null, true);
        echo "</a>
";
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 14
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 15
        echo "    <nav>
        <ul id=\"groups\">
            <li><a href=\"";
        // line 17
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("settings/sites"), "html", null, true);
        echo "\"";
        if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 17, $this->source); })())) {
            echo " class=\"sel\"";
        }
        echo ">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All Sites", "app"), "html", null, true);
        echo "</a></li>
            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allGroups"]) || array_key_exists("allGroups", $context) ? $context["allGroups"] : (function () { throw new RuntimeError('Variable "allGroups" does not exist.', 18, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["g"]) {
            // line 19
            echo "                <li><a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("settings/sites", ["groupId" => craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "id", [])]), "html", null, true);
            echo "\"";
            if (((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 19, $this->source); })()) && (craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "id", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 19, $this->source); })()), "id", [])))) {
                echo " class=\"sel\"";
            }
            echo " data-id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "id", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "name", []), "site"), "html", null, true);
            echo "</a></li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['g'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "        </ul>
    </nav>

    <div class=\"buttons\">
        <button type=\"button\" id=\"newgroupbtn\" class=\"btn add icon\">";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New group", "app"), "html", null, true);
        echo "</button>

        ";
        // line 27
        if ((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 27, $this->source); })())) {
            // line 28
            echo "            <button type=\"button\" id=\"groupsettingsbtn\" class=\"btn settings icon menubtn\" title=\"";
            echo "Settings";
            echo "\" aria-label=\"";
            echo "Settings";
            echo "\"></button>
            <div class=\"menu\">
                <ul>
                    <li><a data-action=\"rename\" role=\"button\">";
            // line 31
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Rename selected group", "app"), "html", null, true);
            echo "</a></li>
                    <li><a data-action=\"delete\" role=\"button\"";
            // line 32
            if (twig_length_filter($this->env, (isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 32, $this->source); })()))) {
                echo " class=\"disabled\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("You can only delete groups that have no sites.", "app"), "html", null, true);
                echo "\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete selected group", "app"), "html", null, true);
            echo "</a></li>
                </ul>
            </div>
        ";
        }
        // line 36
        echo "    </div>
";
        craft\helpers\Template::endProfile("block", "sidebar");
    }

    // line 40
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 41
        echo "    ";
        if (twig_length_filter($this->env, (isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 41, $this->source); })()))) {
            // line 42
            echo "        <div class=\"tablepane\">
            <table id=\"sites\" class=\"data fullwidth\">
                <thead>
                    <th scope=\"col\">";
            // line 45
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "html", null, true);
            echo "</th>
                    <th scope=\"col\">";
            // line 46
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "html", null, true);
            echo "</th>
                    <th scope=\"col\">";
            // line 47
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "html", null, true);
            echo "</th>
                    <th scope=\"col\">";
            // line 48
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Primary", "app"), "html", null, true);
            echo "</th>
                    <th scope=\"col\">";
            // line 49
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "html", null, true);
            echo "</th>
                    ";
            // line 50
            if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 50, $this->source); })())) {
                // line 51
                echo "                        <th scope=\"col\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "html", null, true);
                echo "</th>
                    ";
            }
            // line 53
            echo "                    ";
            if ((isset($context["canSort"]) || array_key_exists("canSort", $context) ? $context["canSort"] : (function () { throw new RuntimeError('Variable "canSort" does not exist.', 53, $this->source); })())) {
                // line 54
                echo "                        <td class=\"thin\"></td>
                    ";
            }
            // line 56
            echo "                    ";
            if ((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 56, $this->source); })())) {
                // line 57
                echo "                        <td class=\"thin\"></td>
                    ";
            }
            // line 59
            echo "                </thead>
                <tbody>
                    ";
            // line 61
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 61, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                // line 62
                echo "                        <tr data-id=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), "html", null, true);
                echo "\" data-uid=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "uid", []), "html", null, true);
                echo "\" data-name=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "site"), "html", null, true);
                echo "\">
                            <th scope=\"row\" data-title=\"";
                // line 63
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "html", null, true);
                echo "\">
                                <a href=\"";
                // line 64
                echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("settings/sites/" . craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []))), "html", null, true);
                echo "\">
                                    <span class=\"status ";
                // line 65
                echo ((craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "enabled", [])) ? ("enabled") : ("disabled"));
                echo "\"></span>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "site"), "html", null, true);
                echo "
                                </a>
                            </th>
                            <td data-title=\"";
                // line 68
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "html", null, true);
                echo "\"><code>";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "</code></td>
                            <td data-title=\"";
                // line 69
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "html", null, true);
                echo "\"><code>";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "language", []), "html", null, true);
                echo "</code></td>
                            <td data-title=\"";
                // line 70
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Primary", "app"), "html", null, true);
                echo "\">";
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "primary", [])) {
                    echo "<div data-icon=\"check\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Yes", "app"), "html", null, true);
                    echo "\"></div>";
                }
                echo "</td>
                            <td data-title=\"";
                // line 71
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "html", null, true);
                echo "\"><code>";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "baseUrl", []), "html", null, true);
                echo "</code></td>
                            ";
                // line 72
                if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 72, $this->source); })())) {
                    // line 73
                    echo "                                <td data-title=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "group", []), "name", []), "site"), "html", null, true);
                    echo "</td>
                            ";
                }
                // line 75
                echo "                            ";
                if ((isset($context["canSort"]) || array_key_exists("canSort", $context) ? $context["canSort"] : (function () { throw new RuntimeError('Variable "canSort" does not exist.', 75, $this->source); })())) {
                    // line 76
                    echo "                                <td class=\"thin\"><a class=\"move icon\" title=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                    echo "\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                    echo "\" role=\"button\"></a></td>
                            ";
                }
                // line 78
                echo "                            ";
                if ((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 78, $this->source); })())) {
                    // line 79
                    echo "                                <td class=\"thin\"><a class=\"delete icon";
                    if (craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "primary", [])) {
                        echo " disabled";
                    }
                    echo "\" title=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "\" role=\"button\"></a></td>
                            ";
                }
                // line 81
                echo "                        </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 83
            echo "                </tbody>
            </table>
        </div>
    ";
        } else {
            // line 87
            echo "        <div class=\"zilch\">
            <p>";
            // line 88
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No sites exist for this group yet.", "app"), "html", null, true);
            echo "</p>
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/sites/index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  342 => 88,  339 => 87,  333 => 83,  326 => 81,  314 => 79,  311 => 78,  303 => 76,  300 => 75,  292 => 73,  290 => 72,  284 => 71,  274 => 70,  268 => 69,  262 => 68,  254 => 65,  250 => 64,  246 => 63,  237 => 62,  233 => 61,  229 => 59,  225 => 57,  222 => 56,  218 => 54,  215 => 53,  209 => 51,  207 => 50,  203 => 49,  199 => 48,  195 => 47,  191 => 46,  187 => 45,  182 => 42,  179 => 41,  174 => 40,  168 => 36,  155 => 32,  151 => 31,  142 => 28,  140 => 27,  135 => 25,  129 => 21,  112 => 19,  108 => 18,  98 => 17,  94 => 15,  89 => 14,  79 => 10,  76 => 9,  71 => 8,  65 => 1,  53 => 95,  51 => 94,  49 => 5,  47 => 4,  45 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"Sites\"|t('app') %}

{% set multiple = (sites|length > 1) %}
{% set canSort = group and multiple %}


{% block actionButton %}
    {% set newSiteUrl = url('settings/sites/new', (group ? { groupId: group.id } : null)) %}
    <a href=\"{{ newSiteUrl }}\" class=\"btn submit add icon\">{{ \"New site\"|t('app') }}</a>
{% endblock %}


{% block sidebar %}
    <nav>
        <ul id=\"groups\">
            <li><a href=\"{{ url('settings/sites') }}\"{% if not group %} class=\"sel\"{% endif %}>{{ \"All Sites\"|t('app') }}</a></li>
            {% for g in allGroups %}
                <li><a href=\"{{ url('settings/sites', {groupId: g.id}) }}\"{% if group and g.id == group.id %} class=\"sel\"{% endif %} data-id=\"{{ g.id }}\">{{ g.name|t('site') }}</a></li>
            {% endfor %}
        </ul>
    </nav>

    <div class=\"buttons\">
        <button type=\"button\" id=\"newgroupbtn\" class=\"btn add icon\">{{ \"New group\"|t('app') }}</button>

        {% if group %}
            <button type=\"button\" id=\"groupsettingsbtn\" class=\"btn settings icon menubtn\" title=\"{{ 'Settings' }}\" aria-label=\"{{ 'Settings' }}\"></button>
            <div class=\"menu\">
                <ul>
                    <li><a data-action=\"rename\" role=\"button\">{{ \"Rename selected group\"|t('app') }}</a></li>
                    <li><a data-action=\"delete\" role=\"button\"{% if sites|length %} class=\"disabled\" title=\"{{ 'You can only delete groups that have no sites.'|t('app') }}\"{% endif %}>{{ \"Delete selected group\"|t('app') }}</a></li>
                </ul>
            </div>
        {% endif %}
    </div>
{% endblock %}


{% block content %}
    {% if sites|length %}
        <div class=\"tablepane\">
            <table id=\"sites\" class=\"data fullwidth\">
                <thead>
                    <th scope=\"col\">{{ \"Name\"|t('app') }}</th>
                    <th scope=\"col\">{{ \"Handle\"|t('app') }}</th>
                    <th scope=\"col\">{{ \"Language\"|t('app') }}</th>
                    <th scope=\"col\">{{ \"Primary\"|t('app') }}</th>
                    <th scope=\"col\">{{ \"Base URL\"|t('app') }}</th>
                    {% if not group %}
                        <th scope=\"col\">{{ \"Group\"|t('app') }}</th>
                    {% endif %}
                    {% if canSort %}
                        <td class=\"thin\"></td>
                    {% endif %}
                    {% if multiple %}
                        <td class=\"thin\"></td>
                    {% endif %}
                </thead>
                <tbody>
                    {% for site in sites %}
                        <tr data-id=\"{{ site.id }}\" data-uid=\"{{ site.uid }}\" data-name=\"{{ site.name|t('site') }}\">
                            <th scope=\"row\" data-title=\"{{ 'Name'|t('app') }}\">
                                <a href=\"{{ url('settings/sites/' ~ site.id) }}\">
                                    <span class=\"status {{ site.enabled ? 'enabled' : 'disabled' }}\"></span>{{ site.name|t('site') }}
                                </a>
                            </th>
                            <td data-title=\"{{ 'Handle'|t('app') }}\"><code>{{ site.handle }}</code></td>
                            <td data-title=\"{{ 'Language'|t('app') }}\"><code>{{ site.language }}</code></td>
                            <td data-title=\"{{ 'Primary'|t('app') }}\">{% if site.primary %}<div data-icon=\"check\" aria-label=\"{{ 'Yes'|t('app') }}\"></div>{% endif %}</td>
                            <td data-title=\"{{ 'Base URL'|t('app') }}\"><code>{{ site.baseUrl }}</code></td>
                            {% if not group %}
                                <td data-title=\"{{ 'Group'|t('app') }}\">{{ site.group.name|t('site') }}</td>
                            {% endif %}
                            {% if canSort %}
                                <td class=\"thin\"><a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" aria-label=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a></td>
                            {% endif %}
                            {% if multiple %}
                                <td class=\"thin\"><a class=\"delete icon{% if site.primary %} disabled{% endif %}\" title=\"{{ 'Delete'|t('app') }}\" aria-label=\"{{ 'Delete'|t('app') }}\" role=\"button\"></a></td>
                            {% endif %}
                        </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    {% else %}
        <div class=\"zilch\">
            <p>{{ 'No sites exist for this group yet.'|t('app') }}</p>
        </div>
    {% endif %}
{% endblock %}


{% js on ready %}
    new Craft.SitesAdmin();

    new Craft.SiteAdminTable({
        tableSelector: '#sites',
        minItems: 1,
        sortable: true,
        reorderAction: 'sites/reorder-sites',
        deleteAction: 'sites/delete-site',
    });
{% endjs %}
", "settings/sites/index", "/var/www/html/vendor/craftcms/cms/src/templates/settings/sites/index.html");
    }
}
