<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Table/columntable */
class __TwigTemplate_989db22e310df9d6165c609d160d304bd2083c73854d37007b87d3e9bafc37b5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Table/columntable");
        // line 1
        $macros["__internal_33a62004c054910f9f3f69536f74f8224064a17f606a2da162b207ab5eb526d1"] = $this->macros["__internal_33a62004c054910f9f3f69536f74f8224064a17f606a2da162b207ab5eb526d1"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Table/columntable", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        ob_start();
        // line 4
        echo "    ";
        $this->loadTemplate("_components/fieldtypes/Table/columntable", "_components/fieldtypes/Table/columntable", 4, "294162918")->display(twig_array_merge($context, ["id" => "columns", "name" => "columns", "cols" =>         // line 7
(isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 7, $this->source); })()), "rows" =>         // line 8
(isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 8, $this->source); })()), "addRowLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Add a column", "app"), "initJs" => false]));
        $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 24
        echo "
";
        // line 25
        echo twig_call_macro($macros["__internal_33a62004c054910f9f3f69536f74f8224064a17f606a2da162b207ab5eb526d1"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Table Columns", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Define the columns your table should have.", "app"), "id" => "columns", "errors" =>         // line 29
(isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 29, $this->source); })())],         // line 30
(isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 30, $this->source); })())], 25, $context, $this->getSourceContext());
        echo "
";
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Table/columntable");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Table/columntable";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 30,  55 => 29,  54 => 25,  51 => 24,  48 => 8,  47 => 7,  45 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from '_includes/forms' import field %}

{% set input %}
    {% embed '_includes/forms/editableTable' with {
        id: 'columns',
        name: 'columns',
        cols: cols,
        rows: rows,
        addRowLabel: 'Add a column'|t('app'),
        initJs: false,
    } %}
        {% block tablecell %}
            {% if colId == 'type' %}
                <div class=\"flex flex-nowrap\">
                    {{ parent() }}
                    <a class=\"settings light{% if value != 'select' %} invisible{% endif %}\" role=\"button\" data-icon=\"settings\"></a>
                </div>
            {% else %}
                {{ parent() }}
            {% endif %}
        {% endblock %}
    {% endembed %}
{% endset %}

{{ field({
    label: 'Table Columns'|t('app'),
    instructions: 'Define the columns your table should have.'|t('app'),
    id: 'columns',
    errors: errors
}, input) }}
", "_components/fieldtypes/Table/columntable", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/Table/columntable.html");
    }
}


/* _components/fieldtypes/Table/columntable */
class __TwigTemplate_989db22e310df9d6165c609d160d304bd2083c73854d37007b87d3e9bafc37b5___294162918 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'tablecell' => [$this, 'block_tablecell'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 4
        return "_includes/forms/editableTable";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Table/columntable");
        $this->parent = $this->loadTemplate("_includes/forms/editableTable", "_components/fieldtypes/Table/columntable", 4);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Table/columntable");
    }

    // line 12
    public function block_tablecell($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "tablecell");
        // line 13
        echo "            ";
        if (((isset($context["colId"]) || array_key_exists("colId", $context) ? $context["colId"] : (function () { throw new RuntimeError('Variable "colId" does not exist.', 13, $this->source); })()) == "type")) {
            // line 14
            echo "                <div class=\"flex flex-nowrap\">
                    ";
            // line 15
            $this->displayParentBlock("tablecell", $context, $blocks);
            echo "
                    <a class=\"settings light";
            // line 16
            if (((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 16, $this->source); })()) != "select")) {
                echo " invisible";
            }
            echo "\" role=\"button\" data-icon=\"settings\"></a>
                </div>
            ";
        } else {
            // line 19
            echo "                ";
            $this->displayParentBlock("tablecell", $context, $blocks);
            echo "
            ";
        }
        // line 21
        echo "        ";
        craft\helpers\Template::endProfile("block", "tablecell");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Table/columntable";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 21,  170 => 19,  162 => 16,  158 => 15,  155 => 14,  152 => 13,  147 => 12,  134 => 4,  56 => 30,  55 => 29,  54 => 25,  51 => 24,  48 => 8,  47 => 7,  45 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from '_includes/forms' import field %}

{% set input %}
    {% embed '_includes/forms/editableTable' with {
        id: 'columns',
        name: 'columns',
        cols: cols,
        rows: rows,
        addRowLabel: 'Add a column'|t('app'),
        initJs: false,
    } %}
        {% block tablecell %}
            {% if colId == 'type' %}
                <div class=\"flex flex-nowrap\">
                    {{ parent() }}
                    <a class=\"settings light{% if value != 'select' %} invisible{% endif %}\" role=\"button\" data-icon=\"settings\"></a>
                </div>
            {% else %}
                {{ parent() }}
            {% endif %}
        {% endblock %}
    {% endembed %}
{% endset %}

{{ field({
    label: 'Table Columns'|t('app'),
    instructions: 'Define the columns your table should have.'|t('app'),
    id: 'columns',
    errors: errors
}, input) }}
", "_components/fieldtypes/Table/columntable", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/Table/columntable.html");
    }
}
