<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/comments_work/comment_form.twig */
class __TwigTemplate_5ea0cf6f4c7abb70dcf6a37e6c39f2fbed7ef55aa9189e5f558365a607906b38 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/comments_work/comment_form.twig");
        // line 7
        echo "
";
        // line 9
        echo "
";
        // line 11
        $context["commentsWork"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "commentsWork", []), "service", []);
        // line 12
        $context["justPosted"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["commentsWork"]) || array_key_exists("commentsWork", $context) ? $context["commentsWork"] : (function () { throw new RuntimeError('Variable "commentsWork" does not exist.', 12, $this->source); })()), "checkJustPosted", [], "method");
        // line 13
        echo "
<a name=\"comment_form\"></a>

";
        // line 16
        if ((isset($context["justPosted"]) || array_key_exists("justPosted", $context) ? $context["justPosted"] : (function () { throw new RuntimeError('Variable "justPosted" does not exist.', 16, $this->source); })())) {
            // line 17
            echo "
    <div class=\"bg-gray-300 rounded p-2\">
        <p>Thanks for your post.</p>
    </div>

";
        } else {
            // line 23
            echo "
    <div class=\"bg-gray-300 rounded p-2\">
        <form method=\"post\" action=\"";
            // line 25
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::actionUrl("/comments-work/default/post-comment"), "html", null, true);
            echo "#comment_form\">
            ";
            // line 26
            echo craft\helpers\Html::csrfInput();
            echo "
            ";
            // line 27
            echo $this->extensions['twentyfourhoursmedia\commentswork\twigextensions\CommentsWorkTwigExtension']->signForm((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 27, $this->source); })()));
            echo "
            <input name=\"redirect\" value=\"";
            // line 28
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 28, $this->source); })()), "app", []), "request", []), "url", []), "html", null, true);
            echo "#comments\" type=\"hidden\"/>
            <input name=\"elementId\" value=\"";
            // line 29
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 29, $this->source); })()), "id", []), "html", null, true);
            echo "\" type=\"hidden\"/>
            <input name=\"siteId\" value=\"";
            // line 30
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 30, $this->source); })()), "siteId", []), "html", null, true);
            echo "\" type=\"hidden\"/>
            <input name=\"commentFormat\" value=\"text\" type=\"hidden\"/>

            <p>Leave a comment here...</p>

            <div class=\"grid grid-cols-2 gap-2\">
                <div>
                    <label for=\"comment-title\">Title</label>
                </div>
                <div>
                    <input name=\"title\" id=\"comment-title\" type=\"text\" class=\"w-full\"/>
                </div>

                <div>
                    <label for=\"comment-content\">Comment</label>
                </div>
                <div>
                    <textarea name=\"comment\" rows=\"5\" id=\"comment-content\" class=\"w-full\"></textarea>
                </div>

                <div class=\"col-span-2 text-right\">
                    <input type=\"submit\" class=\"bg-blue-600 text-white rounded p-2\" value=\"Post comment\"/>
                </div>
            </div>
        </form>
    </div>

";
        }
        craft\helpers\Template::endProfile("template", "_components/comments_work/comment_form.twig");
    }

    public function getTemplateName()
    {
        return "_components/comments_work/comment_form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 30,  83 => 29,  79 => 28,  75 => 27,  71 => 26,  67 => 25,  63 => 23,  55 => 17,  53 => 16,  48 => 13,  46 => 12,  44 => 11,  41 => 9,  38 => 7,);
    }

    public function getSourceContext()
    {
        return new Source("{#
Shows a form where users can enter a comment to an entry

Example:
{% include '_components/comments_worl/comment_form.twig' with {entry: entry} only %}
#}

{# @param entry     the entry to show the comment form for #}

{# check if the user has just posted a comment and provide feedback #}
{% set commentsWork = craft.commentsWork.service %}
{% set justPosted = commentsWork.checkJustPosted() %}

<a name=\"comment_form\"></a>

{% if justPosted %}

    <div class=\"bg-gray-300 rounded p-2\">
        <p>Thanks for your post.</p>
    </div>

{% else %}

    <div class=\"bg-gray-300 rounded p-2\">
        <form method=\"post\" action=\"{{ actionUrl('/comments-work/default/post-comment') }}#comment_form\">
            {{ csrfInput() }}
            {{ signCommentForm(entry) }}
            <input name=\"redirect\" value=\"{{ craft.app.request.url }}#comments\" type=\"hidden\"/>
            <input name=\"elementId\" value=\"{{ entry.id }}\" type=\"hidden\"/>
            <input name=\"siteId\" value=\"{{ entry.siteId }}\" type=\"hidden\"/>
            <input name=\"commentFormat\" value=\"text\" type=\"hidden\"/>

            <p>Leave a comment here...</p>

            <div class=\"grid grid-cols-2 gap-2\">
                <div>
                    <label for=\"comment-title\">Title</label>
                </div>
                <div>
                    <input name=\"title\" id=\"comment-title\" type=\"text\" class=\"w-full\"/>
                </div>

                <div>
                    <label for=\"comment-content\">Comment</label>
                </div>
                <div>
                    <textarea name=\"comment\" rows=\"5\" id=\"comment-content\" class=\"w-full\"></textarea>
                </div>

                <div class=\"col-span-2 text-right\">
                    <input type=\"submit\" class=\"bg-blue-600 text-white rounded p-2\" value=\"Post comment\"/>
                </div>
            </div>
        </form>
    </div>

{% endif %}", "_components/comments_work/comment_form.twig", "/var/www/html/templates/_components/comments_work/comment_form.twig");
    }
}
