<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* comments-work/edit-comment */
class __TwigTemplate_c112c7541614f45e7a2fa608b8c89123e6134c7351cd3058f4fafb7e255794b2 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 16
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "comments-work/edit-comment");
        // line 17
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "comments-work/edit-comment", 17)->unwrap();
        // line 19
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 19, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\commentswork\\assetbundles\\commentswork\\CommentsWorkAsset"], "method");
        // line 20
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 20, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\commentswork\\assetbundles\\indexcpsection\\IndexCPSectionAsset"], "method");
        // line 23
        $context["docsUrl"] = "https://github.com/24hoursmedia-craftcms/comments-work/comments-work/blob/master/README.md";
        // line 26
        $context["title"] = "Comments Work";
        // line 29
        $context["pluginCpUrl"] = craft\helpers\UrlHelper::url("comments-work");
        // line 32
        $context["iconUrl"] = (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 32, $this->source); })()), "getAssetManager", [], "method"), "getPublishedUrl", [0 => "@twentyfourhoursmedia/commentswork/assetbundles/indexcpsection/dist", 1 => true], "method") . "/img/Index-icon.svg");
        // line 36
        $context["commentsWork"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 36, $this->source); })()), "commentsWork", []), "service", []);
        // line 37
        $context["entry"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["commentsWork"]) || array_key_exists("commentsWork", $context) ? $context["commentsWork"] : (function () { throw new RuntimeError('Variable "commentsWork" does not exist.', 37, $this->source); })()), "findAnyById", [0 => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 37, $this->source); })()), "app", []), "request", []), "param", [0 => "id"], "method")], "method");
        // line 39
        $context["fullPageForm"] = true;
        // line 42
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 42, $this->source); })()), "app", []), "request", []), "method", []) == "POST")) {
            // line 43
            craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 43, $this->source); })()), "populateWithPostData", [0 => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 43, $this->source); })()), "app", []), "request", [])], "method");
            // line 44
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 44, $this->source); })()), "app", []), "elements", []), "saveElement", [0 => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 44, $this->source); })())], "method");
            // line 45
            \Craft::$app->getResponse()->redirect(craft\helpers\UrlHelper::url((isset($context["pluginCpUrl"]) || array_key_exists("pluginCpUrl", $context) ? $context["pluginCpUrl"] : (function () { throw new RuntimeError('Variable "pluginCpUrl" does not exist.', 45, $this->source); })())), 302);
            \Craft::$app->end();        }
        // line 54
        ob_start();
        // line 55
        echo "    ";
        if (twig_test_empty((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 55, $this->source); })()))) {
            // line 56
            echo "        <h1>NOTFOUND</h1>
    ";
        } else {
            // line 58
            echo "        <h2>Edit comment #";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 58, $this->source); })()), "id", []), "html", null, true);
            echo "</h2>
        ";
            // line 66
            echo "        <p class=\"textline\">
            ";
            // line 67
            $context["poster"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 67, $this->source); })()), "poster", []);
            // line 68
            echo "            ";
            if ((isset($context["poster"]) || array_key_exists("poster", $context) ? $context["poster"] : (function () { throw new RuntimeError('Variable "poster" does not exist.', 68, $this->source); })())) {
                // line 69
                echo "                <strong>Posted by</strong> <a href=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["poster"]) || array_key_exists("poster", $context) ? $context["poster"] : (function () { throw new RuntimeError('Variable "poster" does not exist.', 69, $this->source); })()), "cpEditUrl", []), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["poster"]) || array_key_exists("poster", $context) ? $context["poster"] : (function () { throw new RuntimeError('Variable "poster" does not exist.', 69, $this->source); })()), "friendlyName", []), "html", null, true);
                echo "</a>,
            ";
            }
            // line 71
            echo "            ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 71, $this->source); })()), "dateCreated", [])), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 71, $this->source); })()), "dateCreated", []), "H:i"), "html", null, true);
            echo "
            <br/>
            ";
            // line 73
            $context["sourceElement"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 73, $this->source); })()), "sourceElement", []);
            // line 74
            echo "            ";
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["sourceElement"]) || array_key_exists("sourceElement", $context) ? $context["sourceElement"] : (function () { throw new RuntimeError('Variable "sourceElement" does not exist.', 74, $this->source); })()), "cpEditUrl", [])) {
                // line 75
                echo "                <strong>Entry:</strong> <a href=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["sourceElement"]) || array_key_exists("sourceElement", $context) ? $context["sourceElement"] : (function () { throw new RuntimeError('Variable "sourceElement" does not exist.', 75, $this->source); })()), "cpEditUrl", []), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["sourceElement"]) || array_key_exists("sourceElement", $context) ? $context["sourceElement"] : (function () { throw new RuntimeError('Variable "sourceElement" does not exist.', 75, $this->source); })()), "title", []), "html", null, true);
                echo "</a>
            ";
            } else {
                // line 77
                echo "                <strong>Entry:</strong> ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["sourceElement"]) || array_key_exists("sourceElement", $context) ? $context["sourceElement"] : (function () { throw new RuntimeError('Variable "sourceElement" does not exist.', 77, $this->source); })()), "title", []), "html", null, true);
                echo "
            ";
            }
            // line 79
            echo "
        </p>

        <p class=\"textline\"></p>
        ";
            // line 83
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Status", "comments-work"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("", "comments-work"), "id" => "status", "name" => "status", "options" => craft\helpers\Template::attribute($this->env, $this->source,             // line 88
(isset($context["commentsWork"]) || array_key_exists("commentsWork", $context) ? $context["commentsWork"] : (function () { throw new RuntimeError('Variable "commentsWork" does not exist.', 88, $this->source); })()), "statusOptions", []), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 89
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 89, $this->source); })()), "status", []), "toggle" => true, "targetPrefix" => ".statusCode-", "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 92
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 92, $this->source); })()), "getErrors", [0 => "status"], "method")]], 83, $context, $this->getSourceContext());
            // line 93
            echo "

        ";
            // line 95
            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "comments-work"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title of the comment", "comments-work"), "id" => "title", "class" => "ltr", "name" => "title", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 101
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 101, $this->source); })()), "title", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 102
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 102, $this->source); })()), "getErrors", [0 => "title"], "method"), "autofocus" => true, "required" => false]], 95, $context, $this->getSourceContext());
            // line 105
            echo "

        <div class=\"field\">
            <div class=\"heading\">
                <label for=\"comment\">Comment:</label>
            </div>
            ";
            // line 111
            echo twig_call_macro($macros["forms"], "macro_textArea", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Comment", "comments-work"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Comment", "comments-work"), "id" => "comment", "class" => "ltr", "name" => "comment", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 117
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 117, $this->source); })()), "comment", []), "rows" => 10, "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 119
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 119, $this->source); })()), "getErrors", [0 => "comment"], "method"), "autofocus" => true, "required" => false]], 111, $context, $this->getSourceContext());
            // line 122
            echo "
        </div>


        <hr/>
    ";
        }
        // line 128
        echo "


";
        $context["content"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 16
        $this->parent = $this->loadTemplate("_layouts/cp", "comments-work/edit-comment", 16);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "comments-work/edit-comment");
    }

    public function getTemplateName()
    {
        return "comments-work/edit-comment";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 16,  167 => 128,  159 => 122,  157 => 119,  156 => 117,  155 => 111,  147 => 105,  145 => 102,  144 => 101,  143 => 95,  139 => 93,  137 => 92,  136 => 89,  135 => 88,  134 => 83,  128 => 79,  122 => 77,  114 => 75,  111 => 74,  109 => 73,  101 => 71,  93 => 69,  90 => 68,  88 => 67,  85 => 66,  80 => 58,  76 => 56,  73 => 55,  71 => 54,  68 => 45,  66 => 44,  64 => 43,  62 => 42,  60 => 39,  58 => 37,  56 => 36,  54 => 32,  52 => 29,  50 => 26,  48 => 23,  46 => 20,  44 => 19,  42 => 17,  34 => 16,);
    }

    public function getSourceContext()
    {
        return new Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * Comments Work plugin for Craft CMS 3.x
 *
 * Comments Work index.twig
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2018 24hoursmedia
 * @link      https://www.24hoursmedia.com
 * @package   CommentsWork
 * @since     1.0.0
 */
#}

{% extends \"_layouts/cp\" %}
{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\commentswork\\\\assetbundles\\\\commentswork\\\\CommentsWorkAsset\") %}
{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\commentswork\\\\assetbundles\\\\indexcpsection\\\\IndexCPSectionAsset\") %}

{# Link for the ? icon at the bottom of the page #}
{% set docsUrl = \"https://github.com/24hoursmedia-craftcms/comments-work/comments-work/blob/master/README.md\" %}

{# The title of this CP section #}
{% set title = \"Comments Work\" %}

{# The URL to this plugin's base CP section #}
{% set pluginCpUrl = url('comments-work') %}

{# Get a URL to an image in our AssetBundle #}
{% set iconUrl = view.getAssetManager().getPublishedUrl('@twentyfourhoursmedia/commentswork/assetbundles/indexcpsection/dist', true) ~ '/img/Index-icon.svg' %}


{# @var commentsWork \\twentyfourhoursmedia\\commentswork\\services\\CommentsWorkService #}
{% set commentsWork = craft.commentsWork.service %}
{% set entry = commentsWork.findAnyById(craft.app.request.param('id')) %}

{% set fullPageForm = true %}


{% if craft.app.request.method == 'POST' %}
    {% do entry.populateWithPostData(craft.app.request) %}
    {% do craft.app.elements.saveElement(entry) %}
    {% redirect(pluginCpUrl) %}
{% endif %}


{#
<img src=\"{{ iconUrl }}\" height=\"64\" width=\"64\" />
#}

{# The content of the CP Section#}
{% set content %}
    {% if entry is empty %}
        <h1>NOTFOUND</h1>
    {% else %}
        <h2>Edit comment #{{ entry.id }}</h2>
        {#
        {% if comment.user.photoId %}
            <div id=\"user-photo\">
                <img width=\"14\" sizes=\"14px\" srcset=\"{{ comment.user.getThumbUrl(14) }} 14w, {{ comment.user.getThumbUrl(28) }} 28w\" alt=\"{{ comment.user.getName() }}\">
            </div>
        {% endif %}
        #}
        <p class=\"textline\">
            {% set poster = entry.poster %}
            {% if poster %}
                <strong>Posted by</strong> <a href=\"{{ poster.cpEditUrl }}\">{{ poster.friendlyName }}</a>,
            {% endif %}
            {{ entry.dateCreated | date }} {{ entry.dateCreated | date('H:i') }}
            <br/>
            {% set sourceElement = entry.sourceElement %}
            {% if sourceElement.cpEditUrl %}
                <strong>Entry:</strong> <a href=\"{{ sourceElement.cpEditUrl }}\">{{ sourceElement.title }}</a>
            {% else %}
                <strong>Entry:</strong> {{ sourceElement.title }}
            {% endif %}

        </p>

        <p class=\"textline\"></p>
        {{ forms.selectField({
            label: \"Status\"|t('comments-work'),
            instructions: \"\"|t('comments-work'),
            id: 'status',
            name: 'status',
            options: commentsWork.statusOptions,
            value: entry.status,
            toggle: true,
            targetPrefix: '.statusCode-',
            errors: entry.getErrors('status')
        }) }}

        {{ forms.textField({
            label: \"Title\"|t('comments-work'),
            instructions: \"Title of the comment\"|t('comments-work'),
            id: 'title',
            class: 'ltr',
            name: 'title',
            value: entry.title,
            errors: entry.getErrors('title'),
            autofocus: true,
            required: false
        }) }}

        <div class=\"field\">
            <div class=\"heading\">
                <label for=\"comment\">Comment:</label>
            </div>
            {{ forms.textArea({
                label: \"Comment\"|t('comments-work'),
                instructions: \"Comment\"|t('comments-work'),
                id: 'comment',
                class: 'ltr',
                name: 'comment',
                value: entry.comment,
                rows: 10,
                errors: entry.getErrors('comment'),
                autofocus: true,
                required: false
            }) }}
        </div>


        <hr/>
    {% endif %}



{% endset %}
", "comments-work/edit-comment", "/var/www/html/vendor/twentyfourhoursmedia/comments-work/src/templates/edit-comment.twig");
    }
}
