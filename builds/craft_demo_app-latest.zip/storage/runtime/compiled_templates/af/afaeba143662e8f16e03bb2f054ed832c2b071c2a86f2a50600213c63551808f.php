<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/text */
class __TwigTemplate_ab256d5f8a0af7da1a74e74cf409279ff28a5e1f42d87be997db734c3233583e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/text");
        // line 1
        $context["type"] = (($context["type"]) ?? ("text"));
        // line 2
        $context["autocomplete"] = (($context["autocomplete"]) ?? (false));
        // line 4
        $context["class"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "text", 1 => ((((        // line 6
$context["disabled"]) ?? (false))) ? ("disabled") : (null)), 2 => (( !((        // line 7
$context["size"]) ?? (false))) ? ("fullwidth") : (null))]));
        // line 10
        $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 11
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 11, $this->source); })()), "type" =>         // line 12
(isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 12, $this->source); })()), "id" => ((        // line 13
$context["id"]) ?? (false)), "inputmode" => ((        // line 14
$context["inputmode"]) ?? (false)), "size" => ((        // line 15
$context["size"]) ?? (false)), "name" => ((        // line 16
$context["name"]) ?? (false)), "value" => ((        // line 17
$context["value"]) ?? (false)), "maxlength" => ((        // line 18
$context["maxlength"]) ?? (false)), "autofocus" => (((        // line 19
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 19, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method")), "autocomplete" => (( !(        // line 20
(isset($context["autocomplete"]) || array_key_exists("autocomplete", $context) ? $context["autocomplete"] : (function () { throw new RuntimeError('Variable "autocomplete" does not exist.', 20, $this->source); })()) === null)) ? (((((isset($context["autocomplete"]) || array_key_exists("autocomplete", $context) ? $context["autocomplete"] : (function () { throw new RuntimeError('Variable "autocomplete" does not exist.', 20, $this->source); })()) === true)) ? ("on") : ((((isset($context["autocomplete"]) || array_key_exists("autocomplete", $context) ? $context["autocomplete"] : (function () { throw new RuntimeError('Variable "autocomplete" does not exist.', 20, $this->source); })())) ? (false) : ("off"))))) : (null)), "autocorrect" => ((((        // line 21
$context["autocorrect"]) ?? (true))) ? (false) : ("off")), "autocapitalize" => ((((        // line 22
$context["autocapitalize"]) ?? (true))) ? (false) : ("off")), "disabled" => ((        // line 23
$context["disabled"]) ?? (false)), "readonly" => ((        // line 24
$context["readonly"]) ?? (false)), "title" => ((        // line 25
$context["title"]) ?? (false)), "placeholder" => ((        // line 26
$context["placeholder"]) ?? (false)), "step" => ((        // line 27
$context["step"]) ?? (false)), "min" => ((        // line 28
$context["min"]) ?? (false)), "max" => ((        // line 29
$context["max"]) ?? (false)), "aria" => ["describedby" => ((        // line 31
$context["instructionsId"]) ?? (false))]], ((        // line 33
$context["inputAttributes"]) ?? ([])), true);
        // line 35
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 36
            $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 36, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 39
        if ((($context["showCharsLeft"]) ?? (false))) {
            // line 40
            $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 40, $this->source); })()), ["data" => ["show-chars-left" =>             // line 42
(isset($context["showCharsLeft"]) || array_key_exists("showCharsLeft", $context) ? $context["showCharsLeft"] : (function () { throw new RuntimeError('Variable "showCharsLeft" does not exist.', 42, $this->source); })())], "style" => [("padding-" . (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 45
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 45, $this->source); })()), "app", []), "locale", []), "getOrientation", [], "method") == "ltr")) ? ("right") : ("left"))) => (((($context["maxlength"]) ?? (false))) ? ((((7.2 * twig_length_filter($this->env, (isset($context["maxlength"]) || array_key_exists("maxlength", $context) ? $context["maxlength"] : (function () { throw new RuntimeError('Variable "maxlength" does not exist.', 45, $this->source); })()))) + 14) . "px")) : (""))]], true);
        }
        // line 50
        $context["input"] = $this->extensions['craft\web\twig\Extension']->tagFunction("input", (isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 50, $this->source); })()));
        // line 52
        if ((($context["unit"]) ?? (false))) {
            // line 53
            echo "    <div class=\"flex\">
        <div class=\"textwrapper\">";
            // line 54
            echo (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 54, $this->source); })());
            echo "</div>
        <div class=\"label light\">";
            // line 55
            echo twig_escape_filter($this->env, (isset($context["unit"]) || array_key_exists("unit", $context) ? $context["unit"] : (function () { throw new RuntimeError('Variable "unit" does not exist.', 55, $this->source); })()), "html", null, true);
            echo "</div>
    </div>";
        } else {
            // line 58
            echo (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 58, $this->source); })());
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/text");
    }

    public function getTemplateName()
    {
        return "_includes/forms/text";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 58,  92 => 55,  88 => 54,  85 => 53,  83 => 52,  81 => 50,  78 => 45,  77 => 42,  76 => 40,  74 => 39,  71 => 36,  69 => 35,  67 => 33,  66 => 31,  65 => 29,  64 => 28,  63 => 27,  62 => 26,  61 => 25,  60 => 24,  59 => 23,  58 => 22,  57 => 21,  56 => 20,  55 => 19,  54 => 18,  53 => 17,  52 => 16,  51 => 15,  50 => 14,  49 => 13,  48 => 12,  47 => 11,  46 => 10,  44 => 7,  43 => 6,  42 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set type = type ?? 'text' %}
{%- set autocomplete = autocomplete ?? false %}

{%- set class = (class ?? [])|explodeClass|merge([
    'text',
    (disabled ?? false) ? 'disabled' : null,
    not (size ?? false) ? 'fullwidth' : null,
]|filter) %}

{%- set inputAttributes = {
    class: class,
    type: type,
    id: id ?? false,
    inputmode: inputmode ?? false,
    size: size ?? false,
    name: name ?? false,
    value: value ?? false,
    maxlength: maxlength ?? false,
    autofocus: (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
    autocomplete: autocomplete is not same as(null) ? (autocomplete is same as(true) ? 'on' : (autocomplete ? false : 'off' )) : null,
    autocorrect: (autocorrect ?? true) ? false : 'off',
    autocapitalize: (autocapitalize ?? true) ? false : 'off',
    disabled: disabled ?? false,
    readonly: readonly ?? false,
    title: title ?? false,
    placeholder: placeholder ?? false,
    step: step ?? false,
    min: min ?? false,
    max: max ?? false,
    aria: {
        describedby: instructionsId ?? false,
    },
}|merge(inputAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set inputAttributes = inputAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{%- endif %}

{%- if showCharsLeft ?? false %}
    {%- set inputAttributes = inputAttributes|merge({
        data: {
            'show-chars-left': showCharsLeft,
        },
        style: {
            (\"padding-#{craft.app.locale.getOrientation() == 'ltr' ? 'right' : 'left'}\"): (maxlength ?? false) ? \"#{7.2*maxlength|length+14}px\",
        },
    }, recursive=true) %}
{%- endif %}

{%- set input = tag('input', inputAttributes) %}

{%- if unit ?? false %}
    <div class=\"flex\">
        <div class=\"textwrapper\">{{ input|raw }}</div>
        <div class=\"label light\">{{ unit }}</div>
    </div>
{%- else %}
    {{- input|raw }}
{%- endif %}
", "_includes/forms/text", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/text.html");
    }
}
