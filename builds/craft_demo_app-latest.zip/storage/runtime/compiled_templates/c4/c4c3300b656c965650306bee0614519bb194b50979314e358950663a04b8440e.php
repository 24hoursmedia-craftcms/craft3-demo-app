<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/revisionmenu */
class __TwigTemplate_35b9ce34704bd8577ea65a13601b2e368461d6fd3b5fa4b1b188efbcc382397a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/revisionmenu");
        // line 6
        echo "
";
        // line 7
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_includes/revisionmenu", 7)->unwrap();
        // line 8
        echo "
";
        // line 9
        $context["drafts"] = (((isset($context["canHaveDrafts"]) || array_key_exists("canHaveDrafts", $context) ? $context["canHaveDrafts"] : (function () { throw new RuntimeError('Variable "canHaveDrafts" does not exist.', 9, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 9, $this->source); })()), "find", [], "method"), "draftOf", [0 =>         // line 10
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 10, $this->source); })())], "method"), "siteId", [0 => craft\helpers\Template::attribute($this->env, $this->source,         // line 11
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 11, $this->source); })()), "siteId", [])], "method"), "anyStatus", [], "method"), "orderBy", [0 => ["dateUpdated" =>         // line 13
(isset($context["SORT_DESC"]) || array_key_exists("SORT_DESC", $context) ? $context["SORT_DESC"] : (function () { throw new RuntimeError('Variable "SORT_DESC" does not exist.', 13, $this->source); })())]], "method"), "with", [0 => [0 => "draftCreator"]], "method"), "all", [], "method")) : ([]));
        // line 16
        echo "
";
        // line 17
        $context["maxRevisions"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "app", []), "config", []), "general", []), "maxRevisions", []);
        // line 18
        if (( !(isset($context["maxRevisions"]) || array_key_exists("maxRevisions", $context) ? $context["maxRevisions"] : (function () { throw new RuntimeError('Variable "maxRevisions" does not exist.', 18, $this->source); })()) || ((isset($context["maxRevisions"]) || array_key_exists("maxRevisions", $context) ? $context["maxRevisions"] : (function () { throw new RuntimeError('Variable "maxRevisions" does not exist.', 18, $this->source); })()) > 1))) {
            // line 19
            echo "    ";
            $context["revisions"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 19, $this->source); })()), "find", [], "method"), "revisionOf", [0 => craft\helpers\Template::attribute($this->env, $this->source,             // line 20
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 20, $this->source); })()), "getSourceId", [], "method")], "method"), "siteId", [0 => craft\helpers\Template::attribute($this->env, $this->source,             // line 21
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 21, $this->source); })()), "siteId", [])], "method"), "anyStatus", [], "method"), "offset", [0 => 1], "method"), "limit", [0 => ((            // line 24
(isset($context["maxRevisions"]) || array_key_exists("maxRevisions", $context) ? $context["maxRevisions"] : (function () { throw new RuntimeError('Variable "maxRevisions" does not exist.', 24, $this->source); })())) ? (min(((isset($context["maxRevisions"]) || array_key_exists("maxRevisions", $context) ? $context["maxRevisions"] : (function () { throw new RuntimeError('Variable "maxRevisions" does not exist.', 24, $this->source); })()) - 1), 10)) : (10))], "method"), "orderBy", [0 => ["dateCreated" =>             // line 25
(isset($context["SORT_DESC"]) || array_key_exists("SORT_DESC", $context) ? $context["SORT_DESC"] : (function () { throw new RuntimeError('Variable "SORT_DESC" does not exist.', 25, $this->source); })())]], "method"), "with", [0 => [0 => "revisionCreator"]], "method"), "all", [], "method");
        } else {
            // line 29
            echo "    ";
            $context["revisions"] = [];
        }
        // line 31
        echo "
";
        // line 32
        $context["baseParams"] = $this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->withoutKeyFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 32, $this->source); })()), "app", []), "request", []), "queryParams", []), "draftId"), "revisionId"), "siteId"), "fresh");
        // line 33
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 33, $this->source); })()), "app", []), "config", []), "general", []), "pathParam", [])) {
            // line 34
            echo "    ";
            $context["baseParams"] = $this->extensions['craft\web\twig\Extension']->withoutKeyFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 34, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 34, $this->source); })()), "app", []), "config", []), "general", []), "pathParam", []));
        }
        // line 36
        $context["supportedSiteIds"] = (($context["supportedSiteIds"]) ?? (craft\helpers\ArrayHelper::getColumn(((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 36, $this->source); })()), "app", []), "isMultiSite", [])) ? ($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 36, $this->source); })()), "getSupportedSites", [], "method"), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [])) : (true)); })) : ([0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 36, $this->source); })()), "siteId", [])])), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])) : ((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 36, $this->source); })()))); })));
        // line 37
        $context["editableSiteIds"] = (($context["editableSiteIds"]) ?? (array_intersect((isset($context["supportedSiteIds"]) || array_key_exists("supportedSiteIds", $context) ? $context["supportedSiteIds"] : (function () { throw new RuntimeError('Variable "supportedSiteIds" does not exist.', 37, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 37, $this->source); })()), "app", []), "sites", []), "getEditableSiteIds", [], "method"))));
        // line 38
        $context["isMultiSiteElement"] = (twig_length_filter($this->env, (isset($context["supportedSiteIds"]) || array_key_exists("supportedSiteIds", $context) ? $context["supportedSiteIds"] : (function () { throw new RuntimeError('Variable "supportedSiteIds" does not exist.', 38, $this->source); })())) > 1);
        // line 39
        $context["canEditMultipleSites"] = (twig_length_filter($this->env, (isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 39, $this->source); })())) > 1);
        // line 40
        $context["isDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 40, $this->source); })()), "getIsDraft", [], "method");
        // line 41
        $context["isRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 41, $this->source); })()), "getIsRevision", [], "method");
        // line 42
        $context["showSiteLabel"] = (($context["showSiteLabel"]) ?? ((isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 42, $this->source); })())));
        // line 43
        $context["showRevisionLabel"] = (($context["showRevisionLabel"]) ?? (((isset($context["canHaveDrafts"]) || array_key_exists("canHaveDrafts", $context) ? $context["canHaveDrafts"] : (function () { throw new RuntimeError('Variable "canHaveDrafts" does not exist.', 43, $this->source); })()) || twig_length_filter($this->env, (isset($context["revisions"]) || array_key_exists("revisions", $context) ? $context["revisions"] : (function () { throw new RuntimeError('Variable "revisions" does not exist.', 43, $this->source); })())))));
        // line 44
        $context["cpEditUrl"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 44, $this->source); })()), "getCpEditUrl", [], "method");
        // line 45
        if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 45, $this->source); })())) {
            // line 46
            echo "    ";
            $context["baseUrl"] = craft\helpers\UrlHelper::url((isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 46, $this->source); })()), $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 46, $this->source); })()), ["draftId" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 46, $this->source); })()), "draftId", [])]));
        } elseif (        // line 47
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 47, $this->source); })())) {
            // line 48
            echo "    ";
            $context["baseUrl"] = craft\helpers\UrlHelper::url((isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 48, $this->source); })()), $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 48, $this->source); })()), ["revisionId" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 48, $this->source); })()), "revisionId", [])]));
        } else {
            // line 50
            echo "    ";
            $context["baseUrl"] = (isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 50, $this->source); })());
        }
        // line 52
        echo "
";
        // line 53
        $context["showRevisions"] = ((isset($context["showRevisionLabel"]) || array_key_exists("showRevisionLabel", $context) ? $context["showRevisionLabel"] : (function () { throw new RuntimeError('Variable "showRevisionLabel" does not exist.', 53, $this->source); })()) &&  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 53, $this->source); })()), "getIsUnpublishedDraft", [], "method"));
        // line 54
        $context["showMenu"] = ((twig_length_filter($this->env, (isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 54, $this->source); })())) > 1) || (isset($context["showRevisions"]) || array_key_exists("showRevisions", $context) ? $context["showRevisions"] : (function () { throw new RuntimeError('Variable "showRevisions" does not exist.', 54, $this->source); })()));
        // line 55
        echo "
<div id=\"context-btngroup\" class=\"btngroup\">
    <button type=\"button\" id=\"context-btn\" class=\"btn ";
        // line 57
        if ((isset($context["showMenu"]) || array_key_exists("showMenu", $context) ? $context["showMenu"] : (function () { throw new RuntimeError('Variable "showMenu" does not exist.', 57, $this->source); })())) {
            echo "menubtn";
        } else {
            echo "disabled";
        }
        echo "\"";
        if ((isset($context["showSiteLabel"]) || array_key_exists("showSiteLabel", $context) ? $context["showSiteLabel"] : (function () { throw new RuntimeError('Variable "showSiteLabel" does not exist.', 57, $this->source); })())) {
            echo " data-icon=\"world\"";
        }
        echo ">";
        // line 58
        if ((isset($context["showSiteLabel"]) || array_key_exists("showSiteLabel", $context) ? $context["showSiteLabel"] : (function () { throw new RuntimeError('Variable "showSiteLabel" does not exist.', 58, $this->source); })())) {
            // line 59
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 59, $this->source); })()), "getSite", [], "method"), "name", []), "site"), "html", null, true);
        }
        // line 61
        if (((isset($context["showSiteLabel"]) || array_key_exists("showSiteLabel", $context) ? $context["showSiteLabel"] : (function () { throw new RuntimeError('Variable "showSiteLabel" does not exist.', 61, $this->source); })()) && (isset($context["showRevisionLabel"]) || array_key_exists("showRevisionLabel", $context) ? $context["showRevisionLabel"] : (function () { throw new RuntimeError('Variable "showRevisionLabel" does not exist.', 61, $this->source); })()))) {
            echo " – ";
        }
        // line 62
        if ((isset($context["showRevisionLabel"]) || array_key_exists("showRevisionLabel", $context) ? $context["showRevisionLabel"] : (function () { throw new RuntimeError('Variable "showRevisionLabel" does not exist.', 62, $this->source); })())) {
            // line 63
            echo "<span id=\"revision-label\">";
            // line 64
            if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 64, $this->source); })())) {
                // line 65
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 65, $this->source); })()), "getDraftName", [], "method"), "html", null, true);
            } elseif (            // line 66
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 66, $this->source); })())) {
                // line 67
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 67, $this->source); })()), "getRevisionLabel", [], "method"), "html", null, true);
            } else {
                // line 69
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Current", "app"), "html", null, true);
            }
            // line 71
            echo "</span>";
        }
        // line 73
        echo "</button>

    <div class=\"menu";
        // line 75
        if ( !(isset($context["showMenu"]) || array_key_exists("showMenu", $context) ? $context["showMenu"] : (function () { throw new RuntimeError('Variable "showMenu" does not exist.', 75, $this->source); })())) {
            echo " hidden";
        }
        echo "\">
        ";
        // line 76
        $context["enabledSiteIds"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 76, $this->source); })()), "app", []), "elements", []), "getEnabledSiteIdsForElement", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 76, $this->source); })()), "id", [])], "method");
        // line 77
        echo "        ";
        $context["siteGroups"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 77, $this->source); })()), "app", []), "sites", []), "getAllGroups", [], "method");
        // line 78
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["siteGroups"]) || array_key_exists("siteGroups", $context) ? $context["siteGroups"] : (function () { throw new RuntimeError('Variable "siteGroups" does not exist.', 78, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 79
            echo "            ";
            $context["groupSites"] = craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "getSites", [], "method");
            // line 80
            echo "            ";
            if (twig_length_filter($this->env, (isset($context["groupSites"]) || array_key_exists("groupSites", $context) ? $context["groupSites"] : (function () { throw new RuntimeError('Variable "groupSites" does not exist.', 80, $this->source); })()))) {
                // line 81
                echo "                ";
                $context["groupIsVisible"] = ((isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 81, $this->source); })()) && twig_length_filter($this->env, array_intersect(craft\helpers\ArrayHelper::getColumn((isset($context["groupSites"]) || array_key_exists("groupSites", $context) ? $context["groupSites"] : (function () { throw new RuntimeError('Variable "groupSites" does not exist.', 81, $this->source); })()), "id"), (isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 81, $this->source); })()))));
                // line 82
                echo "                <div class=\"site-group";
                if ( !(isset($context["groupIsVisible"]) || array_key_exists("groupIsVisible", $context) ? $context["groupIsVisible"] : (function () { throw new RuntimeError('Variable "groupIsVisible" does not exist.', 82, $this->source); })())) {
                    echo " hidden";
                }
                echo "\">
                    ";
                // line 83
                if ((twig_length_filter($this->env, (isset($context["siteGroups"]) || array_key_exists("siteGroups", $context) ? $context["siteGroups"] : (function () { throw new RuntimeError('Variable "siteGroups" does not exist.', 83, $this->source); })())) > 1)) {
                    echo "<h6>";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "name", []), "site"), "html", null, true);
                    echo "</h6>";
                }
                // line 84
                echo "                    <ul class=\"padded\">
                        ";
                // line 85
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["groupSites"]) || array_key_exists("groupSites", $context) ? $context["groupSites"] : (function () { throw new RuntimeError('Variable "groupSites" does not exist.', 85, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                    // line 86
                    echo "                            ";
                    $context["status"] = (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 86, $this->source); })()), "enabled", []) && twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), (isset($context["enabledSiteIds"]) || array_key_exists("enabledSiteIds", $context) ? $context["enabledSiteIds"] : (function () { throw new RuntimeError('Variable "enabledSiteIds" does not exist.', 86, $this->source); })())))) ? ("enabled") : ("disabled"));
                    // line 87
                    echo "                            <li";
                    if (!twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), (isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 87, $this->source); })()))) {
                        echo " class=\"hidden\"";
                    }
                    echo ">
                                ";
                    // line 88
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 88, $this->source); })()), "siteId", []))) {
                        // line 89
                        echo "                                    <a class=\"site-option sel\">
                                        <div class=\"status ";
                        // line 90
                        echo twig_escape_filter($this->env, (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 90, $this->source); })()), "html", null, true);
                        echo "\"></div>";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "site"), "html", null, true);
                        echo "
                                    </a>
                                ";
                    } else {
                        // line 93
                        echo "                                    ";
                        $context["url"] = craft\helpers\UrlHelper::url((isset($context["baseUrl"]) || array_key_exists("baseUrl", $context) ? $context["baseUrl"] : (function () { throw new RuntimeError('Variable "baseUrl" does not exist.', 93, $this->source); })()), ["site" => craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", [])]);
                        // line 94
                        echo "                                    <a class=\"site-option\" href=\"";
                        echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 94, $this->source); })()), "html", null, true);
                        echo "\" data-site-id=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), "html", null, true);
                        echo "\">
                                        <div class=\"status ";
                        // line 95
                        echo twig_escape_filter($this->env, (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 95, $this->source); })()), "html", null, true);
                        echo "\"></div>";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "site"), "html", null, true);
                        echo "
                                    </a>
                                ";
                    }
                    // line 98
                    echo "                            </li>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 100
                echo "                    </ul>
                </div>
            ";
            }
            // line 103
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 104
        echo "
        ";
        // line 105
        if ((isset($context["showRevisions"]) || array_key_exists("showRevisions", $context) ? $context["showRevisions"] : (function () { throw new RuntimeError('Variable "showRevisions" does not exist.', 105, $this->source); })())) {
            // line 106
            echo "            <hr class=\"revision-hr";
            if ( !(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 106, $this->source); })())) {
                echo " hidden";
            }
            echo "\">
            <ul class=\"padded revision-group-current\">
                ";
            // line 108
            $context["currentRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 108, $this->source); })()), "getCurrentRevision", [], "method");
            // line 109
            echo "                ";
            $context["currentRevisionEditTime"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["currentRevision"] ?? null), "dateCreated", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentRevision"] ?? null), "dateCreated", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentRevision"] ?? null), "dateCreated", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 109, $this->source); })()), "dateUpdated", [])));
            // line 110
            echo "                ";
            $context["currentRevisionCreator"] = (((isset($context["currentRevision"]) || array_key_exists("currentRevision", $context) ? $context["currentRevision"] : (function () { throw new RuntimeError('Variable "currentRevision" does not exist.', 110, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentRevision"]) || array_key_exists("currentRevision", $context) ? $context["currentRevision"] : (function () { throw new RuntimeError('Variable "currentRevision" does not exist.', 110, $this->source); })()), "getCreator", [], "method")) : (""));
            // line 111
            echo "                <li>
                    <a";
            // line 112
            if (( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 112, $this->source); })()) &&  !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 112, $this->source); })()))) {
                echo " class=\"sel\"";
            }
            echo " href=\"";
            echo twig_escape_filter($this->env, (isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 112, $this->source); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Current", "app"), "html", null, true);
            echo "
                        <span class=\"light\">–
                            ";
            // line 114
            echo twig_escape_filter($this->env, (((isset($context["currentRevisionCreator"]) || array_key_exists("currentRevisionCreator", $context) ? $context["currentRevisionCreator"] : (function () { throw new RuntimeError('Variable "currentRevisionCreator" does not exist.', 114, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("saved {timestamp} by {creator}", "app", ["timestamp" => $this->extensions['craft\web\twig\Extension']->timestampFilter(            // line 115
(isset($context["currentRevisionEditTime"]) || array_key_exists("currentRevisionEditTime", $context) ? $context["currentRevisionEditTime"] : (function () { throw new RuntimeError('Variable "currentRevisionEditTime" does not exist.', 115, $this->source); })()), "short", true), "creator" => craft\helpers\Template::attribute($this->env, $this->source,             // line 116
(isset($context["currentRevisionCreator"]) || array_key_exists("currentRevisionCreator", $context) ? $context["currentRevisionCreator"] : (function () { throw new RuntimeError('Variable "currentRevisionCreator" does not exist.', 116, $this->source); })()), "name", [])])) : ($this->extensions['craft\web\twig\Extension']->translateFilter("updated {timestamp}", "app", ["timestamp" => $this->extensions['craft\web\twig\Extension']->timestampFilter(            // line 118
(isset($context["currentRevisionEditTime"]) || array_key_exists("currentRevisionEditTime", $context) ? $context["currentRevisionEditTime"] : (function () { throw new RuntimeError('Variable "currentRevisionEditTime" does not exist.', 118, $this->source); })()), "short", true)]))), "html", null, true);
            // line 119
            echo "
                        </span>
                    </a>
                </li>
            </ul>
        ";
        }
        // line 125
        echo "
        ";
        // line 126
        if ((isset($context["drafts"]) || array_key_exists("drafts", $context) ? $context["drafts"] : (function () { throw new RuntimeError('Variable "drafts" does not exist.', 126, $this->source); })())) {
            // line 127
            echo "            <h6>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Drafts", "app"), "html", null, true);
            echo "</h6>
            <ul class=\"padded revision-group-drafts\">
                ";
            // line 129
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["drafts"]) || array_key_exists("drafts", $context) ? $context["drafts"] : (function () { throw new RuntimeError('Variable "drafts" does not exist.', 129, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["draft"]) {
                // line 130
                echo "                    ";
                $context["url"] = craft\helpers\UrlHelper::url((isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 130, $this->source); })()), $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 130, $this->source); })()), ["draftId" => craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "draftId", [])]));
                // line 131
                echo "                    <li>
                        <a";
                // line 132
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "draftId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 132, $this->source); })()), "draftId", []))) {
                    echo " class=\"sel\"";
                }
                echo " href=\"";
                echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 132, $this->source); })()), "html", null, true);
                echo "\">
                            <span class=\"draft-name\">";
                // line 133
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "draftName", []), "html", null, true);
                echo "</span>
                            ";
                // line 134
                $context["creator"] = craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "getCreator", [], "method");
                // line 135
                echo "                            <span class=\"draft-meta light\">–
                                ";
                // line 136
                echo twig_escape_filter($this->env, (((isset($context["creator"]) || array_key_exists("creator", $context) ? $context["creator"] : (function () { throw new RuntimeError('Variable "creator" does not exist.', 136, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("updated {timestamp} by {creator}", "app", ["timestamp" => $this->extensions['craft\web\twig\Extension']->timestampFilter(craft\helpers\Template::attribute($this->env, $this->source,                 // line 137
$context["draft"], "dateUpdated", []), "short", true), "creator" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 138
(isset($context["creator"]) || array_key_exists("creator", $context) ? $context["creator"] : (function () { throw new RuntimeError('Variable "creator" does not exist.', 138, $this->source); })()), "name", [])])) : ($this->extensions['craft\web\twig\Extension']->translateFilter("updated {timestamp}", "app", ["timestamp" => $this->extensions['craft\web\twig\Extension']->timestampFilter(craft\helpers\Template::attribute($this->env, $this->source,                 // line 140
$context["draft"], "dateUpdated", []), "short", true)]))), "html", null, true);
                // line 141
                echo "
                            </span>
                        </a>
                    </li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['draft'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 146
            echo "            </ul>
        ";
        }
        // line 148
        echo "
        ";
        // line 149
        if ((isset($context["revisions"]) || array_key_exists("revisions", $context) ? $context["revisions"] : (function () { throw new RuntimeError('Variable "revisions" does not exist.', 149, $this->source); })())) {
            // line 150
            echo "            <h6>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Recent Revisions", "app"), "html", null, true);
            echo "</h6>
            <ul class=\"padded\" id=\"revision-group-revisions\">
                ";
            // line 152
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["revisions"]) || array_key_exists("revisions", $context) ? $context["revisions"] : (function () { throw new RuntimeError('Variable "revisions" does not exist.', 152, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["revision"]) {
                // line 153
                echo "                    <li>
                        ";
                // line 154
                $context["url"] = craft\helpers\UrlHelper::url((isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 154, $this->source); })()), $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 154, $this->source); })()), ["revisionId" => craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "revisionId", [])]));
                // line 155
                echo "                        <a";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "revisionId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 155, $this->source); })()), "revisionId", []))) {
                    echo " class=\"sel\"";
                }
                echo " href=\"";
                echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 155, $this->source); })()), "html", null, true);
                echo "\">
                            ";
                // line 156
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "getRevisionLabel", [], "method"), "html", null, true);
                echo "
                            ";
                // line 157
                $context["creator"] = craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "getCreator", [], "method");
                // line 158
                echo "                            <span class=\"light\">–
                                ";
                // line 159
                echo twig_escape_filter($this->env, (((isset($context["creator"]) || array_key_exists("creator", $context) ? $context["creator"] : (function () { throw new RuntimeError('Variable "creator" does not exist.', 159, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("saved {timestamp} by {creator}", "app", ["timestamp" => $this->extensions['craft\web\twig\Extension']->timestampFilter(craft\helpers\Template::attribute($this->env, $this->source,                 // line 160
$context["revision"], "dateCreated", []), "short", true), "creator" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 161
(isset($context["creator"]) || array_key_exists("creator", $context) ? $context["creator"] : (function () { throw new RuntimeError('Variable "creator" does not exist.', 161, $this->source); })()), "name", [])])) : ($this->extensions['craft\web\twig\Extension']->translateFilter("updated {timestamp}", "app", ["timestamp" => $this->extensions['craft\web\twig\Extension']->timestampFilter(craft\helpers\Template::attribute($this->env, $this->source,                 // line 163
$context["revision"], "dateCreated", []), "short", true)]))), "html", null, true);
                // line 164
                echo "
                            </span>
                        </a>
                    </li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['revision'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 169
            echo "            </ul>
        ";
        }
        // line 171
        echo "    </div>
</div>

<div id=\"revision-spinner\" class=\"spinner hidden\" title=\"";
        // line 174
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Saving", "app"), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Saving", "app"), "html", null, true);
        echo "\"></div>
<div id=\"revision-status\" class=\"invisible\"></div>
";
        craft\helpers\Template::endProfile("template", "_includes/revisionmenu");
    }

    public function getTemplateName()
    {
        return "_includes/revisionmenu";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  439 => 174,  434 => 171,  430 => 169,  420 => 164,  418 => 163,  417 => 161,  416 => 160,  415 => 159,  412 => 158,  410 => 157,  406 => 156,  397 => 155,  395 => 154,  392 => 153,  388 => 152,  382 => 150,  380 => 149,  377 => 148,  373 => 146,  363 => 141,  361 => 140,  360 => 138,  359 => 137,  358 => 136,  355 => 135,  353 => 134,  349 => 133,  341 => 132,  338 => 131,  335 => 130,  331 => 129,  325 => 127,  323 => 126,  320 => 125,  312 => 119,  310 => 118,  309 => 116,  308 => 115,  307 => 114,  296 => 112,  293 => 111,  290 => 110,  287 => 109,  285 => 108,  277 => 106,  275 => 105,  272 => 104,  266 => 103,  261 => 100,  254 => 98,  246 => 95,  239 => 94,  236 => 93,  228 => 90,  225 => 89,  223 => 88,  216 => 87,  213 => 86,  209 => 85,  206 => 84,  200 => 83,  193 => 82,  190 => 81,  187 => 80,  184 => 79,  179 => 78,  176 => 77,  174 => 76,  168 => 75,  164 => 73,  161 => 71,  158 => 69,  155 => 67,  153 => 66,  151 => 65,  149 => 64,  147 => 63,  145 => 62,  141 => 61,  138 => 59,  136 => 58,  125 => 57,  121 => 55,  119 => 54,  117 => 53,  114 => 52,  110 => 50,  106 => 48,  104 => 47,  101 => 46,  99 => 45,  97 => 44,  95 => 43,  93 => 42,  91 => 41,  89 => 40,  87 => 39,  85 => 38,  83 => 37,  81 => 36,  77 => 34,  75 => 33,  73 => 32,  70 => 31,  66 => 29,  63 => 25,  62 => 24,  61 => 21,  60 => 20,  58 => 19,  56 => 18,  54 => 17,  51 => 16,  49 => 13,  48 => 11,  47 => 10,  46 => 9,  43 => 8,  41 => 7,  38 => 6,);
    }

    public function getSourceContext()
    {
        return new Source("{#
    Shows a revision menu for an element.

    Only an existing element should be passed to this.
#}

{% import \"_includes/forms\" as forms %}

{% set drafts = canHaveDrafts ? element.find()
    .draftOf(element)
    .siteId(element.siteId)
    .anyStatus()
    .orderBy({dateUpdated: SORT_DESC})
    .with(['draftCreator'])
    .all() : [] %}

{% set maxRevisions = craft.app.config.general.maxRevisions %}
{% if not maxRevisions or maxRevisions > 1 %}
    {% set revisions = element.find()
        .revisionOf(element.getSourceId())
        .siteId(element.siteId)
        .anyStatus()
        .offset(1)
        .limit(maxRevisions ? min(maxRevisions - 1, 10) : 10)
        .orderBy({dateCreated: SORT_DESC})
        .with(['revisionCreator'])
        .all() %}
{% else %}
    {% set revisions = [] %}
{% endif %}

{% set baseParams = craft.app.request.queryParams|withoutKey('draftId')|withoutKey('revisionId')|withoutKey('siteId')|withoutKey('fresh') %}
{% if craft.app.config.general.pathParam %}
    {% set baseParams = baseParams|withoutKey(craft.app.config.general.pathParam) %}
{% endif %}
{% set supportedSiteIds = supportedSiteIds ?? (craft.app.isMultiSite ? element.getSupportedSites()|filter(s => s.propagate ?? true) : [element.siteId])|column(s => s.siteId ?? s) %}
{% set editableSiteIds = editableSiteIds ?? supportedSiteIds|intersect(craft.app.sites.getEditableSiteIds()) %}
{% set isMultiSiteElement = supportedSiteIds|length > 1 %}
{% set canEditMultipleSites = editableSiteIds|length > 1 %}
{% set isDraft = element.getIsDraft() %}
{% set isRevision = element.getIsRevision() %}
{% set showSiteLabel = showSiteLabel ?? isMultiSiteElement %}
{% set showRevisionLabel = showRevisionLabel ?? (canHaveDrafts or revisions|length) %}
{% set cpEditUrl = element.getCpEditUrl() %}
{% if isDraft %}
    {% set baseUrl = url(cpEditUrl, baseParams|merge({ draftId: element.draftId })) %}
{% elseif isRevision %}
    {% set baseUrl = url(cpEditUrl, baseParams|merge({ revisionId: element.revisionId })) %}
{% else %}
    {% set baseUrl = cpEditUrl %}
{% endif %}

{% set showRevisions = showRevisionLabel and not element.getIsUnpublishedDraft() %}
{% set showMenu = editableSiteIds|length > 1 or showRevisions %}

<div id=\"context-btngroup\" class=\"btngroup\">
    <button type=\"button\" id=\"context-btn\" class=\"btn {% if showMenu %}menubtn{% else %}disabled{% endif %}\"{% if showSiteLabel %} data-icon=\"world\"{% endif %}>
        {%- if showSiteLabel %}
            {{- element.getSite().name|t('site') }}
        {%- endif %}
        {%- if showSiteLabel and showRevisionLabel %} – {% endif %}
        {%- if showRevisionLabel -%}
            <span id=\"revision-label\">
                {%- if isDraft %}
                    {{- element.getDraftName() }}
                {%- elseif isRevision %}
                    {{- element.getRevisionLabel() }}
                {%- else %}
                    {{- 'Current'|t('app') }}
                {%- endif -%}
            </span>
        {%- endif -%}
    </button>

    <div class=\"menu{% if not showMenu %} hidden{% endif %}\">
        {% set enabledSiteIds = craft.app.elements.getEnabledSiteIdsForElement(element.id) %}
        {% set siteGroups = craft.app.sites.getAllGroups() %}
        {% for group in siteGroups %}
            {% set groupSites = group.getSites() %}
            {% if groupSites|length %}
                {% set groupIsVisible = canEditMultipleSites and groupSites|column('id')|intersect(editableSiteIds)|length %}
                <div class=\"site-group{% if not groupIsVisible %} hidden{% endif %}\">
                    {% if siteGroups|length > 1 %}<h6>{{ group.name|t('site') }}</h6>{% endif %}
                    <ul class=\"padded\">
                        {% for site in groupSites %}
                            {% set status = element.enabled and site.id in enabledSiteIds ? 'enabled' : 'disabled' %}
                            <li{% if site.id not in editableSiteIds %} class=\"hidden\"{% endif %}>
                                {% if site.id == element.siteId %}
                                    <a class=\"site-option sel\">
                                        <div class=\"status {{ status }}\"></div>{{ site.name|t('site') }}
                                    </a>
                                {% else %}
                                    {% set url = url(baseUrl, { site: site.handle }) %}
                                    <a class=\"site-option\" href=\"{{ url }}\" data-site-id=\"{{ site.id }}\">
                                        <div class=\"status {{ status }}\"></div>{{ site.name|t('site') }}
                                    </a>
                                {% endif %}
                            </li>
                        {% endfor %}
                    </ul>
                </div>
            {% endif %}
        {% endfor %}

        {% if showRevisions %}
            <hr class=\"revision-hr{% if not canEditMultipleSites %} hidden{% endif %}\">
            <ul class=\"padded revision-group-current\">
                {% set currentRevision = element.getCurrentRevision() %}
                {% set currentRevisionEditTime = currentRevision.dateCreated ?? element.dateUpdated %}
                {% set currentRevisionCreator = currentRevision ? currentRevision.getCreator() %}
                <li>
                    <a{% if not isDraft and not isRevision %} class=\"sel\"{% endif %} href=\"{{ cpEditUrl }}\">{{ \"Current\"|t('app') }}
                        <span class=\"light\">–
                            {{ currentRevisionCreator ? 'saved {timestamp} by {creator}'|t('app', {
                                timestamp: currentRevisionEditTime|timestamp('short', withPreposition=true),
                                creator: currentRevisionCreator.name,
                            }) : 'updated {timestamp}'|t('app', {
                                timestamp: currentRevisionEditTime|timestamp('short', withPreposition=true),
                            }) }}
                        </span>
                    </a>
                </li>
            </ul>
        {% endif %}

        {% if drafts %}
            <h6>{{ \"Drafts\"|t('app') }}</h6>
            <ul class=\"padded revision-group-drafts\">
                {% for draft in drafts %}
                    {% set url = url(cpEditUrl, baseParams|merge({ draftId: draft.draftId })) %}
                    <li>
                        <a{% if draft.draftId == element.draftId %} class=\"sel\"{% endif %} href=\"{{ url }}\">
                            <span class=\"draft-name\">{{ draft.draftName }}</span>
                            {% set creator = draft.getCreator() %}
                            <span class=\"draft-meta light\">–
                                {{ creator ? 'updated {timestamp} by {creator}'|t('app', {
                                    timestamp: draft.dateUpdated|timestamp('short', withPreposition=true),
                                    creator: creator.name,
                                }) : 'updated {timestamp}'|t('app', {
                                    timestamp: draft.dateUpdated|timestamp('short', withPreposition=true),
                                }) }}
                            </span>
                        </a>
                    </li>
                {% endfor %}
            </ul>
        {% endif %}

        {% if revisions %}
            <h6>{{ \"Recent Revisions\"|t('app') }}</h6>
            <ul class=\"padded\" id=\"revision-group-revisions\">
                {% for revision in revisions %}
                    <li>
                        {% set url = url(cpEditUrl, baseParams|merge({ revisionId: revision.revisionId })) %}
                        <a{% if revision.revisionId == element.revisionId %} class=\"sel\"{% endif %} href=\"{{ url }}\">
                            {{ revision.getRevisionLabel() }}
                            {% set creator = revision.getCreator() %}
                            <span class=\"light\">–
                                {{ creator ? 'saved {timestamp} by {creator}'|t('app', {
                                    timestamp: revision.dateCreated|timestamp('short', withPreposition=true),
                                    creator: creator.name,
                                }) : 'updated {timestamp}'|t('app', {
                                    timestamp: revision.dateCreated|timestamp('short', withPreposition=true),
                                }) }}
                            </span>
                        </a>
                    </li>
                {% endfor %}
            </ul>
        {% endif %}
    </div>
</div>

<div id=\"revision-spinner\" class=\"spinner hidden\" title=\"{{ 'Saving'|t('app') }}\" aria-label=\"{{ 'Saving'|t('app') }}\"></div>
<div id=\"revision-status\" class=\"invisible\"></div>
", "_includes/revisionmenu", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/revisionmenu.html");
    }
}
