<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sites/_edit */
class __TwigTemplate_ae52638d8feae2e3f688029e4bcc5f3941bf96574c0f3d25f9d79097ec8d8e7a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/sites/_edit");
        // line 3
        $context["fullPageForm"] = true;
        // line 5
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/sites/_edit", 5)->unwrap();
        // line 123
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 123, $this->source); })()), "handle", [])) {
            // line 124
            ob_start();
            // line 125
            echo "        new Craft.HandleGenerator('#name', '#handle');
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 4]);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sites/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/sites/_edit");
    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 9
        echo "    ";
        echo craft\helpers\Html::actionInput("sites/save-site");
        echo "
    ";
        // line 10
        echo craft\helpers\Html::redirectInput("settings/sites");
        echo "
    ";
        // line 11
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 11, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 11, $this->source); })()), "id", []));
        }
        // line 12
        echo "
    ";
        // line 13
        echo twig_call_macro($macros["forms"], "macro_selectField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which group should this site belong to?", "app"), "warning" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 17
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 17, $this->source); })()), "id", []) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "app", []), "isMultiSite", []))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "group", "name" => "group", "options" =>         // line 20
(isset($context["groupOptions"]) || array_key_exists("groupOptions", $context) ? $context["groupOptions"] : (function () { throw new RuntimeError('Variable "groupOptions" does not exist.', 20, $this->source); })()), "value" =>         // line 21
(isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new RuntimeError('Variable "groupId" does not exist.', 21, $this->source); })())]], 13, $context, $this->getSourceContext());
        // line 22
        echo "

    <div id=\"site-settings\">
        ";
        // line 25
        echo twig_call_macro($macros["forms"], "macro_autosuggestField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this site will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 31
($context["site"] ?? null), "originalName", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["site"] ?? null), "originalName", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["site"] ?? null), "originalName", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 31, $this->source); })()), "getName", [0 => false], "method"))), "suggestEnvVars" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 33
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 33, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 25, $context, $this->getSourceContext());
        // line 36
        echo "

        ";
        // line 38
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this site in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 46
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 46, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 47
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 47, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 38, $context, $this->getSourceContext());
        // line 49
        echo "

        ";
        // line 51
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 51, $this->source); })()), "app", []), "i18n", []), "getIsIntlLoaded", [], "method")) {
            // line 52
            echo "            ";
            $context["languageWarning"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Enable the [Intl extension]({link1}) or install additional [locale data files]({link2}) for more language options.", "app", ["link1" => "http://php.net/manual/en/book.intl.php", "link2" => "https://github.com/craftcms/locales"]);
            // line 56
            echo "        ";
        }
        // line 57
        echo "
        ";
        // line 58
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The language content in this site will use.", "app"), "id" => "language", "name" => "language", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 63
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 63, $this->source); })()), "language", []), "options" =>         // line 64
(isset($context["languageOptions"]) || array_key_exists("languageOptions", $context) ? $context["languageOptions"] : (function () { throw new RuntimeError('Variable "languageOptions" does not exist.', 64, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 65
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 65, $this->source); })()), "getErrors", [0 => "language"], "method"), "warning" => ((        // line 66
$context["languageWarning"]) ?? (null))]], 58, $context, $this->getSourceContext());
        // line 67
        echo "

        ";
        // line 69
        if (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 69, $this->source); })()), "app", []), "isMultiSite", []) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 69, $this->source); })()), "id", [])) &&  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 69, $this->source); })()), "primary", []))) {
            // line 70
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Make this the primary site", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The primary site will be loaded by default on the front end.", "app"), "id" => "primary", "name" => "primary", "on" => craft\helpers\Template::attribute($this->env, $this->source,             // line 75
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 75, $this->source); })()), "primary", [])]], 70, $context, $this->getSourceContext());
            // line 76
            echo "
        ";
        } else {
            // line 78
            echo "            ";
            echo craft\helpers\Html::hiddenInput("primary", "1");
            echo "
        ";
        }
        // line 80
        echo "
        <hr>

        ";
        // line 83
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This site has its own base URL", "app"), "id" => "has-urls", "name" => "hasUrls", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 87
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 87, $this->source); })()), "hasUrls", []), "toggle" => "url-settings"]], 83, $context, $this->getSourceContext());
        // line 89
        echo "

        <div id=\"url-settings\" class=\"nested-fields";
        // line 91
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 91, $this->source); })()), "hasUrls", [])) {
            echo " hidden";
        }
        echo "\">
            ";
        // line 92
        echo twig_call_macro($macros["forms"], "macro_autosuggestField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The base URL for the site.", "app"), "id" => "base-url", "class" => "ltr", "suggestEnvVars" => true, "suggestAliases" => true, "name" => "baseUrl", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 100
($context["site"] ?? null), "originalBaseUrl", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["site"] ?? null), "originalBaseUrl", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["site"] ?? null), "originalBaseUrl", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 100, $this->source); })()), "getBaseUrl", [0 => false], "method"))), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 101
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 101, $this->source); })()), "getErrors", [0 => "baseUrl"], "method")]], 92, $context, $this->getSourceContext());
        // line 102
        echo "
        </div>
    </div>
";
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 107
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 108
        echo "    ";
        if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 108, $this->source); })()), "app", []), "isMultiSite", []) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 108, $this->source); })()), "id", []))) {
            // line 109
            echo "        <div class=\"meta\">
            ";
            // line 110
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enable on the front end", "app"), "id" => "enabled", "name" => "enabled", "on" => (craft\helpers\Template::attribute($this->env, $this->source,             // line 114
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 114, $this->source); })()), "primary", []) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 114, $this->source); })()), "enabled", [])), "disabled" => craft\helpers\Template::attribute($this->env, $this->source,             // line 115
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 115, $this->source); })()), "primary", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 116
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 116, $this->source); })()), "getErrors", [0 => "enabled"], "method")]], 110, $context, $this->getSourceContext());
            // line 117
            echo "
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "details");
    }

    public function getTemplateName()
    {
        return "settings/sites/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  193 => 117,  191 => 116,  190 => 115,  189 => 114,  188 => 110,  185 => 109,  182 => 108,  177 => 107,  169 => 102,  167 => 101,  166 => 100,  165 => 92,  159 => 91,  155 => 89,  153 => 87,  152 => 83,  147 => 80,  141 => 78,  137 => 76,  135 => 75,  133 => 70,  131 => 69,  127 => 67,  125 => 66,  124 => 65,  123 => 64,  122 => 63,  121 => 58,  118 => 57,  115 => 56,  112 => 52,  110 => 51,  106 => 49,  104 => 47,  103 => 46,  102 => 38,  98 => 36,  96 => 33,  95 => 31,  94 => 25,  89 => 22,  87 => 21,  86 => 20,  85 => 17,  84 => 13,  81 => 12,  77 => 11,  73 => 10,  68 => 9,  63 => 8,  57 => 1,  52 => 125,  50 => 124,  48 => 123,  46 => 5,  44 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
    {{ actionInput('sites/save-site') }}
    {{ redirectInput('settings/sites') }}
    {% if site.id %}{{ hiddenInput('siteId', site.id) }}{% endif %}

    {{ forms.selectField({
        first: true,
        label: \"Group\"|t('app'),
        instructions: \"Which group should this site belong to?\"|t('app'),
        warning: site.id and craft.app.isMultiSite ? 'Changing this may result in data loss.'|t('app'),
        id: 'group',
        name: 'group',
        options: groupOptions,
        value: groupId
    }) }}

    <div id=\"site-settings\">
        {{ forms.autosuggestField({
            first: true,
            label: \"Name\"|t('app'),
            instructions: \"What this site will be called in the control panel.\"|t('app'),
            id: 'name',
            name: 'name',
            value: site.originalName ?? site.getName(false),
            suggestEnvVars: true,
            errors: site.getErrors('name'),
            autofocus: true,
            required: true,
        }) }}

        {{ forms.textField({
            label: \"Handle\"|t('app'),
            instructions: \"How you’ll refer to this site in the templates.\"|t('app'),
            id: 'handle',
            name: 'handle',
            class: 'code',
            autocorrect: false,
            autocapitalize: false,
            value: site.handle,
            errors: site.getErrors('handle'),
            required: true
        }) }}

        {% if not craft.app.i18n.getIsIntlLoaded() %}
            {% set languageWarning = 'Enable the [Intl extension]({link1}) or install additional [locale data files]({link2}) for more language options.'|t('app', {
                link1: 'http://php.net/manual/en/book.intl.php',
                link2: 'https://github.com/craftcms/locales'
            }) %}
        {% endif %}

        {{ forms.selectField({
            label: \"Language\"|t('app'),
            instructions: \"The language content in this site will use.\"|t('app'),
            id: 'language',
            name: 'language',
            value: site.language,
            options: languageOptions,
            errors: site.getErrors('language'),
            warning: languageWarning ?? null
        }) }}

        {% if (craft.app.isMultiSite or not site.id) and not site.primary %}
            {{ forms.lightswitchField({
                label: 'Make this the primary site'|t('app'),
                instructions: \"The primary site will be loaded by default on the front end.\"|t('app'),
                id: 'primary',
                name: 'primary',
                on: site.primary
            }) }}
        {% else %}
            {{ hiddenInput('primary', '1') }}
        {% endif %}

        <hr>

        {{ forms.checkboxField({
            label: \"This site has its own base URL\"|t('app'),
            id: 'has-urls',
            name: 'hasUrls',
            checked: site.hasUrls,
            toggle: 'url-settings'
        }) }}

        <div id=\"url-settings\" class=\"nested-fields{% if not site.hasUrls %} hidden{% endif %}\">
            {{ forms.autosuggestField({
                label: \"Base URL\"|t('app'),
                instructions: \"The base URL for the site.\"|t('app'),
                id: 'base-url',
                class: 'ltr',
                suggestEnvVars: true,
                suggestAliases: true,
                name: 'baseUrl',
                value: site.originalBaseUrl ?? site.getBaseUrl(false),
                errors: site.getErrors('baseUrl')
            }) }}
        </div>
    </div>
{% endblock %}

{% block details %}
    {% if (craft.app.isMultiSite or not site.id) %}
        <div class=\"meta\">
            {{ forms.lightswitchField({
                label: 'Enable on the front end'|t('app'),
                id: 'enabled',
                name: 'enabled',
                on: site.primary or site.enabled,
                disabled: site.primary,
                errors: site.getErrors('enabled'),
            }) }}
        </div>
    {% endif %}
{% endblock %}


{% if not site.handle %}
    {% js on ready %}
        new Craft.HandleGenerator('#name', '#handle');
    {% endjs %}
{% endif %}
", "settings/sites/_edit", "/var/www/html/vendor/craftcms/cms/src/templates/settings/sites/_edit.html");
    }
}
