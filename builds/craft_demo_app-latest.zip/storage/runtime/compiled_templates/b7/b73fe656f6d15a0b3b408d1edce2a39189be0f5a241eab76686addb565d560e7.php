<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* users/_edit */
class __TwigTemplate_d2a4c4a0342c1b9cba5b507a4d0b6eb2340a4dbc1f2d8778e502cbff9e0e09a9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "users/_edit");
        // line 3
        if ((((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 3, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 3, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 3, $this->source); })()), "can", [0 => "editUsers"], "method"))) {
            // line 4
            $context["crumbs"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Users", "app"), "url" => craft\helpers\UrlHelper::url("users")]];
        }
        // line 9
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "users/_edit", 9)->unwrap();
        // line 11
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 11, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\fileupload\\FileUploadAsset"], "method");
        // line 12
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 12, $this->source); })()), "setIsDeltaRegistrationActive", [0 => true], "method");
        // line 14
        $context["requireEmailVerification"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true), "projectConfig", [], "any", false, true), "get", [0 => "users.requireEmailVerification"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true), "projectConfig", [], "any", false, true), "get", [0 => "users.requireEmailVerification"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true), "projectConfig", [], "any", false, true), "get", [0 => "users.requireEmailVerification"], "method")) : (true));
        // line 15
        $context["canAdministrateUsers"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 15, $this->source); })()), "can", [0 => "administrateUsers"], "method");
        // line 17
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "app", []), "request", []), "isPost", [])) {
            // line 18
            $context["currentGroupIds"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 18, $this->source); })()), "app", []), "request", []), "getBodyParam", [0 => "groups"], "method")) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 18, $this->source); })()), "app", []), "request", []), "getBodyParam", [0 => "groups"], "method")) : ([]));
        } else {
            // line 20
            $context["currentGroupIds"] = craft\helpers\ArrayHelper::getColumn(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 20, $this->source); })()), "getGroups", [], "method"), "id");
        }
        // line 23
        ob_start();
        // line 24
        echo "    ";
        echo craft\helpers\Html::csrfInput();
        echo "
    ";
        // line 25
        if ( !(isset($context["isNewUser"]) || array_key_exists("isNewUser", $context) ? $context["isNewUser"] : (function () { throw new RuntimeError('Variable "isNewUser" does not exist.', 25, $this->source); })())) {
            // line 26
            echo craft\helpers\Html::hiddenInput("userId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 26, $this->source); })()), "id", []));
        }
        $context["hiddenInputs"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 30
        echo \Craft::$app->getView()->invokeHook("cp.users.edit", $context);

        // line 392
        ob_start();
        // line 393
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 393, $this->source); })()), "getIsCurrent", [], "method")) {
            // line 394
            echo "        var changeSidebarPicture = true;
    ";
        } else {
            // line 396
            echo "        var changeSidebarPicture = false;
    ";
        }
        // line 398
        echo "
    new Craft.ElevatedSessionForm('#userform', [
        ";
        // line 400
        if ( !(isset($context["isNewUser"]) || array_key_exists("isNewUser", $context) ? $context["isNewUser"] : (function () { throw new RuntimeError('Variable "isNewUser" does not exist.', 400, $this->source); })())) {
            // line 401
            echo "        '#email',
        '#newPassword',
        ";
        }
        // line 404
        echo "        '#admin:not(:checked)',
        '#user-groups input[type=\"checkbox\"]:not(:checked)',
        '#permissions input[type=\"checkbox\"]:not(:checked)'
    ]);
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "users/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "users/_edit");
    }

    // line 32
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 33
        echo "    ";
        if (( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 33, $this->source); })()), "can", [0 => "registerUsers"], "method") || ((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 33, $this->source); })()) != (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 33, $this->source); })())))) {
            // line 34
            echo "        <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
            echo "</button>
    ";
        } else {
            // line 36
            echo "        <div class=\"btngroup\">
            <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">";
            // line 37
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
            echo "</button>
            <button type=\"button\" class=\"btn submit menubtn\" data-form=\"userform\"></button>
            <div class=\"menu\">
                <ul>
                    <li>
                        <a class=\"formsubmit\" data-redirect=\"";
            // line 42
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), [(((isset($context["isNewUser"]) || array_key_exists("isNewUser", $context) ? $context["isNewUser"] : (function () { throw new RuntimeError('Variable "isNewUser" does not exist.', 42, $this->source); })())) ? ("users/{id}") : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 42, $this->source); })()), "getCpEditUrl", [], "method")))]), "html", null, true);
            echo "\">
                            ";
            // line 43
            echo twig_call_macro($macros["forms"], "macro_optionShortcutLabel", ["S"], 43, $context, $this->getSourceContext());
            echo "
                            ";
            // line 44
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "html", null, true);
            echo "
                        </a>
                    </li>
                    <li><a class=\"formsubmit\" data-redirect=\"";
            // line 47
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), ["users/new#"]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save and add another", "app"), "html", null, true);
            echo "</a></li>
                </ul>
            </div>
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 54
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 55
        echo "    ";
        $context["formAttributes"] = ["id" => "userform", "method" => "post", "accept-charset" => "UTF-8", "data" => ["saveshortcut" => true, "saveshortcut-redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [((craft\helpers\Template::attribute($this->env, $this->source,         // line 61
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 61, $this->source); })()), "getIsCurrent", [], "method")) ? ("myaccount") : ((((((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 61, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 61, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 61, $this->source); })()), "can", [0 => "editUsers"], "method"))) ? ("users/{id}") : ("dashboard"))))]), "saveshortcut-scroll" => true, "confirm-unload" => true, "delta" => true]];
        // line 67
        echo "    <form ";
        echo craft\helpers\Html::renderTagAttributes((isset($context["formAttributes"]) || array_key_exists("formAttributes", $context) ? $context["formAttributes"] : (function () { throw new RuntimeError('Variable "formAttributes" does not exist.', 67, $this->source); })()));
        echo ">
        ";
        // line 68
        echo craft\helpers\Html::actionInput("users/save-user");
        echo "
        ";
        // line 69
        echo craft\helpers\Html::redirectInput((((((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 69, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 69, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 69, $this->source); })()), "can", [0 => "editUsers"], "method"))) ? ("users") : ("dashboard")));
        echo "
        ";
        // line 70
        echo twig_escape_filter($this->env, (isset($context["hiddenInputs"]) || array_key_exists("hiddenInputs", $context) ? $context["hiddenInputs"] : (function () { throw new RuntimeError('Variable "hiddenInputs" does not exist.', 70, $this->source); })()), "html", null, true);
        echo "

        <div id=\"account\" class=\"flex-fields\">
            ";
        // line 73
        $this->loadTemplate("users/_accountfields", "users/_edit", 73)->display($context);
        // line 74
        echo "
            ";
        // line 75
        if (( !(isset($context["isNewUser"]) || array_key_exists("isNewUser", $context) ? $context["isNewUser"] : (function () { throw new RuntimeError('Variable "isNewUser" does not exist.', 75, $this->source); })()) && (isset($context["showPhotoField"]) || array_key_exists("showPhotoField", $context) ? $context["showPhotoField"] : (function () { throw new RuntimeError('Variable "showPhotoField" does not exist.', 75, $this->source); })()))) {
            // line 76
            echo "                ";
            echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Photo", "app"), "id" => "photo"], twig_include($this->env, $context, "users/_photo", ["user" =>             // line 79
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 79, $this->source); })())], false)], 76, $context, $this->getSourceContext());
            echo "
            ";
        }
        // line 81
        echo "
            ";
        // line 82
        if ((isset($context["isNewUser"]) || array_key_exists("isNewUser", $context) ? $context["isNewUser"] : (function () { throw new RuntimeError('Variable "isNewUser" does not exist.', 82, $this->source); })())) {
            // line 83
            echo "                <hr>

                ";
            // line 85
            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Email", "app"), "id" => "email", "name" => "email", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 89
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 89, $this->source); })()), "email", []), "required" => true, "type" => "email", "errors" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 92
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 92, $this->source); })()), "getErrors", [0 => "email"], "method"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 92, $this->source); })()), "getErrors", [0 => "unverifiedEmail"], "method")), "inputAttributes" => ["data" => ["lpignore" => "true"]]]], 85, $context, $this->getSourceContext());
            // line 96
            echo "

                ";
            // line 98
            echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Send an activation email now", "app"), "name" => "sendVerificationEmail", "checked" => true]], 98, $context, $this->getSourceContext());
            // line 102
            echo "

            ";
        } elseif ((craft\helpers\Template::attribute($this->env, $this->source,         // line 104
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 104, $this->source); })()), "getIsCurrent", [], "method") || (isset($context["canAdministrateUsers"]) || array_key_exists("canAdministrateUsers", $context) ? $context["canAdministrateUsers"] : (function () { throw new RuntimeError('Variable "canAdministrateUsers" does not exist.', 104, $this->source); })()))) {
            // line 105
            echo "                <hr>

                ";
            // line 107
            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Email", "app"), "warning" => (((            // line 109
(isset($context["requireEmailVerification"]) || array_key_exists("requireEmailVerification", $context) ? $context["requireEmailVerification"] : (function () { throw new RuntimeError('Variable "requireEmailVerification" does not exist.', 109, $this->source); })()) &&  !(isset($context["canAdministrateUsers"]) || array_key_exists("canAdministrateUsers", $context) ? $context["canAdministrateUsers"] : (function () { throw new RuntimeError('Variable "canAdministrateUsers" does not exist.', 109, $this->source); })()))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("New email addresses must be verified before taking effect.", "app")) : ("")), "id" => "email", "name" => "email", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 113
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 113, $this->source); })()), "email", []), "required" => true, "type" => "email", "errors" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 116
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 116, $this->source); })()), "getErrors", [0 => "email"], "method"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 116, $this->source); })()), "getErrors", [0 => "unverifiedEmail"], "method")), "inputAttributes" => ["data" => ["lpignore" => "true"]]]], 107, $context, $this->getSourceContext());
            // line 120
            echo "

                ";
            // line 122
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 122, $this->source); })()), "getIsCurrent", [], "method")) {
                // line 123
                echo "                    ";
                echo twig_call_macro($macros["forms"], "macro_passwordField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("New Password", "app"), "id" => "newPassword", "name" => "newPassword", "autocomplete" => "new-password", "errors" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 128
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 128, $this->source); })()), "getErrors", [0 => "newPassword"], "method"), "inputAttributes" => ["data" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["lpignore" => ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 131
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 131, $this->source); })()), "getIsCurrent", [], "method")) ? (false) : ("true"))])]]], 123, $context, $this->getSourceContext());
                // line 134
                echo "

                    ";
                // line 136
                ob_start();
                // line 137
                echo "                        new Craft.PasswordInput('#newPassword');
                    ";
                craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
                // line 139
                echo "                ";
            }
            // line 140
            echo "
                ";
            // line 141
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 141, $this->source); })()), "admin", [])) {
                // line 142
                echo "                    ";
                echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Require a password reset on next login", "app"), "name" => "passwordResetRequired", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 145
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 145, $this->source); })()), "passwordResetRequired", [])]], 142, $context, $this->getSourceContext());
                // line 146
                echo "
                ";
            }
            // line 148
            echo "
            ";
        }
        // line 150
        echo "        </div>

        ";
        // line 152
        echo (isset($context["fieldsHtml"]) || array_key_exists("fieldsHtml", $context) ? $context["fieldsHtml"] : (function () { throw new RuntimeError('Variable "fieldsHtml" does not exist.', 152, $this->source); })());
        echo "

        ";
        // line 154
        if ((((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 154, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 154, $this->source); })())) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 154, $this->source); })()), "can", [0 => "assignUserGroups"], "method") || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 154, $this->source); })()), "can", [0 => "assignUserPermissions"], "method")))) {
            // line 155
            echo "            <div id=\"perms\" class=\"flex-fields hidden\">

                ";
            // line 157
            if ((((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 157, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 157, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 157, $this->source); })()), "can", [0 => "assignUserGroups"], "method"))) {
                // line 158
                echo "                    <fieldset>
                        <h2>";
                // line 159
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("User Groups", "app"), "html", null, true);
                echo "</h2>

                        ";
                // line 161
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 161, $this->source); })()), "registerDeltaName", [0 => "groups"], "method");
                // line 162
                echo "                        ";
                $context["assignableGroups"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 162, $this->source); })()), "app", []), "userGroups", []), "getAssignableGroups", [0 => (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 162, $this->source); })())], "method");
                // line 163
                echo "
                        ";
                // line 164
                $this->loadTemplate("users/_edit", "users/_edit", 164, "585392955")->display(twig_array_merge($context, ["fieldId" => "user-groups"]));
                // line 185
                echo "                    </fieldset>
                ";
            }
            // line 187
            echo "
                ";
            // line 188
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 188, $this->source); })()), "can", [0 => "assignUserPermissions"], "method")) {
                // line 189
                echo "                    <h2>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Permissions", "app"), "html", null, true);
                echo "</h2>

                    ";
                // line 191
                if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 191, $this->source); })()), "admin", []) && ((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 191, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 191, $this->source); })())))) {
                    // line 192
                    echo "                        ";
                    echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => craft\helpers\Template::raw((("<b>" . $this->extensions['craft\web\twig\Extension']->translateFilter("Admin", "app")) . "</b>")), "name" => "admin", "id" => "admin", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 196
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 196, $this->source); })()), "admin", []), "reverseToggle" => "permissions"]], 192, $context, $this->getSourceContext());
                    // line 198
                    echo "
                    ";
                }
                // line 200
                echo "
                    ";
                // line 201
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 201, $this->source); })()), "registerDeltaName", [0 => "permissions"], "method");
                // line 202
                echo "                    ";
                echo craft\helpers\Html::hiddenInput("permissions", "");
                echo "

                    <div id=\"permissions\" class=\"field";
                // line 204
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 204, $this->source); })()), "admin", [])) {
                    echo " hidden";
                }
                echo "\">
                        ";
                // line 205
                $this->loadTemplate("_includes/permissions", "users/_edit", 205)->display(twig_to_array(["userOrGroup" => ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 206
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 206, $this->source); })()), "admin", [])) ? (null) : ((isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 206, $this->source); })()))), "groupPermissions" => ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 207
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 207, $this->source); })()), "id", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 207, $this->source); })()), "app", []), "userPermissions", []), "getGroupPermissionsByUserId", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 207, $this->source); })()), "id", [])], "method")) : ([]))]));
                // line 209
                echo "                    </div>
                ";
            }
            // line 211
            echo "
            </div>
        ";
        }
        // line 214
        echo "
        ";
        // line 215
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 215, $this->source); })()), "getIsCurrent", [], "method")) {
            // line 216
            echo "            <div id=\"prefs\" class=\"flex-fields hidden\">
                ";
            // line 217
            echo twig_call_macro($macros["forms"], "macro_selectField", [["id" => "preferredLanguage", "name" => "preferredLanguage", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The language that the control panel should use.", "app"), "options" =>             // line 222
(isset($context["localeOptions"]) || array_key_exists("localeOptions", $context) ? $context["localeOptions"] : (function () { throw new RuntimeError('Variable "localeOptions" does not exist.', 222, $this->source); })()), "value" =>             // line 223
(isset($context["userLanguage"]) || array_key_exists("userLanguage", $context) ? $context["userLanguage"] : (function () { throw new RuntimeError('Variable "userLanguage" does not exist.', 223, $this->source); })())]], 217, $context, $this->getSourceContext());
            // line 224
            echo "

                ";
            // line 226
            echo twig_call_macro($macros["forms"], "macro_selectField", [["id" => "preferredLocale", "name" => "preferredLocale", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Formatting Locale", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The locale that should be used for date and number formatting.", "app"), "options" => $this->extensions['craft\web\twig\Extension']->unshiftFilter(            // line 231
(isset($context["localeOptions"]) || array_key_exists("localeOptions", $context) ? $context["localeOptions"] : (function () { throw new RuntimeError('Variable "localeOptions" does not exist.', 231, $this->source); })()), ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Same as language", "app"), "value" => ""]), "value" =>             // line 232
(isset($context["userLocale"]) || array_key_exists("userLocale", $context) ? $context["userLocale"] : (function () { throw new RuntimeError('Variable "userLocale" does not exist.', 232, $this->source); })())]], 226, $context, $this->getSourceContext());
            // line 233
            echo "

                ";
            // line 235
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Week Start Day", "app"), "id" => "weekStartDay", "name" => "weekStartDay", "options" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 239
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 239, $this->source); })()), "app", []), "locale", []), "getWeekDayNames", [], "method"), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 240
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 240, $this->source); })()), "getPreference", [0 => "weekStartDay", 1 => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 240, $this->source); })()), "app", []), "config", []), "general", []), "defaultWeekStartDay", [])], "method")]], 235, $context, $this->getSourceContext());
            // line 241
            echo "

                <hr>

                <fieldset>
                    ";
            // line 246
            $this->loadTemplate("users/_edit", "users/_edit", 246, "479911887")->display(twig_array_merge($context, ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Accessibility", "app")]));
            // line 266
            echo "                </fieldset>

                ";
            // line 268
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 268, $this->source); })()), "admin", [])) {
                // line 269
                echo "                    <fieldset>
                        ";
                // line 270
                $this->loadTemplate("users/_edit", "users/_edit", 270, "1340876126")->display(twig_array_merge($context, ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Development", "app")]));
                // line 307
                echo "                    </fieldset>
                ";
            }
            // line 309
            echo "
                ";
            // line 310
            echo \Craft::$app->getView()->invokeHook("cp.users.edit.prefs", $context);

            // line 311
            echo "            </div>
        ";
        }
        // line 313
        echo "
        ";
        // line 315
        echo "        ";
        echo \Craft::$app->getView()->invokeHook("cp.users.edit.content", $context);

        // line 316
        echo "
        <input type=\"submit\" class=\"hidden\">
    </form>
";
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 321
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 322
        echo "    ";
        if ( !(isset($context["isNewUser"]) || array_key_exists("isNewUser", $context) ? $context["isNewUser"] : (function () { throw new RuntimeError('Variable "isNewUser" does not exist.', 322, $this->source); })())) {
            // line 323
            echo "        ";
            if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 323, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 323, $this->source); })()))) {
                // line 324
                echo "            <form class=\"meta read-only\" method=\"post\" accept-charset=\"UTF-8\">
                ";
                // line 325
                echo twig_escape_filter($this->env, (isset($context["hiddenInputs"]) || array_key_exists("hiddenInputs", $context) ? $context["hiddenInputs"] : (function () { throw new RuntimeError('Variable "hiddenInputs" does not exist.', 325, $this->source); })()), "html", null, true);
                echo "
                <div class=\"data first\">
                    <h5 class=\"heading\">";
                // line 327
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Status", "app"), "html", null, true);
                echo "</h5>
                    <div class=\"value flex\">
                        <div class=\"flex-grow\"><span class=\"status ";
                // line 329
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 329, $this->source); })()), "getStatus", [], "method"), "html", null, true);
                echo "\"></span> ";
                echo twig_escape_filter($this->env, (isset($context["statusLabel"]) || array_key_exists("statusLabel", $context) ? $context["statusLabel"] : (function () { throw new RuntimeError('Variable "statusLabel" does not exist.', 329, $this->source); })()), "html", null, true);
                echo "</div>

                        ";
                // line 331
                if (twig_length_filter($this->env, (isset($context["actions"]) || array_key_exists("actions", $context) ? $context["actions"] : (function () { throw new RuntimeError('Variable "actions" does not exist.', 331, $this->source); })()))) {
                    // line 332
                    echo "                            <div>
                                <button type=\"button\" id=\"action-menubtn\" class=\"btn menubtn\" data-icon=\"settings\" title=\"";
                    // line 333
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"), "html", null, true);
                    echo "\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"), "html", null, true);
                    echo "\"></button>
                                <div class=\"menu\">
                                    ";
                    // line 335
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["actions"]) || array_key_exists("actions", $context) ? $context["actions"] : (function () { throw new RuntimeError('Variable "actions" does not exist.', 335, $this->source); })()));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["actionList"]) {
                        // line 336
                        echo "                                        ";
                        if ( !craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) {
                            echo "<hr>";
                        }
                        // line 337
                        echo "                                        <ul>
                                            ";
                        // line 338
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["actionList"]);
                        foreach ($context['_seq'] as $context["_key"] => $context["actionItem"]) {
                            // line 339
                            echo "                                                <li><a";
                            // line 340
                            if (craft\helpers\Template::attribute($this->env, $this->source, $context["actionItem"], "id", [], "any", true, true)) {
                                echo " id=\"";
                                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["actionItem"], "id", []), "html", null, true);
                                echo "\"";
                                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["actionItem"], "id", []) == "delete-btn")) {
                                    echo " class=\"error\"";
                                }
                            }
                            // line 341
                            if (craft\helpers\Template::attribute($this->env, $this->source, $context["actionItem"], "action", [], "any", true, true)) {
                                echo " class=\"formsubmit\" data-action=\"";
                                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["actionItem"], "action", []), "html", null, true);
                                echo "\"";
                            }
                            // line 342
                            echo ">";
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["actionItem"], "label", []), "html", null, true);
                            echo "</a>
                                                </li>
                                            ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['actionItem'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 345
                        echo "                                        </ul>
                                    ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['actionList'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 347
                    echo "                                </div>
                                <div id=\"action-spinner\" class=\"spinner hidden\"></div>
                            </div>
                        ";
                }
                // line 351
                echo "                    </div>
                </div>

                ";
                // line 354
                if ((((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 354, $this->source); })()), "getStatus", [], "method") == "locked") && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 354, $this->source); })()), "app", []), "config", []), "general", []), "cooldownDuration", [])) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 354, $this->source); })()), "remainingCooldownTime", []))) {
                    // line 355
                    echo "                    <div class=\"data\">
                        <h5 class=\"heading\">";
                    // line 356
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Cooldown Time Remaining", "app"), "html", null, true);
                    echo "</h5>
                        <p class=\"value\">";
                    // line 357
                    echo twig_escape_filter($this->env, craft\helpers\DateTimeHelper::humanDurationFromInterval(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 357, $this->source); })()), "remainingCooldownTime", [])), "html", null, true);
                    echo "</p>
                    </div>
                ";
                }
                // line 360
                echo "
                <div class=\"data\">
                    <h5 class=\"heading\">";
                // line 362
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Registered at", "app"), "html", null, true);
                echo "</h5>
                    <p class=\"value\">";
                // line 363
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 363, $this->source); })()), "dateCreated", []), "short"), "html", null, true);
                echo "</p>
                </div>

                ";
                // line 366
                if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 366, $this->source); })()), "getStatus", [], "method") != "pending")) {
                    // line 367
                    echo "                    <div class=\"data\">
                        <h5 class=\"heading\">";
                    // line 368
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Last login", "app"), "html", null, true);
                    echo "</h5>
                        <p class=\"value\">";
                    // line 369
                    if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 369, $this->source); })()), "lastLoginDate", [])) {
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 369, $this->source); })()), "lastLoginDate", []), "short"), "html", null, true);
                    } else {
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Never", "app"), "html", null, true);
                    }
                    echo "</p>
                    </div>

                    ";
                    // line 372
                    if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 372, $this->source); })()), "getStatus", [], "method") == "locked")) {
                        // line 373
                        echo "                        <div class=\"data\">
                            <h5 class=\"heading\">";
                        // line 374
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Last login fail", "app"), "html", null, true);
                        echo "</h5>
                            <p class=\"value\">";
                        // line 375
                        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 375, $this->source); })()), "lastInvalidLoginDate", [])) {
                            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 375, $this->source); })()), "lastInvalidLoginDate", []), "short"), "html", null, true);
                        }
                        echo "</p>
                        </div>

                        <div class=\"data\">
                            <h5 class=\"heading\">";
                        // line 379
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Login fail count", "app"), "html", null, true);
                        echo "</h5>
                            <p class=\"value\">";
                        // line 380
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 380, $this->source); })()), "invalidLoginCount", []), "html", null, true);
                        echo "</p>
                        </div>
                    ";
                    }
                    // line 383
                    echo "                ";
                }
                // line 384
                echo "            </form>
        ";
            }
            // line 386
            echo "    ";
        }
        // line 387
        echo "
    ";
        // line 389
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.users.edit.details", $context);

        craft\helpers\Template::endProfile("block", "details");
    }

    public function getTemplateName()
    {
        return "users/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  671 => 389,  668 => 387,  665 => 386,  661 => 384,  658 => 383,  652 => 380,  648 => 379,  639 => 375,  635 => 374,  632 => 373,  630 => 372,  620 => 369,  616 => 368,  613 => 367,  611 => 366,  605 => 363,  601 => 362,  597 => 360,  591 => 357,  587 => 356,  584 => 355,  582 => 354,  577 => 351,  571 => 347,  556 => 345,  546 => 342,  540 => 341,  531 => 340,  529 => 339,  525 => 338,  522 => 337,  517 => 336,  500 => 335,  493 => 333,  490 => 332,  488 => 331,  481 => 329,  476 => 327,  471 => 325,  468 => 324,  465 => 323,  462 => 322,  457 => 321,  449 => 316,  445 => 315,  442 => 313,  438 => 311,  435 => 310,  432 => 309,  428 => 307,  426 => 270,  423 => 269,  421 => 268,  417 => 266,  415 => 246,  408 => 241,  406 => 240,  405 => 239,  404 => 235,  400 => 233,  398 => 232,  397 => 231,  396 => 226,  392 => 224,  390 => 223,  389 => 222,  388 => 217,  385 => 216,  383 => 215,  380 => 214,  375 => 211,  371 => 209,  369 => 207,  368 => 206,  367 => 205,  361 => 204,  355 => 202,  353 => 201,  350 => 200,  346 => 198,  344 => 196,  342 => 192,  340 => 191,  334 => 189,  332 => 188,  329 => 187,  325 => 185,  323 => 164,  320 => 163,  317 => 162,  315 => 161,  310 => 159,  307 => 158,  305 => 157,  301 => 155,  299 => 154,  294 => 152,  290 => 150,  286 => 148,  282 => 146,  280 => 145,  278 => 142,  276 => 141,  273 => 140,  270 => 139,  266 => 137,  264 => 136,  260 => 134,  258 => 131,  257 => 128,  255 => 123,  253 => 122,  249 => 120,  247 => 116,  246 => 113,  245 => 109,  244 => 107,  240 => 105,  238 => 104,  234 => 102,  232 => 98,  228 => 96,  226 => 92,  225 => 89,  224 => 85,  220 => 83,  218 => 82,  215 => 81,  210 => 79,  208 => 76,  206 => 75,  203 => 74,  201 => 73,  195 => 70,  191 => 69,  187 => 68,  182 => 67,  180 => 61,  178 => 55,  173 => 54,  160 => 47,  154 => 44,  150 => 43,  146 => 42,  138 => 37,  135 => 36,  129 => 34,  126 => 33,  121 => 32,  115 => 1,  108 => 404,  103 => 401,  101 => 400,  97 => 398,  93 => 396,  89 => 394,  86 => 393,  84 => 392,  81 => 30,  77 => 26,  75 => 25,  70 => 24,  68 => 23,  65 => 20,  62 => 18,  60 => 17,  58 => 15,  56 => 14,  54 => 12,  52 => 11,  50 => 9,  47 => 4,  45 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% if CraftEdition == CraftPro and currentUser.can('editUsers') %}
    {% set crumbs = [
        { label: \"Users\"|t('app'), url: url('users') },
    ] %}
{% endif %}

{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fileupload\\\\FileUploadAsset\") %}
{% do view.setIsDeltaRegistrationActive(true) %}

{% set requireEmailVerification = craft.app.projectConfig.get('users.requireEmailVerification') ?? true %}
{% set canAdministrateUsers = currentUser.can('administrateUsers') %}

{% if craft.app.request.isPost %}
    {% set currentGroupIds = craft.app.request.getBodyParam('groups') ?: [] %}
{% else %}
    {% set currentGroupIds = user.getGroups()|column('id') %}
{% endif %}

{% set hiddenInputs %}
    {{ csrfInput() }}
    {% if not isNewUser -%}
        {{ hiddenInput('userId', user.id) }}
    {%- endif %}
{% endset %}

{% hook \"cp.users.edit\" %}

{% block actionButton %}
    {% if not currentUser.can('registerUsers') or CraftEdition != CraftPro %}
        <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">{{ 'Save'|t('app') }}</button>
    {% else %}
        <div class=\"btngroup\">
            <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">{{ 'Save'|t('app') }}</button>
            <button type=\"button\" class=\"btn submit menubtn\" data-form=\"userform\"></button>
            <div class=\"menu\">
                <ul>
                    <li>
                        <a class=\"formsubmit\" data-redirect=\"{{ (isNewUser ? 'users/{id}' : user.getCpEditUrl())|hash }}\">
                            {{ forms.optionShortcutLabel('S') }}
                            {{ \"Save and continue editing\"|t('app') }}
                        </a>
                    </li>
                    <li><a class=\"formsubmit\" data-redirect=\"{{ 'users/new#'|hash }}\">{{ \"Save and add another\"|t('app') }}</a></li>
                </ul>
            </div>
        </div>
    {% endif %}
{% endblock %}

{% block content %}
    {% set formAttributes = {
        id: 'userform',
        method: 'post',
        'accept-charset': 'UTF-8',
        data: {
            saveshortcut: true,
            'saveshortcut-redirect':  (user.getIsCurrent() ? 'myaccount' : (CraftEdition == CraftPro and currentUser.can('editUsers') ? 'users/{id}' : 'dashboard'))|hash,
            'saveshortcut-scroll': true,
            'confirm-unload': true,
            delta: true,
        },
    } %}
    <form {{ attr(formAttributes) }}>
        {{ actionInput('users/save-user') }}
        {{ redirectInput(CraftEdition == CraftPro and currentUser.can('editUsers') ? 'users' : 'dashboard') }}
        {{ hiddenInputs }}

        <div id=\"account\" class=\"flex-fields\">
            {% include \"users/_accountfields\" %}

            {% if not isNewUser and showPhotoField %}
                {{ forms.field({
                    label: \"Photo\"|t('app'),
                    id: 'photo'
                }, include('users/_photo', {user: user}, with_context = false)) }}
            {% endif %}

            {% if isNewUser %}
                <hr>

                {{ forms.textField({
                    label: \"Email\"|t('app'),
                    id: 'email',
                    name: 'email',
                    value: user.email,
                    required: true,
                    type: 'email',
                    errors: user.getErrors('email')|merge(user.getErrors('unverifiedEmail')),
                    inputAttributes: {
                        data: {lpignore: 'true'},
                    },
                }) }}

                {{ forms.checkboxField({
                    label: 'Send an activation email now'|t('app'),
                    name: 'sendVerificationEmail',
                    checked: true
                }) }}

            {% elseif user.getIsCurrent() or canAdministrateUsers %}
                <hr>

                {{ forms.textField({
                    label: \"Email\"|t('app'),
                    warning: requireEmailVerification and not canAdministrateUsers
                        ? 'New email addresses must be verified before taking effect.'|t('app'),
                    id: 'email',
                    name: 'email',
                    value: user.email,
                    required: true,
                    type: 'email',
                    errors: user.getErrors('email')|merge(user.getErrors('unverifiedEmail')),
                    inputAttributes: {
                        data: {lpignore: 'true'},
                    },
                }) }}

                {% if user.getIsCurrent() %}
                    {{ forms.passwordField({
                        label: \"New Password\"|t('app'),
                        id: 'newPassword',
                        name: 'newPassword',
                        autocomplete: 'new-password',
                        errors: user.getErrors('newPassword'),
                        inputAttributes: {
                            data: {
                                lpignore: user.getIsCurrent() ? false : 'true',
                            }|filter,
                        },
                    }) }}

                    {% js %}
                        new Craft.PasswordInput('#newPassword');
                    {% endjs %}
                {% endif %}

                {% if currentUser.admin %}
                    {{ forms.checkboxField({
                        label: \"Require a password reset on next login\"|t('app'),
                        name: 'passwordResetRequired',
                        checked: user.passwordResetRequired
                    }) }}
                {% endif %}

            {% endif %}
        </div>

        {{ fieldsHtml|raw }}

        {% if CraftEdition == CraftPro and (currentUser.can('assignUserGroups') or currentUser.can('assignUserPermissions')) %}
            <div id=\"perms\" class=\"flex-fields hidden\">

                {% if CraftEdition == CraftPro and currentUser.can('assignUserGroups') %}
                    <fieldset>
                        <h2>{{ \"User Groups\"|t('app') }}</h2>

                        {% do view.registerDeltaName('groups') %}
                        {% set assignableGroups = craft.app.userGroups.getAssignableGroups(user) %}

                        {% embed '_includes/forms/field' with {
                            fieldId: 'user-groups',
                        } %}
                            {% block input %}
                                {% from '_includes/forms' import checkboxField %}
                                {{ hiddenInput('groups', '') }}
                                {% if assignableGroups %}
                                    {% for group in assignableGroups %}
                                        {{ checkboxField({
                                            label: group.name|t('site'),
                                            instructions: group.description ? group.description|t('site')|e,
                                            name: 'groups[]',
                                            value: group.id,
                                            checked: (group.id in currentGroupIds)
                                        }) }}
                                    {% endfor %}
                                {% else %}
                                    <p>{{ \"No user groups exist yet.\"|t('app') }}</p>
                                {% endif %}
                            {% endblock %}
                        {% endembed %}
                    </fieldset>
                {% endif %}

                {% if currentUser.can('assignUserPermissions') %}
                    <h2>{{ \"Permissions\"|t('app') }}</h2>

                    {% if currentUser.admin and CraftEdition == CraftPro %}
                        {{ forms.checkboxField({
                            label: raw(\"<b>#{'Admin'|t('app')}</b>\"),
                            name: 'admin',
                            id: 'admin',
                            checked: user.admin,
                            reverseToggle: 'permissions'
                        }) }}
                    {% endif %}

                    {% do view.registerDeltaName('permissions') %}
                    {{ hiddenInput('permissions', '') }}

                    <div id=\"permissions\" class=\"field{% if user.admin %} hidden{% endif %}\">
                        {% include \"_includes/permissions\" with {
                            userOrGroup: (user.admin ? null : user),
                            groupPermissions: user.id ? craft.app.userPermissions.getGroupPermissionsByUserId(user.id) : []
                        } only %}
                    </div>
                {% endif %}

            </div>
        {% endif %}

        {% if user.getIsCurrent() %}
            <div id=\"prefs\" class=\"flex-fields hidden\">
                {{ forms.selectField({
                    id: 'preferredLanguage',
                    name: 'preferredLanguage',
                    label: \"Language\"|t('app'),
                    instructions: 'The language that the control panel should use.'|t('app'),
                    options: localeOptions,
                    value: userLanguage,
                }) }}

                {{ forms.selectField({
                    id: 'preferredLocale',
                    name: 'preferredLocale',
                    label: \"Formatting Locale\"|t('app'),
                    instructions: 'The locale that should be used for date and number formatting.'|t('app'),
                    options: localeOptions|unshift({label: 'Same as language'|t('app'), value: ''}),
                    value: userLocale,
                }) }}

                {{ forms.selectField({
                    label: \"Week Start Day\"|t('app'),
                    id: 'weekStartDay',
                    name: 'weekStartDay',
                    options: craft.app.locale.getWeekDayNames(),
                    value: user.getPreference('weekStartDay', craft.app.config.general.defaultWeekStartDay)
                }) }}

                <hr>

                <fieldset>
                    {% embed '_includes/forms/field' with {
                        label: 'Accessibility'|t('app'),
                    } %}
                        {% set a11yDefaults = craft.app.config.general.accessibilityDefaults %}
                        {% block input %}
                            {% from '_includes/forms' import checkboxField %}
                            {{ checkboxField({
                                label: 'Use shapes to represent statuses'|t('app'),
                                name: 'useShapes',
                                id: 'useShapes',
                                checked: user.getPreference('useShapes') ?? a11yDefaults['useShapes'] ?? false,
                            }) }}
                            {{ checkboxField({
                                label: 'Underline links'|t('app'),
                                name: 'underlineLinks',
                                id: 'underlineLinks',
                                checked: user.getPreference('underlineLinks') ?? a11yDefaults['underlineLinks'] ?? false,
                            }) }}
                        {% endblock %}
                    {% endembed %}
                </fieldset>

                {% if user.admin %}
                    <fieldset>
                        {% embed '_includes/forms/field' with {
                            label: 'Development'|t('app'),
                        } %}
                            {% block input %}
                                {% from '_includes/forms' import checkboxField %}
                                {{ checkboxField({
                                    label: 'Show field handles in edit forms'|t('app'),
                                    name: 'showFieldHandles',
                                    id: 'showFieldHandles',
                                    checked: user.getPreference('showFieldHandles')
                                }) }}
                                {{ checkboxField({
                                    label: \"Show the debug toolbar on the front end\"|t('app'),
                                    name: 'enableDebugToolbarForSite',
                                    id: 'enableDebugToolbarForSite',
                                    checked: user.getPreference('enableDebugToolbarForSite')
                                }) }}
                                {{ checkboxField({
                                    label: \"Show the debug toolbar in the control panel\"|t('app'),
                                    name: 'enableDebugToolbarForCp',
                                    id: 'enableDebugToolbarForCp',
                                    checked: user.getPreference('enableDebugToolbarForCp')
                                }) }}
                                {{ checkboxField({
                                    label: 'Profile Twig templates when Dev Mode is disabled'|t('app'),
                                    name: 'profileTemplates',
                                    id: 'profileTemplates',
                                    checked: user.getPreference('profileTemplates')
                                }) }}
                                {{ checkboxField({
                                    label: 'Show full exception views when Dev Mode is disabled'|t('app'),
                                    name: 'showExceptionView',
                                    id: 'showExceptionView',
                                    checked: user.getPreference('showExceptionView')
                                }) }}
                            {% endblock %}
                        {% endembed %}
                    </fieldset>
                {% endif %}

                {% hook 'cp.users.edit.prefs' %}
            </div>
        {% endif %}

        {# Give plugins a chance to add other things here #}
        {% hook \"cp.users.edit.content\" %}

        <input type=\"submit\" class=\"hidden\">
    </form>
{% endblock %}

{% block details %}
    {% if not isNewUser %}
        {% if CraftEdition == CraftPro %}
            <form class=\"meta read-only\" method=\"post\" accept-charset=\"UTF-8\">
                {{ hiddenInputs }}
                <div class=\"data first\">
                    <h5 class=\"heading\">{{ \"Status\"|t('app') }}</h5>
                    <div class=\"value flex\">
                        <div class=\"flex-grow\"><span class=\"status {{ user.getStatus() }}\"></span> {{ statusLabel }}</div>

                        {% if actions|length %}
                            <div>
                                <button type=\"button\" id=\"action-menubtn\" class=\"btn menubtn\" data-icon=\"settings\" title=\"{{ 'Actions'|t('app') }}\" aria-label=\"{{ 'Actions'|t('app') }}\"></button>
                                <div class=\"menu\">
                                    {% for actionList in actions %}
                                        {% if not loop.first %}<hr>{% endif %}
                                        <ul>
                                            {% for actionItem in actionList %}
                                                <li><a
                                                        {%- if actionItem.id is defined %} id=\"{{ actionItem.id }}\"{% if actionItem.id == 'delete-btn' %} class=\"error\"{% endif %}{% endif %}
                                                        {%- if actionItem.action is defined %} class=\"formsubmit\" data-action=\"{{ actionItem.action }}\"{% endif -%}
                                                    >{{ actionItem.label }}</a>
                                                </li>
                                            {% endfor %}
                                        </ul>
                                    {% endfor %}
                                </div>
                                <div id=\"action-spinner\" class=\"spinner hidden\"></div>
                            </div>
                        {% endif %}
                    </div>
                </div>

                {% if user.getStatus() == 'locked' and craft.app.config.general.cooldownDuration and user.remainingCooldownTime %}
                    <div class=\"data\">
                        <h5 class=\"heading\">{{ \"Cooldown Time Remaining\"|t('app') }}</h5>
                        <p class=\"value\">{{ user.remainingCooldownTime|duration }}</p>
                    </div>
                {% endif %}

                <div class=\"data\">
                    <h5 class=\"heading\">{{ \"Registered at\"|t('app') }}</h5>
                    <p class=\"value\">{{ user.dateCreated|datetime('short') }}</p>
                </div>

                {% if user.getStatus() != 'pending' %}
                    <div class=\"data\">
                        <h5 class=\"heading\">{{ \"Last login\"|t('app') }}</h5>
                        <p class=\"value\">{% if user.lastLoginDate %}{{ user.lastLoginDate|datetime('short') }}{% else %}{{ \"Never\"|t('app') }}{% endif %}</p>
                    </div>

                    {% if user.getStatus() == 'locked' %}
                        <div class=\"data\">
                            <h5 class=\"heading\">{{ \"Last login fail\"|t('app') }}</h5>
                            <p class=\"value\">{% if user.lastInvalidLoginDate %}{{ user.lastInvalidLoginDate|datetime('short') }}{% endif %}</p>
                        </div>

                        <div class=\"data\">
                            <h5 class=\"heading\">{{ \"Login fail count\"|t('app') }}</h5>
                            <p class=\"value\">{{ user.invalidLoginCount }}</p>
                        </div>
                    {% endif %}
                {% endif %}
            </form>
        {% endif %}
    {% endif %}

    {# Give plugins a chance to add other stuff here #}
    {% hook \"cp.users.edit.details\" %}
{% endblock %}

{% js %}
    {% if user.getIsCurrent() %}
        var changeSidebarPicture = true;
    {% else %}
        var changeSidebarPicture = false;
    {% endif %}

    new Craft.ElevatedSessionForm('#userform', [
        {% if not isNewUser %}
        '#email',
        '#newPassword',
        {% endif %}
        '#admin:not(:checked)',
        '#user-groups input[type=\"checkbox\"]:not(:checked)',
        '#permissions input[type=\"checkbox\"]:not(:checked)'
    ]);
{% endjs %}
", "users/_edit", "/var/www/html/vendor/craftcms/cms/src/templates/users/_edit.html");
    }
}


/* users/_edit */
class __TwigTemplate_d2a4c4a0342c1b9cba5b507a4d0b6eb2340a4dbc1f2d8778e502cbff9e0e09a9___585392955 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 164
        return "_includes/forms/field";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "users/_edit");
        $this->parent = $this->loadTemplate("_includes/forms/field", "users/_edit", 164);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "users/_edit");
    }

    // line 167
    public function block_input($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "input");
        // line 168
        echo "                                ";
        $macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"] = $this->loadTemplate("_includes/forms", "users/_edit", 168)->unwrap();
        // line 169
        echo "                                ";
        echo craft\helpers\Html::hiddenInput("groups", "");
        echo "
                                ";
        // line 170
        if ((isset($context["assignableGroups"]) || array_key_exists("assignableGroups", $context) ? $context["assignableGroups"] : (function () { throw new RuntimeError('Variable "assignableGroups" does not exist.', 170, $this->source); })())) {
            // line 171
            echo "                                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["assignableGroups"]) || array_key_exists("assignableGroups", $context) ? $context["assignableGroups"] : (function () { throw new RuntimeError('Variable "assignableGroups" does not exist.', 171, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
                // line 172
                echo "                                        ";
                echo twig_call_macro($macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,                 // line 173
$context["group"], "name", []), "site"), "instructions" => ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 174
$context["group"], "description", [])) ? (twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "description", []), "site"))) : ("")), "name" => "groups[]", "value" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 176
$context["group"], "id", []), "checked" => twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source,                 // line 177
$context["group"], "id", []), (isset($context["currentGroupIds"]) || array_key_exists("currentGroupIds", $context) ? $context["currentGroupIds"] : (function () { throw new RuntimeError('Variable "currentGroupIds" does not exist.', 177, $this->source); })()))]], 172, $context, $this->getSourceContext());
                // line 178
                echo "
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 180
            echo "                                ";
        } else {
            // line 181
            echo "                                    <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No user groups exist yet.", "app"), "html", null, true);
            echo "</p>
                                ";
        }
        // line 183
        echo "                            ";
        craft\helpers\Template::endProfile("block", "input");
    }

    public function getTemplateName()
    {
        return "users/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1183 => 183,  1177 => 181,  1174 => 180,  1167 => 178,  1165 => 177,  1164 => 176,  1163 => 174,  1162 => 173,  1160 => 172,  1155 => 171,  1153 => 170,  1148 => 169,  1145 => 168,  1140 => 167,  1127 => 164,  671 => 389,  668 => 387,  665 => 386,  661 => 384,  658 => 383,  652 => 380,  648 => 379,  639 => 375,  635 => 374,  632 => 373,  630 => 372,  620 => 369,  616 => 368,  613 => 367,  611 => 366,  605 => 363,  601 => 362,  597 => 360,  591 => 357,  587 => 356,  584 => 355,  582 => 354,  577 => 351,  571 => 347,  556 => 345,  546 => 342,  540 => 341,  531 => 340,  529 => 339,  525 => 338,  522 => 337,  517 => 336,  500 => 335,  493 => 333,  490 => 332,  488 => 331,  481 => 329,  476 => 327,  471 => 325,  468 => 324,  465 => 323,  462 => 322,  457 => 321,  449 => 316,  445 => 315,  442 => 313,  438 => 311,  435 => 310,  432 => 309,  428 => 307,  426 => 270,  423 => 269,  421 => 268,  417 => 266,  415 => 246,  408 => 241,  406 => 240,  405 => 239,  404 => 235,  400 => 233,  398 => 232,  397 => 231,  396 => 226,  392 => 224,  390 => 223,  389 => 222,  388 => 217,  385 => 216,  383 => 215,  380 => 214,  375 => 211,  371 => 209,  369 => 207,  368 => 206,  367 => 205,  361 => 204,  355 => 202,  353 => 201,  350 => 200,  346 => 198,  344 => 196,  342 => 192,  340 => 191,  334 => 189,  332 => 188,  329 => 187,  325 => 185,  323 => 164,  320 => 163,  317 => 162,  315 => 161,  310 => 159,  307 => 158,  305 => 157,  301 => 155,  299 => 154,  294 => 152,  290 => 150,  286 => 148,  282 => 146,  280 => 145,  278 => 142,  276 => 141,  273 => 140,  270 => 139,  266 => 137,  264 => 136,  260 => 134,  258 => 131,  257 => 128,  255 => 123,  253 => 122,  249 => 120,  247 => 116,  246 => 113,  245 => 109,  244 => 107,  240 => 105,  238 => 104,  234 => 102,  232 => 98,  228 => 96,  226 => 92,  225 => 89,  224 => 85,  220 => 83,  218 => 82,  215 => 81,  210 => 79,  208 => 76,  206 => 75,  203 => 74,  201 => 73,  195 => 70,  191 => 69,  187 => 68,  182 => 67,  180 => 61,  178 => 55,  173 => 54,  160 => 47,  154 => 44,  150 => 43,  146 => 42,  138 => 37,  135 => 36,  129 => 34,  126 => 33,  121 => 32,  115 => 1,  108 => 404,  103 => 401,  101 => 400,  97 => 398,  93 => 396,  89 => 394,  86 => 393,  84 => 392,  81 => 30,  77 => 26,  75 => 25,  70 => 24,  68 => 23,  65 => 20,  62 => 18,  60 => 17,  58 => 15,  56 => 14,  54 => 12,  52 => 11,  50 => 9,  47 => 4,  45 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% if CraftEdition == CraftPro and currentUser.can('editUsers') %}
    {% set crumbs = [
        { label: \"Users\"|t('app'), url: url('users') },
    ] %}
{% endif %}

{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fileupload\\\\FileUploadAsset\") %}
{% do view.setIsDeltaRegistrationActive(true) %}

{% set requireEmailVerification = craft.app.projectConfig.get('users.requireEmailVerification') ?? true %}
{% set canAdministrateUsers = currentUser.can('administrateUsers') %}

{% if craft.app.request.isPost %}
    {% set currentGroupIds = craft.app.request.getBodyParam('groups') ?: [] %}
{% else %}
    {% set currentGroupIds = user.getGroups()|column('id') %}
{% endif %}

{% set hiddenInputs %}
    {{ csrfInput() }}
    {% if not isNewUser -%}
        {{ hiddenInput('userId', user.id) }}
    {%- endif %}
{% endset %}

{% hook \"cp.users.edit\" %}

{% block actionButton %}
    {% if not currentUser.can('registerUsers') or CraftEdition != CraftPro %}
        <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">{{ 'Save'|t('app') }}</button>
    {% else %}
        <div class=\"btngroup\">
            <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">{{ 'Save'|t('app') }}</button>
            <button type=\"button\" class=\"btn submit menubtn\" data-form=\"userform\"></button>
            <div class=\"menu\">
                <ul>
                    <li>
                        <a class=\"formsubmit\" data-redirect=\"{{ (isNewUser ? 'users/{id}' : user.getCpEditUrl())|hash }}\">
                            {{ forms.optionShortcutLabel('S') }}
                            {{ \"Save and continue editing\"|t('app') }}
                        </a>
                    </li>
                    <li><a class=\"formsubmit\" data-redirect=\"{{ 'users/new#'|hash }}\">{{ \"Save and add another\"|t('app') }}</a></li>
                </ul>
            </div>
        </div>
    {% endif %}
{% endblock %}

{% block content %}
    {% set formAttributes = {
        id: 'userform',
        method: 'post',
        'accept-charset': 'UTF-8',
        data: {
            saveshortcut: true,
            'saveshortcut-redirect':  (user.getIsCurrent() ? 'myaccount' : (CraftEdition == CraftPro and currentUser.can('editUsers') ? 'users/{id}' : 'dashboard'))|hash,
            'saveshortcut-scroll': true,
            'confirm-unload': true,
            delta: true,
        },
    } %}
    <form {{ attr(formAttributes) }}>
        {{ actionInput('users/save-user') }}
        {{ redirectInput(CraftEdition == CraftPro and currentUser.can('editUsers') ? 'users' : 'dashboard') }}
        {{ hiddenInputs }}

        <div id=\"account\" class=\"flex-fields\">
            {% include \"users/_accountfields\" %}

            {% if not isNewUser and showPhotoField %}
                {{ forms.field({
                    label: \"Photo\"|t('app'),
                    id: 'photo'
                }, include('users/_photo', {user: user}, with_context = false)) }}
            {% endif %}

            {% if isNewUser %}
                <hr>

                {{ forms.textField({
                    label: \"Email\"|t('app'),
                    id: 'email',
                    name: 'email',
                    value: user.email,
                    required: true,
                    type: 'email',
                    errors: user.getErrors('email')|merge(user.getErrors('unverifiedEmail')),
                    inputAttributes: {
                        data: {lpignore: 'true'},
                    },
                }) }}

                {{ forms.checkboxField({
                    label: 'Send an activation email now'|t('app'),
                    name: 'sendVerificationEmail',
                    checked: true
                }) }}

            {% elseif user.getIsCurrent() or canAdministrateUsers %}
                <hr>

                {{ forms.textField({
                    label: \"Email\"|t('app'),
                    warning: requireEmailVerification and not canAdministrateUsers
                        ? 'New email addresses must be verified before taking effect.'|t('app'),
                    id: 'email',
                    name: 'email',
                    value: user.email,
                    required: true,
                    type: 'email',
                    errors: user.getErrors('email')|merge(user.getErrors('unverifiedEmail')),
                    inputAttributes: {
                        data: {lpignore: 'true'},
                    },
                }) }}

                {% if user.getIsCurrent() %}
                    {{ forms.passwordField({
                        label: \"New Password\"|t('app'),
                        id: 'newPassword',
                        name: 'newPassword',
                        autocomplete: 'new-password',
                        errors: user.getErrors('newPassword'),
                        inputAttributes: {
                            data: {
                                lpignore: user.getIsCurrent() ? false : 'true',
                            }|filter,
                        },
                    }) }}

                    {% js %}
                        new Craft.PasswordInput('#newPassword');
                    {% endjs %}
                {% endif %}

                {% if currentUser.admin %}
                    {{ forms.checkboxField({
                        label: \"Require a password reset on next login\"|t('app'),
                        name: 'passwordResetRequired',
                        checked: user.passwordResetRequired
                    }) }}
                {% endif %}

            {% endif %}
        </div>

        {{ fieldsHtml|raw }}

        {% if CraftEdition == CraftPro and (currentUser.can('assignUserGroups') or currentUser.can('assignUserPermissions')) %}
            <div id=\"perms\" class=\"flex-fields hidden\">

                {% if CraftEdition == CraftPro and currentUser.can('assignUserGroups') %}
                    <fieldset>
                        <h2>{{ \"User Groups\"|t('app') }}</h2>

                        {% do view.registerDeltaName('groups') %}
                        {% set assignableGroups = craft.app.userGroups.getAssignableGroups(user) %}

                        {% embed '_includes/forms/field' with {
                            fieldId: 'user-groups',
                        } %}
                            {% block input %}
                                {% from '_includes/forms' import checkboxField %}
                                {{ hiddenInput('groups', '') }}
                                {% if assignableGroups %}
                                    {% for group in assignableGroups %}
                                        {{ checkboxField({
                                            label: group.name|t('site'),
                                            instructions: group.description ? group.description|t('site')|e,
                                            name: 'groups[]',
                                            value: group.id,
                                            checked: (group.id in currentGroupIds)
                                        }) }}
                                    {% endfor %}
                                {% else %}
                                    <p>{{ \"No user groups exist yet.\"|t('app') }}</p>
                                {% endif %}
                            {% endblock %}
                        {% endembed %}
                    </fieldset>
                {% endif %}

                {% if currentUser.can('assignUserPermissions') %}
                    <h2>{{ \"Permissions\"|t('app') }}</h2>

                    {% if currentUser.admin and CraftEdition == CraftPro %}
                        {{ forms.checkboxField({
                            label: raw(\"<b>#{'Admin'|t('app')}</b>\"),
                            name: 'admin',
                            id: 'admin',
                            checked: user.admin,
                            reverseToggle: 'permissions'
                        }) }}
                    {% endif %}

                    {% do view.registerDeltaName('permissions') %}
                    {{ hiddenInput('permissions', '') }}

                    <div id=\"permissions\" class=\"field{% if user.admin %} hidden{% endif %}\">
                        {% include \"_includes/permissions\" with {
                            userOrGroup: (user.admin ? null : user),
                            groupPermissions: user.id ? craft.app.userPermissions.getGroupPermissionsByUserId(user.id) : []
                        } only %}
                    </div>
                {% endif %}

            </div>
        {% endif %}

        {% if user.getIsCurrent() %}
            <div id=\"prefs\" class=\"flex-fields hidden\">
                {{ forms.selectField({
                    id: 'preferredLanguage',
                    name: 'preferredLanguage',
                    label: \"Language\"|t('app'),
                    instructions: 'The language that the control panel should use.'|t('app'),
                    options: localeOptions,
                    value: userLanguage,
                }) }}

                {{ forms.selectField({
                    id: 'preferredLocale',
                    name: 'preferredLocale',
                    label: \"Formatting Locale\"|t('app'),
                    instructions: 'The locale that should be used for date and number formatting.'|t('app'),
                    options: localeOptions|unshift({label: 'Same as language'|t('app'), value: ''}),
                    value: userLocale,
                }) }}

                {{ forms.selectField({
                    label: \"Week Start Day\"|t('app'),
                    id: 'weekStartDay',
                    name: 'weekStartDay',
                    options: craft.app.locale.getWeekDayNames(),
                    value: user.getPreference('weekStartDay', craft.app.config.general.defaultWeekStartDay)
                }) }}

                <hr>

                <fieldset>
                    {% embed '_includes/forms/field' with {
                        label: 'Accessibility'|t('app'),
                    } %}
                        {% set a11yDefaults = craft.app.config.general.accessibilityDefaults %}
                        {% block input %}
                            {% from '_includes/forms' import checkboxField %}
                            {{ checkboxField({
                                label: 'Use shapes to represent statuses'|t('app'),
                                name: 'useShapes',
                                id: 'useShapes',
                                checked: user.getPreference('useShapes') ?? a11yDefaults['useShapes'] ?? false,
                            }) }}
                            {{ checkboxField({
                                label: 'Underline links'|t('app'),
                                name: 'underlineLinks',
                                id: 'underlineLinks',
                                checked: user.getPreference('underlineLinks') ?? a11yDefaults['underlineLinks'] ?? false,
                            }) }}
                        {% endblock %}
                    {% endembed %}
                </fieldset>

                {% if user.admin %}
                    <fieldset>
                        {% embed '_includes/forms/field' with {
                            label: 'Development'|t('app'),
                        } %}
                            {% block input %}
                                {% from '_includes/forms' import checkboxField %}
                                {{ checkboxField({
                                    label: 'Show field handles in edit forms'|t('app'),
                                    name: 'showFieldHandles',
                                    id: 'showFieldHandles',
                                    checked: user.getPreference('showFieldHandles')
                                }) }}
                                {{ checkboxField({
                                    label: \"Show the debug toolbar on the front end\"|t('app'),
                                    name: 'enableDebugToolbarForSite',
                                    id: 'enableDebugToolbarForSite',
                                    checked: user.getPreference('enableDebugToolbarForSite')
                                }) }}
                                {{ checkboxField({
                                    label: \"Show the debug toolbar in the control panel\"|t('app'),
                                    name: 'enableDebugToolbarForCp',
                                    id: 'enableDebugToolbarForCp',
                                    checked: user.getPreference('enableDebugToolbarForCp')
                                }) }}
                                {{ checkboxField({
                                    label: 'Profile Twig templates when Dev Mode is disabled'|t('app'),
                                    name: 'profileTemplates',
                                    id: 'profileTemplates',
                                    checked: user.getPreference('profileTemplates')
                                }) }}
                                {{ checkboxField({
                                    label: 'Show full exception views when Dev Mode is disabled'|t('app'),
                                    name: 'showExceptionView',
                                    id: 'showExceptionView',
                                    checked: user.getPreference('showExceptionView')
                                }) }}
                            {% endblock %}
                        {% endembed %}
                    </fieldset>
                {% endif %}

                {% hook 'cp.users.edit.prefs' %}
            </div>
        {% endif %}

        {# Give plugins a chance to add other things here #}
        {% hook \"cp.users.edit.content\" %}

        <input type=\"submit\" class=\"hidden\">
    </form>
{% endblock %}

{% block details %}
    {% if not isNewUser %}
        {% if CraftEdition == CraftPro %}
            <form class=\"meta read-only\" method=\"post\" accept-charset=\"UTF-8\">
                {{ hiddenInputs }}
                <div class=\"data first\">
                    <h5 class=\"heading\">{{ \"Status\"|t('app') }}</h5>
                    <div class=\"value flex\">
                        <div class=\"flex-grow\"><span class=\"status {{ user.getStatus() }}\"></span> {{ statusLabel }}</div>

                        {% if actions|length %}
                            <div>
                                <button type=\"button\" id=\"action-menubtn\" class=\"btn menubtn\" data-icon=\"settings\" title=\"{{ 'Actions'|t('app') }}\" aria-label=\"{{ 'Actions'|t('app') }}\"></button>
                                <div class=\"menu\">
                                    {% for actionList in actions %}
                                        {% if not loop.first %}<hr>{% endif %}
                                        <ul>
                                            {% for actionItem in actionList %}
                                                <li><a
                                                        {%- if actionItem.id is defined %} id=\"{{ actionItem.id }}\"{% if actionItem.id == 'delete-btn' %} class=\"error\"{% endif %}{% endif %}
                                                        {%- if actionItem.action is defined %} class=\"formsubmit\" data-action=\"{{ actionItem.action }}\"{% endif -%}
                                                    >{{ actionItem.label }}</a>
                                                </li>
                                            {% endfor %}
                                        </ul>
                                    {% endfor %}
                                </div>
                                <div id=\"action-spinner\" class=\"spinner hidden\"></div>
                            </div>
                        {% endif %}
                    </div>
                </div>

                {% if user.getStatus() == 'locked' and craft.app.config.general.cooldownDuration and user.remainingCooldownTime %}
                    <div class=\"data\">
                        <h5 class=\"heading\">{{ \"Cooldown Time Remaining\"|t('app') }}</h5>
                        <p class=\"value\">{{ user.remainingCooldownTime|duration }}</p>
                    </div>
                {% endif %}

                <div class=\"data\">
                    <h5 class=\"heading\">{{ \"Registered at\"|t('app') }}</h5>
                    <p class=\"value\">{{ user.dateCreated|datetime('short') }}</p>
                </div>

                {% if user.getStatus() != 'pending' %}
                    <div class=\"data\">
                        <h5 class=\"heading\">{{ \"Last login\"|t('app') }}</h5>
                        <p class=\"value\">{% if user.lastLoginDate %}{{ user.lastLoginDate|datetime('short') }}{% else %}{{ \"Never\"|t('app') }}{% endif %}</p>
                    </div>

                    {% if user.getStatus() == 'locked' %}
                        <div class=\"data\">
                            <h5 class=\"heading\">{{ \"Last login fail\"|t('app') }}</h5>
                            <p class=\"value\">{% if user.lastInvalidLoginDate %}{{ user.lastInvalidLoginDate|datetime('short') }}{% endif %}</p>
                        </div>

                        <div class=\"data\">
                            <h5 class=\"heading\">{{ \"Login fail count\"|t('app') }}</h5>
                            <p class=\"value\">{{ user.invalidLoginCount }}</p>
                        </div>
                    {% endif %}
                {% endif %}
            </form>
        {% endif %}
    {% endif %}

    {# Give plugins a chance to add other stuff here #}
    {% hook \"cp.users.edit.details\" %}
{% endblock %}

{% js %}
    {% if user.getIsCurrent() %}
        var changeSidebarPicture = true;
    {% else %}
        var changeSidebarPicture = false;
    {% endif %}

    new Craft.ElevatedSessionForm('#userform', [
        {% if not isNewUser %}
        '#email',
        '#newPassword',
        {% endif %}
        '#admin:not(:checked)',
        '#user-groups input[type=\"checkbox\"]:not(:checked)',
        '#permissions input[type=\"checkbox\"]:not(:checked)'
    ]);
{% endjs %}
", "users/_edit", "/var/www/html/vendor/craftcms/cms/src/templates/users/_edit.html");
    }
}


/* users/_edit */
class __TwigTemplate_d2a4c4a0342c1b9cba5b507a4d0b6eb2340a4dbc1f2d8778e502cbff9e0e09a9___479911887 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 246
        return "_includes/forms/field";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "users/_edit");
        // line 249
        $context["a11yDefaults"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 249, $this->source); })()), "app", []), "config", []), "general", []), "accessibilityDefaults", []);
        // line 246
        $this->parent = $this->loadTemplate("_includes/forms/field", "users/_edit", 246);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "users/_edit");
    }

    // line 250
    public function block_input($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "input");
        // line 251
        echo "                            ";
        $macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"] = $this->loadTemplate("_includes/forms", "users/_edit", 251)->unwrap();
        // line 252
        echo "                            ";
        echo twig_call_macro($macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use shapes to represent statuses", "app"), "name" => "useShapes", "id" => "useShapes", "checked" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 256
($context["user"] ?? null), "getPreference", [0 => "useShapes"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["user"] ?? null), "getPreference", [0 => "useShapes"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["user"] ?? null), "getPreference", [0 => "useShapes"], "method")) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array")) : (false))))]], 252, $context, $this->getSourceContext());
        // line 257
        echo "
                            ";
        // line 258
        echo twig_call_macro($macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Underline links", "app"), "name" => "underlineLinks", "id" => "underlineLinks", "checked" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 262
($context["user"] ?? null), "getPreference", [0 => "underlineLinks"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["user"] ?? null), "getPreference", [0 => "underlineLinks"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["user"] ?? null), "getPreference", [0 => "underlineLinks"], "method")) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array")) : (false))))]], 258, $context, $this->getSourceContext());
        // line 263
        echo "
                        ";
        craft\helpers\Template::endProfile("block", "input");
    }

    public function getTemplateName()
    {
        return "users/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1671 => 263,  1669 => 262,  1668 => 258,  1665 => 257,  1663 => 256,  1661 => 252,  1658 => 251,  1653 => 250,  1647 => 246,  1645 => 249,  1637 => 246,  1183 => 183,  1177 => 181,  1174 => 180,  1167 => 178,  1165 => 177,  1164 => 176,  1163 => 174,  1162 => 173,  1160 => 172,  1155 => 171,  1153 => 170,  1148 => 169,  1145 => 168,  1140 => 167,  1127 => 164,  671 => 389,  668 => 387,  665 => 386,  661 => 384,  658 => 383,  652 => 380,  648 => 379,  639 => 375,  635 => 374,  632 => 373,  630 => 372,  620 => 369,  616 => 368,  613 => 367,  611 => 366,  605 => 363,  601 => 362,  597 => 360,  591 => 357,  587 => 356,  584 => 355,  582 => 354,  577 => 351,  571 => 347,  556 => 345,  546 => 342,  540 => 341,  531 => 340,  529 => 339,  525 => 338,  522 => 337,  517 => 336,  500 => 335,  493 => 333,  490 => 332,  488 => 331,  481 => 329,  476 => 327,  471 => 325,  468 => 324,  465 => 323,  462 => 322,  457 => 321,  449 => 316,  445 => 315,  442 => 313,  438 => 311,  435 => 310,  432 => 309,  428 => 307,  426 => 270,  423 => 269,  421 => 268,  417 => 266,  415 => 246,  408 => 241,  406 => 240,  405 => 239,  404 => 235,  400 => 233,  398 => 232,  397 => 231,  396 => 226,  392 => 224,  390 => 223,  389 => 222,  388 => 217,  385 => 216,  383 => 215,  380 => 214,  375 => 211,  371 => 209,  369 => 207,  368 => 206,  367 => 205,  361 => 204,  355 => 202,  353 => 201,  350 => 200,  346 => 198,  344 => 196,  342 => 192,  340 => 191,  334 => 189,  332 => 188,  329 => 187,  325 => 185,  323 => 164,  320 => 163,  317 => 162,  315 => 161,  310 => 159,  307 => 158,  305 => 157,  301 => 155,  299 => 154,  294 => 152,  290 => 150,  286 => 148,  282 => 146,  280 => 145,  278 => 142,  276 => 141,  273 => 140,  270 => 139,  266 => 137,  264 => 136,  260 => 134,  258 => 131,  257 => 128,  255 => 123,  253 => 122,  249 => 120,  247 => 116,  246 => 113,  245 => 109,  244 => 107,  240 => 105,  238 => 104,  234 => 102,  232 => 98,  228 => 96,  226 => 92,  225 => 89,  224 => 85,  220 => 83,  218 => 82,  215 => 81,  210 => 79,  208 => 76,  206 => 75,  203 => 74,  201 => 73,  195 => 70,  191 => 69,  187 => 68,  182 => 67,  180 => 61,  178 => 55,  173 => 54,  160 => 47,  154 => 44,  150 => 43,  146 => 42,  138 => 37,  135 => 36,  129 => 34,  126 => 33,  121 => 32,  115 => 1,  108 => 404,  103 => 401,  101 => 400,  97 => 398,  93 => 396,  89 => 394,  86 => 393,  84 => 392,  81 => 30,  77 => 26,  75 => 25,  70 => 24,  68 => 23,  65 => 20,  62 => 18,  60 => 17,  58 => 15,  56 => 14,  54 => 12,  52 => 11,  50 => 9,  47 => 4,  45 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% if CraftEdition == CraftPro and currentUser.can('editUsers') %}
    {% set crumbs = [
        { label: \"Users\"|t('app'), url: url('users') },
    ] %}
{% endif %}

{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fileupload\\\\FileUploadAsset\") %}
{% do view.setIsDeltaRegistrationActive(true) %}

{% set requireEmailVerification = craft.app.projectConfig.get('users.requireEmailVerification') ?? true %}
{% set canAdministrateUsers = currentUser.can('administrateUsers') %}

{% if craft.app.request.isPost %}
    {% set currentGroupIds = craft.app.request.getBodyParam('groups') ?: [] %}
{% else %}
    {% set currentGroupIds = user.getGroups()|column('id') %}
{% endif %}

{% set hiddenInputs %}
    {{ csrfInput() }}
    {% if not isNewUser -%}
        {{ hiddenInput('userId', user.id) }}
    {%- endif %}
{% endset %}

{% hook \"cp.users.edit\" %}

{% block actionButton %}
    {% if not currentUser.can('registerUsers') or CraftEdition != CraftPro %}
        <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">{{ 'Save'|t('app') }}</button>
    {% else %}
        <div class=\"btngroup\">
            <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">{{ 'Save'|t('app') }}</button>
            <button type=\"button\" class=\"btn submit menubtn\" data-form=\"userform\"></button>
            <div class=\"menu\">
                <ul>
                    <li>
                        <a class=\"formsubmit\" data-redirect=\"{{ (isNewUser ? 'users/{id}' : user.getCpEditUrl())|hash }}\">
                            {{ forms.optionShortcutLabel('S') }}
                            {{ \"Save and continue editing\"|t('app') }}
                        </a>
                    </li>
                    <li><a class=\"formsubmit\" data-redirect=\"{{ 'users/new#'|hash }}\">{{ \"Save and add another\"|t('app') }}</a></li>
                </ul>
            </div>
        </div>
    {% endif %}
{% endblock %}

{% block content %}
    {% set formAttributes = {
        id: 'userform',
        method: 'post',
        'accept-charset': 'UTF-8',
        data: {
            saveshortcut: true,
            'saveshortcut-redirect':  (user.getIsCurrent() ? 'myaccount' : (CraftEdition == CraftPro and currentUser.can('editUsers') ? 'users/{id}' : 'dashboard'))|hash,
            'saveshortcut-scroll': true,
            'confirm-unload': true,
            delta: true,
        },
    } %}
    <form {{ attr(formAttributes) }}>
        {{ actionInput('users/save-user') }}
        {{ redirectInput(CraftEdition == CraftPro and currentUser.can('editUsers') ? 'users' : 'dashboard') }}
        {{ hiddenInputs }}

        <div id=\"account\" class=\"flex-fields\">
            {% include \"users/_accountfields\" %}

            {% if not isNewUser and showPhotoField %}
                {{ forms.field({
                    label: \"Photo\"|t('app'),
                    id: 'photo'
                }, include('users/_photo', {user: user}, with_context = false)) }}
            {% endif %}

            {% if isNewUser %}
                <hr>

                {{ forms.textField({
                    label: \"Email\"|t('app'),
                    id: 'email',
                    name: 'email',
                    value: user.email,
                    required: true,
                    type: 'email',
                    errors: user.getErrors('email')|merge(user.getErrors('unverifiedEmail')),
                    inputAttributes: {
                        data: {lpignore: 'true'},
                    },
                }) }}

                {{ forms.checkboxField({
                    label: 'Send an activation email now'|t('app'),
                    name: 'sendVerificationEmail',
                    checked: true
                }) }}

            {% elseif user.getIsCurrent() or canAdministrateUsers %}
                <hr>

                {{ forms.textField({
                    label: \"Email\"|t('app'),
                    warning: requireEmailVerification and not canAdministrateUsers
                        ? 'New email addresses must be verified before taking effect.'|t('app'),
                    id: 'email',
                    name: 'email',
                    value: user.email,
                    required: true,
                    type: 'email',
                    errors: user.getErrors('email')|merge(user.getErrors('unverifiedEmail')),
                    inputAttributes: {
                        data: {lpignore: 'true'},
                    },
                }) }}

                {% if user.getIsCurrent() %}
                    {{ forms.passwordField({
                        label: \"New Password\"|t('app'),
                        id: 'newPassword',
                        name: 'newPassword',
                        autocomplete: 'new-password',
                        errors: user.getErrors('newPassword'),
                        inputAttributes: {
                            data: {
                                lpignore: user.getIsCurrent() ? false : 'true',
                            }|filter,
                        },
                    }) }}

                    {% js %}
                        new Craft.PasswordInput('#newPassword');
                    {% endjs %}
                {% endif %}

                {% if currentUser.admin %}
                    {{ forms.checkboxField({
                        label: \"Require a password reset on next login\"|t('app'),
                        name: 'passwordResetRequired',
                        checked: user.passwordResetRequired
                    }) }}
                {% endif %}

            {% endif %}
        </div>

        {{ fieldsHtml|raw }}

        {% if CraftEdition == CraftPro and (currentUser.can('assignUserGroups') or currentUser.can('assignUserPermissions')) %}
            <div id=\"perms\" class=\"flex-fields hidden\">

                {% if CraftEdition == CraftPro and currentUser.can('assignUserGroups') %}
                    <fieldset>
                        <h2>{{ \"User Groups\"|t('app') }}</h2>

                        {% do view.registerDeltaName('groups') %}
                        {% set assignableGroups = craft.app.userGroups.getAssignableGroups(user) %}

                        {% embed '_includes/forms/field' with {
                            fieldId: 'user-groups',
                        } %}
                            {% block input %}
                                {% from '_includes/forms' import checkboxField %}
                                {{ hiddenInput('groups', '') }}
                                {% if assignableGroups %}
                                    {% for group in assignableGroups %}
                                        {{ checkboxField({
                                            label: group.name|t('site'),
                                            instructions: group.description ? group.description|t('site')|e,
                                            name: 'groups[]',
                                            value: group.id,
                                            checked: (group.id in currentGroupIds)
                                        }) }}
                                    {% endfor %}
                                {% else %}
                                    <p>{{ \"No user groups exist yet.\"|t('app') }}</p>
                                {% endif %}
                            {% endblock %}
                        {% endembed %}
                    </fieldset>
                {% endif %}

                {% if currentUser.can('assignUserPermissions') %}
                    <h2>{{ \"Permissions\"|t('app') }}</h2>

                    {% if currentUser.admin and CraftEdition == CraftPro %}
                        {{ forms.checkboxField({
                            label: raw(\"<b>#{'Admin'|t('app')}</b>\"),
                            name: 'admin',
                            id: 'admin',
                            checked: user.admin,
                            reverseToggle: 'permissions'
                        }) }}
                    {% endif %}

                    {% do view.registerDeltaName('permissions') %}
                    {{ hiddenInput('permissions', '') }}

                    <div id=\"permissions\" class=\"field{% if user.admin %} hidden{% endif %}\">
                        {% include \"_includes/permissions\" with {
                            userOrGroup: (user.admin ? null : user),
                            groupPermissions: user.id ? craft.app.userPermissions.getGroupPermissionsByUserId(user.id) : []
                        } only %}
                    </div>
                {% endif %}

            </div>
        {% endif %}

        {% if user.getIsCurrent() %}
            <div id=\"prefs\" class=\"flex-fields hidden\">
                {{ forms.selectField({
                    id: 'preferredLanguage',
                    name: 'preferredLanguage',
                    label: \"Language\"|t('app'),
                    instructions: 'The language that the control panel should use.'|t('app'),
                    options: localeOptions,
                    value: userLanguage,
                }) }}

                {{ forms.selectField({
                    id: 'preferredLocale',
                    name: 'preferredLocale',
                    label: \"Formatting Locale\"|t('app'),
                    instructions: 'The locale that should be used for date and number formatting.'|t('app'),
                    options: localeOptions|unshift({label: 'Same as language'|t('app'), value: ''}),
                    value: userLocale,
                }) }}

                {{ forms.selectField({
                    label: \"Week Start Day\"|t('app'),
                    id: 'weekStartDay',
                    name: 'weekStartDay',
                    options: craft.app.locale.getWeekDayNames(),
                    value: user.getPreference('weekStartDay', craft.app.config.general.defaultWeekStartDay)
                }) }}

                <hr>

                <fieldset>
                    {% embed '_includes/forms/field' with {
                        label: 'Accessibility'|t('app'),
                    } %}
                        {% set a11yDefaults = craft.app.config.general.accessibilityDefaults %}
                        {% block input %}
                            {% from '_includes/forms' import checkboxField %}
                            {{ checkboxField({
                                label: 'Use shapes to represent statuses'|t('app'),
                                name: 'useShapes',
                                id: 'useShapes',
                                checked: user.getPreference('useShapes') ?? a11yDefaults['useShapes'] ?? false,
                            }) }}
                            {{ checkboxField({
                                label: 'Underline links'|t('app'),
                                name: 'underlineLinks',
                                id: 'underlineLinks',
                                checked: user.getPreference('underlineLinks') ?? a11yDefaults['underlineLinks'] ?? false,
                            }) }}
                        {% endblock %}
                    {% endembed %}
                </fieldset>

                {% if user.admin %}
                    <fieldset>
                        {% embed '_includes/forms/field' with {
                            label: 'Development'|t('app'),
                        } %}
                            {% block input %}
                                {% from '_includes/forms' import checkboxField %}
                                {{ checkboxField({
                                    label: 'Show field handles in edit forms'|t('app'),
                                    name: 'showFieldHandles',
                                    id: 'showFieldHandles',
                                    checked: user.getPreference('showFieldHandles')
                                }) }}
                                {{ checkboxField({
                                    label: \"Show the debug toolbar on the front end\"|t('app'),
                                    name: 'enableDebugToolbarForSite',
                                    id: 'enableDebugToolbarForSite',
                                    checked: user.getPreference('enableDebugToolbarForSite')
                                }) }}
                                {{ checkboxField({
                                    label: \"Show the debug toolbar in the control panel\"|t('app'),
                                    name: 'enableDebugToolbarForCp',
                                    id: 'enableDebugToolbarForCp',
                                    checked: user.getPreference('enableDebugToolbarForCp')
                                }) }}
                                {{ checkboxField({
                                    label: 'Profile Twig templates when Dev Mode is disabled'|t('app'),
                                    name: 'profileTemplates',
                                    id: 'profileTemplates',
                                    checked: user.getPreference('profileTemplates')
                                }) }}
                                {{ checkboxField({
                                    label: 'Show full exception views when Dev Mode is disabled'|t('app'),
                                    name: 'showExceptionView',
                                    id: 'showExceptionView',
                                    checked: user.getPreference('showExceptionView')
                                }) }}
                            {% endblock %}
                        {% endembed %}
                    </fieldset>
                {% endif %}

                {% hook 'cp.users.edit.prefs' %}
            </div>
        {% endif %}

        {# Give plugins a chance to add other things here #}
        {% hook \"cp.users.edit.content\" %}

        <input type=\"submit\" class=\"hidden\">
    </form>
{% endblock %}

{% block details %}
    {% if not isNewUser %}
        {% if CraftEdition == CraftPro %}
            <form class=\"meta read-only\" method=\"post\" accept-charset=\"UTF-8\">
                {{ hiddenInputs }}
                <div class=\"data first\">
                    <h5 class=\"heading\">{{ \"Status\"|t('app') }}</h5>
                    <div class=\"value flex\">
                        <div class=\"flex-grow\"><span class=\"status {{ user.getStatus() }}\"></span> {{ statusLabel }}</div>

                        {% if actions|length %}
                            <div>
                                <button type=\"button\" id=\"action-menubtn\" class=\"btn menubtn\" data-icon=\"settings\" title=\"{{ 'Actions'|t('app') }}\" aria-label=\"{{ 'Actions'|t('app') }}\"></button>
                                <div class=\"menu\">
                                    {% for actionList in actions %}
                                        {% if not loop.first %}<hr>{% endif %}
                                        <ul>
                                            {% for actionItem in actionList %}
                                                <li><a
                                                        {%- if actionItem.id is defined %} id=\"{{ actionItem.id }}\"{% if actionItem.id == 'delete-btn' %} class=\"error\"{% endif %}{% endif %}
                                                        {%- if actionItem.action is defined %} class=\"formsubmit\" data-action=\"{{ actionItem.action }}\"{% endif -%}
                                                    >{{ actionItem.label }}</a>
                                                </li>
                                            {% endfor %}
                                        </ul>
                                    {% endfor %}
                                </div>
                                <div id=\"action-spinner\" class=\"spinner hidden\"></div>
                            </div>
                        {% endif %}
                    </div>
                </div>

                {% if user.getStatus() == 'locked' and craft.app.config.general.cooldownDuration and user.remainingCooldownTime %}
                    <div class=\"data\">
                        <h5 class=\"heading\">{{ \"Cooldown Time Remaining\"|t('app') }}</h5>
                        <p class=\"value\">{{ user.remainingCooldownTime|duration }}</p>
                    </div>
                {% endif %}

                <div class=\"data\">
                    <h5 class=\"heading\">{{ \"Registered at\"|t('app') }}</h5>
                    <p class=\"value\">{{ user.dateCreated|datetime('short') }}</p>
                </div>

                {% if user.getStatus() != 'pending' %}
                    <div class=\"data\">
                        <h5 class=\"heading\">{{ \"Last login\"|t('app') }}</h5>
                        <p class=\"value\">{% if user.lastLoginDate %}{{ user.lastLoginDate|datetime('short') }}{% else %}{{ \"Never\"|t('app') }}{% endif %}</p>
                    </div>

                    {% if user.getStatus() == 'locked' %}
                        <div class=\"data\">
                            <h5 class=\"heading\">{{ \"Last login fail\"|t('app') }}</h5>
                            <p class=\"value\">{% if user.lastInvalidLoginDate %}{{ user.lastInvalidLoginDate|datetime('short') }}{% endif %}</p>
                        </div>

                        <div class=\"data\">
                            <h5 class=\"heading\">{{ \"Login fail count\"|t('app') }}</h5>
                            <p class=\"value\">{{ user.invalidLoginCount }}</p>
                        </div>
                    {% endif %}
                {% endif %}
            </form>
        {% endif %}
    {% endif %}

    {# Give plugins a chance to add other stuff here #}
    {% hook \"cp.users.edit.details\" %}
{% endblock %}

{% js %}
    {% if user.getIsCurrent() %}
        var changeSidebarPicture = true;
    {% else %}
        var changeSidebarPicture = false;
    {% endif %}

    new Craft.ElevatedSessionForm('#userform', [
        {% if not isNewUser %}
        '#email',
        '#newPassword',
        {% endif %}
        '#admin:not(:checked)',
        '#user-groups input[type=\"checkbox\"]:not(:checked)',
        '#permissions input[type=\"checkbox\"]:not(:checked)'
    ]);
{% endjs %}
", "users/_edit", "/var/www/html/vendor/craftcms/cms/src/templates/users/_edit.html");
    }
}


/* users/_edit */
class __TwigTemplate_d2a4c4a0342c1b9cba5b507a4d0b6eb2340a4dbc1f2d8778e502cbff9e0e09a9___1340876126 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 270
        return "_includes/forms/field";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "users/_edit");
        $this->parent = $this->loadTemplate("_includes/forms/field", "users/_edit", 270);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "users/_edit");
    }

    // line 273
    public function block_input($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "input");
        // line 274
        echo "                                ";
        $macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"] = $this->loadTemplate("_includes/forms", "users/_edit", 274)->unwrap();
        // line 275
        echo "                                ";
        echo twig_call_macro($macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show field handles in edit forms", "app"), "name" => "showFieldHandles", "id" => "showFieldHandles", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 279
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 279, $this->source); })()), "getPreference", [0 => "showFieldHandles"], "method")]], 275, $context, $this->getSourceContext());
        // line 280
        echo "
                                ";
        // line 281
        echo twig_call_macro($macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show the debug toolbar on the front end", "app"), "name" => "enableDebugToolbarForSite", "id" => "enableDebugToolbarForSite", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 285
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 285, $this->source); })()), "getPreference", [0 => "enableDebugToolbarForSite"], "method")]], 281, $context, $this->getSourceContext());
        // line 286
        echo "
                                ";
        // line 287
        echo twig_call_macro($macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show the debug toolbar in the control panel", "app"), "name" => "enableDebugToolbarForCp", "id" => "enableDebugToolbarForCp", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 291
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 291, $this->source); })()), "getPreference", [0 => "enableDebugToolbarForCp"], "method")]], 287, $context, $this->getSourceContext());
        // line 292
        echo "
                                ";
        // line 293
        echo twig_call_macro($macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Profile Twig templates when Dev Mode is disabled", "app"), "name" => "profileTemplates", "id" => "profileTemplates", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 297
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 297, $this->source); })()), "getPreference", [0 => "profileTemplates"], "method")]], 293, $context, $this->getSourceContext());
        // line 298
        echo "
                                ";
        // line 299
        echo twig_call_macro($macros["__internal_ff0881b13a7540a189c9a12da309097d59220aca5fc9d78e2a885af52cb7cbf7"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show full exception views when Dev Mode is disabled", "app"), "name" => "showExceptionView", "id" => "showExceptionView", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 303
(isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 303, $this->source); })()), "getPreference", [0 => "showExceptionView"], "method")]], 299, $context, $this->getSourceContext());
        // line 304
        echo "
                            ";
        craft\helpers\Template::endProfile("block", "input");
    }

    public function getTemplateName()
    {
        return "users/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  2175 => 304,  2173 => 303,  2172 => 299,  2169 => 298,  2167 => 297,  2166 => 293,  2163 => 292,  2161 => 291,  2160 => 287,  2157 => 286,  2155 => 285,  2154 => 281,  2151 => 280,  2149 => 279,  2147 => 275,  2144 => 274,  2139 => 273,  2126 => 270,  1671 => 263,  1669 => 262,  1668 => 258,  1665 => 257,  1663 => 256,  1661 => 252,  1658 => 251,  1653 => 250,  1647 => 246,  1645 => 249,  1637 => 246,  1183 => 183,  1177 => 181,  1174 => 180,  1167 => 178,  1165 => 177,  1164 => 176,  1163 => 174,  1162 => 173,  1160 => 172,  1155 => 171,  1153 => 170,  1148 => 169,  1145 => 168,  1140 => 167,  1127 => 164,  671 => 389,  668 => 387,  665 => 386,  661 => 384,  658 => 383,  652 => 380,  648 => 379,  639 => 375,  635 => 374,  632 => 373,  630 => 372,  620 => 369,  616 => 368,  613 => 367,  611 => 366,  605 => 363,  601 => 362,  597 => 360,  591 => 357,  587 => 356,  584 => 355,  582 => 354,  577 => 351,  571 => 347,  556 => 345,  546 => 342,  540 => 341,  531 => 340,  529 => 339,  525 => 338,  522 => 337,  517 => 336,  500 => 335,  493 => 333,  490 => 332,  488 => 331,  481 => 329,  476 => 327,  471 => 325,  468 => 324,  465 => 323,  462 => 322,  457 => 321,  449 => 316,  445 => 315,  442 => 313,  438 => 311,  435 => 310,  432 => 309,  428 => 307,  426 => 270,  423 => 269,  421 => 268,  417 => 266,  415 => 246,  408 => 241,  406 => 240,  405 => 239,  404 => 235,  400 => 233,  398 => 232,  397 => 231,  396 => 226,  392 => 224,  390 => 223,  389 => 222,  388 => 217,  385 => 216,  383 => 215,  380 => 214,  375 => 211,  371 => 209,  369 => 207,  368 => 206,  367 => 205,  361 => 204,  355 => 202,  353 => 201,  350 => 200,  346 => 198,  344 => 196,  342 => 192,  340 => 191,  334 => 189,  332 => 188,  329 => 187,  325 => 185,  323 => 164,  320 => 163,  317 => 162,  315 => 161,  310 => 159,  307 => 158,  305 => 157,  301 => 155,  299 => 154,  294 => 152,  290 => 150,  286 => 148,  282 => 146,  280 => 145,  278 => 142,  276 => 141,  273 => 140,  270 => 139,  266 => 137,  264 => 136,  260 => 134,  258 => 131,  257 => 128,  255 => 123,  253 => 122,  249 => 120,  247 => 116,  246 => 113,  245 => 109,  244 => 107,  240 => 105,  238 => 104,  234 => 102,  232 => 98,  228 => 96,  226 => 92,  225 => 89,  224 => 85,  220 => 83,  218 => 82,  215 => 81,  210 => 79,  208 => 76,  206 => 75,  203 => 74,  201 => 73,  195 => 70,  191 => 69,  187 => 68,  182 => 67,  180 => 61,  178 => 55,  173 => 54,  160 => 47,  154 => 44,  150 => 43,  146 => 42,  138 => 37,  135 => 36,  129 => 34,  126 => 33,  121 => 32,  115 => 1,  108 => 404,  103 => 401,  101 => 400,  97 => 398,  93 => 396,  89 => 394,  86 => 393,  84 => 392,  81 => 30,  77 => 26,  75 => 25,  70 => 24,  68 => 23,  65 => 20,  62 => 18,  60 => 17,  58 => 15,  56 => 14,  54 => 12,  52 => 11,  50 => 9,  47 => 4,  45 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% if CraftEdition == CraftPro and currentUser.can('editUsers') %}
    {% set crumbs = [
        { label: \"Users\"|t('app'), url: url('users') },
    ] %}
{% endif %}

{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fileupload\\\\FileUploadAsset\") %}
{% do view.setIsDeltaRegistrationActive(true) %}

{% set requireEmailVerification = craft.app.projectConfig.get('users.requireEmailVerification') ?? true %}
{% set canAdministrateUsers = currentUser.can('administrateUsers') %}

{% if craft.app.request.isPost %}
    {% set currentGroupIds = craft.app.request.getBodyParam('groups') ?: [] %}
{% else %}
    {% set currentGroupIds = user.getGroups()|column('id') %}
{% endif %}

{% set hiddenInputs %}
    {{ csrfInput() }}
    {% if not isNewUser -%}
        {{ hiddenInput('userId', user.id) }}
    {%- endif %}
{% endset %}

{% hook \"cp.users.edit\" %}

{% block actionButton %}
    {% if not currentUser.can('registerUsers') or CraftEdition != CraftPro %}
        <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">{{ 'Save'|t('app') }}</button>
    {% else %}
        <div class=\"btngroup\">
            <button type=\"button\" class=\"btn submit formsubmit\" data-form=\"userform\">{{ 'Save'|t('app') }}</button>
            <button type=\"button\" class=\"btn submit menubtn\" data-form=\"userform\"></button>
            <div class=\"menu\">
                <ul>
                    <li>
                        <a class=\"formsubmit\" data-redirect=\"{{ (isNewUser ? 'users/{id}' : user.getCpEditUrl())|hash }}\">
                            {{ forms.optionShortcutLabel('S') }}
                            {{ \"Save and continue editing\"|t('app') }}
                        </a>
                    </li>
                    <li><a class=\"formsubmit\" data-redirect=\"{{ 'users/new#'|hash }}\">{{ \"Save and add another\"|t('app') }}</a></li>
                </ul>
            </div>
        </div>
    {% endif %}
{% endblock %}

{% block content %}
    {% set formAttributes = {
        id: 'userform',
        method: 'post',
        'accept-charset': 'UTF-8',
        data: {
            saveshortcut: true,
            'saveshortcut-redirect':  (user.getIsCurrent() ? 'myaccount' : (CraftEdition == CraftPro and currentUser.can('editUsers') ? 'users/{id}' : 'dashboard'))|hash,
            'saveshortcut-scroll': true,
            'confirm-unload': true,
            delta: true,
        },
    } %}
    <form {{ attr(formAttributes) }}>
        {{ actionInput('users/save-user') }}
        {{ redirectInput(CraftEdition == CraftPro and currentUser.can('editUsers') ? 'users' : 'dashboard') }}
        {{ hiddenInputs }}

        <div id=\"account\" class=\"flex-fields\">
            {% include \"users/_accountfields\" %}

            {% if not isNewUser and showPhotoField %}
                {{ forms.field({
                    label: \"Photo\"|t('app'),
                    id: 'photo'
                }, include('users/_photo', {user: user}, with_context = false)) }}
            {% endif %}

            {% if isNewUser %}
                <hr>

                {{ forms.textField({
                    label: \"Email\"|t('app'),
                    id: 'email',
                    name: 'email',
                    value: user.email,
                    required: true,
                    type: 'email',
                    errors: user.getErrors('email')|merge(user.getErrors('unverifiedEmail')),
                    inputAttributes: {
                        data: {lpignore: 'true'},
                    },
                }) }}

                {{ forms.checkboxField({
                    label: 'Send an activation email now'|t('app'),
                    name: 'sendVerificationEmail',
                    checked: true
                }) }}

            {% elseif user.getIsCurrent() or canAdministrateUsers %}
                <hr>

                {{ forms.textField({
                    label: \"Email\"|t('app'),
                    warning: requireEmailVerification and not canAdministrateUsers
                        ? 'New email addresses must be verified before taking effect.'|t('app'),
                    id: 'email',
                    name: 'email',
                    value: user.email,
                    required: true,
                    type: 'email',
                    errors: user.getErrors('email')|merge(user.getErrors('unverifiedEmail')),
                    inputAttributes: {
                        data: {lpignore: 'true'},
                    },
                }) }}

                {% if user.getIsCurrent() %}
                    {{ forms.passwordField({
                        label: \"New Password\"|t('app'),
                        id: 'newPassword',
                        name: 'newPassword',
                        autocomplete: 'new-password',
                        errors: user.getErrors('newPassword'),
                        inputAttributes: {
                            data: {
                                lpignore: user.getIsCurrent() ? false : 'true',
                            }|filter,
                        },
                    }) }}

                    {% js %}
                        new Craft.PasswordInput('#newPassword');
                    {% endjs %}
                {% endif %}

                {% if currentUser.admin %}
                    {{ forms.checkboxField({
                        label: \"Require a password reset on next login\"|t('app'),
                        name: 'passwordResetRequired',
                        checked: user.passwordResetRequired
                    }) }}
                {% endif %}

            {% endif %}
        </div>

        {{ fieldsHtml|raw }}

        {% if CraftEdition == CraftPro and (currentUser.can('assignUserGroups') or currentUser.can('assignUserPermissions')) %}
            <div id=\"perms\" class=\"flex-fields hidden\">

                {% if CraftEdition == CraftPro and currentUser.can('assignUserGroups') %}
                    <fieldset>
                        <h2>{{ \"User Groups\"|t('app') }}</h2>

                        {% do view.registerDeltaName('groups') %}
                        {% set assignableGroups = craft.app.userGroups.getAssignableGroups(user) %}

                        {% embed '_includes/forms/field' with {
                            fieldId: 'user-groups',
                        } %}
                            {% block input %}
                                {% from '_includes/forms' import checkboxField %}
                                {{ hiddenInput('groups', '') }}
                                {% if assignableGroups %}
                                    {% for group in assignableGroups %}
                                        {{ checkboxField({
                                            label: group.name|t('site'),
                                            instructions: group.description ? group.description|t('site')|e,
                                            name: 'groups[]',
                                            value: group.id,
                                            checked: (group.id in currentGroupIds)
                                        }) }}
                                    {% endfor %}
                                {% else %}
                                    <p>{{ \"No user groups exist yet.\"|t('app') }}</p>
                                {% endif %}
                            {% endblock %}
                        {% endembed %}
                    </fieldset>
                {% endif %}

                {% if currentUser.can('assignUserPermissions') %}
                    <h2>{{ \"Permissions\"|t('app') }}</h2>

                    {% if currentUser.admin and CraftEdition == CraftPro %}
                        {{ forms.checkboxField({
                            label: raw(\"<b>#{'Admin'|t('app')}</b>\"),
                            name: 'admin',
                            id: 'admin',
                            checked: user.admin,
                            reverseToggle: 'permissions'
                        }) }}
                    {% endif %}

                    {% do view.registerDeltaName('permissions') %}
                    {{ hiddenInput('permissions', '') }}

                    <div id=\"permissions\" class=\"field{% if user.admin %} hidden{% endif %}\">
                        {% include \"_includes/permissions\" with {
                            userOrGroup: (user.admin ? null : user),
                            groupPermissions: user.id ? craft.app.userPermissions.getGroupPermissionsByUserId(user.id) : []
                        } only %}
                    </div>
                {% endif %}

            </div>
        {% endif %}

        {% if user.getIsCurrent() %}
            <div id=\"prefs\" class=\"flex-fields hidden\">
                {{ forms.selectField({
                    id: 'preferredLanguage',
                    name: 'preferredLanguage',
                    label: \"Language\"|t('app'),
                    instructions: 'The language that the control panel should use.'|t('app'),
                    options: localeOptions,
                    value: userLanguage,
                }) }}

                {{ forms.selectField({
                    id: 'preferredLocale',
                    name: 'preferredLocale',
                    label: \"Formatting Locale\"|t('app'),
                    instructions: 'The locale that should be used for date and number formatting.'|t('app'),
                    options: localeOptions|unshift({label: 'Same as language'|t('app'), value: ''}),
                    value: userLocale,
                }) }}

                {{ forms.selectField({
                    label: \"Week Start Day\"|t('app'),
                    id: 'weekStartDay',
                    name: 'weekStartDay',
                    options: craft.app.locale.getWeekDayNames(),
                    value: user.getPreference('weekStartDay', craft.app.config.general.defaultWeekStartDay)
                }) }}

                <hr>

                <fieldset>
                    {% embed '_includes/forms/field' with {
                        label: 'Accessibility'|t('app'),
                    } %}
                        {% set a11yDefaults = craft.app.config.general.accessibilityDefaults %}
                        {% block input %}
                            {% from '_includes/forms' import checkboxField %}
                            {{ checkboxField({
                                label: 'Use shapes to represent statuses'|t('app'),
                                name: 'useShapes',
                                id: 'useShapes',
                                checked: user.getPreference('useShapes') ?? a11yDefaults['useShapes'] ?? false,
                            }) }}
                            {{ checkboxField({
                                label: 'Underline links'|t('app'),
                                name: 'underlineLinks',
                                id: 'underlineLinks',
                                checked: user.getPreference('underlineLinks') ?? a11yDefaults['underlineLinks'] ?? false,
                            }) }}
                        {% endblock %}
                    {% endembed %}
                </fieldset>

                {% if user.admin %}
                    <fieldset>
                        {% embed '_includes/forms/field' with {
                            label: 'Development'|t('app'),
                        } %}
                            {% block input %}
                                {% from '_includes/forms' import checkboxField %}
                                {{ checkboxField({
                                    label: 'Show field handles in edit forms'|t('app'),
                                    name: 'showFieldHandles',
                                    id: 'showFieldHandles',
                                    checked: user.getPreference('showFieldHandles')
                                }) }}
                                {{ checkboxField({
                                    label: \"Show the debug toolbar on the front end\"|t('app'),
                                    name: 'enableDebugToolbarForSite',
                                    id: 'enableDebugToolbarForSite',
                                    checked: user.getPreference('enableDebugToolbarForSite')
                                }) }}
                                {{ checkboxField({
                                    label: \"Show the debug toolbar in the control panel\"|t('app'),
                                    name: 'enableDebugToolbarForCp',
                                    id: 'enableDebugToolbarForCp',
                                    checked: user.getPreference('enableDebugToolbarForCp')
                                }) }}
                                {{ checkboxField({
                                    label: 'Profile Twig templates when Dev Mode is disabled'|t('app'),
                                    name: 'profileTemplates',
                                    id: 'profileTemplates',
                                    checked: user.getPreference('profileTemplates')
                                }) }}
                                {{ checkboxField({
                                    label: 'Show full exception views when Dev Mode is disabled'|t('app'),
                                    name: 'showExceptionView',
                                    id: 'showExceptionView',
                                    checked: user.getPreference('showExceptionView')
                                }) }}
                            {% endblock %}
                        {% endembed %}
                    </fieldset>
                {% endif %}

                {% hook 'cp.users.edit.prefs' %}
            </div>
        {% endif %}

        {# Give plugins a chance to add other things here #}
        {% hook \"cp.users.edit.content\" %}

        <input type=\"submit\" class=\"hidden\">
    </form>
{% endblock %}

{% block details %}
    {% if not isNewUser %}
        {% if CraftEdition == CraftPro %}
            <form class=\"meta read-only\" method=\"post\" accept-charset=\"UTF-8\">
                {{ hiddenInputs }}
                <div class=\"data first\">
                    <h5 class=\"heading\">{{ \"Status\"|t('app') }}</h5>
                    <div class=\"value flex\">
                        <div class=\"flex-grow\"><span class=\"status {{ user.getStatus() }}\"></span> {{ statusLabel }}</div>

                        {% if actions|length %}
                            <div>
                                <button type=\"button\" id=\"action-menubtn\" class=\"btn menubtn\" data-icon=\"settings\" title=\"{{ 'Actions'|t('app') }}\" aria-label=\"{{ 'Actions'|t('app') }}\"></button>
                                <div class=\"menu\">
                                    {% for actionList in actions %}
                                        {% if not loop.first %}<hr>{% endif %}
                                        <ul>
                                            {% for actionItem in actionList %}
                                                <li><a
                                                        {%- if actionItem.id is defined %} id=\"{{ actionItem.id }}\"{% if actionItem.id == 'delete-btn' %} class=\"error\"{% endif %}{% endif %}
                                                        {%- if actionItem.action is defined %} class=\"formsubmit\" data-action=\"{{ actionItem.action }}\"{% endif -%}
                                                    >{{ actionItem.label }}</a>
                                                </li>
                                            {% endfor %}
                                        </ul>
                                    {% endfor %}
                                </div>
                                <div id=\"action-spinner\" class=\"spinner hidden\"></div>
                            </div>
                        {% endif %}
                    </div>
                </div>

                {% if user.getStatus() == 'locked' and craft.app.config.general.cooldownDuration and user.remainingCooldownTime %}
                    <div class=\"data\">
                        <h5 class=\"heading\">{{ \"Cooldown Time Remaining\"|t('app') }}</h5>
                        <p class=\"value\">{{ user.remainingCooldownTime|duration }}</p>
                    </div>
                {% endif %}

                <div class=\"data\">
                    <h5 class=\"heading\">{{ \"Registered at\"|t('app') }}</h5>
                    <p class=\"value\">{{ user.dateCreated|datetime('short') }}</p>
                </div>

                {% if user.getStatus() != 'pending' %}
                    <div class=\"data\">
                        <h5 class=\"heading\">{{ \"Last login\"|t('app') }}</h5>
                        <p class=\"value\">{% if user.lastLoginDate %}{{ user.lastLoginDate|datetime('short') }}{% else %}{{ \"Never\"|t('app') }}{% endif %}</p>
                    </div>

                    {% if user.getStatus() == 'locked' %}
                        <div class=\"data\">
                            <h5 class=\"heading\">{{ \"Last login fail\"|t('app') }}</h5>
                            <p class=\"value\">{% if user.lastInvalidLoginDate %}{{ user.lastInvalidLoginDate|datetime('short') }}{% endif %}</p>
                        </div>

                        <div class=\"data\">
                            <h5 class=\"heading\">{{ \"Login fail count\"|t('app') }}</h5>
                            <p class=\"value\">{{ user.invalidLoginCount }}</p>
                        </div>
                    {% endif %}
                {% endif %}
            </form>
        {% endif %}
    {% endif %}

    {# Give plugins a chance to add other stuff here #}
    {% hook \"cp.users.edit.details\" %}
{% endblock %}

{% js %}
    {% if user.getIsCurrent() %}
        var changeSidebarPicture = true;
    {% else %}
        var changeSidebarPicture = false;
    {% endif %}

    new Craft.ElevatedSessionForm('#userform', [
        {% if not isNewUser %}
        '#email',
        '#newPassword',
        {% endif %}
        '#admin:not(:checked)',
        '#user-groups input[type=\"checkbox\"]:not(:checked)',
        '#permissions input[type=\"checkbox\"]:not(:checked)'
    ]);
{% endjs %}
", "users/_edit", "/var/www/html/vendor/craftcms/cms/src/templates/users/_edit.html");
    }
}
