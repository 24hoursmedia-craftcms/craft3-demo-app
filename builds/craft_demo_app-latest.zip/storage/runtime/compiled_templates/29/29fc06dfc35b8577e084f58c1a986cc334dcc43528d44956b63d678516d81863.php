<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/checkbox */
class __TwigTemplate_6d93cf73a1dcdc53a38f35ca84d20f50531e343efe4b4d7beddb26024152c8be extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/checkbox");
        // line 1
        ob_start();
        // line 2
        echo "
";
        // line 3
        $context["id"] = (($context["id"]) ?? (("checkbox" . twig_random($this->env))));
        // line 4
        $context["label"] = (($context["checkboxLabel"]) ?? ((($context["label"]) ?? (null))));
        // line 5
        echo "
";
        // line 6
        $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 7
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 7, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass(((        // line 8
$context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((((        // line 9
$context["toggle"]) ?? ((($context["reverseToggle"]) ?? (false))))) ? ("fieldtoggle") : (null)), 1 => "checkbox"])), "checked" => (((        // line 12
$context["checked"]) ?? (false)) && (isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 12, $this->source); })())), "autofocus" => (((        // line 13
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 13, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method")), "disabled" => ((((        // line 14
$context["disabled"]) ?? (false))) ? (true) : (false)), "aria" => ["describedby" => ((        // line 16
$context["instructionsId"]) ?? (false))], "data" => ["target" => ((        // line 19
$context["toggle"]) ?? (false)), "reverse-target" => ((        // line 20
$context["reverseToggle"]) ?? (false))]], ((        // line 22
$context["inputAttributes"]) ?? ([])), true);
        // line 23
        echo "
";
        // line 24
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 25
            $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 25, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 27
        echo "
";
        // line 28
        if (((isset($context["name"]) || array_key_exists("name", $context)) && ((twig_length_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 28, $this->source); })())) < 3) || (twig_slice($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 28, $this->source); })()),  -2) != "[]")))) {
            // line 29
            echo "    ";
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 29, $this->source); })()), "");
            echo "
";
        }
        // line 31
        echo "
";
        // line 32
        echo craft\helpers\Html::input("checkbox", (($context["name"]) ?? (null)), (($context["value"]) ?? (1)), (isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 32, $this->source); })()));
        echo "

<label for=\"";
        // line 34
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 34, $this->source); })()), "html", null, true);
        echo "\">
    ";
        // line 35
        echo twig_escape_filter($this->env, (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 35, $this->source); })()), "html", null, true);
        echo "
    ";
        // line 36
        if ((($context["info"]) ?? (null))) {
            // line 37
            echo "        <span class=\"info\">";
            echo $this->extensions['craft\web\twig\Extension']->markdownFilter((isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new RuntimeError('Variable "info" does not exist.', 37, $this->source); })()));
            echo "</span>
    ";
        }
        // line 39
        echo "</label>

";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        craft\helpers\Template::endProfile("template", "_includes/forms/checkbox");
    }

    public function getTemplateName()
    {
        return "_includes/forms/checkbox";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 39,  99 => 37,  97 => 36,  93 => 35,  89 => 34,  84 => 32,  81 => 31,  75 => 29,  73 => 28,  70 => 27,  67 => 25,  65 => 24,  62 => 23,  60 => 22,  59 => 20,  58 => 19,  57 => 16,  56 => 14,  55 => 13,  54 => 12,  53 => 9,  52 => 8,  51 => 7,  50 => 6,  47 => 5,  45 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- spaceless %}

{% set id = id ?? \"checkbox#{random()}\" %}
{% set label = checkboxLabel ?? label ?? null %}

{% set inputAttributes = {
    id: id,
    class: (class ?? [])|explodeClass|merge([
        (toggle ?? reverseToggle ?? false) ? 'fieldtoggle' : null,
        'checkbox'
    ]|filter),
    checked: (checked ?? false) and checked,
    autofocus: (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
    disabled: (disabled ?? false) ? true : false,
    aria: {
        describedby: instructionsId ?? false,
    },
    data: {
        target: toggle ?? false,
        'reverse-target': reverseToggle ?? false,
    }
}|merge(inputAttributes ?? [], recursive=true) %}

{% if block('attr') is defined %}
    {%- set inputAttributes = inputAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% if name is defined and (name|length < 3 or name|slice(-2) != '[]') %}
    {{ hiddenInput(name, '') }}
{% endif %}

{{ input('checkbox', name ?? null, value ?? 1, inputAttributes) }}

<label for=\"{{ id }}\">
    {{ label }}
    {% if info ?? null %}
        <span class=\"info\">{{ info|md|raw }}</span>
    {% endif %}
</label>

{% endspaceless -%}
", "_includes/forms/checkbox", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/checkbox.html");
    }
}
