<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_components/fields/ViewsWorkField_input */
class __TwigTemplate_88900a0b4695304b0fd4c1545135aaabd458bc67cb49b13a05aacd919ae9c696 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_components/fields/ViewsWorkField_input");
        // line 15
        echo "
";
        // line 16
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "views-work/_components/fields/ViewsWorkField_input", 16)->unwrap();
        // line 17
        echo "

";
        // line 20
        echo "
<table>
    <tr>
        <th>Total views:</th>
        <td>";
        // line 24
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 24, $this->source); })()), "total", []), "html", null, true);
        echo "</td>
    </tr>
    <tr>
        <th>Views this month:</th>
        <td>";
        // line 28
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 28, $this->source); })()), "thisMonth", []), "html", null, true);
        echo "</td>
    </tr>
    <tr>
        <th>Views this week:</th>
        <td>";
        // line 32
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 32, $this->source); })()), "thisWeek", []), "html", null, true);
        echo "</td>
    </tr>
    <tr>
        <th>Views today:</th>
        <td>";
        // line 36
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 36, $this->source); })()), "today", []), "html", null, true);
        echo "</td>
    </tr>
</table>

";
        craft\helpers\Template::endProfile("template", "views-work/_components/fields/ViewsWorkField_input");
    }

    public function getTemplateName()
    {
        return "views-work/_components/fields/ViewsWorkField_input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 36,  67 => 32,  60 => 28,  53 => 24,  47 => 20,  43 => 17,  41 => 16,  38 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * ViewsWork plugin for Craft CMS 3.x
 *
 * ViewsWorkField Field Input
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2020 24hoursmedia
 * @link      https://www.24hoursmedia.com
 * @package   ViewsWork
 * @since     1.0.0
 */
#}

{% import \"_includes/forms\" as forms %}


{# value \\twentyfourhoursmedia\\viewswork\\models\\ViewRecording #}

<table>
    <tr>
        <th>Total views:</th>
        <td>{{ value.total }}</td>
    </tr>
    <tr>
        <th>Views this month:</th>
        <td>{{ value.thisMonth }}</td>
    </tr>
    <tr>
        <th>Views this week:</th>
        <td>{{ value.thisWeek }}</td>
    </tr>
    <tr>
        <th>Views today:</th>
        <td>{{ value.today }}</td>
    </tr>
</table>

{#
{{ forms.textField({
        label: 'Some Field',
        instructions: 'Enter some text here.',
        id: name,
        name: name,
        value: value})
}}
#}
", "views-work/_components/fields/ViewsWorkField_input", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_components/fields/ViewsWorkField_input.twig");
    }
}
