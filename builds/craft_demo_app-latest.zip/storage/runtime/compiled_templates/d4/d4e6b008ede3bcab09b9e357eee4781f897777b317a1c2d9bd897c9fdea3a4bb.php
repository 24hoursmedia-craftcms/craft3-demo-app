<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_index */
class __TwigTemplate_54b518def4c667b5a4317382ad7ae2465b4055d91f1023a272fcca6904f0aae2 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_index");
        $this->parent = $this->loadTemplate("_layout.html.twig", "views-work/_index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "views-work/_index");
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 4
        echo "
    <div class=\"app-content\">
        <h1>";
        // line 6
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 6, $this->source); })()), "title", []), "html", null, true);
        echo "</h1>
        ";
        // line 7
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 7, $this->source); })()), "bodyText", []), "html", null, true);
        echo "
    </div>

    <hr class=\"mt-4 mb-4\" />

   ";
        // line 12
        $this->loadTemplate("_components/views_work/view_counts.twig", "views-work/_index", 12)->display(twig_array_merge($context, ["entry" => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 12, $this->source); })())]));
        // line 13
        echo "
    <hr class=\"mt-4 mb-4\" />

    <div class=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mt-8 mb-4\">
        ";
        // line 17
        $context["popular_entries"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "entries", []), "orderByPopular", [0 => "total", 1 => 1], "method"), "limit", [0 => 5], "method");
        // line 18
        echo "        ";
        $this->loadTemplate("views-work/_index", "views-work/_index", 18, "1778773655")->display($context);
        // line 31
        echo "
        ";
        // line 32
        $context["popular_entries"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 32, $this->source); })()), "entries", []), "orderByPopular", [0 => "week", 1 => 1], "method"), "limit", [0 => 5], "method");
        // line 33
        echo "        ";
        $this->loadTemplate("views-work/_index", "views-work/_index", 33, "1405141852")->display($context);
        // line 46
        echo "
        ";
        // line 47
        $context["popular_entries"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 47, $this->source); })()), "entries", []), "orderByPopular", [0 => "day", 1 => 1], "method"), "limit", [0 => 5], "method");
        // line 48
        echo "        ";
        $this->loadTemplate("views-work/_index", "views-work/_index", 48, "1836351039")->display($context);
        // line 61
        echo "    </div>



    ";
        // line 66
        echo "    ";
        echo $this->extensions['twentyfourhoursmedia\viewswork\twigextensions\ViewsWorkTwigExtension']->viewsWorkImage((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 66, $this->source); })()));
        echo "

";
        craft\helpers\Template::endProfile("block", "body");
    }

    public function getTemplateName()
    {
        return "views-work/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 66,  98 => 61,  95 => 48,  93 => 47,  90 => 46,  87 => 33,  85 => 32,  82 => 31,  79 => 18,  77 => 17,  71 => 13,  69 => 12,  61 => 7,  57 => 6,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '_layout.html.twig' %}

{% block body %}

    <div class=\"app-content\">
        <h1>{{ entry.title }}</h1>
        {{ entry.bodyText }}
    </div>

    <hr class=\"mt-4 mb-4\" />

   {% include '_components/views_work/view_counts.twig' with {entry: entry} %}

    <hr class=\"mt-4 mb-4\" />

    <div class=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mt-8 mb-4\">
        {% set popular_entries = craft.entries.orderByPopular('total', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (total){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.total }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}

        {% set popular_entries = craft.entries.orderByPopular('week', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (this week){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.thisWeek }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}

        {% set popular_entries = craft.entries.orderByPopular('day', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (today){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.today }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}
    </div>



    {# Register the pageview with a registration pixel #}
    {{ entry | views_work_image }}

{% endblock %}", "views-work/_index", "/var/www/html/templates/views-work/_index.twig");
    }
}


/* views-work/_index */
class __TwigTemplate_54b518def4c667b5a4317382ad7ae2465b4055d91f1023a272fcca6904f0aae2___1778773655 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 18
        return "_components/cards/simple_card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_index");
        $this->parent = $this->loadTemplate("_components/cards/simple_card.html.twig", "views-work/_index", 18);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "views-work/_index");
    }

    // line 19
    public function block_heading($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "heading");
        echo "Popular (total)";
        craft\helpers\Template::endProfile("block", "heading");
    }

    // line 20
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 21
        echo "                <ul>
                    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["popular_entries"]) || array_key_exists("popular_entries", $context) ? $context["popular_entries"] : (function () { throw new RuntimeError('Variable "popular_entries" does not exist.', 22, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 23
            echo "                        <li class=\"mb-2\"><a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", []), "html", null, true);
            echo "\" class=\"flex\">
                                <div class=\"flex-grow\">";
            // line 24
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
            echo "</div>
                                <div class=\"app-badge bg-red-600\">";
            // line 25
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "viewsWork", []), "total", []), "html", null, true);
            echo "</div>
                            </a></li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "                </ul>
            ";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "views-work/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  274 => 28,  265 => 25,  261 => 24,  256 => 23,  252 => 22,  249 => 21,  244 => 20,  235 => 19,  222 => 18,  104 => 66,  98 => 61,  95 => 48,  93 => 47,  90 => 46,  87 => 33,  85 => 32,  82 => 31,  79 => 18,  77 => 17,  71 => 13,  69 => 12,  61 => 7,  57 => 6,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '_layout.html.twig' %}

{% block body %}

    <div class=\"app-content\">
        <h1>{{ entry.title }}</h1>
        {{ entry.bodyText }}
    </div>

    <hr class=\"mt-4 mb-4\" />

   {% include '_components/views_work/view_counts.twig' with {entry: entry} %}

    <hr class=\"mt-4 mb-4\" />

    <div class=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mt-8 mb-4\">
        {% set popular_entries = craft.entries.orderByPopular('total', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (total){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.total }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}

        {% set popular_entries = craft.entries.orderByPopular('week', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (this week){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.thisWeek }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}

        {% set popular_entries = craft.entries.orderByPopular('day', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (today){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.today }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}
    </div>



    {# Register the pageview with a registration pixel #}
    {{ entry | views_work_image }}

{% endblock %}", "views-work/_index", "/var/www/html/templates/views-work/_index.twig");
    }
}


/* views-work/_index */
class __TwigTemplate_54b518def4c667b5a4317382ad7ae2465b4055d91f1023a272fcca6904f0aae2___1405141852 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 33
        return "_components/cards/simple_card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_index");
        $this->parent = $this->loadTemplate("_components/cards/simple_card.html.twig", "views-work/_index", 33);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "views-work/_index");
    }

    // line 34
    public function block_heading($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "heading");
        echo "Popular (this week)";
        craft\helpers\Template::endProfile("block", "heading");
    }

    // line 35
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 36
        echo "                <ul>
                    ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["popular_entries"]) || array_key_exists("popular_entries", $context) ? $context["popular_entries"] : (function () { throw new RuntimeError('Variable "popular_entries" does not exist.', 37, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 38
            echo "                        <li class=\"mb-2\"><a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", []), "html", null, true);
            echo "\" class=\"flex\">
                                <div class=\"flex-grow\">";
            // line 39
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
            echo "</div>
                                <div class=\"app-badge bg-red-600\">";
            // line 40
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "viewsWork", []), "thisWeek", []), "html", null, true);
            echo "</div>
                            </a></li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "                </ul>
            ";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "views-work/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  441 => 43,  432 => 40,  428 => 39,  423 => 38,  419 => 37,  416 => 36,  411 => 35,  402 => 34,  389 => 33,  274 => 28,  265 => 25,  261 => 24,  256 => 23,  252 => 22,  249 => 21,  244 => 20,  235 => 19,  222 => 18,  104 => 66,  98 => 61,  95 => 48,  93 => 47,  90 => 46,  87 => 33,  85 => 32,  82 => 31,  79 => 18,  77 => 17,  71 => 13,  69 => 12,  61 => 7,  57 => 6,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '_layout.html.twig' %}

{% block body %}

    <div class=\"app-content\">
        <h1>{{ entry.title }}</h1>
        {{ entry.bodyText }}
    </div>

    <hr class=\"mt-4 mb-4\" />

   {% include '_components/views_work/view_counts.twig' with {entry: entry} %}

    <hr class=\"mt-4 mb-4\" />

    <div class=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mt-8 mb-4\">
        {% set popular_entries = craft.entries.orderByPopular('total', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (total){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.total }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}

        {% set popular_entries = craft.entries.orderByPopular('week', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (this week){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.thisWeek }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}

        {% set popular_entries = craft.entries.orderByPopular('day', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (today){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.today }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}
    </div>



    {# Register the pageview with a registration pixel #}
    {{ entry | views_work_image }}

{% endblock %}", "views-work/_index", "/var/www/html/templates/views-work/_index.twig");
    }
}


/* views-work/_index */
class __TwigTemplate_54b518def4c667b5a4317382ad7ae2465b4055d91f1023a272fcca6904f0aae2___1836351039 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 48
        return "_components/cards/simple_card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_index");
        $this->parent = $this->loadTemplate("_components/cards/simple_card.html.twig", "views-work/_index", 48);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "views-work/_index");
    }

    // line 49
    public function block_heading($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "heading");
        echo "Popular (today)";
        craft\helpers\Template::endProfile("block", "heading");
    }

    // line 50
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 51
        echo "                <ul>
                    ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["popular_entries"]) || array_key_exists("popular_entries", $context) ? $context["popular_entries"] : (function () { throw new RuntimeError('Variable "popular_entries" does not exist.', 52, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 53
            echo "                        <li class=\"mb-2\"><a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", []), "html", null, true);
            echo "\" class=\"flex\">
                                <div class=\"flex-grow\">";
            // line 54
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
            echo "</div>
                                <div class=\"app-badge bg-red-600\">";
            // line 55
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "viewsWork", []), "today", []), "html", null, true);
            echo "</div>
                            </a></li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "                </ul>
            ";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "views-work/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  608 => 58,  599 => 55,  595 => 54,  590 => 53,  586 => 52,  583 => 51,  578 => 50,  569 => 49,  556 => 48,  441 => 43,  432 => 40,  428 => 39,  423 => 38,  419 => 37,  416 => 36,  411 => 35,  402 => 34,  389 => 33,  274 => 28,  265 => 25,  261 => 24,  256 => 23,  252 => 22,  249 => 21,  244 => 20,  235 => 19,  222 => 18,  104 => 66,  98 => 61,  95 => 48,  93 => 47,  90 => 46,  87 => 33,  85 => 32,  82 => 31,  79 => 18,  77 => 17,  71 => 13,  69 => 12,  61 => 7,  57 => 6,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '_layout.html.twig' %}

{% block body %}

    <div class=\"app-content\">
        <h1>{{ entry.title }}</h1>
        {{ entry.bodyText }}
    </div>

    <hr class=\"mt-4 mb-4\" />

   {% include '_components/views_work/view_counts.twig' with {entry: entry} %}

    <hr class=\"mt-4 mb-4\" />

    <div class=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mt-8 mb-4\">
        {% set popular_entries = craft.entries.orderByPopular('total', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (total){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.total }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}

        {% set popular_entries = craft.entries.orderByPopular('week', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (this week){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.thisWeek }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}

        {% set popular_entries = craft.entries.orderByPopular('day', 1).limit(5) %}
        {% embed '_components/cards/simple_card.html.twig' %}
            {% block heading %}Popular (today){% endblock %}
            {% block content %}
                <ul>
                    {% for item in popular_entries %}
                        <li class=\"mb-2\"><a href=\"{{ item.url }}\" class=\"flex\">
                                <div class=\"flex-grow\">{{ item.title }}</div>
                                <div class=\"app-badge bg-red-600\">{{ item.viewsWork.today }}</div>
                            </a></li>
                    {% endfor %}
                </ul>
            {% endblock %}
        {% endembed %}
    </div>



    {# Register the pageview with a registration pixel #}
    {{ entry | views_work_image }}

{% endblock %}", "views-work/_index", "/var/www/html/templates/views-work/_index.twig");
    }
}
