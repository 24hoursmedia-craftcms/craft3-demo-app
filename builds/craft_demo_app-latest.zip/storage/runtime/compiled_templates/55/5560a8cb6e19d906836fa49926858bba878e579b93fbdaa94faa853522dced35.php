<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/time */
class __TwigTemplate_d5956a7fee4ecdcee051efcc54d8e7eea3126bce3b08e9f71dc84c2c49fd45d6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/time");
        // line 1
        $context["id"] = ((($context["id"]) ?? (("time" . twig_random($this->env)))) . "-time");
        // line 2
        $context["name"] = (($context["name"]) ?? (null));
        // line 3
        $context["value"] = (($context["value"]) ?? (null));
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\timepicker\\TimepickerAsset"], "method");
        // line 7
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->mergeFilter([0 => "timewrapper"], craft\helpers\Html::explodeClass(((        // line 8
$context["class"]) ?? ([]))))], ((        // line 9
$context["containerAttributes"]) ?? ([])), true);
        // line 11
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 12
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 12, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 14
        echo "
";
        // line 15
        ob_start();
        // line 16
        $this->loadTemplate("_includes/forms/text", "_includes/forms/time", 16)->display(twig_array_merge($context, ["name" => ((        // line 17
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 17, $this->source); })())) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 17, $this->source); })()) . "[time]")) : (null)), "autocomplete" => false, "size" => 10, "placeholder" => " ", "value" => ((        // line 21
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 21, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->timeFilter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 21, $this->source); })()), "short")) : (""))]));
        // line 23
        echo "<div data-icon=\"time\"></div>
    ";
        // line 24
        if ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 24, $this->source); })())) {
            // line 25
            echo craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 25, $this->source); })()) . "[timezone]"), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 25, $this->source); })()), "app", []), "getTimeZone", [], "method"));
        }
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 15
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 15, $this->source); })()));
        // line 28
        echo "
";
        // line 29
        $context["options"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["minTime" => ((        // line 30
$context["minTime"]) ?? (null)), "maxTime" => ((        // line 31
$context["maxTime"]) ?? (null)), "disableTimeRanges" => ((        // line 32
$context["disableTimeRanges"]) ?? (null)), "step" => ((        // line 33
$context["minuteIncrement"]) ?? (null)), "forceRoundTime" => ((        // line 34
$context["forceRoundTime"]) ?? (false))]);
        // line 36
        echo "
";
        // line 38
        $context["jsonOptions"] = (((twig_constant("JSON_HEX_TAG") | twig_constant("JSON_HEX_AMP")) | twig_constant("JSON_HEX_QUOT")) | twig_constant("JSON_FORCE_OBJECT"));
        // line 40
        ob_start();
        // line 41
        echo "    var \$timePicker = \$('#";
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 41, $this->source); })())]), "js"), "html", null, true);
        echo "');
    \$timePicker.timepicker(\$.extend(";
        // line 42
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 42, $this->source); })()), (isset($context["jsonOptions"]) || array_key_exists("jsonOptions", $context) ? $context["jsonOptions"] : (function () { throw new RuntimeError('Variable "jsonOptions" does not exist.', 42, $this->source); })()));
        echo ", Craft.timepickerOptions));

    ";
        // line 44
        if (((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 44, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, ($context["value"] ?? null), "format", [], "any", true, true))) {
            // line 45
            echo "        \$timePicker.timepicker('setTime', ";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 45, $this->source); })()), "format", [0 => "G"], "method"), "html", null, true);
            echo "*3600 + ";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 45, $this->source); })()), "format", [0 => "i"], "method"), "html", null, true);
            echo "*60 + ";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 45, $this->source); })()), "format", [0 => "s"], "method"), "html", null, true);
            echo ");
    ";
        }
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/time");
    }

    public function getTemplateName()
    {
        return "_includes/forms/time";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 45,  101 => 44,  96 => 42,  91 => 41,  89 => 40,  87 => 38,  84 => 36,  82 => 34,  81 => 33,  80 => 32,  79 => 31,  78 => 30,  77 => 29,  74 => 28,  72 => 15,  69 => 25,  67 => 24,  64 => 23,  62 => 21,  61 => 17,  60 => 16,  58 => 15,  55 => 14,  52 => 12,  50 => 11,  48 => 9,  47 => 8,  46 => 7,  44 => 5,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set id = (id ?? \"time#{random()}\") ~ '-time' -%}
{% set name = name ?? null -%}
{% set value = value ?? null -%}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\timepicker\\\\TimepickerAsset') -%}

{% set containerAttributes = {
    class: ['timewrapper']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% tag 'div' with containerAttributes %}
    {%- include \"_includes/forms/text\" with {
        name: name ? \"#{name}[time]\" : null,
        autocomplete: false,
        size: 10,
        placeholder: ' ',
        value: (value ? value|time('short') : '')
    } -%}
    <div data-icon=\"time\"></div>
    {% if name -%}
        {{ hiddenInput(\"#{name}[timezone]\", craft.app.getTimeZone()) }}
    {%- endif -%}
{% endtag %}

{% set options = {
    minTime: minTime ?? null,
    maxTime: maxTime ?? null,
    disableTimeRanges: disableTimeRanges ?? null,
    step: minuteIncrement ?? null,
    forceRoundTime: forceRoundTime ?? false,
}|filter %}

{# include JSON_FORCE_OBJECT in the json_encode options #}
{% set jsonOptions = constant('JSON_HEX_TAG') b-or constant('JSON_HEX_AMP') b-or constant('JSON_HEX_QUOT') b-or constant('JSON_FORCE_OBJECT') %}

{%- js %}
    var \$timePicker = \$('#{{ id|namespaceInputId|e('js') }}');
    \$timePicker.timepicker(\$.extend({{ options|json_encode(jsonOptions)|raw }}, Craft.timepickerOptions));

    {% if value and value.format is defined %}
        \$timePicker.timepicker('setTime', {{ value.format('G') }}*3600 + {{ value.format('i') }}*60 + {{ value.format('s') }});
    {% endif %}
{%- endjs %}
", "_includes/forms/time", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/time.html");
    }
}
