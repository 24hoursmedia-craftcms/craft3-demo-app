<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/field */
class __TwigTemplate_dbaca29334f07008562a7ed196602ed91d6345e47b208e740e9ae569d33669f6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/field");
        // line 1
        $context["fieldset"] = (($context["fieldset"]) ?? (false));
        // line 2
        $context["id"] = (($context["id"]) ?? (("field" . twig_random($this->env))));
        // line 3
        $context["fieldId"] = (($context["fieldId"]) ?? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 3, $this->source); })()) . "-field")));
        // line 4
        $context["labelId"] = (($context["labelId"]) ?? ((((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 4, $this->source); })()) . "-") . (((isset($context["fieldset"]) || array_key_exists("fieldset", $context) ? $context["fieldset"] : (function () { throw new RuntimeError('Variable "fieldset" does not exist.', 4, $this->source); })())) ? ("legend") : ("label")))));
        // line 5
        $context["instructionsId"] = (($context["instructionsId"]) ?? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 5, $this->source); })()) . "-instructions")));
        // line 6
        $context["status"] = (($context["status"]) ?? (null));
        // line 7
        $context["label"] = (($context["fieldLabel"]) ?? ((($context["label"]) ?? (((        $this->hasBlock("label", $context, $blocks)) ? (        $this->renderBlock("label", $context, $blocks)) : (null))))));
        // line 8
        if (((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 8, $this->source); })()) == "__blank__")) {
            // line 9
            $context["label"] = null;
        }
        // line 11
        $context["siteId"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) ? ((($context["siteId"]) ?? (null))) : (null));
        // line 12
        $context["site"] = (((isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 12, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "app", []), "sites", []), "getSiteById", [0 => (isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 12, $this->source); })())], "method")) : (null));
        // line 13
        $context["required"] = (($context["required"]) ?? (false));
        // line 14
        $context["instructions"] = (($context["instructions"]) ?? (((        $this->hasBlock("instructions", $context, $blocks)) ? (        $this->renderBlock("instructions", $context, $blocks)) : (null))));
        // line 15
        $context["instructionsPosition"] = (($context["instructionsPosition"]) ?? ("before"));
        // line 16
        $context["tip"] = (($context["tip"]) ?? (((        $this->hasBlock("tip", $context, $blocks)) ? (        $this->renderBlock("tip", $context, $blocks)) : (null))));
        // line 17
        $context["warning"] = (($context["warning"]) ?? (((        $this->hasBlock("warning", $context, $blocks)) ? (        $this->renderBlock("warning", $context, $blocks)) : (null))));
        // line 18
        $context["orientation"] = (($context["orientation"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, (((isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 18, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 18, $this->source); })()), "getLocale", [], "method")) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 18, $this->source); })()), "app", []), "locale", []))), "getOrientation", [], "method")));
        // line 19
        $context["translatable"] = (($context["translatable"]) ?? ( !((isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 19, $this->source); })()) === null)));
        // line 20
        $context["errors"] = (($context["errors"]) ?? (null));
        // line 21
        $context["fieldClass"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["fieldClass"]) ?? ([]))), [0 => "field", 1 => ((((        // line 23
$context["first"]) ?? (false))) ? ("first") : (null)), 2 => ((        // line 24
(isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 24, $this->source); })())) ? ("has-errors") : (null))]));
        // line 26
        $context["showAttribute"] = (((($context["attribute"]) ?? (false)) && (((craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "admin", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "admin", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "admin", [])) : (false))) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 26, $this->source); })()), "getPreference", [0 => "showFieldHandles"], "method"));
        // line 29
        $context["fieldAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 30
(isset($context["fieldClass"]) || array_key_exists("fieldClass", $context) ? $context["fieldClass"] : (function () { throw new RuntimeError('Variable "fieldClass" does not exist.', 30, $this->source); })()), "id" =>         // line 31
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 31, $this->source); })())], ((        // line 32
$context["fieldAttributes"]) ?? ([])), true);
        // line 34
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 35
            $context["fieldAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["fieldAttributes"]) || array_key_exists("fieldAttributes", $context) ? $context["fieldAttributes"] : (function () { throw new RuntimeError('Variable "fieldAttributes" does not exist.', 35, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 38
        $context["inputContainerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "input", 1 =>         // line 41
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 41, $this->source); })()), 2 => ((        // line 42
(isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 42, $this->source); })())) ? ("errors") : (null))])], ((        // line 44
$context["inputContainerAttributes"]) ?? ([])), true);
        // line 46
        $context["instructionsHtml"] = (((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 46, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->tagFunction("div", ["id" =>         // line 47
(isset($context["instructionsId"]) || array_key_exists("instructionsId", $context) ? $context["instructionsId"] : (function () { throw new RuntimeError('Variable "instructionsId" does not exist.', 47, $this->source); })()), "class" => [0 => "instructions"], "html" => $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter(        // line 49
(isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 49, $this->source); })()), "gfm-comment"), "/&amp;(\\w+);/", "&\$1;")])) : (""));
        // line 51
        echo "
";
        // line 52
        ob_start();
        // line 53
        echo "    ";
        if ((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 53, $this->source); })())) {
            // line 54
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => [0 => "status-badge", 1 => craft\helpers\Template::attribute($this->env, $this->source,             // line 55
(isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 55, $this->source); })()), 0, [], "array")], "text" => twig_upper_filter($this->env, twig_slice($this->env, craft\helpers\Template::attribute($this->env, $this->source,             // line 56
(isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 56, $this->source); })()), 1, [], "array"), 0, 1)), "title" => craft\helpers\Template::attribute($this->env, $this->source,             // line 57
(isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 57, $this->source); })()), 1, [], "array"), "aria" => ["label" => craft\helpers\Template::attribute($this->env, $this->source,             // line 59
(isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 59, $this->source); })()), 1, [], "array")]]);
            // line 61
            echo "
    ";
        }
        // line 63
        echo "    ";
        if (((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 63, $this->source); })()) || (isset($context["showAttribute"]) || array_key_exists("showAttribute", $context) ? $context["showAttribute"] : (function () { throw new RuntimeError('Variable "showAttribute" does not exist.', 63, $this->source); })()))) {
            // line 64
            echo "        <div class=\"heading\">
            ";
            // line 65
            $this->displayBlock('heading', $context, $blocks);
            // line 95
            echo "        </div>
    ";
        }
        // line 97
        echo "    ";
        echo ((((isset($context["instructionsPosition"]) || array_key_exists("instructionsPosition", $context) ? $context["instructionsPosition"] : (function () { throw new RuntimeError('Variable "instructionsPosition" does not exist.', 97, $this->source); })()) == "before")) ? ((isset($context["instructionsHtml"]) || array_key_exists("instructionsHtml", $context) ? $context["instructionsHtml"] : (function () { throw new RuntimeError('Variable "instructionsHtml" does not exist.', 97, $this->source); })())) : (""));
        echo "
    ";
        // line 98
        ob_start();
        // line 99
        echo "        ";
        $this->displayBlock('input', $context, $blocks);
        // line 102
        echo "    ";
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 98
(isset($context["inputContainerAttributes"]) || array_key_exists("inputContainerAttributes", $context) ? $context["inputContainerAttributes"] : (function () { throw new RuntimeError('Variable "inputContainerAttributes" does not exist.', 98, $this->source); })()));
        // line 103
        echo "    ";
        echo ((((isset($context["instructionsPosition"]) || array_key_exists("instructionsPosition", $context) ? $context["instructionsPosition"] : (function () { throw new RuntimeError('Variable "instructionsPosition" does not exist.', 103, $this->source); })()) == "after")) ? ((isset($context["instructionsHtml"]) || array_key_exists("instructionsHtml", $context) ? $context["instructionsHtml"] : (function () { throw new RuntimeError('Variable "instructionsHtml" does not exist.', 103, $this->source); })())) : (""));
        echo "
    ";
        // line 104
        if ((isset($context["tip"]) || array_key_exists("tip", $context) ? $context["tip"] : (function () { throw new RuntimeError('Variable "tip" does not exist.', 104, $this->source); })())) {
            // line 105
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("p", ["class" => [0 => "notice", 1 => "with-icon"], "html" => $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter(            // line 107
(isset($context["tip"]) || array_key_exists("tip", $context) ? $context["tip"] : (function () { throw new RuntimeError('Variable "tip" does not exist.', 107, $this->source); })()), null, true), "/&amp;(\\w+);/", "&\$1;")]);
            // line 108
            echo "
    ";
        }
        // line 110
        echo "    ";
        if ((isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 110, $this->source); })())) {
            // line 111
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("p", ["class" => [0 => "warning", 1 => "with-icon"], "html" => $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter(            // line 113
(isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 113, $this->source); })()), null, true), "/&amp;(\\w+);/", "&\$1;")]);
            // line 114
            echo "
    ";
        }
        // line 116
        echo "    ";
        $this->loadTemplate("_includes/forms/errorList", "_includes/forms/field", 116)->display(twig_array_merge($context, ["errors" => (isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 116, $this->source); })())]));
        echo craft\helpers\Html::tag(((        // line 52
(isset($context["fieldset"]) || array_key_exists("fieldset", $context) ? $context["fieldset"] : (function () { throw new RuntimeError('Variable "fieldset" does not exist.', 52, $this->source); })())) ? ("fieldset") : ("div")), ob_get_clean(), (isset($context["fieldAttributes"]) || array_key_exists("fieldAttributes", $context) ? $context["fieldAttributes"] : (function () { throw new RuntimeError('Variable "fieldAttributes" does not exist.', 52, $this->source); })()));
        craft\helpers\Template::endProfile("template", "_includes/forms/field");
    }

    // line 65
    public function block_heading($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "heading");
        // line 66
        echo "                ";
        if ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 66, $this->source); })())) {
            // line 67
            echo "                    ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction((((isset($context["fieldset"]) || array_key_exists("fieldset", $context) ? $context["fieldset"] : (function () { throw new RuntimeError('Variable "fieldset" does not exist.', 67, $this->source); })())) ? ("legend") : ("label")), $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>             // line 68
(isset($context["labelId"]) || array_key_exists("labelId", $context) ? $context["labelId"] : (function () { throw new RuntimeError('Variable "labelId" does not exist.', 68, $this->source); })()), "class" => ((            // line 69
(isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 69, $this->source); })())) ? ([0 => "required"]) : ([])), "for" => (((((            // line 70
$context["id"]) ?? (false)) &&  !(isset($context["fieldset"]) || array_key_exists("fieldset", $context) ? $context["fieldset"] : (function () { throw new RuntimeError('Variable "fieldset" does not exist.', 70, $this->source); })()))) ? ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 70, $this->source); })())) : (null)), "html" =>             // line 71
(isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 71, $this->source); })())], ((            // line 72
$context["labelAttributes"]) ?? ([])), true));
            // line 73
            if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new RuntimeError('Variable "translatable" does not exist.', 73, $this->source); })())) {
                // line 74
                echo "                        ";
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => "t9n-indicator", "title" => ((                // line 76
$context["translationDescription"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("This field is translatable.", "app"))), "aria" => ["label" => ((                // line 78
$context["translationDescription"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("This field is translatable.", "app")))], "data" => ["icon" => "language"]]);
                // line 83
                echo "
                    ";
            }
        }
        // line 86
        echo "                ";
        if ((isset($context["showAttribute"]) || array_key_exists("showAttribute", $context) ? $context["showAttribute"] : (function () { throw new RuntimeError('Variable "showAttribute" does not exist.', 86, $this->source); })())) {
            // line 87
            echo "                    <div class=\"flex-grow\"></div>
                    ";
            // line 88
            $this->loadTemplate("_includes/forms/copytextbtn", "_includes/forms/field", 88)->display(twig_to_array(["id" => (            // line 89
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 89, $this->source); })()) . "-attribute"), "class" => [0 => "code", 1 => "small", 2 => "light"], "value" =>             // line 91
(isset($context["attribute"]) || array_key_exists("attribute", $context) ? $context["attribute"] : (function () { throw new RuntimeError('Variable "attribute" does not exist.', 91, $this->source); })())]));
            // line 93
            echo "                ";
        }
        // line 94
        echo "            ";
        craft\helpers\Template::endProfile("block", "heading");
    }

    // line 99
    public function block_input($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "input");
        // line 100
        echo "            ";
        echo (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 100, $this->source); })());
        echo "
        ";
        craft\helpers\Template::endProfile("block", "input");
    }

    public function getTemplateName()
    {
        return "_includes/forms/field";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  234 => 100,  229 => 99,  224 => 94,  221 => 93,  219 => 91,  218 => 89,  217 => 88,  214 => 87,  211 => 86,  206 => 83,  204 => 78,  203 => 76,  201 => 74,  199 => 73,  197 => 72,  196 => 71,  195 => 70,  194 => 69,  193 => 68,  191 => 67,  188 => 66,  183 => 65,  178 => 52,  175 => 116,  171 => 114,  169 => 113,  167 => 111,  164 => 110,  160 => 108,  158 => 107,  156 => 105,  154 => 104,  149 => 103,  147 => 98,  145 => 102,  142 => 99,  140 => 98,  135 => 97,  131 => 95,  129 => 65,  126 => 64,  123 => 63,  119 => 61,  117 => 59,  116 => 57,  115 => 56,  114 => 55,  112 => 54,  109 => 53,  107 => 52,  104 => 51,  102 => 49,  101 => 47,  100 => 46,  98 => 44,  97 => 42,  96 => 41,  95 => 38,  92 => 35,  90 => 34,  88 => 32,  87 => 31,  86 => 30,  85 => 29,  83 => 26,  81 => 24,  80 => 23,  79 => 21,  77 => 20,  75 => 19,  73 => 18,  71 => 17,  69 => 16,  67 => 15,  65 => 14,  63 => 13,  61 => 12,  59 => 11,  56 => 9,  54 => 8,  52 => 7,  50 => 6,  48 => 5,  46 => 4,  44 => 3,  42 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set fieldset = fieldset ?? false %}
{%- set id = id ?? \"field#{random()}\" %}
{%- set fieldId = fieldId ?? \"#{id}-field\" %}
{%- set labelId = labelId ?? \"#{id}-#{fieldset ? 'legend' : 'label'}\" %}
{%- set instructionsId = instructionsId ?? \"#{id}-instructions\"  %}
{%- set status = status ?? null %}
{%- set label = fieldLabel ?? label ?? block('label') ?? null %}
{%- if label == '__blank__' %}
    {%- set label = null %}
{%- endif %}
{%- set siteId = craft.app.getIsMultiSite() ? (siteId ?? null) : null %}
{%- set site = siteId ? craft.app.sites.getSiteById(siteId) : null %}
{%- set required = required ?? false %}
{%- set instructions = instructions ?? block('instructions') ?? null %}
{%- set instructionsPosition = instructionsPosition ?? 'before' %}
{%- set tip = tip ?? block('tip') ?? null %}
{%- set warning = warning ?? block('warning') ?? null %}
{%- set orientation = orientation ?? (site ? site.getLocale() : craft.app.locale).getOrientation() %}
{%- set translatable = translatable ?? (site is not same as(null)) %}
{%- set errors = errors ?? null -%}
{%- set fieldClass = (fieldClass ?? [])|explodeClass|merge([
    'field',
    (first ?? false) ? 'first' : null,
    errors ? 'has-errors' : null,
])|filter %}
{%- set showAttribute = (attribute ?? false) and (currentUser.admin ?? false) and currentUser.getPreference('showFieldHandles') %}


{%- set fieldAttributes = {
    class: fieldClass,
    id: fieldId,
}|merge(fieldAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set fieldAttributes = fieldAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{%- set inputContainerAttributes = {
    class: [
        'input',
        orientation,
        errors ? 'errors' : null,
    ]|filter,
}|merge(inputContainerAttributes ?? [], recursive=true) %}

{%- set instructionsHtml = instructions ? tag('div', {
    id: instructionsId,
    class: ['instructions'],
    html: instructions|md('gfm-comment')|replace('/&amp;(\\\\w+);/', '&\$1;'),
}) %}

{% tag (fieldset ? 'fieldset' : 'div') with fieldAttributes %}
    {% if status %}
        {{ tag('div', {
            class: ['status-badge', status[0]],
            text: status[1][0:1]|upper,
            title: status[1],
            aria: {
                label: status[1],
            },
        }) }}
    {% endif %}
    {% if label or showAttribute %}
        <div class=\"heading\">
            {% block heading %}
                {% if label %}
                    {{ tag(fieldset ? 'legend' : 'label', {
                        id: labelId,
                        class: required ? ['required'] : [],
                        for: (id ?? false) and not fieldset ? id : null,
                        html: label,
                    }|merge(labelAttributes ?? [], recursive=true)) }}
                    {%- if translatable %}
                        {{ tag('div', {
                            class: 't9n-indicator',
                            title: translationDescription ?? 'This field is translatable.'|t('app'),
                            aria: {
                                label: translationDescription ?? 'This field is translatable.'|t('app'),
                            },
                            data: {
                                icon: 'language',
                            },
                        }) }}
                    {% endif -%}
                {% endif %}
                {% if showAttribute %}
                    <div class=\"flex-grow\"></div>
                    {% include '_includes/forms/copytextbtn' with {
                        id: \"#{fieldId}-attribute\",
                        class: ['code', 'small', 'light'],
                        value: attribute,
                    } only %}
                {% endif %}
            {% endblock %}
        </div>
    {% endif %}
    {{ instructionsPosition == 'before' ? instructionsHtml|raw }}
    {% tag 'div' with inputContainerAttributes %}
        {% block input %}
            {{ input|raw }}
        {% endblock %}
    {% endtag %}
    {{ instructionsPosition == 'after' ? instructionsHtml|raw }}
    {% if tip %}
        {{ tag('p', {
            class: ['notice', 'with-icon'],
            html: tip|md(inlineOnly=true)|replace('/&amp;(\\\\w+);/', '&\$1;'),
        }) }}
    {% endif %}
    {% if warning %}
        {{ tag('p', {
            class: ['warning', 'with-icon'],
            html: warning|md(inlineOnly=true)|replace('/&amp;(\\\\w+);/', '&\$1;'),
        }) }}
    {% endif %}
    {% include \"_includes/forms/errorList\" with { errors: errors } %}
{% endtag %}
", "_includes/forms/field", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/field.html");
    }
}
