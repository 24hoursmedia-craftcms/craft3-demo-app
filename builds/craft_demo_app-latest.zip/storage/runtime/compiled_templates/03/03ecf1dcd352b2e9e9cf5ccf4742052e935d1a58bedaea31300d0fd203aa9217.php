<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _partials/top_nav.twig */
class __TwigTemplate_4dd0e579b52cb3a0987c02cac5bc47b3a432959f0fd9b7ff191f6402c858a8c4 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_partials/top_nav.twig");
        // line 1
        echo "<div class=\"text-white text-xs hidden sm:block ml-2\">
    <a href=\"#\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer\">Dashboard</a>
    <a href=\"#\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer ml-1\">Projects</a>
    <a href=\"#\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer ml-1\">Issues</a>
    <a href=\"#\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer ml-1\">Boards</a>
</div>";
        craft\helpers\Template::endProfile("template", "_partials/top_nav.twig");
    }

    public function getTemplateName()
    {
        return "_partials/top_nav.twig";
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"text-white text-xs hidden sm:block ml-2\">
    <a href=\"#\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer\">Dashboard</a>
    <a href=\"#\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer ml-1\">Projects</a>
    <a href=\"#\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer ml-1\">Issues</a>
    <a href=\"#\" class=\"bg-gray-900 hover:bg-gray-700 p-2 rounded cursor-pointer ml-1\">Boards</a>
</div>", "_partials/top_nav.twig", "/var/www/html/templates/_partials/top_nav.twig");
    }
}
