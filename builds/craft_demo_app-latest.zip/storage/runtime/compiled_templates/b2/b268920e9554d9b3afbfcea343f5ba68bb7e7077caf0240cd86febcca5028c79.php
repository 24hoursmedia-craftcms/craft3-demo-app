<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms */
class __TwigTemplate_82f40dabb4d03c26c58f37492d56ec598c184a7a714fda76a1e14dc9915b1ad2 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $macros["_self"] = $this->macros["_self"] = $this;
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms");
        // line 4
        echo "

";
        // line 7
        echo "

";
        // line 12
        echo "

";
        // line 17
        echo "

";
        // line 22
        echo "

";
        // line 27
        echo "

";
        // line 32
        echo "

";
        // line 37
        echo "

";
        // line 42
        echo "

";
        // line 47
        echo "

";
        // line 52
        echo "

";
        // line 57
        echo "

";
        // line 62
        echo "

";
        // line 67
        echo "

";
        // line 72
        echo "

";
        // line 77
        echo "

";
        // line 82
        echo "

";
        // line 87
        echo "

";
        // line 92
        echo "

";
        // line 97
        echo "

";
        // line 102
        echo "

";
        // line 107
        echo "

";
        // line 112
        echo "

";
        // line 115
        echo "

";
        // line 129
        echo "

";
        // line 135
        echo "

";
        // line 141
        echo "

";
        // line 147
        echo "

";
        // line 153
        echo "

";
        // line 159
        echo "

";
        // line 165
        echo "

";
        // line 181
        echo "

";
        // line 187
        echo "

";
        // line 193
        echo "

";
        // line 199
        echo "

";
        // line 212
        echo "

";
        // line 221
        echo "

";
        // line 230
        echo "

";
        // line 239
        echo "

";
        // line 245
        echo "

";
        // line 255
        echo "

";
        // line 261
        echo "

";
        // line 267
        echo "

";
        // line 291
        echo "

";
        // line 298
        echo "

";
        // line 301
        echo "

";
        // line 306
        echo "
";
        craft\helpers\Template::endProfile("template", "_includes/forms");
    }

    // line 1
    public function macro_errorList($__errors__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "errors" => $__errors__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "errorList");
            // line 2
            echo "    ";
            $this->loadTemplate("_includes/forms/errorList", "_includes/forms", 2)->display($context);
            craft\helpers\Template::endProfile("macro", "errorList");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 9
    public function macro_hidden($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "hidden");
            // line 10
            $this->loadTemplate("_includes/forms/hidden", "_includes/forms", 10)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 10, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "hidden");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 14
    public function macro_text($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "text");
            // line 15
            echo "    ";
            $this->loadTemplate("_includes/forms/text", "_includes/forms", 15)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 15, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "text");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 19
    public function macro_password($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "password");
            // line 20
            echo "    ";
            $this->loadTemplate("_includes/forms/password", "_includes/forms", 20)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 20, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "password");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 24
    public function macro_copytext($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "copytext");
            // line 25
            echo "    ";
            $this->loadTemplate("_includes/forms/copytext", "_includes/forms", 25)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 25, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "copytext");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 29
    public function macro_date($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "date");
            // line 30
            echo "    ";
            $this->loadTemplate("_includes/forms/date", "_includes/forms", 30)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 30, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "date");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 34
    public function macro_time($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "time");
            // line 35
            echo "    ";
            $this->loadTemplate("_includes/forms/time", "_includes/forms", 35)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 35, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "time");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 39
    public function macro_color($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "color");
            // line 40
            echo "    ";
            $this->loadTemplate("_includes/forms/color", "_includes/forms", 40)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 40, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "color");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 44
    public function macro_textarea($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "textarea");
            // line 45
            echo "    ";
            $this->loadTemplate("_includes/forms/textarea", "_includes/forms", 45)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 45, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "textarea");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 49
    public function macro_select($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "select");
            // line 50
            echo "    ";
            $this->loadTemplate("_includes/forms/select", "_includes/forms", 50)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 50, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "select");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 54
    public function macro_multiselect($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "multiselect");
            // line 55
            echo "    ";
            $this->loadTemplate("_includes/forms/multiselect", "_includes/forms", 55)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 55, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "multiselect");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 59
    public function macro_checkbox($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkbox");
            // line 60
            echo "    ";
            $this->loadTemplate("_includes/forms/checkbox", "_includes/forms", 60)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 60, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkbox");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 64
    public function macro_checkboxGroup($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxGroup");
            // line 65
            echo "    ";
            $this->loadTemplate("_includes/forms/checkboxGroup", "_includes/forms", 65)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 65, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkboxGroup");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 69
    public function macro_checkboxSelect($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxSelect");
            // line 70
            echo "    ";
            $this->loadTemplate("_includes/forms/checkboxSelect", "_includes/forms", 70)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 70, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkboxSelect");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 74
    public function macro_radio($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "radio");
            // line 75
            echo "    ";
            $this->loadTemplate("_includes/forms/radio", "_includes/forms", 75)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 75, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "radio");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 79
    public function macro_radioGroup($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "radioGroup");
            // line 80
            echo "    ";
            $this->loadTemplate("_includes/forms/radioGroup", "_includes/forms", 80)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 80, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "radioGroup");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 84
    public function macro_file($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "file");
            // line 85
            echo "    ";
            $this->loadTemplate("_includes/forms/file", "_includes/forms", 85)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 85, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "file");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 89
    public function macro_lightswitch($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "lightswitch");
            // line 90
            echo "    ";
            $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms", 90)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 90, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "lightswitch");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 94
    public function macro_editableTable($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "editableTable");
            // line 95
            echo "    ";
            $this->loadTemplate("_includes/forms/editableTable", "_includes/forms", 95)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 95, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "editableTable");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 99
    public function macro_elementSelect($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "elementSelect");
            // line 100
            echo "    ";
            $this->loadTemplate("_includes/forms/elementSelect", "_includes/forms", 100)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 100, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "elementSelect");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 104
    public function macro_autosuggest($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "autosuggest");
            // line 105
            echo "    ";
            $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms", 105)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 105, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "autosuggest");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 109
    public function macro_fieldLayoutDesigner($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "fieldLayoutDesigner");
            // line 110
            echo "    ";
            $this->loadTemplate("_includes/forms/fieldLayoutDesigner", "_includes/forms", 110)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 110, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "fieldLayoutDesigner");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 117
    public function macro_field($__config__ = null, $__input__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "input" => $__input__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "field");
            // line 118
            echo "    ";
            $context["id"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("field" . twig_random($this->env))));
            // line 119
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 119, $this->source); })()), ["id" =>             // line 120
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 120, $this->source); })()), "labelId" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 121
($context["config"] ?? null), "labelId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "labelId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "labelId", [])) : (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 121, $this->source); })()) . "-label"))), "instructionsId" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 122
($context["config"] ?? null), "instructionsId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructionsId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructionsId", [])) : (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 122, $this->source); })()) . "-instructions")))]);
            // line 124
            echo "    ";
            if ((is_string($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 124, $this->source); })())) && is_string($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = "template:") && ('' === $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 || 0 === strpos($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4, $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144)))) {
                // line 125
                echo "        ";
                $context["input"] = twig_include($this->env, $context, twig_slice($this->env, (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 125, $this->source); })()), 9, null), (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 125, $this->source); })()));
                // line 126
                echo "    ";
            }
            // line 127
            echo "    ";
            $this->loadTemplate("_includes/forms/field", "_includes/forms", 127)->display(twig_to_array($this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 127, $this->source); })()), ["input" => (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 127, $this->source); })())])));
            craft\helpers\Template::endProfile("macro", "field");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 131
    public function macro_textField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "textField");
            // line 132
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 132, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("text" . twig_random($this->env))))]);
            // line 133
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 133, $this->source); })()), "template:_includes/forms/text"], 133, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "textField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 137
    public function macro_copytextField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "copytextField");
            // line 138
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 138, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("copytext" . twig_random($this->env))))]);
            // line 139
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 139, $this->source); })()), "template:_includes/forms/copytext"], 139, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "copytextField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 143
    public function macro_passwordField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "passwordField");
            // line 144
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 144, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("password" . twig_random($this->env))))]);
            // line 145
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 145, $this->source); })()), "template:_includes/forms/password"], 145, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "passwordField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 149
    public function macro_dateField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "dateField");
            // line 150
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 150, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("date" . twig_random($this->env))))]);
            // line 151
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 151, $this->source); })()), "template:_includes/forms/date"], 151, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "dateField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 155
    public function macro_timeField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "timeField");
            // line 156
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 156, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("time" . twig_random($this->env))))]);
            // line 157
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 157, $this->source); })()), "template:_includes/forms/time"], 157, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "timeField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 161
    public function macro_colorField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "colorField");
            // line 162
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 162, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("color" . twig_random($this->env))))]);
            // line 163
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 163, $this->source); })()), "template:_includes/forms/color"], 163, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "colorField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 167
    public function macro_dateTimeField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "dateTimeField");
            // line 168
            echo "    ";
            $context["id"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("datetime" . twig_random($this->env))));
            // line 169
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 169, $this->source); })()), ["id" =>             // line 170
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 170, $this->source); })()), "instructionsId" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 171
($context["config"] ?? null), "instructionsId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructionsId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructionsId", [])) : (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 171, $this->source); })()) . "-instructions")))]);
            // line 173
            echo "    ";
            ob_start();
            // line 174
            echo "        <div class=\"datetimewrapper\">
            ";
            // line 175
            echo twig_call_macro($macros["_self"], "macro_date", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 175, $this->source); })())], 175, $context, $this->getSourceContext());
            echo "
            ";
            // line 176
            echo twig_call_macro($macros["_self"], "macro_time", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 176, $this->source); })())], 176, $context, $this->getSourceContext());
            echo "
        </div>
    ";
            $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 179
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 179, $this->source); })()), (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 179, $this->source); })())], 179, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "dateTimeField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 183
    public function macro_textareaField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "textareaField");
            // line 184
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 184, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("textarea" . twig_random($this->env))))]);
            // line 185
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 185, $this->source); })()), "template:_includes/forms/textarea"], 185, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "textareaField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 189
    public function macro_selectField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "selectField");
            // line 190
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 190, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("select" . twig_random($this->env))))]);
            // line 191
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 191, $this->source); })()), "template:_includes/forms/select"], 191, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "selectField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 195
    public function macro_multiselectField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "multiselectField");
            // line 196
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 196, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("multiselect" . twig_random($this->env))))]);
            // line 197
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 197, $this->source); })()), "template:_includes/forms/multiselect"], 197, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "multiselectField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 201
    public function macro_checkboxField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxField");
            // line 202
            echo "    ";
            // line 203
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 203, $this->source); })()), ["fieldset" => craft\helpers\Template::attribute($this->env, $this->source,             // line 204
($context["config"] ?? null), "fieldLabel", [], "any", true, true), "fieldClass" => $this->extensions['craft\web\twig\Extension']->pushFilter(craft\helpers\Html::explodeClass((((craft\helpers\Template::attribute($this->env, $this->source,             // line 205
($context["config"] ?? null), "fieldClass", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [])) : ([]))), "checkboxfield"), "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 206
($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("checkbox" . twig_random($this->env)))), "checkboxLabel" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 207
($context["config"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [])) : (null)), "instructionsPosition" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 208
($context["config"] ?? null), "instructionsPosition", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructionsPosition", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructionsPosition", [])) : ("after"))]), "label");
            // line 210
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 210, $this->source); })()), "template:_includes/forms/checkbox"], 210, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "checkboxField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 214
    public function macro_checkboxGroupField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxGroupField");
            // line 215
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 215, $this->source); })()), ["fieldset" => true, "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 217
($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("checkboxgroup" . twig_random($this->env))))]);
            // line 219
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 219, $this->source); })()), "template:_includes/forms/checkboxGroup"], 219, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "checkboxGroupField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 223
    public function macro_checkboxSelectField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxSelectField");
            // line 224
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 224, $this->source); })()), ["fieldset" => true, "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 226
($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("checkboxselect" . twig_random($this->env))))]);
            // line 228
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 228, $this->source); })()), "template:_includes/forms/checkboxSelect"], 228, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "checkboxSelectField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 232
    public function macro_radioGroupField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "radioGroupField");
            // line 233
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 233, $this->source); })()), ["fieldset" => true, "id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 235
($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("radiogroup" . twig_random($this->env))))]);
            // line 237
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 237, $this->source); })()), "template:_includes/forms/radioGroup"], 237, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "radioGroupField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 241
    public function macro_fileField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "fileField");
            // line 242
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 242, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("file" . twig_random($this->env))))]);
            // line 243
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 243, $this->source); })()), "template:_includes/forms/file"], 243, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "fileField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 247
    public function macro_lightswitchField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "lightswitchField");
            // line 248
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 248, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 249
($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("lightswitch" . twig_random($this->env)))), "fieldClass" => $this->extensions['craft\web\twig\Extension']->pushFilter(craft\helpers\Html::explodeClass((((craft\helpers\Template::attribute($this->env, $this->source,             // line 250
($context["config"] ?? null), "fieldClass", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [])) : ([]))), "lightswitch-field"), "fieldLabel" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 251
($context["config"] ?? null), "fieldLabel", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLabel", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLabel", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "label", [])) : (null))))]), "label");
            // line 253
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 253, $this->source); })()), "template:_includes/forms/lightswitch"], 253, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "lightswitchField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 257
    public function macro_editableTableField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "editableTableField");
            // line 258
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 258, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("editabletable" . twig_random($this->env))))]);
            // line 259
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 259, $this->source); })()), "template:_includes/forms/editableTable"], 259, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "editableTableField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 263
    public function macro_elementSelectField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "elementSelectField");
            // line 264
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 264, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("elementselect" . twig_random($this->env))))]);
            // line 265
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 265, $this->source); })()), "template:_includes/forms/elementSelect"], 265, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "elementSelectField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 269
    public function macro_autosuggestField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "autosuggestField");
            // line 270
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 270, $this->source); })()), ["id" => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [])) : (("autosuggest" . twig_random($this->env))))]);
            // line 271
            echo "
    ";
            // line 273
            echo "    ";
            if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [])) : (false))) {
                // line 274
                echo "        ";
                $context["value"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [])) : (""));
                // line 275
                echo "        ";
                if (( !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true) && !twig_in_filter(twig_slice($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 275, $this->source); })()), 0, 1), [0 => "\$", 1 => "@"]))) {
                    // line 276
                    echo "            ";
                    $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 276, $this->source); })()), ["tip" => ((((((((craft\helpers\Template::attribute($this->env, $this->source,                     // line 277
($context["config"] ?? null), "suggestAliases", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestAliases", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestAliases", [])) : (false))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable, or begin with an alias.", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable.", "app"))) . " <a href=\"https://craftcms.com/docs/3.x/config/#environmental-configuration\" class=\"go\">") . $this->extensions['craft\web\twig\Extension']->translateFilter("Learn more", "app")) . "</a>")]);
                    // line 282
                    echo "        ";
                } elseif ((( !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "warning", [], "any", true, true) && (((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 282, $this->source); })()) == "@web") || (twig_slice($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 282, $this->source); })()), 0, 5) == "@web/"))) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 282, $this->source); })()), "app", []), "request", []), "isWebAliasSetDynamically", []))) {
                    // line 283
                    echo "            ";
                    $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 283, $this->source); })()), ["warning" => $this->extensions['craft\web\twig\Extension']->translateFilter("The `@web` alias is not recommended if it is determined automatically.", "app")]);
                    // line 286
                    echo "        ";
                }
                // line 287
                echo "    ";
            }
            // line 288
            echo "
    ";
            // line 289
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 289, $this->source); })()), "template:_includes/forms/autosuggest"], 289, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "autosuggestField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 293
    public function macro_fieldLayoutDesignerField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "fieldLayoutDesignerField");
            // line 294
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [$this->extensions['craft\web\twig\Extension']->mergeFilter(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Layout", "app")],             // line 296
(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 296, $this->source); })())), "template:_includes/forms/fieldLayoutDesigner"], 294, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "fieldLayoutDesignerField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 303
    public function macro_optionShortcutLabel($__key__ = null, $__shift__ = null, $__alt__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "key" => $__key__,
            "shift" => $__shift__,
            "alt" => $__alt__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "optionShortcutLabel");
            // line 304
            echo "<span class=\"shortcut\">";
            echo twig_call_macro($macros["_self"], "macro_shortcutText", [(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 304, $this->source); })()), (isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new RuntimeError('Variable "shift" does not exist.', 304, $this->source); })()), (isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new RuntimeError('Variable "alt" does not exist.', 304, $this->source); })())], 304, $context, $this->getSourceContext());
            echo "</span>";
            craft\helpers\Template::endProfile("macro", "optionShortcutLabel");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 307
    public function macro_shortcutText($__key__ = null, $__shift__ = null, $__alt__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "key" => $__key__,
            "shift" => $__shift__,
            "alt" => $__alt__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "shortcutText");
            // line 308
            switch (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 308, $this->source); })()), "app", []), "request", []), "getClientOs", [], "method")) {
                case "Mac":
                {
                    // line 310
                    echo twig_escape_filter($this->env, ((((((isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new RuntimeError('Variable "alt" does not exist.', 310, $this->source); })())) ? ("⌥") : ("")) . (((isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new RuntimeError('Variable "shift" does not exist.', 310, $this->source); })())) ? ("⇧") : (""))) . "⌘") . (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 310, $this->source); })())), "html", null, true);
                    break;
                }
                default:
                {
                    // line 312
                    echo twig_escape_filter($this->env, ((("Ctrl+" . (((isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new RuntimeError('Variable "alt" does not exist.', 312, $this->source); })())) ? ("Alt+") : (""))) . (((isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new RuntimeError('Variable "shift" does not exist.', 312, $this->source); })())) ? ("Shift+") : (""))) . (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 312, $this->source); })())), "html", null, true);
                }
            }
            craft\helpers\Template::endProfile("macro", "shortcutText");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1538 => 312,  1532 => 310,  1528 => 308,  1512 => 307,  1500 => 304,  1484 => 303,  1472 => 296,  1470 => 294,  1456 => 293,  1444 => 289,  1441 => 288,  1438 => 287,  1435 => 286,  1432 => 283,  1429 => 282,  1427 => 277,  1425 => 276,  1422 => 275,  1419 => 274,  1416 => 273,  1413 => 271,  1410 => 270,  1396 => 269,  1383 => 265,  1380 => 264,  1366 => 263,  1353 => 259,  1350 => 258,  1336 => 257,  1323 => 253,  1321 => 251,  1320 => 250,  1319 => 249,  1317 => 248,  1303 => 247,  1290 => 243,  1287 => 242,  1273 => 241,  1260 => 237,  1258 => 235,  1256 => 233,  1242 => 232,  1229 => 228,  1227 => 226,  1225 => 224,  1211 => 223,  1198 => 219,  1196 => 217,  1194 => 215,  1180 => 214,  1167 => 210,  1165 => 208,  1164 => 207,  1163 => 206,  1162 => 205,  1161 => 204,  1159 => 203,  1157 => 202,  1143 => 201,  1130 => 197,  1127 => 196,  1113 => 195,  1100 => 191,  1097 => 190,  1083 => 189,  1070 => 185,  1067 => 184,  1053 => 183,  1040 => 179,  1034 => 176,  1030 => 175,  1027 => 174,  1024 => 173,  1022 => 171,  1021 => 170,  1019 => 169,  1016 => 168,  1002 => 167,  989 => 163,  986 => 162,  972 => 161,  959 => 157,  956 => 156,  942 => 155,  929 => 151,  926 => 150,  912 => 149,  899 => 145,  896 => 144,  882 => 143,  869 => 139,  866 => 138,  852 => 137,  839 => 133,  836 => 132,  822 => 131,  811 => 127,  808 => 126,  805 => 125,  802 => 124,  800 => 122,  799 => 121,  798 => 120,  796 => 119,  793 => 118,  778 => 117,  767 => 110,  753 => 109,  742 => 105,  728 => 104,  717 => 100,  703 => 99,  692 => 95,  678 => 94,  667 => 90,  653 => 89,  642 => 85,  628 => 84,  617 => 80,  603 => 79,  592 => 75,  578 => 74,  567 => 70,  553 => 69,  542 => 65,  528 => 64,  517 => 60,  503 => 59,  492 => 55,  478 => 54,  467 => 50,  453 => 49,  442 => 45,  428 => 44,  417 => 40,  403 => 39,  392 => 35,  378 => 34,  367 => 30,  353 => 29,  342 => 25,  328 => 24,  317 => 20,  303 => 19,  292 => 15,  278 => 14,  268 => 10,  254 => 9,  243 => 2,  229 => 1,  223 => 306,  219 => 301,  215 => 298,  211 => 291,  207 => 267,  203 => 261,  199 => 255,  195 => 245,  191 => 239,  187 => 230,  183 => 221,  179 => 212,  175 => 199,  171 => 193,  167 => 187,  163 => 181,  159 => 165,  155 => 159,  151 => 153,  147 => 147,  143 => 141,  139 => 135,  135 => 129,  131 => 115,  127 => 112,  123 => 107,  119 => 102,  115 => 97,  111 => 92,  107 => 87,  103 => 82,  99 => 77,  95 => 72,  91 => 67,  87 => 62,  83 => 57,  79 => 52,  75 => 47,  71 => 42,  67 => 37,  63 => 32,  59 => 27,  55 => 22,  51 => 17,  47 => 12,  43 => 7,  39 => 4,);
    }

    public function getSourceContext()
    {
        return new Source("{% macro errorList(errors) %}
    {% include \"_includes/forms/errorList\" %}
{% endmacro %}


{# Inputs #}


{% macro hidden(config) -%}
    {% include \"_includes/forms/hidden\" with config only %}
{%- endmacro %}


{% macro text(config) %}
    {% include \"_includes/forms/text\" with config only %}
{% endmacro %}


{% macro password(config) %}
    {% include \"_includes/forms/password\" with config only %}
{% endmacro %}


{% macro copytext(config) %}
    {% include \"_includes/forms/copytext\" with config only %}
{% endmacro %}


{% macro date(config) %}
    {% include \"_includes/forms/date\" with config only %}
{% endmacro %}


{% macro time(config) %}
    {% include \"_includes/forms/time\" with config only %}
{% endmacro %}


{% macro color(config) %}
    {% include \"_includes/forms/color\" with config only %}
{% endmacro %}


{% macro textarea(config) %}
    {% include \"_includes/forms/textarea\" with config only %}
{% endmacro %}


{% macro select(config) %}
    {% include \"_includes/forms/select\" with config only %}
{% endmacro %}


{% macro multiselect(config) %}
    {% include \"_includes/forms/multiselect\" with config only %}
{% endmacro %}


{% macro checkbox(config) %}
    {% include \"_includes/forms/checkbox\" with config only %}
{% endmacro %}


{% macro checkboxGroup(config) %}
    {% include \"_includes/forms/checkboxGroup\" with config only %}
{% endmacro %}


{% macro checkboxSelect(config) %}
    {% include \"_includes/forms/checkboxSelect\" with config only %}
{% endmacro %}


{% macro radio(config) %}
    {% include \"_includes/forms/radio\" with config only %}
{% endmacro %}


{% macro radioGroup(config) %}
    {% include \"_includes/forms/radioGroup\" with config only %}
{% endmacro %}


{% macro file(config) %}
    {% include \"_includes/forms/file\" with config only %}
{% endmacro %}


{% macro lightswitch(config) %}
    {% include \"_includes/forms/lightswitch\" with config only %}
{% endmacro %}


{% macro editableTable(config) %}
    {% include \"_includes/forms/editableTable\" with config only %}
{% endmacro %}


{% macro elementSelect(config) %}
    {% include \"_includes/forms/elementSelect\" with config only %}
{% endmacro %}


{% macro autosuggest(config) %}
    {% include \"_includes/forms/autosuggest\" with config only %}
{% endmacro %}


{% macro fieldLayoutDesigner(config) %}
    {% include \"_includes/forms/fieldLayoutDesigner\" with config only %}
{% endmacro %}


{# Fields #}


{% macro field(config, input) %}
    {% set id = config.id ?? \"field#{random()}\" %}
    {% set config = config|merge({
        id: id,
        labelId: config.labelId ?? \"#{id}-label\",
        instructionsId: config.instructionsId ?? \"#{id}-instructions\",
    }) %}
    {% if input starts with 'template:' %}
        {% set input = include(input[9:], config) %}
    {% endif %}
    {% include \"_includes/forms/field\" with config|merge({ input: input }) only %}
{% endmacro %}


{% macro textField(config) %}
    {% set config = config|merge({id: config.id ?? \"text#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/text') }}
{% endmacro %}


{% macro copytextField(config) %}
    {% set config = config|merge({id: config.id ?? \"copytext#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/copytext') }}
{% endmacro %}


{% macro passwordField(config) %}
    {% set config = config|merge({id: config.id ?? \"password#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/password') }}
{% endmacro %}


{% macro dateField(config) %}
    {% set config = config|merge({id: config.id ?? \"date#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/date') }}
{% endmacro %}


{% macro timeField(config) %}
    {% set config = config|merge({id: config.id ?? \"time#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/time') }}
{% endmacro %}


{% macro colorField(config) %}
    {% set config = config|merge({id: config.id ?? \"color#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/color') }}
{% endmacro %}


{% macro dateTimeField(config) %}
    {% set id = config.id ?? \"datetime#{random()}\" %}
    {% set config = config|merge({
        id: id,
        instructionsId: config.instructionsId ?? \"#{id}-instructions\",
    }) %}
    {% set input %}
        <div class=\"datetimewrapper\">
            {{ _self.date(config) }}
            {{ _self.time(config) }}
        </div>
    {% endset %}
    {{ _self.field(config, input) }}
{% endmacro %}


{% macro textareaField(config) %}
    {% set config = config|merge({id: config.id ?? \"textarea#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/textarea') }}
{% endmacro %}


{% macro selectField(config) %}
    {% set config = config|merge({id: config.id ?? \"select#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/select') }}
{% endmacro %}


{% macro multiselectField(config) %}
    {% set config = config|merge({id: config.id ?? \"multiselect#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/multiselect') }}
{% endmacro %}


{% macro checkboxField(config) %}
    {# label --> checkboxLabel #}
    {% set config = config|merge({
        fieldset: config.fieldLabel is defined,
        fieldClass: (config.fieldClass ?? [])|explodeClass|push('checkboxfield'),
        id: config.id ?? \"checkbox#{random()}\",
        checkboxLabel: config.label ?? null,
        instructionsPosition: config.instructionsPosition ?? 'after',
    })|withoutKey('label') %}
    {{ _self.field(config, 'template:_includes/forms/checkbox') }}
{% endmacro %}


{% macro checkboxGroupField(config) %}
    {% set config = config|merge({
        fieldset: true,
        id: config.id ?? \"checkboxgroup#{random()}\",
    }) %}
    {{ _self.field(config, 'template:_includes/forms/checkboxGroup') }}
{% endmacro %}


{% macro checkboxSelectField(config) %}
    {% set config = config|merge({
        fieldset: true,
        id: config.id ?? \"checkboxselect#{random()}\",
    }) %}
    {{ _self.field(config, 'template:_includes/forms/checkboxSelect') }}
{% endmacro %}


{% macro radioGroupField(config) %}
    {% set config = config|merge({
        fieldset: true,
        id: config.id ?? \"radiogroup#{random()}\",
    }) %}
    {{ _self.field(config, 'template:_includes/forms/radioGroup') }}
{% endmacro %}


{% macro fileField(config) %}
    {% set config = config|merge({id: config.id ?? \"file#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/file') }}
{% endmacro %}


{% macro lightswitchField(config) %}
    {% set config = config|merge({
        id: config.id ?? \"lightswitch#{random()}\",
        fieldClass: (config.fieldClass ?? [])|explodeClass|push('lightswitch-field'),
        fieldLabel: config.fieldLabel ?? config.label ?? null,
    })|withoutKey('label') %}
    {{ _self.field(config, 'template:_includes/forms/lightswitch') }}
{% endmacro %}


{% macro editableTableField(config) %}
    {% set config = config|merge({id: config.id ?? \"editabletable#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/editableTable') }}
{% endmacro %}


{% macro elementSelectField(config) %}
    {% set config = config|merge({id: config.id ?? \"elementselect#{random()}\"}) %}
    {{ _self.field(config, 'template:_includes/forms/elementSelect') }}
{% endmacro %}


{% macro autosuggestField(config) %}
    {% set config = config|merge({id: config.id ?? \"autosuggest#{random()}\"}) %}

    {# Suggest an environment variable / alias? #}
    {% if (config.suggestEnvVars ?? false) %}
        {% set value = config.value ?? '' %}
        {% if config.tip is not defined and value[0:1] not in ['\$', '@'] %}
            {% set config = config|merge({
                tip: ((config.suggestAliases ?? false)
                    ? 'This can be set to an environment variable, or begin with an alias.'|t('app')
                    : 'This can be set to an environment variable.'|t('app'))
                    ~ ' <a href=\"https://craftcms.com/docs/3.x/config/#environmental-configuration\" class=\"go\">' ~ 'Learn more'|t('app') ~ '</a>'
            }) %}
        {% elseif config.warning is not defined and (value == '@web' or value[0:5] == '@web/') and craft.app.request.isWebAliasSetDynamically %}
            {% set config = config|merge({
                warning: 'The `@web` alias is not recommended if it is determined automatically.'|t('app')
            }) %}
        {% endif %}
    {% endif %}

    {{ _self.field(config, 'template:_includes/forms/autosuggest') }}
{% endmacro %}


{% macro fieldLayoutDesignerField(config) %}
    {{ _self.field({
        label: 'Field Layout'|t('app'),
    }|merge(config), 'template:_includes/forms/fieldLayoutDesigner') }}
{% endmacro %}


{# Other #}


{% macro optionShortcutLabel(key, shift, alt) -%}
    <span class=\"shortcut\">{{ _self.shortcutText(key, shift, alt) }}</span>
{%- endmacro %}

{% macro shortcutText(key, shift, alt) %}
    {%- switch craft.app.request.getClientOs() %}
        {%- case 'Mac' %}
            {{- (alt ? '⌥') ~ (shift ? '⇧') ~ '⌘' ~ key }}
        {%- default %}
            {{- 'Ctrl+' ~ (alt ? 'Alt+') ~ (shift ? 'Shift+') ~ key }}
    {%- endswitch %}
{%- endmacro %}
", "_includes/forms", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms.html");
    }
}
