<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* entries/_edit */
class __TwigTemplate_35e96a1a10054a2963a21b9a1d32f76f39e8da8fad568e1b711748dd113e43ec extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'settings' => [$this, 'block_settings'],
            'meta' => [$this, 'block_meta'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/element";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "entries/_edit");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "entries/_edit", 2)->unwrap();
        // line 4
        $context["isSingle"] = (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 4, $this->source); })()), "type", []) == "single");
        // line 5
        $context["isDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 5, $this->source); })()), "getIsDraft", [], "method");
        // line 6
        $context["isRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 6, $this->source); })()), "getIsRevision", [], "method");
        // line 8
        $context["element"] = (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 8, $this->source); })());
        // line 9
        $context["hasRevisions"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 9, $this->source); })()), "enableVersioning", []);
        // line 10
        $context["redirectUrl"] = ("entries/" . (((isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 10, $this->source); })())) ? ("singles") : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 10, $this->source); })()), "handle", []))));
        // line 11
        $context["saveSourceAction"] = "entries/save-entry";
        // line 12
        $context["duplicateSourceAction"] = "entries/duplicate-entry";
        // line 13
        $context["deleteSourceAction"] = "entries/delete-entry";
        // line 14
        $context["deleteForSiteAction"] = "entries/delete-for-site";
        // line 15
        $context["saveDraftAction"] = "entry-revisions/save-draft";
        // line 16
        $context["deleteDraftAction"] = "entry-revisions/delete-draft";
        // line 17
        $context["publishDraftAction"] = "entry-revisions/publish-draft";
        // line 18
        $context["revertSourceAction"] = "entry-revisions/revert-entry-to-version";
        // line 19
        $context["canUpdateSource"] = ((craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 20, $this->source); })()), "can", [0 => ("publishEntries" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 20, $this->source); })()))], "method") && ((        // line 21
(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 21, $this->source); })()) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 21, $this->source); })()), "authorId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 21, $this->source); })()), "id", []))) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 21, $this->source); })()), "can", [0 => ("publishPeerEntries" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 21, $this->source); })()))], "method"))) && (( !        // line 22
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 22, $this->source); })()) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 22, $this->source); })()), "creatorId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 22, $this->source); })()), "id", []))) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 22, $this->source); })()), "can", [0 => ("publishPeerEntryDrafts" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 22, $this->source); })()))], "method")));
        // line 24
        $context["canDuplicateSource"] = ((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 24, $this->source); })()) &&  !(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 24, $this->source); })()));
        // line 25
        $context["canDeleteDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 25, $this->source); })()), "can", [0 => ("deletePeerEntryDrafts" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 25, $this->source); })()))], "method");
        // line 27
        if (( !(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 27, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 27, $this->source); })()))) {
            // line 28
            $context["nextEntryParams"] = [0 => ("siteId=" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 28, $this->source); })()), "siteId", []))];
            // line 29
            if ((isset($context["showEntryTypes"]) || array_key_exists("showEntryTypes", $context) ? $context["showEntryTypes"] : (function () { throw new RuntimeError('Variable "showEntryTypes" does not exist.', 29, $this->source); })())) {
                // line 30
                $context["nextEntryParams"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["nextEntryParams"]) || array_key_exists("nextEntryParams", $context) ? $context["nextEntryParams"] : (function () { throw new RuntimeError('Variable "nextEntryParams" does not exist.', 30, $this->source); })()), [0 => "typeId={type.id}"]);
            }
            // line 32
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 32, $this->source); })()), "type", []) == "structure")) {
                // line 33
                $context["nextEntryParams"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["nextEntryParams"]) || array_key_exists("nextEntryParams", $context) ? $context["nextEntryParams"] : (function () { throw new RuntimeError('Variable "nextEntryParams" does not exist.', 33, $this->source); })()), [0 => "parentId={parent.id}"]);
            }
            // line 35
            $context["canDuplicateSource"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 35, $this->source); })()), "can", [0 => ("createEntries" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 35, $this->source); })()))], "method");
            // line 36
            $context["canAddAnother"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 36, $this->source); })()), "can", [0 => ("createEntries" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 36, $this->source); })()))], "method");
            // line 37
            $context["addAnotherRedirectUrl"] = ((("entries/" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 37, $this->source); })()), "handle", [])) . "/new?") . twig_join_filter((isset($context["nextEntryParams"]) || array_key_exists("nextEntryParams", $context) ? $context["nextEntryParams"] : (function () { throw new RuntimeError('Variable "nextEntryParams" does not exist.', 37, $this->source); })()), "&"));
        }
        // line 41
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit", $context);

        // line 149
        if (( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 149, $this->source); })()), "slug", []) || twig_in_filter("__temp_", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 149, $this->source); })()), "slug", [])))) {
            // line 150
            ob_start();
            // line 151
            echo "        window.slugGenerator = new Craft.SlugGenerator('#title', '#slug', {
            charMap: ";
            // line 152
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 152, $this->source); })()), "cp", []), "getAsciiCharMap", [0 => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 152, $this->source); })()), "site", []), "language", [])], "method"));
            echo "
        });
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/element", "entries/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "entries/_edit");
    }

    // line 44
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 45
        echo "    ";
        echo craft\helpers\Html::hiddenInput("sectionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 45, $this->source); })()), "id", []));
        echo "
    ";
        // line 46
        $this->displayParentBlock("content", $context, $blocks);
        echo "

    ";
        // line 49
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit.content", $context);

        craft\helpers\Template::endProfile("block", "content");
    }

    // line 52
    public function block_settings($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "settings");
        // line 53
        echo "    ";
        if (( !(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 53, $this->source); })()) && (isset($context["showEntryTypes"]) || array_key_exists("showEntryTypes", $context) ? $context["showEntryTypes"] : (function () { throw new RuntimeError('Variable "showEntryTypes" does not exist.', 53, $this->source); })()))) {
            // line 54
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_selectField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 55
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 55, $this->source); })()), "getAttributeStatus", [0 => "typeId"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry Type", "app"), "id" => "entryType", "name" => "typeId", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 59
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 59, $this->source); })()), "id", []), "options" =>             // line 60
(isset($context["entryTypeOptions"]) || array_key_exists("entryTypeOptions", $context) ? $context["entryTypeOptions"] : (function () { throw new RuntimeError('Variable "entryTypeOptions" does not exist.', 60, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 61
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 61, $this->source); })()), "getErrors", [0 => "typeId"], "method")]], 54, $context, $this->getSourceContext());
            // line 62
            echo "
    ";
        }
        // line 64
        echo "
    ";
        // line 65
        echo twig_call_macro($macros["forms"], "macro_textField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,         // line 66
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 66, $this->source); })()), "getAttributeStatus", [0 => "slug"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Slug", "app"), "siteId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 68
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 68, $this->source); })()), "siteId", []), "translationDescription" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site.", "app"), "id" => "slug", "name" => "slug", "autocorrect" => false, "autocapitalize" => false, "value" => ((twig_in_filter("__temp_", craft\helpers\Template::attribute($this->env, $this->source,         // line 74
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 74, $this->source); })()), "slug", []))) ? ("") : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 74, $this->source); })()), "slug", []))), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enter slug", "app"), "errors" => (( !        // line 76
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 76, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 76, $this->source); })()), "getErrors", [0 => "slug"], "method"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 76, $this->source); })()), "getErrors", [0 => "uri"], "method"))) : ("")), "disabled" =>         // line 77
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 77, $this->source); })())]], 65, $context, $this->getSourceContext());
        // line 78
        echo "

    ";
        // line 80
        if ( !(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 80, $this->source); })())) {
            // line 81
            echo "        ";
            if ((isset($context["parentOptionCriteria"]) || array_key_exists("parentOptionCriteria", $context))) {
                // line 82
                echo "            ";
                echo twig_call_macro($macros["forms"], "macro_elementSelectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Parent", "app"), "id" => "parentId", "name" => "parentId", "elementType" =>                 // line 86
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 86, $this->source); })()), "selectionLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"), "sources" => [0 => ("section:" . craft\helpers\Template::attribute($this->env, $this->source,                 // line 88
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 88, $this->source); })()), "uid", []))], "criteria" =>                 // line 89
(isset($context["parentOptionCriteria"]) || array_key_exists("parentOptionCriteria", $context) ? $context["parentOptionCriteria"] : (function () { throw new RuntimeError('Variable "parentOptionCriteria" does not exist.', 89, $this->source); })()), "limit" => 1, "elements" => (((                // line 91
(isset($context["parent"]) || array_key_exists("parent", $context)) && (isset($context["parent"]) || array_key_exists("parent", $context) ? $context["parent"] : (function () { throw new RuntimeError('Variable "parent" does not exist.', 91, $this->source); })()))) ? ([0 => (isset($context["parent"]) || array_key_exists("parent", $context) ? $context["parent"] : (function () { throw new RuntimeError('Variable "parent" does not exist.', 91, $this->source); })())]) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 92
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 92, $this->source); })()), "getErrors", [0 => "parent"], "method")]], 82, $context, $this->getSourceContext());
                // line 93
                echo "
        ";
            }
            // line 95
            echo "
        ";
            // line 96
            if ((((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 96, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 96, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 96, $this->source); })()), "can", [0 => ("editPeerEntries" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 96, $this->source); })()))], "method"))) {
                // line 97
                echo "            ";
                echo twig_call_macro($macros["forms"], "macro_elementSelectField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 98
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 98, $this->source); })()), "getAttributeStatus", [0 => "authorId"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Author", "app"), "id" => "author", "name" => "author", "elementType" =>                 // line 102
(isset($context["userElementType"]) || array_key_exists("userElementType", $context) ? $context["userElementType"] : (function () { throw new RuntimeError('Variable "userElementType" does not exist.', 102, $this->source); })()), "selectionLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"), "criteria" =>                 // line 104
(isset($context["authorOptionCriteria"]) || array_key_exists("authorOptionCriteria", $context) ? $context["authorOptionCriteria"] : (function () { throw new RuntimeError('Variable "authorOptionCriteria" does not exist.', 104, $this->source); })()), "limit" => 1, "elements" => (((                // line 106
(isset($context["author"]) || array_key_exists("author", $context)) && (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 106, $this->source); })()))) ? ([0 => (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 106, $this->source); })())]) : (""))]], 97, $context, $this->getSourceContext());
                // line 107
                echo "
        ";
            }
            // line 109
            echo "
        ";
            // line 110
            echo twig_call_macro($macros["forms"], "macro_dateTimeField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 111
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 111, $this->source); })()), "getAttributeStatus", [0 => "postDate"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Post Date", "app"), "id" => "postDate", "name" => "postDate", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 115
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 115, $this->source); })()), "postDate", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 115, $this->source); })()), "postDate", [])) : (null)), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 116
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 116, $this->source); })()), "getErrors", [0 => "postDate"], "method"), "disabled" =>             // line 117
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 117, $this->source); })())]], 110, $context, $this->getSourceContext());
            // line 118
            echo "

        ";
            // line 120
            echo twig_call_macro($macros["forms"], "macro_dateTimeField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 121
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 121, $this->source); })()), "getAttributeStatus", [0 => "expiryDate"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Expiry Date", "app"), "id" => "expiryDate", "name" => "expiryDate", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 125
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 125, $this->source); })()), "expiryDate", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 125, $this->source); })()), "expiryDate", [])) : (null)), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 126
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 126, $this->source); })()), "getErrors", [0 => "expiryDate"], "method"), "disabled" =>             // line 127
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 127, $this->source); })())]], 120, $context, $this->getSourceContext());
            // line 128
            echo "
    ";
        }
        // line 130
        echo "
    ";
        // line 131
        $this->displayParentBlock("settings", $context, $blocks);
        echo "
    ";
        // line 133
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit.settings", $context);

        craft\helpers\Template::endProfile("block", "settings");
    }

    // line 136
    public function block_meta($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "meta");
        // line 137
        echo "    ";
        $this->displayParentBlock("meta", $context, $blocks);
        echo "
    ";
        // line 139
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit.meta", $context);

        craft\helpers\Template::endProfile("block", "meta");
    }

    // line 142
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 143
        echo "    ";
        $this->displayParentBlock("details", $context, $blocks);
        echo "
    ";
        // line 145
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit.details", $context);

        craft\helpers\Template::endProfile("block", "details");
    }

    public function getTemplateName()
    {
        return "entries/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  281 => 145,  276 => 143,  271 => 142,  264 => 139,  259 => 137,  254 => 136,  247 => 133,  243 => 131,  240 => 130,  236 => 128,  234 => 127,  233 => 126,  232 => 125,  231 => 121,  230 => 120,  226 => 118,  224 => 117,  223 => 116,  222 => 115,  221 => 111,  220 => 110,  217 => 109,  213 => 107,  211 => 106,  210 => 104,  209 => 102,  208 => 98,  206 => 97,  204 => 96,  201 => 95,  197 => 93,  195 => 92,  194 => 91,  193 => 89,  192 => 88,  191 => 86,  189 => 82,  186 => 81,  184 => 80,  180 => 78,  178 => 77,  177 => 76,  176 => 74,  175 => 68,  174 => 66,  173 => 65,  170 => 64,  166 => 62,  164 => 61,  163 => 60,  162 => 59,  161 => 55,  159 => 54,  156 => 53,  151 => 52,  144 => 49,  139 => 46,  134 => 45,  129 => 44,  123 => 1,  116 => 152,  113 => 151,  111 => 150,  109 => 149,  106 => 41,  103 => 37,  101 => 36,  99 => 35,  96 => 33,  94 => 32,  91 => 30,  89 => 29,  87 => 28,  85 => 27,  83 => 25,  81 => 24,  79 => 22,  78 => 21,  77 => 20,  76 => 19,  74 => 18,  72 => 17,  70 => 16,  68 => 15,  66 => 14,  64 => 13,  62 => 12,  60 => 11,  58 => 10,  56 => 9,  54 => 8,  52 => 6,  50 => 5,  48 => 4,  46 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/element\" %}
{% import \"_includes/forms\" as forms %}

{% set isSingle = section.type == 'single' %}
{% set isDraft = entry.getIsDraft() %}
{% set isRevision = entry.getIsRevision() %}

{% set element = entry %}
{% set hasRevisions = section.enableVersioning %}
{% set redirectUrl = 'entries/' ~ (isSingle ? 'singles' : section.handle) %}
{% set saveSourceAction = 'entries/save-entry' %}
{% set duplicateSourceAction = 'entries/duplicate-entry' %}
{% set deleteSourceAction = 'entries/delete-entry' %}
{% set deleteForSiteAction = 'entries/delete-for-site' %}
{% set saveDraftAction = 'entry-revisions/save-draft' %}
{% set deleteDraftAction = 'entry-revisions/delete-draft' %}
{% set publishDraftAction = 'entry-revisions/publish-draft' %}
{% set revertSourceAction = 'entry-revisions/revert-entry-to-version' %}
{% set canUpdateSource = (
    currentUser.can('publishEntries'~permissionSuffix) and
    (isSingle or entry.authorId == currentUser.id or currentUser.can('publishPeerEntries'~permissionSuffix)) and
    (not isDraft or entry.creatorId == currentUser.id or currentUser.can('publishPeerEntryDrafts'~permissionSuffix))
) %}
{% set canDuplicateSource = canUpdateSource and not isSingle %}
{% set canDeleteDraft = currentUser.can('deletePeerEntryDrafts'~permissionSuffix) %}

{% if not isSingle and canUpdateSource %}
    {% set nextEntryParams = [\"siteId=#{entry.siteId}\"] %}
    {% if showEntryTypes %}
        {% set nextEntryParams = nextEntryParams|merge(['typeId={type.id}']) %}
    {% endif %}
    {% if section.type == 'structure' %}
        {% set nextEntryParams = nextEntryParams|merge(['parentId={parent.id}']) %}
    {% endif %}
    {% set canDuplicateSource = currentUser.can(\"createEntries#{permissionSuffix}\") %}
    {% set canAddAnother = currentUser.can(\"createEntries#{permissionSuffix}\") %}
    {% set addAnotherRedirectUrl = \"entries/#{section.handle}/new?\" ~ nextEntryParams|join('&') %}
{% endif %}


{% hook \"cp.entries.edit\" %}


{% block content %}
    {{ hiddenInput('sectionId', section.id) }}
    {{ parent() }}

    {# Give plugins a chance to add other things here #}
    {% hook \"cp.entries.edit.content\" %}
{% endblock %}

{% block settings %}
    {% if not isSingle and showEntryTypes %}
        {{ forms.selectField({
            status: entry.getAttributeStatus('typeId'),
            label: \"Entry Type\"|t('app'),
            id: 'entryType',
            name: 'typeId',
            value: entryType.id,
            options: entryTypeOptions,
            errors: entry.getErrors('typeId'),
        }) }}
    {% endif %}

    {{ forms.textField({
        status: entry.getAttributeStatus('slug'),
        label: \"Slug\"|t('app'),
        siteId: entry.siteId,
        translationDescription: 'This field is translated for each site.'|t('app'),
        id: 'slug',
        name: 'slug',
        autocorrect: false,
        autocapitalize: false,
        value: '__temp_' in entry.slug ? '' : entry.slug,
        placeholder: \"Enter slug\"|t('app'),
        errors: (not isRevision ? entry.getErrors('slug')|merge(entry.getErrors('uri'))),
        disabled: isRevision
    }) }}

    {% if not isSingle %}
        {% if parentOptionCriteria is defined %}
            {{ forms.elementSelectField({
                label: \"Parent\"|t('app'),
                id: 'parentId',
                name: 'parentId',
                elementType: elementType,
                selectionLabel: \"Choose\"|t('app'),
                sources: ['section:'~section.uid],
                criteria: parentOptionCriteria,
                limit: 1,
                elements: (parent is defined and parent ? [parent]),
                errors: entry.getErrors('parent')
            }) }}
        {% endif %}

        {% if CraftEdition == CraftPro and currentUser.can('editPeerEntries'~permissionSuffix) %}
            {{ forms.elementSelectField({
                status: entry.getAttributeStatus('authorId'),
                label: \"Author\"|t('app'),
                id: 'author',
                name: 'author',
                elementType: userElementType,
                selectionLabel: \"Choose\"|t('app'),
                criteria: authorOptionCriteria,
                limit: 1,
                elements: (author is defined and author ? [author])
            }) }}
        {% endif %}

        {{ forms.dateTimeField({
            status: entry.getAttributeStatus('postDate'),
            label: \"Post Date\"|t('app'),
            id: 'postDate',
            name: 'postDate',
            value: (entry.postDate ? entry.postDate : null),
            errors: entry.getErrors('postDate'),
            disabled: isRevision
        }) }}

        {{ forms.dateTimeField({
            status: entry.getAttributeStatus('expiryDate'),
            label: \"Expiry Date\"|t('app'),
            id: 'expiryDate',
            name: 'expiryDate',
            value: (entry.expiryDate ? entry.expiryDate : null),
            errors: entry.getErrors('expiryDate'),
            disabled: isRevision
        }) }}
    {% endif %}

    {{ parent() }}
    {# Give plugins a chance to add other things here #}
    {% hook \"cp.entries.edit.settings\" %}
{% endblock %}

{% block meta %}
    {{ parent() }}
    {# Give plugins a chance to add other things here #}
    {% hook \"cp.entries.edit.meta\" %}
{% endblock %}

{% block details %}
    {{ parent() }}
    {# Give plugins a chance to add other things here #}
    {% hook \"cp.entries.edit.details\" %}
{% endblock %}


{% if not entry.slug or '__temp_' in entry.slug %}
    {% js %}
        window.slugGenerator = new Craft.SlugGenerator('#title', '#slug', {
            charMap: {{ craft.cp.getAsciiCharMap(entry.site.language)|json_encode|raw }}
        });
    {% endjs %}
{% endif %}
", "entries/_edit", "/var/www/html/vendor/craftcms/cms/src/templates/entries/_edit.html");
    }
}
