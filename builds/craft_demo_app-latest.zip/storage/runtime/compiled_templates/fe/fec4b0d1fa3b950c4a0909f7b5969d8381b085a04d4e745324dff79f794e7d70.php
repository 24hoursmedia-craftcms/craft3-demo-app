<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/cp */
class __TwigTemplate_813f140acdb785d7ea81662aa2d6e544d3f1f3d985d03dad4f9db42f71ec6a53 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'mainFormAttributes' => [$this, 'block_mainFormAttributes'],
            'header' => [$this, 'block_header'],
            'pageTitle' => [$this, 'block_pageTitle'],
            'contextMenu' => [$this, 'block_contextMenu'],
            'main' => [$this, 'block_main'],
            'tabs' => [$this, 'block_tabs'],
            'content' => [$this, 'block_content'],
            'actionButton' => [$this, 'block_actionButton'],
            'submitButton' => [$this, 'block_submitButton'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 42
        return "_layouts/basecp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/cp");
        // line 45
        $context["queue"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 45, $this->source); })()), "app", []), "queue", []);
        // line 46
        ob_start();
        // line 47
        echo "    ";
        if (call_user_func_array($this->env->getTest('instance of')->getCallable(), [(isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 47, $this->source); })()), "craft\\queue\\QueueInterface"])) {
            // line 48
            echo "        Craft.cp.setJobInfo(";
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 48, $this->source); })()), "getJobInfo", [0 => 100], "method"));
            echo ", false);
        ";
            // line 49
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 49, $this->source); })()), "getHasReservedJobs", [], "method")) {
                // line 50
                echo "            Craft.cp.trackJobProgress(true);
        ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 51
(isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 51, $this->source); })()), "getHasWaitingJobs", [], "method")) {
                // line 52
                echo "            Craft.cp.runQueue();
        ";
            }
            // line 54
            echo "    ";
        } else {
            // line 55
            echo "        Craft.cp.enableQueue = false;
    ";
        }
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 59
        $context["hasSystemIcon"] = (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 59, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 59, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 59, $this->source); })()), "rebrand", []), "isIconUploaded", []));
        // line 60
        $context["fullPageForm"] = ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context)) && (isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 60, $this->source); })()));
        // line 62
        $context["editionName"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 62, $this->source); })()), "app", []), "getEditionName", [], "method");
        // line 63
        $context["canUpgradeEdition"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 63, $this->source); })()), "app", []), "getCanUpgradeEdition", [], "method");
        // line 64
        $context["licensedEdition"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 64, $this->source); })()), "app", []), "getLicensedEdition", [], "method");
        // line 65
        $context["isTrial"] = ( !((isset($context["licensedEdition"]) || array_key_exists("licensedEdition", $context) ? $context["licensedEdition"] : (function () { throw new RuntimeError('Variable "licensedEdition" does not exist.', 65, $this->source); })()) === null) &&  !((isset($context["licensedEdition"]) || array_key_exists("licensedEdition", $context) ? $context["licensedEdition"] : (function () { throw new RuntimeError('Variable "licensedEdition" does not exist.', 65, $this->source); })()) === (isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 65, $this->source); })())));
        // line 67
        $context["sidebar"] = twig_trim_filter((($context["sidebar"]) ?? (((        $this->hasBlock("sidebar", $context, $blocks)) ? (        $this->renderBlock("sidebar", $context, $blocks)) : ("")))));
        // line 68
        $context["toolbar"] = twig_trim_filter((($context["toolbar"]) ?? (((        $this->hasBlock("toolbar", $context, $blocks)) ? (        $this->renderBlock("toolbar", $context, $blocks)) : ("")))));
        // line 69
        $context["actionButton"] = twig_trim_filter(((        $this->hasBlock("actionButton", $context, $blocks)) ? (        $this->renderBlock("actionButton", $context, $blocks)) : ("")));
        // line 70
        $context["details"] = twig_trim_filter((($context["details"]) ?? (((        $this->hasBlock("details", $context, $blocks)) ? (        $this->renderBlock("details", $context, $blocks)) : ("")))));
        // line 71
        $context["footer"] = twig_trim_filter((($context["footer"]) ?? (((        $this->hasBlock("footer", $context, $blocks)) ? (        $this->renderBlock("footer", $context, $blocks)) : ("")))));
        // line 72
        $context["crumbs"] = (($context["crumbs"]) ?? (null));
        // line 73
        $context["tabs"] = ((((isset($context["tabs"]) || array_key_exists("tabs", $context)) && (twig_length_filter($this->env, (isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 73, $this->source); })())) != 1))) ? ((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 73, $this->source); })())) : (null));
        // line 75
        $context["mainContentClasses"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((        // line 76
(isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 76, $this->source); })())) ? ("has-sidebar") : ("")), 1 => ((        // line 77
(isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 77, $this->source); })())) ? ("has-details") : ("")), 2 => ((        // line 78
(isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 78, $this->source); })())) ? ("has-tabs") : (""))]);
        // line 81
        $context["showHeader"] = (($context["showHeader"]) ?? (true));
        // line 82
        if ( !(isset($context["showHeader"]) || array_key_exists("showHeader", $context) ? $context["showHeader"] : (function () { throw new RuntimeError('Variable "showHeader" does not exist.', 82, $this->source); })())) {
            // line 83
            $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->pushFilter(craft\helpers\Html::explodeClass((($context["bodyClass"]) ?? ([]))), "no-header");
        }
        // line 86
        $context["mainAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => "main", "role" => "main"], ((        // line 89
$context["mainAttributes"]) ?? ([])));
        // line 91
        $context["mainFormAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => "main-form", "method" => "post", "accept-charset" => "UTF-8", "novalidate" => true, "data" => ["saveshortcut" => ((        // line 97
$context["saveShortcut"]) ?? (true)), "saveshortcut-redirect" => ((((        // line 98
$context["saveShortcutRedirect"]) ?? (false))) ? (call_user_func_array($this->env->getFilter('hash')->getCallable(), [(isset($context["saveShortcutRedirect"]) || array_key_exists("saveShortcutRedirect", $context) ? $context["saveShortcutRedirect"] : (function () { throw new RuntimeError('Variable "saveShortcutRedirect" does not exist.', 98, $this->source); })())])) : (false)), "saveshortcut-scroll" => ((        // line 99
$context["retainScrollOnSaveShortcut"]) ?? (false)), "actions" => ((        // line 100
$context["formActions"]) ?? (false)), "confirm-unload" => true, "delta" => craft\helpers\Template::attribute($this->env, $this->source,         // line 102
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 102, $this->source); })()), "getIsDeltaRegistrationActive", [], "method")]], ((        // line 104
$context["mainFormAttributes"]) ?? ([])), true);
        // line 106
        ob_start();
        // line 107
        echo "    <div class=\"header-photo\">
        ";
        // line 108
        echo $this->extensions['craft\web\twig\Extension']->tagFunction("img", ["width" => 30, "height" => 30, "sizes" => "30px", "srcset" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 112
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 112, $this->source); })()), "getThumbUrl", [0 => 30], "method") . " 30w, ") . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 112, $this->source); })()), "getThumbUrl", [0 => 60], "method")) . " 60w"), "alt" => craft\helpers\Template::attribute($this->env, $this->source,         // line 113
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 113, $this->source); })()), "getName", [], "method")]);
        // line 114
        echo "
    </div>
";
        $context["userPhoto"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 281
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 281, $this->source); })()), "can", [0 => "performUpdates"], "method") &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 281, $this->source); })()), "app", []), "updates", []), "getIsUpdateInfoCached", [], "method"))) {
            // line 282
            ob_start();
            // line 283
            echo "        Craft.cp.checkForUpdates();
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 42
        $this->parent = $this->loadTemplate("_layouts/basecp", "_layouts/cp", 42);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_layouts/cp");
    }

    // line 118
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 119
        echo "    <div id=\"global-container\">
        ";
        // line 120
        $this->loadTemplate("_layouts/components/global-sidebar", "_layouts/cp", 120)->display($context);
        // line 121
        echo "
        <div id=\"page-container\">
            ";
        // line 123
        $this->loadTemplate("_layouts/components/alerts", "_layouts/cp", 123)->display($context);
        // line 124
        echo "            ";
        $this->loadTemplate("_layouts/components/notifications", "_layouts/cp", 124)->display($context);
        // line 125
        echo "
            <div id=\"global-header\" role=\"region\" aria-label=\"";
        // line 126
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "\">
                <div class=\"flex\">
                    ";
        // line 128
        $this->loadTemplate("_layouts/components/crumbs", "_layouts/cp", 128)->display($context);
        // line 129
        echo "                    <div class=\"flex-grow\"></div>
                    <button type=\"button\" id=\"user-info\" class=\"btn menubtn\" aria-label=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "\" title=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "\" data-menu-anchor=\".header-photo\">
                        ";
        // line 131
        echo twig_escape_filter($this->env, (isset($context["userPhoto"]) || array_key_exists("userPhoto", $context) ? $context["userPhoto"] : (function () { throw new RuntimeError('Variable "userPhoto" does not exist.', 131, $this->source); })()), "html", null, true);
        echo "
                    </button>
                    <div class=\"menu\" data-align=\"right\">
                        <ul>
                            <li>
                                <a href=\"";
        // line 136
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("myaccount"), "html", null, true);
        echo "\" class=\"flex flex-nowrap\">
                                    ";
        // line 137
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 137, $this->source); })()), "photoId", [])) {
            // line 138
            echo "                                        ";
            echo twig_escape_filter($this->env, (isset($context["userPhoto"]) || array_key_exists("userPhoto", $context) ? $context["userPhoto"] : (function () { throw new RuntimeError('Variable "userPhoto" does not exist.', 138, $this->source); })()), "html", null, true);
            echo "
                                    ";
        }
        // line 140
        echo "                                    <div class=\"flex-grow\">
                                        <div>";
        // line 141
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 141, $this->source); })()), "username", []), "html", null, true);
        echo "</div>
                                        ";
        // line 142
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 142, $this->source); })()), "app", []), "config", []), "general", []), "useEmailAsUsername", [])) {
            // line 143
            echo "                                            <div class=\"light smalltext\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 143, $this->source); })()), "email", []), "html", null, true);
            echo "</div>
                                        ";
        }
        // line 145
        echo "                                    </div>
                                </a>
                            </li>
                        </ul>
                        <hr>
                        <ul>
                            <li><a href=\"";
        // line 151
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("logout"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign out", "app"), "html", null, true);
        echo "</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">
                <main ";
        // line 158
        echo craft\helpers\Html::renderTagAttributes((isset($context["mainAttributes"]) || array_key_exists("mainAttributes", $context) ? $context["mainAttributes"] : (function () { throw new RuntimeError('Variable "mainAttributes" does not exist.', 158, $this->source); })()));
        echo ">

                    ";
        // line 160
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 160, $this->source); })())) {
            // line 161
            echo "<form ";
            $this->displayBlock('mainFormAttributes', $context, $blocks);
            echo ">";
            // line 162
            echo craft\helpers\Html::csrfInput();
        }
        // line 164
        echo "
                    ";
        // line 165
        if ((isset($context["showHeader"]) || array_key_exists("showHeader", $context) ? $context["showHeader"] : (function () { throw new RuntimeError('Variable "showHeader" does not exist.', 165, $this->source); })())) {
            // line 166
            echo "                        <div id=\"header-container\">
                            <header id=\"header\">
                                ";
            // line 168
            $this->displayBlock('header', $context, $blocks);
            // line 188
            echo "                            </header><!-- #header -->
                        </div>
                    ";
        }
        // line 191
        echo "
                    <div id=\"main-content\" class=\"";
        // line 192
        echo twig_escape_filter($this->env, twig_join_filter((isset($context["mainContentClasses"]) || array_key_exists("mainContentClasses", $context) ? $context["mainContentClasses"] : (function () { throw new RuntimeError('Variable "mainContentClasses" does not exist.', 192, $this->source); })()), " "), "html", null, true);
        echo "\">
                        ";
        // line 194
        echo "                        ";
        if ((isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 194, $this->source); })())) {
            // line 195
            echo "                            <div id=\"sidebar-toggle-container\">
                                <button type=\"button\" id=\"sidebar-toggle\" class=\"btn menubtn\"><span id=\"selected-sidebar-item-label\"></span></button>
                            </div>
                            <div id=\"sidebar-container\">
                                <div id=\"sidebar\" class=\"sidebar\">
                                    ";
            // line 200
            echo (isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 200, $this->source); })());
            echo "
                                </div>
                            </div>
                        ";
        }
        // line 204
        echo "
                        ";
        // line 206
        echo "                        <div id=\"content-container\">
                            ";
        // line 207
        $this->displayBlock('main', $context, $blocks);
        // line 227
        echo "                        </div><!-- #content-container -->

                        ";
        // line 229
        if ( !twig_test_empty((isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 229, $this->source); })()))) {
            // line 230
            echo "                            <div id=\"details-container\">
                                <div id=\"details\">
                                    ";
            // line 232
            echo (isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 232, $this->source); })());
            echo "
                                </div>
                            </div>
                        ";
        }
        // line 236
        echo "                    </div><!-- #main-content -->

                    ";
        // line 238
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 238, $this->source); })())) {
            // line 239
            echo "</form><!-- #main-form -->";
        }
        // line 241
        echo "                </main><!-- #main -->
            </div><!-- #main-container -->

            <footer id=\"global-footer\">
                <div id=\"edition-logo\" title=\"";
        // line 245
        echo twig_escape_filter($this->env, ($this->extensions['craft\web\twig\Extension']->translateFilter("{edition} edition", "app", ["edition" => (isset($context["editionName"]) || array_key_exists("editionName", $context) ? $context["editionName"] : (function () { throw new RuntimeError('Variable "editionName" does not exist.', 245, $this->source); })())]) . (((isset($context["isTrial"]) || array_key_exists("isTrial", $context) ? $context["isTrial"] : (function () { throw new RuntimeError('Variable "isTrial" does not exist.', 245, $this->source); })())) ? ((" " . $this->extensions['craft\web\twig\Extension']->translateFilter("(trial)", "app"))) : (""))), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, ($this->extensions['craft\web\twig\Extension']->translateFilter("{edition} edition", "app", ["edition" => (isset($context["editionName"]) || array_key_exists("editionName", $context) ? $context["editionName"] : (function () { throw new RuntimeError('Variable "editionName" does not exist.', 245, $this->source); })())]) . (((isset($context["isTrial"]) || array_key_exists("isTrial", $context) ? $context["isTrial"] : (function () { throw new RuntimeError('Variable "isTrial" does not exist.', 245, $this->source); })())) ? ((" " . $this->extensions['craft\web\twig\Extension']->translateFilter("(trial)", "app"))) : (""))), "html", null, true);
        echo "\">
                    <div class=\"edition-name\">";
        // line 246
        echo twig_escape_filter($this->env, (isset($context["editionName"]) || array_key_exists("editionName", $context) ? $context["editionName"] : (function () { throw new RuntimeError('Variable "editionName" does not exist.', 246, $this->source); })()), "html", null, true);
        echo "</div>
                    ";
        // line 247
        if ((isset($context["isTrial"]) || array_key_exists("isTrial", $context) ? $context["isTrial"] : (function () { throw new RuntimeError('Variable "isTrial" does not exist.', 247, $this->source); })())) {
            // line 248
            echo "                        <div class=\"edition-trial\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Trial", "app"), "html", null, true);
            echo "</div>
                    ";
        }
        // line 250
        echo "                </div>
                <ul id=\"app-info\">
                    <li>Craft CMS ";
        // line 252
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 252, $this->source); })()), "app", []), "version", []), "html", null, true);
        echo "</li>
                    ";
        // line 253
        if ((isset($context["canUpgradeEdition"]) || array_key_exists("canUpgradeEdition", $context) ? $context["canUpgradeEdition"] : (function () { throw new RuntimeError('Variable "canUpgradeEdition" does not exist.', 253, $this->source); })())) {
            // line 254
            echo "                        <li>
                            <a class=\"go\" href=\"";
            // line 255
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("plugin-store/upgrade-craft"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (((isset($context["isTrial"]) || array_key_exists("isTrial", $context) ? $context["isTrial"] : (function () { throw new RuntimeError('Variable "isTrial" does not exist.', 255, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Buy Craft Pro", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Upgrade to Craft Pro", "app"))), "html", null, true);
            echo "</a>
                        </li>
                    ";
        }
        // line 258
        echo "                </ul>
            </footer>

        </div><!-- #page-container -->
    </div><!-- #global-container -->
";
        craft\helpers\Template::endProfile("block", "body");
    }

    // line 161
    public function block_mainFormAttributes($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "mainFormAttributes");
        echo craft\helpers\Html::renderTagAttributes((isset($context["mainFormAttributes"]) || array_key_exists("mainFormAttributes", $context) ? $context["mainFormAttributes"] : (function () { throw new RuntimeError('Variable "mainFormAttributes" does not exist.', 161, $this->source); })()));
        craft\helpers\Template::endProfile("block", "mainFormAttributes");
    }

    // line 168
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "header");
        // line 169
        echo "                                    <div id=\"page-title\" class=\"flex flex-nowrap";
        if ((isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 169, $this->source); })())) {
            echo " has-toolbar";
        }
        echo "\">
                                        ";
        // line 170
        $this->displayBlock('pageTitle', $context, $blocks);
        // line 175
        echo "                                        ";
        $this->displayBlock('contextMenu', $context, $blocks);
        // line 176
        echo "                                    </div>
                                    ";
        // line 177
        if ((isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 177, $this->source); })())) {
            // line 178
            echo "                                        <div id=\"toolbar\" class=\"flex flex-nowrap\">
                                            ";
            // line 179
            echo (isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 179, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 182
        echo "                                    ";
        if ((isset($context["actionButton"]) || array_key_exists("actionButton", $context) ? $context["actionButton"] : (function () { throw new RuntimeError('Variable "actionButton" does not exist.', 182, $this->source); })())) {
            // line 183
            echo "                                        <div id=\"action-button\" class=\"flex\">
                                            ";
            // line 184
            echo (isset($context["actionButton"]) || array_key_exists("actionButton", $context) ? $context["actionButton"] : (function () { throw new RuntimeError('Variable "actionButton" does not exist.', 184, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 187
        echo "                                ";
        craft\helpers\Template::endProfile("block", "header");
    }

    // line 170
    public function block_pageTitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "pageTitle");
        // line 171
        echo "                                            ";
        if (((isset($context["title"]) || array_key_exists("title", $context)) && twig_length_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 171, $this->source); })())))) {
            // line 172
            echo "                                                <h1 title=\"";
            echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 172, $this->source); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 172, $this->source); })()), "html", null, true);
            echo "</h1>
                                            ";
        }
        // line 174
        echo "                                        ";
        craft\helpers\Template::endProfile("block", "pageTitle");
    }

    // line 175
    public function block_contextMenu($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "contextMenu");
        craft\helpers\Template::endProfile("block", "contextMenu");
    }

    // line 207
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 208
        echo "                                ";
        $this->displayBlock('tabs', $context, $blocks);
        // line 213
        echo "
                                <div id=\"content\" class=\"content-pane\">
                                    ";
        // line 215
        $this->displayBlock('content', $context, $blocks);
        // line 218
        echo "
                                    ";
        // line 220
        echo "                                    ";
        if ((isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 220, $this->source); })())) {
            // line 221
            echo "                                        <div id=\"footer\" class=\"flex\">
                                            ";
            // line 222
            echo (isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 222, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 225
        echo "                                </div>
                            ";
        craft\helpers\Template::endProfile("block", "main");
    }

    // line 208
    public function block_tabs($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "tabs");
        // line 209
        echo "                                    ";
        if ((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 209, $this->source); })())) {
            // line 210
            echo "                                        ";
            $this->loadTemplate("_includes/tabs", "_layouts/cp", 210)->display($context);
            // line 211
            echo "                                    ";
        }
        // line 212
        echo "                                ";
        craft\helpers\Template::endProfile("block", "tabs");
    }

    // line 215
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 216
        echo "                                        ";
        (((isset($context["content"]) || array_key_exists("content", $context))) ? (print (twig_escape_filter($this->env, (isset($context["content"]) || array_key_exists("content", $context) ? $context["content"] : (function () { throw new RuntimeError('Variable "content" does not exist.', 216, $this->source); })()), "html", null, true))) : (print ("")));
        echo "
                                    ";
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 266
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 267
        echo "    ";
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 267, $this->source); })())) {
            // line 268
            echo "        <div class=\"btngroup\">
            ";
            // line 269
            $this->displayBlock('submitButton', $context, $blocks);
            // line 272
            echo "            ";
            if ((($context["formActions"]) ?? (false))) {
                // line 273
                echo "                <button type=\"button\" class=\"btn submit menubtn\"></button>
                ";
                // line 274
                $this->loadTemplate("_layouts/components/form-action-menu", "_layouts/cp", 274)->display($context);
                // line 275
                echo "            ";
            }
            // line 276
            echo "        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 269
    public function block_submitButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "submitButton");
        // line 270
        echo "                <button type=\"submit\" class=\"btn submit\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
        echo "</button>
            ";
        craft\helpers\Template::endProfile("block", "submitButton");
    }

    public function getTemplateName()
    {
        return "_layouts/cp";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  586 => 270,  581 => 269,  574 => 276,  571 => 275,  569 => 274,  566 => 273,  563 => 272,  561 => 269,  558 => 268,  555 => 267,  550 => 266,  542 => 216,  537 => 215,  532 => 212,  529 => 211,  526 => 210,  523 => 209,  518 => 208,  512 => 225,  506 => 222,  503 => 221,  500 => 220,  497 => 218,  495 => 215,  491 => 213,  488 => 208,  483 => 207,  475 => 175,  470 => 174,  462 => 172,  459 => 171,  454 => 170,  449 => 187,  443 => 184,  440 => 183,  437 => 182,  431 => 179,  428 => 178,  426 => 177,  423 => 176,  420 => 175,  418 => 170,  411 => 169,  406 => 168,  397 => 161,  387 => 258,  379 => 255,  376 => 254,  374 => 253,  370 => 252,  366 => 250,  360 => 248,  358 => 247,  354 => 246,  348 => 245,  342 => 241,  339 => 239,  337 => 238,  333 => 236,  326 => 232,  322 => 230,  320 => 229,  316 => 227,  314 => 207,  311 => 206,  308 => 204,  301 => 200,  294 => 195,  291 => 194,  287 => 192,  284 => 191,  279 => 188,  277 => 168,  273 => 166,  271 => 165,  268 => 164,  265 => 162,  261 => 161,  259 => 160,  254 => 158,  242 => 151,  234 => 145,  228 => 143,  226 => 142,  222 => 141,  219 => 140,  213 => 138,  211 => 137,  207 => 136,  199 => 131,  193 => 130,  190 => 129,  188 => 128,  183 => 126,  180 => 125,  177 => 124,  175 => 123,  171 => 121,  169 => 120,  166 => 119,  161 => 118,  155 => 42,  150 => 283,  148 => 282,  146 => 281,  141 => 114,  139 => 113,  138 => 112,  137 => 108,  134 => 107,  132 => 106,  130 => 104,  129 => 102,  128 => 100,  127 => 99,  126 => 98,  125 => 97,  124 => 91,  122 => 89,  121 => 86,  118 => 83,  116 => 82,  114 => 81,  112 => 78,  111 => 77,  110 => 76,  109 => 75,  107 => 73,  105 => 72,  103 => 71,  101 => 70,  99 => 69,  97 => 68,  95 => 67,  93 => 65,  91 => 64,  89 => 63,  87 => 62,  85 => 60,  83 => 59,  78 => 55,  75 => 54,  71 => 52,  69 => 51,  66 => 50,  64 => 49,  59 => 48,  56 => 47,  54 => 46,  52 => 45,  44 => 42,);
    }

    public function getSourceContext()
    {
        return new Source("{#
┌────────────────────────────────────────────────────────────────────────────────────┐
│                                 #global-container                                  │
│   ┌─────┐   ┌──────────────────────────────────────────────────────────────────┐   │
│   │     │   │                         #page-container                          │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-header                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │                                                                  │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                          #main                           │   │   │
│   │  #  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  g  │   │   │   │                #header-container                 │   │   │   │
│   │  l  │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │  o  │   │   │                                                          │   │   │
│   │  b  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  a  │   │   │   │                  #main-content                   │   │   │   │
│   │  l  │   │   │   │   ┌─────┐   ┌──────────────────────┐   ┌─────┐   │   │   │   │
│   │  -  │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │  s  │   │   │   │   │  #  │   │                      │   │  #  │   │   │   │   │
│   │  i  │   │   │   │   │  s  │   │                      │   │  d  │   │   │   │   │
│   │  d  │   │   │   │   │  i  │   │                      │   │  e  │   │   │   │   │
│   │  e  │   │   │   │   │  d  │   │       #content       │   │  t  │   │   │   │   │
│   │  b  │   │   │   │   │  e  │   │                      │   │  a  │   │   │   │   │
│   │  a  │   │   │   │   │  b  │   │                      │   │  i  │   │   │   │   │
│   │  r  │   │   │   │   │  a  │   │                      │   │  l  │   │   │   │   │
│   │     │   │   │   │   │  r  │   │                      │   │  s  │   │   │   │   │
│   │     │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │     │   │   │   │   └─────┘   └──────────────────────┘   └─────┘   │   │   │   │
│   │     │   │   │   │                                                  │   │   │   │
│   │     │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │     │   │   │                                                          │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-footer                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   └─────┘   └──────────────────────────────────────────────────────────────────┘   │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘
#}

{% extends \"_layouts/basecp\" %}

{# The CP only supports queue components that implement QueueInterface #}
{% set queue = craft.app.queue %}
{% js %}
    {% if queue is instance of(\"craft\\\\queue\\\\QueueInterface\") %}
        Craft.cp.setJobInfo({{ queue.getJobInfo(100)|json_encode|raw }}, false);
        {% if queue.getHasReservedJobs() %}
            Craft.cp.trackJobProgress(true);
        {% elseif queue.getHasWaitingJobs() %}
            Craft.cp.runQueue();
        {% endif %}
    {% else %}
        Craft.cp.enableQueue = false;
    {% endif %}
{% endjs %}

{% set hasSystemIcon = CraftEdition == CraftPro and craft.rebrand.isIconUploaded %}
{% set fullPageForm = (fullPageForm is defined and fullPageForm) %}

{% set editionName = craft.app.getEditionName() %}
{% set canUpgradeEdition = craft.app.getCanUpgradeEdition() %}
{% set licensedEdition = craft.app.getLicensedEdition() %}
{% set isTrial = licensedEdition is not same as(null) and licensedEdition is not same as(CraftEdition) %}

{% set sidebar = (sidebar ?? block('sidebar') ?? '')|trim %}
{% set toolbar = (toolbar ?? block('toolbar') ?? '')|trim %}
{% set actionButton = (block('actionButton') ?? '')|trim %}
{% set details = (details ?? block('details') ?? '')|trim %}
{% set footer = (footer ?? block('footer') ?? '')|trim %}
{% set crumbs = crumbs ?? null %}
{% set tabs = tabs is defined and tabs|length != 1 ? tabs : null %}

{% set mainContentClasses = [
    sidebar ? 'has-sidebar',
    details ? 'has-details',
    tabs ? 'has-tabs',
]|filter %}

{% set showHeader = showHeader ?? true %}
{% if not showHeader %}
    {% set bodyClass = (bodyClass ?? [])|explodeClass|push('no-header') -%}
{% endif %}

{% set mainAttributes = {
    id: 'main',
    role: 'main',
}|merge(mainAttributes ?? []) %}

{% set mainFormAttributes = {
    id: 'main-form',
    method: 'post',
    'accept-charset': 'UTF-8',
    novalidate: true,
    data: {
        saveshortcut: saveShortcut ?? true,
        'saveshortcut-redirect': (saveShortcutRedirect ?? false) ? saveShortcutRedirect|hash : false,
        'saveshortcut-scroll': retainScrollOnSaveShortcut ?? false,
        actions: formActions ?? false,
        'confirm-unload': true,
        delta: view.getIsDeltaRegistrationActive(),
    },
}|merge(mainFormAttributes ?? [], recursive=true) %}

{% set userPhoto %}
    <div class=\"header-photo\">
        {{ tag('img', {
            width: 30,
            height: 30,
            sizes: '30px',
            srcset: \"#{currentUser.getThumbUrl(30)} 30w, #{currentUser.getThumbUrl(60)} 60w\",
            alt: currentUser.getName(),
        }) }}
    </div>
{% endset %}

{% block body %}
    <div id=\"global-container\">
        {% include '_layouts/components/global-sidebar' %}

        <div id=\"page-container\">
            {% include '_layouts/components/alerts' %}
            {% include '_layouts/components/notifications' %}

            <div id=\"global-header\" role=\"region\" aria-label=\"{{ 'My Account'|t('app') }}\">
                <div class=\"flex\">
                    {% include '_layouts/components/crumbs' %}
                    <div class=\"flex-grow\"></div>
                    <button type=\"button\" id=\"user-info\" class=\"btn menubtn\" aria-label=\"{{ 'My Account'|t('app') }}\" title=\"{{ 'My Account'|t('app') }}\" data-menu-anchor=\".header-photo\">
                        {{ userPhoto }}
                    </button>
                    <div class=\"menu\" data-align=\"right\">
                        <ul>
                            <li>
                                <a href=\"{{ url('myaccount') }}\" class=\"flex flex-nowrap\">
                                    {% if currentUser.photoId %}
                                        {{ userPhoto }}
                                    {% endif %}
                                    <div class=\"flex-grow\">
                                        <div>{{ currentUser.username }}</div>
                                        {% if not craft.app.config.general.useEmailAsUsername %}
                                            <div class=\"light smalltext\">{{ currentUser.email }}</div>
                                        {% endif %}
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <hr>
                        <ul>
                            <li><a href=\"{{ url('logout') }}\">{{ \"Sign out\"|t('app') }}</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">
                <main {{ attr(mainAttributes) }}>

                    {% if fullPageForm -%}
                        <form {% block mainFormAttributes %}{{ attr(mainFormAttributes) }}{% endblock %}>
                            {{- csrfInput() }}
                    {%- endif %}

                    {% if showHeader %}
                        <div id=\"header-container\">
                            <header id=\"header\">
                                {% block header %}
                                    <div id=\"page-title\" class=\"flex flex-nowrap{% if toolbar %} has-toolbar{% endif %}\">
                                        {% block pageTitle %}
                                            {% if title is defined and title|length %}
                                                <h1 title=\"{{ title }}\">{{ title }}</h1>
                                            {% endif %}
                                        {% endblock %}
                                        {% block contextMenu %}{% endblock %}
                                    </div>
                                    {% if toolbar %}
                                        <div id=\"toolbar\" class=\"flex flex-nowrap\">
                                            {{ toolbar|raw }}
                                        </div>
                                    {% endif %}
                                    {% if actionButton %}
                                        <div id=\"action-button\" class=\"flex\">
                                            {{ actionButton|raw }}
                                        </div>
                                    {% endif %}
                                {% endblock %}
                            </header><!-- #header -->
                        </div>
                    {% endif %}

                    <div id=\"main-content\" class=\"{{ mainContentClasses|join(' ') }}\">
                        {# sidebar #}
                        {% if sidebar %}
                            <div id=\"sidebar-toggle-container\">
                                <button type=\"button\" id=\"sidebar-toggle\" class=\"btn menubtn\"><span id=\"selected-sidebar-item-label\"></span></button>
                            </div>
                            <div id=\"sidebar-container\">
                                <div id=\"sidebar\" class=\"sidebar\">
                                    {{ sidebar|raw }}
                                </div>
                            </div>
                        {% endif %}

                        {# content-container #}
                        <div id=\"content-container\">
                            {% block main %}
                                {% block tabs %}
                                    {% if tabs %}
                                        {% include \"_includes/tabs\" %}
                                    {% endif %}
                                {% endblock %}

                                <div id=\"content\" class=\"content-pane\">
                                    {% block content %}
                                        {{ content is defined ? content }}
                                    {% endblock %}

                                    {# footer #}
                                    {% if footer %}
                                        <div id=\"footer\" class=\"flex\">
                                            {{ footer|raw }}
                                        </div>
                                    {% endif %}
                                </div>
                            {% endblock %}
                        </div><!-- #content-container -->

                        {% if details is not empty %}
                            <div id=\"details-container\">
                                <div id=\"details\">
                                    {{ details|raw }}
                                </div>
                            </div>
                        {% endif %}
                    </div><!-- #main-content -->

                    {% if fullPageForm -%}
                        </form><!-- #main-form -->
                    {%- endif %}
                </main><!-- #main -->
            </div><!-- #main-container -->

            <footer id=\"global-footer\">
                <div id=\"edition-logo\" title=\"{{ '{edition} edition'|t('app', {edition: editionName}) ~ (isTrial ? ' ' ~ '(trial)'|t('app')) }}\" aria-label=\"{{ '{edition} edition'|t('app', {edition: editionName}) ~ (isTrial ? ' ' ~ '(trial)'|t('app')) }}\">
                    <div class=\"edition-name\">{{ editionName }}</div>
                    {% if isTrial %}
                        <div class=\"edition-trial\">{{ \"Trial\"|t('app') }}</div>
                    {% endif %}
                </div>
                <ul id=\"app-info\">
                    <li>Craft CMS {{ craft.app.version }}</li>
                    {% if canUpgradeEdition %}
                        <li>
                            <a class=\"go\" href=\"{{ url('plugin-store/upgrade-craft') }}\">{{ isTrial ? 'Buy Craft Pro'|t('app') : 'Upgrade to Craft Pro'|t('app') }}</a>
                        </li>
                    {% endif %}
                </ul>
            </footer>

        </div><!-- #page-container -->
    </div><!-- #global-container -->
{% endblock %}


{% block actionButton %}
    {% if fullPageForm %}
        <div class=\"btngroup\">
            {% block submitButton %}
                <button type=\"submit\" class=\"btn submit\">{{ 'Save'|t('app') }}</button>
            {% endblock %}
            {% if formActions ?? false %}
                <button type=\"button\" class=\"btn submit menubtn\"></button>
                {% include '_layouts/components/form-action-menu' %}
            {% endif %}
        </div>
    {% endif %}
{% endblock %}


{% if currentUser.can('performUpdates') and not craft.app.updates.getIsUpdateInfoCached() %}
    {% js %}
        Craft.cp.checkForUpdates();
    {% endjs %}
{% endif %}
", "_layouts/cp", "/var/www/html/vendor/craftcms/cms/src/templates/_layouts/cp.html");
    }
}
