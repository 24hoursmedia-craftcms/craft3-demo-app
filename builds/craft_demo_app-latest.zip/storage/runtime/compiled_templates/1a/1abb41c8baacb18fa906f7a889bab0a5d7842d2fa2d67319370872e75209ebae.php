<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__bfc710d8ee850a648fe64dfe2d5f1621f80643e397232d0884e9c6a2b01edd68 */
class __TwigTemplate_9851abb778e778c914ffd48c1c7ceb2a66d29279a855c6ed87214b808e04f0cc extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__bfc710d8ee850a648fe64dfe2d5f1621f80643e397232d0884e9c6a2b01edd68");
        // line 1
        echo "content/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        craft\helpers\Template::endProfile("template", "__string_template__bfc710d8ee850a648fe64dfe2d5f1621f80643e397232d0884e9c6a2b01edd68");
    }

    public function getTemplateName()
    {
        return "__string_template__bfc710d8ee850a648fe64dfe2d5f1621f80643e397232d0884e9c6a2b01edd68";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("content/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__bfc710d8ee850a648fe64dfe2d5f1621f80643e397232d0884e9c6a2b01edd68", "");
    }
}
