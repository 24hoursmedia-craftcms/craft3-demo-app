<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/base */
class __TwigTemplate_dac375bf2bad8273444a41992c6dc1dd4df4bfbe37b83de13087191e89924e7f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'body' => [$this, 'block_body'],
            'foot' => [$this, 'block_foot'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/base");
        // line 1
        $context["systemName"] = $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "app", []), "getSystemName", [], "method"), "site");
        // line 2
        $context["docTitle"] = (((isset($context["docTitle"]) || array_key_exists("docTitle", $context))) ? ((isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 2, $this->source); })())) : (strip_tags((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 2, $this->source); })()))));
        // line 3
        $context["orientation"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", []), "locale", []), "getOrientation", [], "method");
        // line 4
        $context["a11yDefaults"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", []), "config", []), "general", []), "accessibilityDefaults", []);
        // line 5
        echo "
";
        // line 6
        $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["bodyClass"]) ?? ([]))), [0 =>         // line 7
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 7, $this->source); })()), 1 => (((((craft\helpers\Template::attribute($this->env, $this->source,         // line 8
($context["currentUser"] ?? null), "getPreference", [0 => "useShapes"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", [0 => "useShapes"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", [0 => "useShapes"], "method")) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "useShapes", [], "array")) : (false))))) ? ("use-shapes") : ("")), 2 => (((((craft\helpers\Template::attribute($this->env, $this->source,         // line 9
($context["currentUser"] ?? null), "getPreference", [0 => "underlineLinks"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", [0 => "underlineLinks"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "getPreference", [0 => "underlineLinks"], "method")) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a11yDefaults"] ?? null), "underlineLinks", [], "array")) : (false))))) ? ("underline-links") : (""))]));
        // line 12
        $context["bodyAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 13
(isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 13, $this->source); })()), "dir" =>         // line 14
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 14, $this->source); })())], ((        // line 15
$context["bodyAttributes"]) ?? ([])), true);
        // line 17
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 17, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\cp\\CpAsset"], "method");
        // line 18
        $context["cpAssetUrl"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 18, $this->source); })()), "getAssetManager", [], "method"), "getPublishedUrl", [0 => "@app/web/assets/cp/dist", 1 => true], "method");
        // line 20
        echo \Craft::$app->getView()->invokeHook("cp.layouts.base", $context);

        // line 22
        echo "<!DOCTYPE html>
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"";
        // line 23
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 23, $this->source); })()), "app", []), "language", []), "html", null, true);
        echo "\">
<head>
    ";
        // line 25
        $this->displayBlock('head', $context, $blocks);
        // line 52
        echo "</head>
<body ";
        // line 53
        echo craft\helpers\Html::renderTagAttributes((isset($context["bodyAttributes"]) || array_key_exists("bodyAttributes", $context) ? $context["bodyAttributes"] : (function () { throw new RuntimeError('Variable "bodyAttributes" does not exist.', 53, $this->source); })()));
        echo ">
    ";
        // line 54
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "
    ";
        // line 55
        $this->displayBlock('body', $context, $blocks);
        // line 56
        echo "    ";
        $this->displayBlock('foot', $context, $blocks);
        // line 57
        echo "    ";
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), []);
        echo "
</body>
</html>
";
        craft\helpers\Template::endProfile("template", "_layouts/base");
    }

    // line 25
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "head");
        // line 26
        echo "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <title>";
        // line 28
        echo twig_escape_filter($this->env, (((isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 28, $this->source); })()) . (((twig_length_filter($this->env, (isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 28, $this->source); })())) && twig_length_filter($this->env, (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 28, $this->source); })())))) ? (" - ") : (""))) . (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 28, $this->source); })())), "html", null, true);
        echo "</title>
    ";
        // line 29
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"referrer\" content=\"origin-when-cross-origin\">

    ";
        // line 33
        $context["hasCustomIcon"] = false;
        // line 34
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 34, $this->source); })()), "app", []), "config", []), "general", []), "cpHeadTags", []));
        foreach ($context['_seq'] as $context["_key"] => $context["tag"]) {
            // line 35
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 0, [], "array"), craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array"));
            echo "
        ";
            // line 36
            if (((craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 0, [], "array") == "link") && ((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true), "rel", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true), "rel", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true), "rel", [])) : (null)) == "icon"))) {
                // line 37
                echo "            ";
                $context["hasCustomIcon"] = true;
                // line 38
                echo "        ";
            }
            // line 39
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tag'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "    ";
        if ( !(isset($context["hasCustomIcon"]) || array_key_exists("hasCustomIcon", $context) ? $context["hasCustomIcon"] : (function () { throw new RuntimeError('Variable "hasCustomIcon" does not exist.', 40, $this->source); })())) {
            // line 41
            echo "        <link rel=\"icon\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 41, $this->source); })()), "html", null, true);
            echo "/images/icons/favicon.ico\">
        <link rel=\"icon\" type=\"image/svg+xml\" sizes=\"any\" href=\"";
            // line 42
            echo twig_escape_filter($this->env, (isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 42, $this->source); })()), "html", null, true);
            echo "/images/icons/icon.svg\">
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"";
            // line 43
            echo twig_escape_filter($this->env, (isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 43, $this->source); })()), "html", null, true);
            echo "/images/icons/apple-touch-icon.png\">
        <link rel=\"mask-icon\" href=\"";
            // line 44
            echo twig_escape_filter($this->env, (isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 44, $this->source); })()), "html", null, true);
            echo "/images/icons/safari-pinned-tab.svg\" color=\"#e5422b\">
    ";
        }
        // line 46
        echo "
    <script type=\"text/javascript\">
        // Fix for Firefox autofocus CSS bug
        // See: http://stackoverflow.com/questions/18943276/html-5-autofocus-messes-up-css-loading/18945951#18945951
    </script>
    ";
        craft\helpers\Template::endProfile("block", "head");
    }

    // line 55
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        craft\helpers\Template::endProfile("block", "body");
    }

    // line 56
    public function block_foot($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "foot");
        craft\helpers\Template::endProfile("block", "foot");
    }

    public function getTemplateName()
    {
        return "_layouts/base";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  190 => 56,  182 => 55,  172 => 46,  167 => 44,  163 => 43,  159 => 42,  154 => 41,  151 => 40,  145 => 39,  142 => 38,  139 => 37,  137 => 36,  132 => 35,  127 => 34,  125 => 33,  118 => 29,  114 => 28,  110 => 26,  105 => 25,  95 => 57,  92 => 56,  90 => 55,  86 => 54,  82 => 53,  79 => 52,  77 => 25,  72 => 23,  69 => 22,  66 => 20,  64 => 18,  62 => 17,  60 => 15,  59 => 14,  58 => 13,  57 => 12,  55 => 9,  54 => 8,  53 => 7,  52 => 6,  49 => 5,  47 => 4,  45 => 3,  43 => 2,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set systemName = craft.app.getSystemName()|t('site') -%}
{% set docTitle = docTitle is defined ? docTitle : title|striptags -%}
{% set orientation = craft.app.locale.getOrientation() -%}
{% set a11yDefaults = craft.app.config.general.accessibilityDefaults %}

{% set bodyClass = (bodyClass ?? [])|explodeClass|merge([
    orientation,
    (currentUser.getPreference('useShapes') ?? a11yDefaults['useShapes'] ?? false) ? 'use-shapes',
    (currentUser.getPreference('underlineLinks') ?? a11yDefaults['underlineLinks'] ?? false) ? 'underline-links',
])|filter -%}

{% set bodyAttributes = {
    class: bodyClass,
    dir: orientation,
}|merge(bodyAttributes ?? {}, recursive=true) -%}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\cp\\\\CpAsset') -%}
{% set cpAssetUrl = view.getAssetManager().getPublishedUrl('@app/web/assets/cp/dist', true) -%}

{% hook \"cp.layouts.base\" -%}

<!DOCTYPE html>
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"{{ craft.app.language }}\">
<head>
    {% block head %}
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <title>{{ docTitle ~ (docTitle|length and systemName|length ? ' - ') ~ systemName }}</title>
    {{ head() }}
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"referrer\" content=\"origin-when-cross-origin\">

    {% set hasCustomIcon = false %}
    {% for tag in craft.app.config.general.cpHeadTags %}
        {{ tag(tag[0], tag[1]) }}
        {% if tag[0] == 'link' and (tag[1].rel ?? null) == 'icon' %}
            {% set hasCustomIcon = true %}
        {% endif %}
    {% endfor %}
    {% if not hasCustomIcon %}
        <link rel=\"icon\" href=\"{{ cpAssetUrl }}/images/icons/favicon.ico\">
        <link rel=\"icon\" type=\"image/svg+xml\" sizes=\"any\" href=\"{{ cpAssetUrl }}/images/icons/icon.svg\">
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"{{ cpAssetUrl }}/images/icons/apple-touch-icon.png\">
        <link rel=\"mask-icon\" href=\"{{ cpAssetUrl }}/images/icons/safari-pinned-tab.svg\" color=\"#e5422b\">
    {% endif %}

    <script type=\"text/javascript\">
        // Fix for Firefox autofocus CSS bug
        // See: http://stackoverflow.com/questions/18943276/html-5-autofocus-messes-up-css-loading/18945951#18945951
    </script>
    {% endblock %}
</head>
<body {{ attr(bodyAttributes) }}>
    {{ beginBody() }}
    {% block body %}{% endblock %}
    {% block foot %}{% endblock %}
    {{ endBody() }}
</body>
</html>
", "_layouts/base", "/var/www/html/vendor/craftcms/cms/src/templates/_layouts/base.html");
    }
}
