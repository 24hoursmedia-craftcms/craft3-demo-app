<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/comments_work/comments.twig */
class __TwigTemplate_56ea865ef80181f4933716c219d97e4562a9f654c0529e98b357c005e7fa2828 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/comments_work/comments.twig");
        // line 12
        echo "
";
        // line 14
        echo "
";
        // line 15
        $context["cw_options"] = ["all_sites" => false];
        // line 18
        echo "
";
        // line 19
        $context["commentsWork"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 19, $this->source); })()), "commentsWork", []), "service", []);
        // line 20
        $context["count"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["commentsWork"]) || array_key_exists("commentsWork", $context) ? $context["commentsWork"] : (function () { throw new RuntimeError('Variable "commentsWork" does not exist.', 20, $this->source); })()), "countComments", [0 => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 20, $this->source); })()), 1 => (isset($context["cw_options"]) || array_key_exists("cw_options", $context) ? $context["cw_options"] : (function () { throw new RuntimeError('Variable "cw_options" does not exist.', 20, $this->source); })())], "method");
        // line 21
        $context["comments"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["commentsWork"]) || array_key_exists("commentsWork", $context) ? $context["commentsWork"] : (function () { throw new RuntimeError('Variable "commentsWork" does not exist.', 21, $this->source); })()), "fetchComments", [0 => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 21, $this->source); })()), 1 => 0, 2 => 10, 3 => (isset($context["cw_options"]) || array_key_exists("cw_options", $context) ? $context["cw_options"] : (function () { throw new RuntimeError('Variable "cw_options" does not exist.', 21, $this->source); })())], "method");
        // line 22
        echo "
<div class=\"mt-3 mb-3\">
    <p>";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 24, $this->source); })()), "html", null, true);
        echo " comments</p>

    ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["comments"]) || array_key_exists("comments", $context) ? $context["comments"] : (function () { throw new RuntimeError('Variable "comments" does not exist.', 26, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 27
            echo "        ";
            // line 28
            echo "        <div class=\"bg-blue-200 mt-1 mb-2 p-2\">
            <small class=\"mb-2\">
                ";
            // line 30
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["comment"], "dateCreated", [])), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["comment"], "dateCreated", []), "H:i"), "html", null, true);
            echo "
                ";
            // line 31
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["comment"], "user", [])) {
                // line 32
                echo "                    by ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["comment"], "user", []), "friendlyName", []), "html", null, true);
                echo "
                    ";
            } else {
                // line 34
                echo "                    (anonymous comment)
                ";
            }
            // line 36
            echo "
                ";
            // line 37
            if ( !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->source, $context["comment"], "title", []))) {
                // line 38
                echo "                    <div class=\"mb-2 mt-2\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["comment"], "title", []), "html", null, true);
                echo "</div>
                ";
            }
            // line 40
            echo "                <p class=\"mt-1 text-lg\">„";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["comment"], "comment", []), "html", null, true);
            echo "”</p>
            </small>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "
</div>
";
        craft\helpers\Template::endProfile("template", "_components/comments_work/comments.twig");
    }

    public function getTemplateName()
    {
        return "_components/comments_work/comments.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 44,  103 => 40,  97 => 38,  95 => 37,  92 => 36,  88 => 34,  82 => 32,  80 => 31,  74 => 30,  70 => 28,  68 => 27,  64 => 26,  59 => 24,  55 => 22,  53 => 21,  51 => 20,  49 => 19,  46 => 18,  44 => 15,  41 => 14,  38 => 12,);
    }

    public function getSourceContext()
    {
        return new Source("{#
Shows the comments users left behind for an entry

Example:

{% include '_components/comments_work/comments.twig' with {
    entry: entry
    } only
%}

#}

{# @param entry     the entry to show the comment form for #}

{% set cw_options = {
    all_sites: false
} %}

{% set commentsWork = craft.commentsWork.service %}
{% set count = commentsWork.countComments(entry, cw_options) %}
{% set comments = commentsWork.fetchComments(entry, 0, 10, cw_options) %}

<div class=\"mt-3 mb-3\">
    <p>{{ count }} comments</p>

    {% for comment in comments %}
        {# @var comment \\twentyfourhoursmedia\\commentswork\\models\\CommentModel #}
        <div class=\"bg-blue-200 mt-1 mb-2 p-2\">
            <small class=\"mb-2\">
                {{ comment.dateCreated | date }} {{ comment.dateCreated | date('H:i') }}
                {% if comment.user %}
                    by {{ comment.user.friendlyName }}
                    {% else %}
                    (anonymous comment)
                {% endif %}

                {% if comment.title is not empty %}
                    <div class=\"mb-2 mt-2\">{{ comment.title }}</div>
                {% endif %}
                <p class=\"mt-1 text-lg\">„{{ comment.comment }}”</p>
            </small>
        </div>
    {% endfor %}

</div>
", "_components/comments_work/comments.twig", "/var/www/html/templates/_components/comments_work/comments.twig");
    }
}
