<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/elementfieldsettings */
class __TwigTemplate_5fa94dfd45ab1fd4d3528d60d2400d326649660cc3fa441016a29ca2f254c9e7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'fieldSettings' => [$this, 'block_fieldSettings'],
            'sourcesField' => [$this, 'block_sourcesField'],
            'limitField' => [$this, 'block_limitField'],
            'viewModeField' => [$this, 'block_viewModeField'],
            'selectionLabelField' => [$this, 'block_selectionLabelField'],
            'validateRelatedElementsField' => [$this, 'block_validateRelatedElementsField'],
            'advancedSettings' => [$this, 'block_advancedSettings'],
            'targetSiteField' => [$this, 'block_targetSiteField'],
            'localizeRelationsField' => [$this, 'block_localizeRelationsField'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/elementfieldsettings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/elementfieldsettings", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        $context["sourceOptions"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 3, $this->source); })()), "getSourceOptions", [], "method");
        // line 4
        $context["elementType"] = (($context["elementType"]) ?? ((isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 4, $this->source); })())));
        // line 5
        echo "
";
        // line 6
        $this->displayBlock('fieldSettings', $context, $blocks);
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/elementfieldsettings");
    }

    public function block_fieldSettings($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "fieldSettings");
        // line 7
        echo "    ";
        $this->displayBlock('sourcesField', $context, $blocks);
        // line 35
        echo "
    ";
        // line 36
        $this->displayBlock('limitField', $context, $blocks);
        // line 49
        echo "
    ";
        // line 50
        $this->displayBlock('viewModeField', $context, $blocks);
        // line 53
        echo "
    ";
        // line 54
        $this->displayBlock('selectionLabelField', $context, $blocks);
        // line 65
        echo "
    ";
        // line 66
        $this->displayBlock('validateRelatedElementsField', $context, $blocks);
        // line 75
        echo "
    ";
        // line 76
        $this->displayBlock('advancedSettings', $context, $blocks);
        craft\helpers\Template::endProfile("block", "fieldSettings");
    }

    // line 7
    public function block_sourcesField($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "sourcesField");
        // line 8
        echo "        ";
        if ((isset($context["sourceOptions"]) || array_key_exists("sourceOptions", $context) ? $context["sourceOptions"] : (function () { throw new RuntimeError('Variable "sourceOptions" does not exist.', 8, $this->source); })())) {
            // line 9
            echo "            ";
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 9, $this->source); })()), "allowMultipleSources", [])) {
                // line 10
                echo "                ";
                echo twig_call_macro($macros["forms"], "macro_checkboxSelectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sources", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which sources do you want to select {type} from?", "app", ["type" =>                 // line 12
(isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 12, $this->source); })())]), "id" => "sources", "name" => "sources", "options" =>                 // line 15
(isset($context["sourceOptions"]) || array_key_exists("sourceOptions", $context) ? $context["sourceOptions"] : (function () { throw new RuntimeError('Variable "sourceOptions" does not exist.', 15, $this->source); })()), "values" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 16
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 16, $this->source); })()), "sources", []), "showAllOption" => true]], 10, $context, $this->getSourceContext());
                // line 18
                echo "
            ";
            } else {
                // line 20
                echo "                ";
                echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Source", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which source do you want to select {type} from?", "app", ["type" =>                 // line 22
(isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 22, $this->source); })())]), "id" => "source", "name" => "source", "options" =>                 // line 25
(isset($context["sourceOptions"]) || array_key_exists("sourceOptions", $context) ? $context["sourceOptions"] : (function () { throw new RuntimeError('Variable "sourceOptions" does not exist.', 25, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 26
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 26, $this->source); })()), "source", [])]], 20, $context, $this->getSourceContext());
                // line 27
                echo "
            ";
            }
            // line 29
            echo "        ";
        } else {
            // line 30
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_field", [["label" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 31
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 31, $this->source); })()), "allowMultipleSources", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Sources", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Source", "app")))], (("<p class=\"error\">" . $this->extensions['craft\web\twig\Extension']->translateFilter("No sources exist yet.", "app")) . "</p>")], 30, $context, $this->getSourceContext());
            // line 32
            echo "
        ";
        }
        // line 34
        echo "    ";
        craft\helpers\Template::endProfile("block", "sourcesField");
    }

    // line 36
    public function block_limitField($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "limitField");
        // line 37
        echo "        ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 37, $this->source); })()), "allowLimit", [])) {
            // line 38
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Limit", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Limit the number of selectable {type}.", "app", ["type" =>             // line 40
(isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 40, $this->source); })())]), "id" => "limit", "name" => "limit", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 43
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 43, $this->source); })()), "limit", []), "size" => 2, "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 45
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 45, $this->source); })()), "getErrors", [0 => "limit"], "method")]], 38, $context, $this->getSourceContext());
            // line 46
            echo "
        ";
        }
        // line 48
        echo "    ";
        craft\helpers\Template::endProfile("block", "limitField");
    }

    // line 50
    public function block_viewModeField($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "viewModeField");
        // line 51
        echo "        ";
        echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 51, $this->source); })()), "getViewModeFieldHtml", [], "method");
        echo "
    ";
        craft\helpers\Template::endProfile("block", "viewModeField");
    }

    // line 54
    public function block_selectionLabelField($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "selectionLabelField");
        // line 55
        echo "        ";
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Selection Label", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enter the text you want to appear on the {type} selection input.", "app", ["type" =>         // line 57
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 57, $this->source); })())]), "id" => "selectionLabel", "name" => "selectionLabel", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 60
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 60, $this->source); })()), "selectionLabel", []), "placeholder" => craft\helpers\Template::attribute($this->env, $this->source,         // line 61
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 61, $this->source); })()), "defaultSelectionLabel", [], "method"), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 62
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 62, $this->source); })()), "getErrors", [0 => "selectionLabel"], "method")]], 55, $context, $this->getSourceContext());
        // line 63
        echo "
    ";
        craft\helpers\Template::endProfile("block", "selectionLabelField");
    }

    // line 66
    public function block_validateRelatedElementsField($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "validateRelatedElementsField");
        // line 67
        echo "        ";
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Validate related {type}", "app", ["type" =>         // line 68
(isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 68, $this->source); })())]), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether validation errors on the related {type} should prevent the source element from being saved.", "app", ["type" =>         // line 69
(isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 69, $this->source); })())]), "id" => "validate-related-elements", "name" => "validateRelatedElements", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 72
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 72, $this->source); })()), "validateRelatedElements", [])]], 67, $context, $this->getSourceContext());
        // line 73
        echo "
    ";
        craft\helpers\Template::endProfile("block", "validateRelatedElementsField");
    }

    // line 76
    public function block_advancedSettings($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "advancedSettings");
        // line 77
        echo "        <hr>

        <a class=\"fieldtoggle\" data-target=\"advanced\">";
        // line 79
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Advanced", "app"), "html", null, true);
        echo "</a>
        <div id=\"advanced\" class=\"hidden\">

            ";
        // line 82
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow self relations", "app", ["type" =>         // line 83
(isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 83, $this->source); })())]), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether {type} should be allowed to relate themselves.", "app", ["type" =>         // line 84
(isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 84, $this->source); })())]), "id" => "allow-self-relations", "name" => "allowSelfRelations", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 87
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 87, $this->source); })()), "allowSelfRelations", [])]], 82, $context, $this->getSourceContext());
        // line 88
        echo "

            ";
        // line 90
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 90, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 91
            echo "
                ";
            // line 92
            $this->displayBlock('targetSiteField', $context, $blocks);
            // line 95
            echo "
                ";
            // line 96
            $this->displayBlock('localizeRelationsField', $context, $blocks);
            // line 104
            echo "            ";
        }
        // line 105
        echo "
        </div>
    ";
        craft\helpers\Template::endProfile("block", "advancedSettings");
    }

    // line 92
    public function block_targetSiteField($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "targetSiteField");
        // line 93
        echo "                    ";
        echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 93, $this->source); })()), "getTargetSiteFieldHtml", [], "method");
        echo "
                ";
        craft\helpers\Template::endProfile("block", "targetSiteField");
    }

    // line 96
    public function block_localizeRelationsField($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "localizeRelationsField");
        // line 97
        echo "                    ";
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Manage relations on a per-site basis", "app"), "id" => "localize-relations", "name" => "localizeRelations", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 101
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 101, $this->source); })()), "localizeRelations", [])]], 97, $context, $this->getSourceContext());
        // line 102
        echo "
                ";
        craft\helpers\Template::endProfile("block", "localizeRelationsField");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/elementfieldsettings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  285 => 102,  283 => 101,  281 => 97,  276 => 96,  268 => 93,  263 => 92,  256 => 105,  253 => 104,  251 => 96,  248 => 95,  246 => 92,  243 => 91,  241 => 90,  237 => 88,  235 => 87,  234 => 84,  233 => 83,  232 => 82,  226 => 79,  222 => 77,  217 => 76,  211 => 73,  209 => 72,  208 => 69,  207 => 68,  205 => 67,  200 => 66,  194 => 63,  192 => 62,  191 => 61,  190 => 60,  189 => 57,  187 => 55,  182 => 54,  174 => 51,  169 => 50,  164 => 48,  160 => 46,  158 => 45,  157 => 43,  156 => 40,  154 => 38,  151 => 37,  146 => 36,  141 => 34,  137 => 32,  135 => 31,  133 => 30,  130 => 29,  126 => 27,  124 => 26,  123 => 25,  122 => 22,  120 => 20,  116 => 18,  114 => 16,  113 => 15,  112 => 12,  110 => 10,  107 => 9,  104 => 8,  99 => 7,  94 => 76,  91 => 75,  89 => 66,  86 => 65,  84 => 54,  81 => 53,  79 => 50,  76 => 49,  74 => 36,  71 => 35,  68 => 7,  59 => 6,  56 => 5,  54 => 4,  52 => 3,  49 => 2,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% set sourceOptions = field.getSourceOptions() %}
{% set elementType = elementType ?? pluralElementType %}

{% block fieldSettings %}
    {% block sourcesField %}
        {% if sourceOptions %}
            {% if field.allowMultipleSources %}
                {{ forms.checkboxSelectField({
                    label: \"Sources\"|t('app'),
                    instructions: \"Which sources do you want to select {type} from?\"|t('app', { type: pluralElementType }),
                    id: 'sources',
                    name: 'sources',
                    options: sourceOptions,
                    values: field.sources,
                    showAllOption: true,
                }) }}
            {% else %}
                {{ forms.selectField({
                    label: \"Source\"|t('app'),
                    instructions: \"Which source do you want to select {type} from?\"|t('app', { type: pluralElementType }),
                    id: 'source',
                    name: 'source',
                    options: sourceOptions,
                    value: field.source
                }) }}
            {% endif %}
        {% else %}
            {{ forms.field({
                label: (field.allowMultipleSources ? \"Sources\"|t('app') : \"Source\"|t('app'))
            }, '<p class=\"error\">' ~ \"No sources exist yet.\"|t('app') ~ '</p>') }}
        {% endif %}
    {% endblock %}

    {% block limitField %}
        {% if field.allowLimit %}
            {{ forms.textField({
                label: \"Limit\"|t('app'),
                instructions: \"Limit the number of selectable {type}.\"|t('app', { type: pluralElementType }),
                id: 'limit',
                name: 'limit',
                value: field.limit,
                size: 2,
                errors: field.getErrors('limit')
            }) }}
        {% endif %}
    {% endblock %}

    {% block viewModeField %}
        {{ field.getViewModeFieldHtml()|raw }}
    {% endblock %}

    {% block selectionLabelField %}
        {{ forms.textField({
            label: \"Selection Label\"|t('app'),
            instructions: \"Enter the text you want to appear on the {type} selection input.\"|t('app', { type: elementType }),
            id: 'selectionLabel',
            name: 'selectionLabel',
            value: field.selectionLabel,
            placeholder: field.defaultSelectionLabel(),
            errors: field.getErrors('selectionLabel')
        }) }}
    {% endblock %}

    {% block validateRelatedElementsField %}
        {{ forms.checkboxField({
            label: 'Validate related {type}'|t('app', { type: pluralElementType }),
            instructions: 'Whether validation errors on the related {type} should prevent the source element from being saved.'|t('app', { type: pluralElementType }),
            id: 'validate-related-elements',
            name: 'validateRelatedElements',
            checked: field.validateRelatedElements
        }) }}
    {% endblock %}

    {% block advancedSettings %}
        <hr>

        <a class=\"fieldtoggle\" data-target=\"advanced\">{{ \"Advanced\"|t('app') }}</a>
        <div id=\"advanced\" class=\"hidden\">

            {{ forms.checkboxField({
                label: 'Allow self relations'|t('app', { type: pluralElementType }),
                instructions: 'Whether {type} should be allowed to relate themselves.'|t('app', { type: pluralElementType }),
                id: 'allow-self-relations',
                name: 'allowSelfRelations',
                checked: field.allowSelfRelations,
            }) }}

            {% if craft.app.getIsMultiSite() %}

                {% block targetSiteField %}
                    {{ field.getTargetSiteFieldHtml()|raw }}
                {% endblock %}

                {% block localizeRelationsField %}
                    {{ forms.checkboxField({
                        label: \"Manage relations on a per-site basis\"|t('app'),
                        id: 'localize-relations',
                        name: 'localizeRelations',
                        checked: field.localizeRelations
                    }) }}
                {% endblock %}
            {% endif %}

        </div>
    {% endblock %}
{% endblock %}
", "_components/fieldtypes/elementfieldsettings", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/elementfieldsettings.html");
    }
}
