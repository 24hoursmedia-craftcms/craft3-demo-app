<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/elementSelect */
class __TwigTemplate_c7b7704d1979eb25e3fe8439d43c7de9c12c08547d16d000bab9ed926ebc87e6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/elementSelect");
        // line 1
        if ((($context["name"]) ?? (false))) {
            // line 2
            echo "    ";
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 2, $this->source); })()), "");
            echo "
";
        }
        // line 5
        $context["id"] = (($context["id"]) ?? (("elementselect" . twig_random($this->env))));
        // line 6
        $context["elements"] = (($context["elements"]) ?? ([]));
        // line 7
        $context["jsClass"] = (($context["jsClass"]) ?? ("Craft.BaseElementSelectInput"));
        // line 8
        $context["sources"] = (($context["sources"]) ?? (null));
        // line 9
        $context["criteria"] = (($context["criteria"]) ?? (null));
        // line 10
        $context["sourceElementId"] = (($context["sourceElementId"]) ?? (null));
        // line 11
        $context["storageKey"] = (($context["storageKey"]) ?? (null));
        // line 12
        $context["viewMode"] = (($context["viewMode"]) ?? ("list"));
        // line 13
        $context["sortable"] = (($context["sortable"]) ?? (true));
        // line 14
        $context["prevalidate"] = (($context["prevalidate"]) ?? (false));
        // line 15
        $context["fieldId"] = (($context["fieldId"]) ?? (null));
        // line 16
        $context["limit"] = (($context["limit"]) ?? (null));
        // line 17
        echo "
";
        // line 18
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 19
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 19, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter([0 => "elementselect"], craft\helpers\Html::explodeClass(((        // line 20
$context["class"]) ?? ([]))))], ((        // line 21
$context["containerAttributes"]) ?? ([])), true);
        // line 23
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 24
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 24, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 26
        echo "
";
        // line 27
        ob_start();
        // line 28
        echo "    <div class=\"elements\">
        ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 29, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 30
            echo "            ";
            $this->loadTemplate("_elements/element", "_includes/forms/elementSelect", 30)->display(twig_array_merge($context, ["context" => "field", "size" => (((            // line 32
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 32, $this->source); })()) == "large")) ? ("large") : ("small"))]));
            // line 34
            echo "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "    </div>

    <div class=\"flex";
        // line 37
        if (((isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 37, $this->source); })()) && (twig_length_filter($this->env, (isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 37, $this->source); })())) >= (isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 37, $this->source); })())))) {
            echo " hidden";
        }
        echo "\">
        <button type=\"button\" class=\"btn add icon dashed\">";
        // line 38
        echo twig_escape_filter($this->env, (($context["selectionLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"))), "html", null, true);
        echo "</button>
    </div>
";
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 27
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 27, $this->source); })()));
        // line 41
        echo "
";
        // line 42
        $context["jsSettings"] = ["id" => call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [        // line 43
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 43, $this->source); })())]), "name" => call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), [        // line 44
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 44, $this->source); })())]), "elementType" =>         // line 45
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 45, $this->source); })()), "sources" =>         // line 46
(isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 46, $this->source); })()), "criteria" =>         // line 47
(isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 47, $this->source); })()), "allowSelfRelations" => ((        // line 48
$context["allowSelfRelations"]) ?? (false)), "sourceElementId" =>         // line 49
(isset($context["sourceElementId"]) || array_key_exists("sourceElementId", $context) ? $context["sourceElementId"] : (function () { throw new RuntimeError('Variable "sourceElementId" does not exist.', 49, $this->source); })()), "disabledElementIds" => ((        // line 50
$context["disabledElementIds"]) ?? (null)), "viewMode" =>         // line 51
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 51, $this->source); })()), "limit" =>         // line 52
(isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 52, $this->source); })()), "showSiteMenu" => ((        // line 53
$context["showSiteMenu"]) ?? (false)), "modalStorageKey" =>         // line 54
(isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 54, $this->source); })()), "fieldId" =>         // line 55
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 55, $this->source); })()), "sortable" =>         // line 56
(isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 56, $this->source); })()), "prevalidate" =>         // line 57
(isset($context["prevalidate"]) || array_key_exists("prevalidate", $context) ? $context["prevalidate"] : (function () { throw new RuntimeError('Variable "prevalidate" does not exist.', 57, $this->source); })()), "modalSettings" => ((        // line 58
$context["modalSettings"]) ?? ([]))];
        // line 60
        echo "
";
        // line 61
        ob_start();
        // line 62
        echo "    new ";
        echo twig_escape_filter($this->env, (isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 62, $this->source); })()), "html", null, true);
        echo "(";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["jsSettings"]) || array_key_exists("jsSettings", $context) ? $context["jsSettings"] : (function () { throw new RuntimeError('Variable "jsSettings" does not exist.', 62, $this->source); })()));
        echo ");
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/elementSelect");
    }

    public function getTemplateName()
    {
        return "_includes/forms/elementSelect";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 62,  167 => 61,  164 => 60,  162 => 58,  161 => 57,  160 => 56,  159 => 55,  158 => 54,  157 => 53,  156 => 52,  155 => 51,  154 => 50,  153 => 49,  152 => 48,  151 => 47,  150 => 46,  149 => 45,  148 => 44,  147 => 43,  146 => 42,  143 => 41,  141 => 27,  136 => 38,  130 => 37,  126 => 35,  112 => 34,  110 => 32,  108 => 30,  91 => 29,  88 => 28,  86 => 27,  83 => 26,  80 => 24,  78 => 23,  76 => 21,  75 => 20,  74 => 19,  73 => 18,  70 => 17,  68 => 16,  66 => 15,  64 => 14,  62 => 13,  60 => 12,  58 => 11,  56 => 10,  54 => 9,  52 => 8,  50 => 7,  48 => 6,  46 => 5,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if name ?? false %}
    {{ hiddenInput(name, '') }}
{% endif -%}

{% set id = id ?? \"elementselect#{random()}\" -%}
{% set elements = elements ?? [] -%}
{% set jsClass = jsClass ?? 'Craft.BaseElementSelectInput' -%}
{% set sources = sources ?? null -%}
{% set criteria = criteria ?? null -%}
{% set sourceElementId = sourceElementId ?? null -%}
{% set storageKey = storageKey ?? null -%}
{% set viewMode = viewMode ?? 'list' %}
{% set sortable = sortable ?? true %}
{% set prevalidate = prevalidate ?? false %}
{% set fieldId = fieldId ?? null %}
{% set limit = limit ?? null %}

{% set containerAttributes = {
    id: id,
    class: ['elementselect']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% tag 'div' with containerAttributes %}
    <div class=\"elements\">
        {% for element in elements %}
            {% include \"_elements/element\" with {
                context: 'field',
                size: (viewMode == 'large' ? 'large' : 'small')
            } %}
        {% endfor %}
    </div>

    <div class=\"flex{% if limit and elements|length >= limit %} hidden{% endif %}\">
        <button type=\"button\" class=\"btn add icon dashed\">{{ selectionLabel ?? \"Choose\"|t('app') }}</button>
    </div>
{% endtag %}

{% set jsSettings = {
    id: id|namespaceInputId,
    name: name|namespaceInputName,
    elementType: elementType,
    sources: sources,
    criteria: criteria,
    allowSelfRelations: allowSelfRelations ?? false,
    sourceElementId: sourceElementId,
    disabledElementIds: disabledElementIds ?? null,
    viewMode: viewMode,
    limit: limit,
    showSiteMenu: showSiteMenu ?? false,
    modalStorageKey: storageKey,
    fieldId: fieldId,
    sortable: sortable,
    prevalidate: prevalidate,
    modalSettings: modalSettings ?? {},
} %}

{% js %}
    new {{ jsClass }}({{ jsSettings|json_encode|raw }});
{% endjs %}
", "_includes/forms/elementSelect", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/elementSelect.html");
    }
}
