<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_components/widgets/ViewedNowWidget_settings */
class __TwigTemplate_daecdbf1c64e023dc62c8e77d6f9d43854929787d9402214f301cb4daf0d50d5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_components/widgets/ViewedNowWidget_settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "views-work/_components/widgets/ViewedNowWidget_settings", 1)->unwrap();
        // line 2
        $macros["cpmacros"] = $this->macros["cpmacros"] = $this->loadTemplate("views-work/_macros", "views-work/_components/widgets/ViewedNowWidget_settings", 2)->unwrap();
        // line 3
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\viewswork\\assetbundles\\viewswork\\ViewsWorkAsset"], "method");
        // line 4
        echo "
";
        // line 5
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 6
            echo "    ";
            $context["editableSites"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", []), "sites", []), "getEditableSites", [], "method");
            // line 7
            echo "

    ";
            // line 9
            if ((twig_length_filter($this->env, (isset($context["editableSites"]) || array_key_exists("editableSites", $context) ? $context["editableSites"] : (function () { throw new RuntimeError('Variable "editableSites" does not exist.', 9, $this->source); })())) > 1)) {
                // line 10
                echo "        ";
                ob_start();
                // line 11
                echo "            <div class=\"select\">
                <select id=\"site-id\" name=\"siteId\">
                    ";
                // line 13
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["editableSites"]) || array_key_exists("editableSites", $context) ? $context["editableSites"] : (function () { throw new RuntimeError('Variable "editableSites" does not exist.', 13, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                    // line 14
                    echo "                        <option value=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), "html", null, true);
                    echo "\"";
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 14, $this->source); })()), "siteId", []))) {
                        echo " selected";
                    }
                    echo ">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "site"), "html", null, true);
                    echo "</option>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 16
                echo "                </select>
            </div>
        ";
                $context["siteInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
                // line 19
                echo "
        ";
                // line 20
                echo twig_call_macro($macros["forms"], "macro_field", [["id" => "site-id", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app")],                 // line 23
(isset($context["siteInput"]) || array_key_exists("siteInput", $context) ? $context["siteInput"] : (function () { throw new RuntimeError('Variable "siteInput" does not exist.', 23, $this->source); })())], 20, $context, $this->getSourceContext());
                echo "


        ";
                // line 26
                echo twig_call_macro($macros["forms"], "macro_lightswitch", [["label" => "Ignore selected site and use all sites", "id" => "allSites", "name" => "allSites", "on" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 30
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 30, $this->source); })()), "allSites", [], "array")]], 26, $context, $this->getSourceContext());
                // line 31
                echo "
    ";
            }
        }
        // line 34
        echo "
";
        // line 35
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => "Widget title", "instructions" => "Title to display on the widget", "id" => "widgetTitle", "name" => "widgetTitle", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 40
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 40, $this->source); })()), "widgetTitle", [], "array")]], 35, $context, $this->getSourceContext());
        // line 41
        echo "

";
        // line 43
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => "Number of items", "instructions" => "Max number of items to show", "id" => "count", "name" => "count", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 48
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 48, $this->source); })()), "count", [], "array")]], 43, $context, $this->getSourceContext());
        // line 49
        echo "

";
        // line 51
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => "Seconds", "instructions" => "How many seconds the last view was registered", "id" => "seconds", "name" => "seconds", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 56
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 56, $this->source); })()), "seconds", [], "array")]], 51, $context, $this->getSourceContext());
        // line 57
        echo "


";
        // line 60
        echo twig_call_macro($macros["forms"], "macro_lightswitch", [["label" => "Enable auto refresh every 5 seconds", "id" => "enableAutoRefresh", "name" => "enableAutoRefresh", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 64
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 64, $this->source); })()), "enableAutoRefresh", [], "array")]], 60, $context, $this->getSourceContext());
        craft\helpers\Template::endProfile("template", "views-work/_components/widgets/ViewedNowWidget_settings");
    }

    public function getTemplateName()
    {
        return "views-work/_components/widgets/ViewedNowWidget_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 64,  132 => 60,  127 => 57,  125 => 56,  124 => 51,  120 => 49,  118 => 48,  117 => 43,  113 => 41,  111 => 40,  110 => 35,  107 => 34,  102 => 31,  100 => 30,  99 => 26,  93 => 23,  92 => 20,  89 => 19,  84 => 16,  69 => 14,  65 => 13,  61 => 11,  58 => 10,  56 => 9,  52 => 7,  49 => 6,  47 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}
{% import 'views-work/_macros' as cpmacros %}
{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\viewswork\\\\assetbundles\\\\viewswork\\\\ViewsWorkAsset\") %}

{% if craft.app.getIsMultiSite() %}
    {% set editableSites = craft.app.sites.getEditableSites() %}


    {% if editableSites|length > 1 %}
        {% set siteInput %}
            <div class=\"select\">
                <select id=\"site-id\" name=\"siteId\">
                    {% for site in editableSites %}
                        <option value=\"{{ site.id }}\"{% if site.id == widget.siteId %} selected{% endif %}>{{ site.name|t('site') }}</option>
                    {% endfor %}
                </select>
            </div>
        {% endset %}

        {{ forms.field({
            id: 'site-id',
            label: \"Site\"|t('app')
        }, siteInput) }}


        {{ forms.lightswitch({
            label: 'Ignore selected site and use all sites',
            id: 'allSites',
            name: 'allSites',
            on: widget['allSites']})
        }}
    {% endif %}
{% endif %}

{{ forms.textField({
    label: 'Widget title',
    instructions: 'Title to display on the widget',
    id: 'widgetTitle',
    name: 'widgetTitle',
    value: widget['widgetTitle']})
}}

{{ forms.textField({
    label: 'Number of items',
    instructions: 'Max number of items to show',
    id: 'count',
    name: 'count',
    value: widget['count']})
}}

{{ forms.textField({
    label: 'Seconds',
    instructions: 'How many seconds the last view was registered',
    id: 'seconds',
    name: 'seconds',
    value: widget['seconds']})
}}


{{ forms.lightswitch({
    label: 'Enable auto refresh every 5 seconds',
    id: 'enableAutoRefresh',
    name: 'enableAutoRefresh',
    on: widget['enableAutoRefresh']})
}}", "views-work/_components/widgets/ViewedNowWidget_settings", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_components/widgets/ViewedNowWidget_settings.twig");
    }
}
