<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Matrix/input */
class __TwigTemplate_d595412f81197bb2615bfe8d171b4846bf0c59810a5bec8b230fe578719c5d67 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Matrix/input");
        // line 1
        echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 1, $this->source); })()), "");
        echo "

<div class=\"matrix matrix-field\" id=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 3, $this->source); })()), "html", null, true);
        echo "\">
    <div class=\"blocks\">
        ";
        // line 5
        $context["totalNewBlocks"] = 0;
        // line 6
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new RuntimeError('Variable "blocks" does not exist.', 6, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
            // line 7
            echo "            ";
            $context["blockId"] = craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "id", []);
            // line 8
            echo "            ";
            $context["blockIsNew"] = twig_test_empty((isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new RuntimeError('Variable "blockId" does not exist.', 8, $this->source); })()));
            // line 9
            echo "            ";
            if ((isset($context["blockIsNew"]) || array_key_exists("blockIsNew", $context) ? $context["blockIsNew"] : (function () { throw new RuntimeError('Variable "blockIsNew" does not exist.', 9, $this->source); })())) {
                // line 10
                echo "                ";
                $context["totalNewBlocks"] = ((isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new RuntimeError('Variable "totalNewBlocks" does not exist.', 10, $this->source); })()) + 1);
                // line 11
                echo "                ";
                $context["blockId"] = ("new" . (isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new RuntimeError('Variable "totalNewBlocks" does not exist.', 11, $this->source); })()));
                // line 12
                echo "            ";
            }
            // line 13
            echo "            ";
            $context["baseInputName"] = ((((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 13, $this->source); })()) . "[blocks][") . (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new RuntimeError('Variable "blockId" does not exist.', 13, $this->source); })())) . "]");
            // line 14
            echo "            ";
            $context["blockAttributes"] = ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "matrixblock", 1 => (( !craft\helpers\Template::attribute($this->env, $this->source,             // line 17
$context["block"], "enabled", [])) ? ("disabled") : ("")), 2 => ((            // line 18
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 18, $this->source); })())) ? ("static") : (""))]), "data" => ["id" =>             // line 21
(isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new RuntimeError('Variable "blockId" does not exist.', 21, $this->source); })()), "type" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 22
$context["block"], "getType", [], "method"), "handle", []), "collapsed" => craft\helpers\Template::attribute($this->env, $this->source,             // line 23
$context["block"], "collapsed", [])]];
            // line 26
            echo "
            <div ";
            // line 27
            echo craft\helpers\Html::renderTagAttributes((isset($context["blockAttributes"]) || array_key_exists("blockAttributes", $context) ? $context["blockAttributes"] : (function () { throw new RuntimeError('Variable "blockAttributes" does not exist.', 27, $this->source); })()));
            echo ">
                ";
            // line 28
            if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 28, $this->source); })())) {
                // line 29
                echo "                    ";
                echo craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 29, $this->source); })()) . "[sortOrder][]"), (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new RuntimeError('Variable "blockId" does not exist.', 29, $this->source); })()));
                echo "
                    ";
                // line 31
                echo "                    ";
                if ( !(isset($context["blockIsNew"]) || array_key_exists("blockIsNew", $context) ? $context["blockIsNew"] : (function () { throw new RuntimeError('Variable "blockIsNew" does not exist.', 31, $this->source); })())) {
                    // line 32
                    echo "                        ";
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 32, $this->source); })()), "registerDeltaName", [0 => (isset($context["baseInputName"]) || array_key_exists("baseInputName", $context) ? $context["baseInputName"] : (function () { throw new RuntimeError('Variable "baseInputName" does not exist.', 32, $this->source); })())], "method");
                    // line 33
                    echo "                    ";
                }
                // line 34
                echo "                    ";
                echo craft\helpers\Html::hiddenInput(((isset($context["baseInputName"]) || array_key_exists("baseInputName", $context) ? $context["baseInputName"] : (function () { throw new RuntimeError('Variable "baseInputName" does not exist.', 34, $this->source); })()) . "[type]"), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "getType", [], "method"), "handle", []));
                echo "
                    ";
                // line 35
                echo craft\helpers\Html::hiddenInput(((isset($context["baseInputName"]) || array_key_exists("baseInputName", $context) ? $context["baseInputName"] : (function () { throw new RuntimeError('Variable "baseInputName" does not exist.', 35, $this->source); })()) . "[enabled]"), ((craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "enabled", [])) ? ("1") : ("")));
                echo "
                    <div class=\"titlebar\">
                        <div class=\"blocktype";
                // line 37
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "hasErrors", [], "method")) {
                    echo " error";
                }
                echo "\">
                            ";
                // line 38
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "getType", [], "method"), "name", []), "site"), "html", null, true);
                echo "
                            ";
                // line 39
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "hasErrors", [], "method")) {
                    echo "<span data-icon=\"alert\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Error", "app"), "html", null, true);
                    echo "\"></span>";
                }
                // line 40
                echo "                        </div>
                        <div class=\"preview\"></div>
                    </div>
                    <div class=\"checkbox\" title=\"";
                // line 43
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Select", "app"), "html", null, true);
                echo "\" aria-label=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Select", "app"), "html", null, true);
                echo "\"></div>
                    <div class=\"actions\">
                        <div class=\"status off\" title=\"";
                // line 45
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Disabled", "app"), "html", null, true);
                echo "\" aria-label=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Disabled", "app"), "html", null, true);
                echo "\"></div>
                        <a class=\"settings icon menubtn\" title=\"";
                // line 46
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"), "html", null, true);
                echo "\" aria-label=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"), "html", null, true);
                echo "\" role=\"button\"></a>
                        <div class=\"menu\">
                            <ul class=\"padded\">
                                <li><a data-icon=\"collapse\" data-action=\"collapse\">";
                // line 49
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Collapse", "app"), "html", null, true);
                echo "</a></li>
                                <li class=\"hidden\"><a data-icon=\"expand\" data-action=\"expand\">";
                // line 50
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Expand", "app"), "html", null, true);
                echo "</a></li>
                                <li";
                // line 51
                if ( !craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "enabled", [])) {
                    echo " class=\"hidden\"";
                }
                echo "><a data-icon=\"disabled\" data-action=\"disable\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Disable", "app"), "html", null, true);
                echo "</a></li>
                                <li";
                // line 52
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "enabled", [])) {
                    echo " class=\"hidden\"";
                }
                echo "><a data-icon=\"enabled\" data-action=\"enable\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Enable", "app"), "html", null, true);
                echo "</a></li>
                                <li><a data-icon=\"uarr\" data-action=\"moveUp\">";
                // line 53
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Move up", "app"), "html", null, true);
                echo "</a></li>
                                <li><a data-icon=\"darr\" data-action=\"moveDown\">";
                // line 54
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Move down", "app"), "html", null, true);
                echo "</a></li>
                            </ul>
                            ";
                // line 56
                if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new RuntimeError('Variable "staticBlocks" does not exist.', 56, $this->source); })())) {
                    // line 57
                    echo "                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    <li><a class=\"error\" data-icon=\"remove\" data-action=\"delete\">";
                    // line 59
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "</a></li>
                                </ul>
                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    ";
                    // line 63
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 63, $this->source); })()));
                    foreach ($context['_seq'] as $context["_key"] => $context["blockType"]) {
                        // line 64
                        echo "                                        <li><a data-icon=\"plus\" data-action=\"add\" data-type=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "handle", []), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Add {type} above", "app", ["type" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "name", []), "site")]), "html", null, true);
                        echo "</a></li>
                                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blockType'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 66
                    echo "                                </ul>
                            ";
                }
                // line 68
                echo "                        </div>
                        <a class=\"move icon\" title=\"";
                // line 69
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\" aria-label=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\" role=\"button\"></a>
                    </div>
                ";
            }
            // line 72
            echo "                <div class=\"fields\">
                    ";
            // line 73
            $_namespace = (isset($context["baseInputName"]) || array_key_exists("baseInputName", $context) ? $context["baseInputName"] : (function () { throw new RuntimeError('Variable "baseInputName" does not exist.', 73, $this->source); })());
            if ($_namespace) {
                $_originalNamespace = Craft::$app->getView()->getNamespace();
                Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                ob_start();
                try {
                    // line 74
                    echo "                        ";
                    echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "getFieldLayout", [], "method"), "createForm", [0 => $context["block"], 1 => (isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 74, $this->source); })())], "method"), "render", [], "method");
                    echo "
                    ";
                } catch (Exception $e) {
                    ob_end_clean();

                    throw $e;
                }
                echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                Craft::$app->getView()->setNamespace($_originalNamespace);
            } else {
                echo "                        ";
                echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "getFieldLayout", [], "method"), "createForm", [0 => $context["block"], 1 => (isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 74, $this->source); })())], "method"), "render", [], "method");
                echo "
                    ";
            }
            unset($_originalNamespace, $_namespace);
            // line 76
            echo "                </div>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "    </div>
    ";
        // line 80
        if (( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 80, $this->source); })()) &&  !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new RuntimeError('Variable "staticBlocks" does not exist.', 80, $this->source); })()))) {
            // line 81
            echo "        <div class=\"buttons\">
            <div class=\"btngroup\">
                ";
            // line 83
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 83, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["blockType"]) {
                // line 84
                echo "                    <button type=\"button\" class=\"btn dashed";
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) {
                    echo " add icon";
                }
                echo "\" data-type=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "handle", []), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "name", []), "site"), "html", null, true);
                echo "</button>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blockType'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 86
            echo "            </div>

            <button type=\"button\" class=\"btn dashed add icon menubtn hidden\">";
            // line 88
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Add a block", "app"), "html", null, true);
            echo "</button>
            <div class=\"menu\">
                <ul>
                    ";
            // line 91
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 91, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["blockType"]) {
                // line 92
                echo "                        <li><a data-type=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "handle", []), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "name", []), "site"), "html", null, true);
                echo "</a></li>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blockType'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 94
            echo "                </ul>
            </div>
        </div>
    ";
        }
        // line 98
        echo "</div>
";
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Matrix/input");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Matrix/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  352 => 98,  346 => 94,  335 => 92,  331 => 91,  325 => 88,  321 => 86,  298 => 84,  281 => 83,  277 => 81,  275 => 80,  272 => 79,  264 => 76,  245 => 74,  238 => 73,  235 => 72,  227 => 69,  224 => 68,  220 => 66,  209 => 64,  205 => 63,  198 => 59,  194 => 57,  192 => 56,  187 => 54,  183 => 53,  175 => 52,  167 => 51,  163 => 50,  159 => 49,  151 => 46,  145 => 45,  138 => 43,  133 => 40,  127 => 39,  123 => 38,  117 => 37,  112 => 35,  107 => 34,  104 => 33,  101 => 32,  98 => 31,  93 => 29,  91 => 28,  87 => 27,  84 => 26,  82 => 23,  81 => 22,  80 => 21,  79 => 18,  78 => 17,  76 => 14,  73 => 13,  70 => 12,  67 => 11,  64 => 10,  61 => 9,  58 => 8,  55 => 7,  50 => 6,  48 => 5,  43 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ hiddenInput(name, '') }}

<div class=\"matrix matrix-field\" id=\"{{ id }}\">
    <div class=\"blocks\">
        {% set totalNewBlocks = 0 %}
        {% for block in blocks %}
            {% set blockId = block.id %}
            {% set blockIsNew = blockId is empty %}
            {% if blockIsNew %}
                {% set totalNewBlocks = totalNewBlocks + 1 %}
                {% set blockId = 'new'~totalNewBlocks %}
            {% endif %}
            {% set baseInputName = \"#{name}[blocks][#{blockId}]\" %}
            {% set blockAttributes = {
                class: [
                    'matrixblock',
                    not block.enabled ? 'disabled',
                    static ? 'static',
                ]|filter,
                data: {
                    id: blockId,
                    type: block.getType().handle,
                    collapsed: block.collapsed,
                },
            } %}

            <div {{ attr(blockAttributes) }}>
                {% if not static %}
                    {{ hiddenInput(\"#{name}[sortOrder][]\", blockId) }}
                    {# only register a delta name for this black if it's not new #}
                    {% if not blockIsNew %}
                        {% do view.registerDeltaName(baseInputName) %}
                    {% endif %}
                    {{ hiddenInput(\"#{baseInputName}[type]\", block.getType().handle) }}
                    {{ hiddenInput(\"#{baseInputName}[enabled]\", block.enabled ? '1' : '') }}
                    <div class=\"titlebar\">
                        <div class=\"blocktype{% if block.hasErrors() %} error{% endif %}\">
                            {{ block.getType().name|t('site') }}
                            {% if block.hasErrors() %}<span data-icon=\"alert\" aria-label=\"{{ 'Error'|t('app') }}\"></span>{% endif %}
                        </div>
                        <div class=\"preview\"></div>
                    </div>
                    <div class=\"checkbox\" title=\"{{ 'Select'|t('app') }}\" aria-label=\"{{ 'Select'|t('app') }}\"></div>
                    <div class=\"actions\">
                        <div class=\"status off\" title=\"{{ 'Disabled'|t('app') }}\" aria-label=\"{{ 'Disabled'|t('app') }}\"></div>
                        <a class=\"settings icon menubtn\" title=\"{{ 'Actions'|t('app') }}\" aria-label=\"{{ 'Actions'|t('app') }}\" role=\"button\"></a>
                        <div class=\"menu\">
                            <ul class=\"padded\">
                                <li><a data-icon=\"collapse\" data-action=\"collapse\">{{ \"Collapse\"|t('app') }}</a></li>
                                <li class=\"hidden\"><a data-icon=\"expand\" data-action=\"expand\">{{ \"Expand\"|t('app') }}</a></li>
                                <li{% if not block.enabled %} class=\"hidden\"{% endif %}><a data-icon=\"disabled\" data-action=\"disable\">{{ \"Disable\"|t('app') }}</a></li>
                                <li{% if block.enabled %} class=\"hidden\"{% endif %}><a data-icon=\"enabled\" data-action=\"enable\">{{ \"Enable\"|t('app') }}</a></li>
                                <li><a data-icon=\"uarr\" data-action=\"moveUp\">{{ 'Move up'|t('app') }}</a></li>
                                <li><a data-icon=\"darr\" data-action=\"moveDown\">{{ 'Move down'|t('app') }}</a></li>
                            </ul>
                            {% if not staticBlocks %}
                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    <li><a class=\"error\" data-icon=\"remove\" data-action=\"delete\">{{ \"Delete\"|t('app') }}</a></li>
                                </ul>
                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    {% for blockType in blockTypes %}
                                        <li><a data-icon=\"plus\" data-action=\"add\" data-type=\"{{ blockType.handle }}\">{{ \"Add {type} above\"|t('app', { type: blockType.name|t('site') }) }}</a></li>
                                    {% endfor %}
                                </ul>
                            {% endif %}
                        </div>
                        <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" aria-label=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a>
                    </div>
                {% endif %}
                <div class=\"fields\">
                    {% namespace baseInputName %}
                        {{ block.getFieldLayout().createForm(block, static).render()|raw }}
                    {% endnamespace %}
                </div>
            </div>
        {% endfor %}
    </div>
    {% if not static and not staticBlocks %}
        <div class=\"buttons\">
            <div class=\"btngroup\">
                {% for blockType in blockTypes %}
                    <button type=\"button\" class=\"btn dashed{% if loop.first %} add icon{% endif %}\" data-type=\"{{ blockType.handle }}\">{{ blockType.name|t('site') }}</button>
                {% endfor %}
            </div>

            <button type=\"button\" class=\"btn dashed add icon menubtn hidden\">{{ \"Add a block\"|t('app') }}</button>
            <div class=\"menu\">
                <ul>
                    {% for blockType in blockTypes %}
                        <li><a data-type=\"{{ blockType.handle }}\">{{ blockType.name|t('site') }}</a></li>
                    {% endfor %}
                </ul>
            </div>
        </div>
    {% endif %}
</div>
", "_components/fieldtypes/Matrix/input", "/var/www/html/vendor/craftcms/cms/src/templates/_components/fieldtypes/Matrix/input.html");
    }
}
