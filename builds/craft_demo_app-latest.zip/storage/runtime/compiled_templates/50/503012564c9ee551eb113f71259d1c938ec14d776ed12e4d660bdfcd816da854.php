<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/_index */
class __TwigTemplate_e274a35190f0c395492409663082afdf14ca65bb58e5b20b2264ea71b0e1c6d7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "dashboard/_index");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Dashboard", "app");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "dashboard/_index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "dashboard/_index");
    }

    // line 4
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 5
        echo "    <div class=\"buttons\">
        <div class=\"newwidget btngroup\">
            <button type=\"button\" id=\"newwidgetmenubtn\" class=\"btn menubtn add icon\">";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New widget", "app"), "html", null, true);
        echo "</button>
            <div class=\"menu newwidgetmenu\">
                <ul>
                    ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["widgetTypes"]) || array_key_exists("widgetTypes", $context) ? $context["widgetTypes"] : (function () { throw new RuntimeError('Variable "widgetTypes" does not exist.', 10, $this->source); })()));
        foreach ($context['_seq'] as $context["type"] => $context["info"]) {
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "selectable", [])) {
                // line 11
                echo "                        <li>
                            <a data-type=\"";
                // line 12
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo "\" data-name=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "name", []), "html", null, true);
                echo "\">
                                <span class=\"icon\" aria-hidden=\"true\">";
                // line 13
                echo $this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "iconSvg", []), false);
                echo "</span>
                                ";
                // line 14
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "name", []), "html", null, true);
                echo "
                            </a>
                        </li>
                    ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['info'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "                </ul>
            </div>
        </div>

        <button type=\"button\" id=\"widgetManagerBtn\" class=\"btn settings icon\" title=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "html", null, true);
        echo "\"></button>
    </div>
";
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 27
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 28
        echo "    <div id=\"dashboard-grid\" class=\"grid\">
        ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["widgets"]) || array_key_exists("widgets", $context) ? $context["widgets"] : (function () { throw new RuntimeError('Variable "widgets" does not exist.', 29, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["widget"]) {
            // line 30
            echo "            <div class=\"item\" data-colspan=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "colspan", []), "html", null, true);
            echo "\">
                <div id=\"widget";
            // line 31
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "id", []), "html", null, true);
            echo "\" class=\"widget ";
            echo twig_escape_filter($this->env, twig_lower_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "type", [])), "html", null, true);
            echo "\" data-id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "id", []), "html", null, true);
            echo "\" data-type=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "type", []), "html", null, true);
            echo "\" data-title=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "title", []), "html", null, true);
            echo "\">
                    <div class=\"front\">
                        <div class=\"pane\">
                            <div class=\"spinner body-loading\"></div>
                            ";
            // line 35
            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "title", []) || craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "subtitle", []))) {
                // line 36
                echo "                                <div class=\"widget-heading\">
                                    ";
                // line 37
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "title", [])) {
                    // line 38
                    echo "                                        <h2>";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "title", []), "html", null, true);
                    echo "</h2>
                                    ";
                }
                // line 40
                echo "                                    ";
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "subtitle", [])) {
                    // line 41
                    echo "                                        <h5>";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "subtitle", []), "html", null, true);
                    echo "</h5>
                                    ";
                }
                // line 43
                echo "                                </div>
                            ";
            }
            // line 45
            echo "                            <div class=\"body\">
                                ";
            // line 46
            echo craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "bodyHtml", []);
            echo "
                            </div>
                            <div class=\"settings icon hidden\"></div>
                        </div>
                    </div>
                    <div class=\"back hidden\">
                        <form class=\"pane\">
                            ";
            // line 53
            echo craft\helpers\Html::hiddenInput("widgetId", craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "id", []));
            echo "
                            <h2 class=\"first\">";
            // line 54
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("{type} Settings", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, $context["widget"], "name", [])]), "html", null, true);
            echo "</h2>
                            <div class=\"settings\"></div>
                            <hr>
                            <div class=\"buttons clearafter\">
                                <button type=\"submit\" class=\"btn submit\">";
            // line 58
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
            echo "</button>
                                <button type=\"button\" class=\"btn\">";
            // line 59
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Cancel", "app"), "html", null, true);
            echo "</button>
                                <div class=\"spinner hidden\"></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['widget'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "    </div>
";
        craft\helpers\Template::endProfile("block", "main");
    }

    public function getTemplateName()
    {
        return "dashboard/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  212 => 67,  198 => 59,  194 => 58,  187 => 54,  183 => 53,  173 => 46,  170 => 45,  166 => 43,  160 => 41,  157 => 40,  151 => 38,  149 => 37,  146 => 36,  144 => 35,  129 => 31,  124 => 30,  120 => 29,  117 => 28,  112 => 27,  102 => 22,  96 => 18,  85 => 14,  81 => 13,  75 => 12,  72 => 11,  67 => 10,  61 => 7,  57 => 5,  52 => 4,  46 => 1,  44 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"Dashboard\"|t('app') %}

{% block actionButton %}
    <div class=\"buttons\">
        <div class=\"newwidget btngroup\">
            <button type=\"button\" id=\"newwidgetmenubtn\" class=\"btn menubtn add icon\">{{ 'New widget'|t('app') }}</button>
            <div class=\"menu newwidgetmenu\">
                <ul>
                    {% for type, info in widgetTypes if info.selectable %}
                        <li>
                            <a data-type=\"{{ type }}\" data-name=\"{{ info.name }}\">
                                <span class=\"icon\" aria-hidden=\"true\">{{ svg(info.iconSvg, sanitize=false) }}</span>
                                {{ info.name }}
                            </a>
                        </li>
                    {% endfor %}
                </ul>
            </div>
        </div>

        <button type=\"button\" id=\"widgetManagerBtn\" class=\"btn settings icon\" title=\"{{ 'Settings'|t('app') }}\" aria-label=\"{{ 'Settings'|t('app') }}\"></button>
    </div>
{% endblock %}


{% block main %}
    <div id=\"dashboard-grid\" class=\"grid\">
        {% for widget in widgets %}
            <div class=\"item\" data-colspan=\"{{ widget.colspan }}\">
                <div id=\"widget{{ widget.id }}\" class=\"widget {{ widget.type|lower }}\" data-id=\"{{ widget.id }}\" data-type=\"{{ widget.type }}\" data-title=\"{{ widget.title }}\">
                    <div class=\"front\">
                        <div class=\"pane\">
                            <div class=\"spinner body-loading\"></div>
                            {% if widget.title or widget.subtitle %}
                                <div class=\"widget-heading\">
                                    {% if widget.title %}
                                        <h2>{{ widget.title }}</h2>
                                    {% endif %}
                                    {% if widget.subtitle %}
                                        <h5>{{ widget.subtitle }}</h5>
                                    {% endif %}
                                </div>
                            {% endif %}
                            <div class=\"body\">
                                {{ widget.bodyHtml|raw }}
                            </div>
                            <div class=\"settings icon hidden\"></div>
                        </div>
                    </div>
                    <div class=\"back hidden\">
                        <form class=\"pane\">
                            {{ hiddenInput('widgetId', widget.id) }}
                            <h2 class=\"first\">{{ \"{type} Settings\"|t('app', { type: widget.name }) }}</h2>
                            <div class=\"settings\"></div>
                            <hr>
                            <div class=\"buttons clearafter\">
                                <button type=\"submit\" class=\"btn submit\">{{ 'Save'|t('app') }}</button>
                                <button type=\"button\" class=\"btn\">{{ 'Cancel'|t('app') }}</button>
                                <div class=\"spinner hidden\"></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        {% endfor %}
    </div>
{% endblock %}
", "dashboard/_index", "/var/www/html/vendor/craftcms/cms/src/templates/dashboard/_index.html");
    }
}
