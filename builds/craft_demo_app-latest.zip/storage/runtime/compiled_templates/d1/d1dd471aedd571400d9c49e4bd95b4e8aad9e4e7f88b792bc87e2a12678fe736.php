<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/editableTable */
class __TwigTemplate_3536e862bbd80ee2cdc55edce53f58cf00eddd3a020d39b04fe197296154d203 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'tablecell' => [$this, 'block_tablecell'],
        ];
        $macros["_self"] = $this->macros["_self"] = $this;
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/editableTable");
        // line 1
        $context["static"] = (($context["static"]) ?? (false));
        // line 2
        $context["fullWidth"] = (($context["fullWidth"]) ?? (true));
        // line 3
        $context["cols"] = (($context["cols"]) ?? ([]));
        // line 4
        $context["rows"] = (($context["rows"]) ?? ([]));
        // line 5
        $context["initJs"] = ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 5, $this->source); })()) && (($context["initJs"]) ?? (true)));
        // line 6
        $context["minRows"] = (($context["minRows"]) ?? (null));
        // line 7
        $context["maxRows"] = (($context["maxRows"]) ?? (null));
        // line 8
        $context["staticRows"] = (((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 8, $this->source); })()) || (($context["staticRows"]) ?? (false))) || ((((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 8, $this->source); })()) == 1) && ((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 8, $this->source); })()) == 1)) && (twig_length_filter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 8, $this->source); })())) == 1)));
        // line 9
        $context["fixedRows"] = ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 9, $this->source); })()) && (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 9, $this->source); })()) && ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 9, $this->source); })()) == (isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 9, $this->source); })()))) && ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 9, $this->source); })()) == twig_length_filter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 9, $this->source); })())))));
        // line 10
        echo "
";
        // line 11
        if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 11, $this->source); })())) {
            // line 12
            echo "    ";
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 12, $this->source); })()), "");
            echo "
";
        }
        // line 14
        echo "
";
        // line 23
        echo "
";
        // line 24
        $context["tableAttributes"] = ["id" =>         // line 25
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 25, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "editable", 1 => ((        // line 28
(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 28, $this->source); })())) ? ("fullwidth") : ("")), 2 => ((        // line 29
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 29, $this->source); })())) ? ("static") : ("")), 3 => (((twig_length_filter($this->env,         // line 30
(isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 30, $this->source); })())) == 0)) ? ("hidden") : (""))])];
        // line 34
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 35
            $context["tableAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableAttributes"]) || array_key_exists("tableAttributes", $context) ? $context["tableAttributes"] : (function () { throw new RuntimeError('Variable "tableAttributes" does not exist.', 35, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 37
        echo "
";
        // line 38
        ob_start();
        // line 39
        echo "    <thead>
        <tr>
            ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 41, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["col"]) {
            // line 42
            switch (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", [])) {
                case "time":
                {
                    // line 44
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 44, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\timepicker\\TimepickerAsset"], "method");
                    break;
                }
                case "template":
                {
                    // line 46
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 46, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\vue\\VueAsset"], "method");
                    break;
                }
            }
            // line 48
            echo "                <th scope=\"col\" class=\"";
            echo twig_call_macro($macros["_self"], "macro_cellClass", [(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 48, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ([]))], 48, $context, $this->getSourceContext());
            echo "\">";
            // line 49
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "headingHtml", [], "any", true, true)) {
                // line 50
                echo craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "headingHtml", []);
            } elseif ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 51
$context["col"], "heading", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", [])) : (false))) {
                // line 52
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", []), "html", null, true);
            } else {
                // line 54
                echo "                        &nbsp;";
            }
            // line 56
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "info", [], "any", true, true)) {
                // line 57
                echo "<span class=\"info\">";
                echo $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "info", []));
                echo "</span>";
            }
            // line 59
            echo "</th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['col'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "            ";
        if ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 61, $this->source); })())) {
            // line 62
            echo "                <th colspan=\"";
            echo (((isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 62, $this->source); })())) ? (1) : (2));
            echo "\"></th>
            ";
        }
        // line 64
        echo "        </tr>
    </thead>
    <tbody>
        ";
        // line 67
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 67, $this->source); })()));
        foreach ($context['_seq'] as $context["rowId"] => $context["row"]) {
            // line 68
            echo "            <tr data-id=\"";
            echo twig_escape_filter($this->env, $context["rowId"], "html", null, true);
            echo "\">
                ";
            // line 69
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 69, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["colId"] => $context["col"]) {
                // line 70
                echo "                    ";
                $context["cell"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array")) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array")) : (null))));
                // line 71
                echo "                    ";
                $context["value"] = ((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "value", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new RuntimeError('Variable "cell" does not exist.', 71, $this->source); })()), "value", [])) : ((isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new RuntimeError('Variable "cell" does not exist.', 71, $this->source); })())));
                // line 72
                echo "                    ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", []) == "heading")) {
                    // line 73
                    echo "                        <th scope=\"row\" class=\"";
                    echo twig_call_macro($macros["_self"], "macro_cellClass", [(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 73, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ([]))))], 73, $context, $this->getSourceContext());
                    echo "\">";
                    echo (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 73, $this->source); })());
                    echo "</th>
                    ";
                } elseif ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 74
$context["col"], "type", []) == "html")) {
                    // line 75
                    echo "                        <td class=\"";
                    echo twig_call_macro($macros["_self"], "macro_cellClass", [(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 75, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ([]))))], 75, $context, $this->getSourceContext());
                    echo "\">";
                    echo (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 75, $this->source); })());
                    echo "</td>
                    ";
                } else {
                    // line 77
                    echo "                        ";
                    $context["hasErrors"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [])) : (false));
                    // line 78
                    echo "                        ";
                    $context["cellName"] = ((((((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 78, $this->source); })()) . "[") . $context["rowId"]) . "][") . $context["colId"]) . "]");
                    // line 79
                    echo "                        ";
                    $context["isCode"] = ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "code", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "code", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "code", [])) : (false)) || (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", []) == "color"));
                    // line 80
                    echo "                        <td class=\"";
                    echo twig_call_macro($macros["_self"], "macro_cellClass", [(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 80, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ([]))], 80, $context, $this->getSourceContext());
                    echo " ";
                    if ((isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new RuntimeError('Variable "isCode" does not exist.', 80, $this->source); })())) {
                        echo "code";
                    }
                    echo " ";
                    if ((isset($context["hasErrors"]) || array_key_exists("hasErrors", $context) ? $context["hasErrors"] : (function () { throw new RuntimeError('Variable "hasErrors" does not exist.', 80, $this->source); })())) {
                        echo "error";
                    }
                    echo "\"";
                    if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [])) : (false))) {
                        echo " width=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", []), "html", null, true);
                        echo "\"";
                    }
                    echo ">
                            ";
                    // line 81
                    $this->displayBlock('tablecell', $context, $blocks);
                    // line 150
                    echo "                        </td>
                    ";
                }
                // line 152
                echo "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['colId'], $context['col'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 153
            echo "                ";
            if ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 153, $this->source); })())) {
                // line 154
                echo "                    <td class=\"thin action\"><a class=\"move icon\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\" aria-label=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\"></a></td>
                    ";
                // line 155
                if ( !(isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 155, $this->source); })())) {
                    echo "<td class=\"thin action\"><a class=\"delete icon\" title=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "\"></a></td>";
                }
                // line 156
                echo "                ";
            }
            // line 157
            echo "            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['rowId'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 159
        echo "    </tbody>
";
        echo craft\helpers\Html::tag("table", ob_get_clean(),         // line 38
(isset($context["tableAttributes"]) || array_key_exists("tableAttributes", $context) ? $context["tableAttributes"] : (function () { throw new RuntimeError('Variable "tableAttributes" does not exist.', 38, $this->source); })()));
        // line 161
        echo "
";
        // line 162
        if (( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 162, $this->source); })()) &&  !(isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 162, $this->source); })()))) {
            // line 163
            echo "    <button type=\"button\" class=\"btn add icon\">";
            echo twig_escape_filter($this->env, (($context["addRowLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Add a row", "app"))), "html", null, true);
            echo "</button>
";
        }
        // line 165
        echo "
";
        // line 166
        if ((isset($context["initJs"]) || array_key_exists("initJs", $context) ? $context["initJs"] : (function () { throw new RuntimeError('Variable "initJs" does not exist.', 166, $this->source); })())) {
            // line 167
            echo "    ";
            $context["jsId"] = twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 167, $this->source); })())]), "js");
            // line 168
            echo "    ";
            $context["jsName"] = twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), [(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 168, $this->source); })())]), "js");
            // line 169
            echo "    ";
            $context["jsCols"] = $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 169, $this->source); })()));
            // line 170
            echo "    ";
            $context["defaultValues"] = (($context["defaultValues"]) ?? (null));
            // line 171
            echo "    ";
            ob_start();
            // line 172
            echo "        new Craft.EditableTable(\"";
            echo twig_escape_filter($this->env, (isset($context["jsId"]) || array_key_exists("jsId", $context) ? $context["jsId"] : (function () { throw new RuntimeError('Variable "jsId" does not exist.', 172, $this->source); })()), "html", null, true);
            echo "\", \"";
            echo twig_escape_filter($this->env, (isset($context["jsName"]) || array_key_exists("jsName", $context) ? $context["jsName"] : (function () { throw new RuntimeError('Variable "jsName" does not exist.', 172, $this->source); })()), "html", null, true);
            echo "\", ";
            echo (isset($context["jsCols"]) || array_key_exists("jsCols", $context) ? $context["jsCols"] : (function () { throw new RuntimeError('Variable "jsCols" does not exist.', 172, $this->source); })());
            echo ", {
            defaultValues: ";
            // line 173
            echo (((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new RuntimeError('Variable "defaultValues" does not exist.', 173, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new RuntimeError('Variable "defaultValues" does not exist.', 173, $this->source); })()))) : ("{}"));
            echo ",
            staticRows: ";
            // line 174
            echo (((isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 174, $this->source); })())) ? ("true") : ("false"));
            echo ",
            minRows: ";
            // line 175
            (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 175, $this->source); })())) ? (print (twig_escape_filter($this->env, (isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 175, $this->source); })()), "html", null, true))) : (print ("null")));
            echo ",
            maxRows: ";
            // line 176
            (((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 176, $this->source); })())) ? (print (twig_escape_filter($this->env, (isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 176, $this->source); })()), "html", null, true))) : (print ("null")));
            echo "
        });
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/editableTable");
    }

    // line 81
    public function block_tablecell($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "tablecell");
        // line 82
        switch (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 82, $this->source); })()), "type", [])) {
            case "checkbox":
            {
                // line 84
                echo "<div class=\"checkbox-wrapper\">
                                            ";
                // line 85
                $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/editableTable", 85)->display(twig_to_array(["name" =>                 // line 86
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 86, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 87
($context["col"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])) : (1)), "checked" =>  !twig_test_empty(                // line 88
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 88, $this->source); })())), "disabled" =>                 // line 89
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 89, $this->source); })())]));
                // line 91
                echo "                                        </div>";
                break;
            }
            case "color":
            {
                // line 93
                $this->loadTemplate("_includes/forms/color", "_includes/forms/editableTable", 93)->display(twig_to_array(["name" =>                 // line 94
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 94, $this->source); })()), "value" =>                 // line 95
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 95, $this->source); })()), "small" => true, "disabled" =>                 // line 97
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 97, $this->source); })())]));
                break;
            }
            case "date":
            {
                // line 100
                $this->loadTemplate("_includes/forms/date", "_includes/forms/editableTable", 100)->display(twig_to_array(["name" =>                 // line 101
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 101, $this->source); })()), "value" =>                 // line 102
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 102, $this->source); })()), "disabled" =>                 // line 103
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 103, $this->source); })())]));
                break;
            }
            case "lightswitch":
            {
                // line 106
                $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms/editableTable", 106)->display(twig_to_array(["name" =>                 // line 107
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 107, $this->source); })()), "on" =>                 // line 108
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 108, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 109
($context["col"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])) : (1)), "small" => true, "disabled" =>                 // line 111
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 111, $this->source); })())]));
                // line 113
                echo "                                    ";
                break;
            }
            case "select":
            {
                // line 114
                $this->loadTemplate("_includes/forms/select", "_includes/forms/editableTable", 114)->display(twig_to_array(["class" => "small", "name" =>                 // line 116
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 116, $this->source); })()), "options" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 117
($context["cell"] ?? null), "options", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "options", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "options", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 117, $this->source); })()), "options", []))), "value" =>                 // line 118
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 118, $this->source); })()), "disabled" =>                 // line 119
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 119, $this->source); })())]));
                break;
            }
            case "time":
            {
                // line 122
                $this->loadTemplate("_includes/forms/time", "_includes/forms/editableTable", 122)->display(twig_to_array(["name" =>                 // line 123
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 123, $this->source); })()), "value" =>                 // line 124
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 124, $this->source); })()), "disabled" =>                 // line 125
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 125, $this->source); })())]));
                break;
            }
            case "email":
            case "url":
            {
                // line 128
                $this->loadTemplate("_includes/forms/text", "_includes/forms/editableTable", 128)->display(twig_to_array(["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 129
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 129, $this->source); })()), "type", []), "name" =>                 // line 130
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 130, $this->source); })()), "placeholder" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 131
($context["col"] ?? null), "placeholder", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [])) : (null)), "value" =>                 // line 132
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 132, $this->source); })()), "disabled" =>                 // line 133
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 133, $this->source); })())]));
                break;
            }
            case "template":
            {
                // line 136
                $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms/editableTable", 136)->display(twig_to_array(["name" =>                 // line 137
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 137, $this->source); })()), "suggestions" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,                 // line 138
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 138, $this->source); })()), "cp", []), "getTemplateSuggestions", [], "method"), "value" =>                 // line 139
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 139, $this->source); })()), "disabled" =>                 // line 140
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 140, $this->source); })())]));
                break;
            }
            default:
            {
                // line 143
                if ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 143, $this->source); })())) {
                    // line 144
                    echo "                                            <pre class=\"disabled\">";
                    echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 144, $this->source); })()), "html", null, true);
                    echo "</pre>
                                        ";
                } else {
                    // line 146
                    echo "                                            <textarea name=\"";
                    echo twig_escape_filter($this->env, (isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 146, $this->source); })()), "html", null, true);
                    echo "\" rows=\"";
                    (((craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "rows", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "rows", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "rows", []), "html", null, true))) : (print (1)));
                    echo "\"";
                    if (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [], "any", true, true)) {
                        echo " placeholder=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 146, $this->source); })()), "placeholder", []), "html", null, true);
                        echo "\"";
                    }
                    echo ">";
                    echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 146, $this->source); })()), "html", null, true);
                    echo "</textarea>
                                        ";
                }
            }
        }
        craft\helpers\Template::endProfile("block", "tablecell");
    }

    // line 15
    public function macro_cellClass($__fullWidth__ = null, $__col__ = null, $__class__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "fullWidth" => $__fullWidth__,
            "col" => $__col__,
            "class" => $__class__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "cellClass");
            // line 16
            echo twig_escape_filter($this->env, twig_join_filter($this->extensions['craft\web\twig\Extension']->mergeFilter(((twig_test_iterable((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 16, $this->source); })()))) ? ((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 16, $this->source); })())) : ([0 => (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 16, $this->source); })())])), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => (craft\helpers\Template::attribute($this->env, $this->source,             // line 17
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 17, $this->source); })()), "type", []) . "-cell"), 1 => ((twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source,             // line 18
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 18, $this->source); })()), "type", []), [0 => "color", 1 => "date", 2 => "email", 3 => "multiline", 4 => "number", 5 => "singleline", 6 => "template", 7 => "time", 8 => "url"])) ? ("textual") : (null)), 2 => (((            // line 19
(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 19, $this->source); })()) && (((craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [])) : (false)))) ? ("thin") : (null)), 3 => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 20
($context["col"] ?? null), "info", [], "any", true, true)) ? ("has-info") : (null))])), " "), "html", null, true);
            craft\helpers\Template::endProfile("macro", "cellClass");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms/editableTable";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  497 => 20,  496 => 19,  495 => 18,  494 => 17,  493 => 16,  477 => 15,  456 => 146,  450 => 144,  448 => 143,  442 => 140,  441 => 139,  440 => 138,  439 => 137,  438 => 136,  432 => 133,  431 => 132,  430 => 131,  429 => 130,  428 => 129,  427 => 128,  420 => 125,  419 => 124,  418 => 123,  417 => 122,  411 => 119,  410 => 118,  409 => 117,  408 => 116,  407 => 114,  401 => 113,  399 => 111,  398 => 109,  397 => 108,  396 => 107,  395 => 106,  389 => 103,  388 => 102,  387 => 101,  386 => 100,  380 => 97,  379 => 95,  378 => 94,  377 => 93,  371 => 91,  369 => 89,  368 => 88,  367 => 87,  366 => 86,  365 => 85,  362 => 84,  358 => 82,  353 => 81,  343 => 176,  339 => 175,  335 => 174,  331 => 173,  322 => 172,  319 => 171,  316 => 170,  313 => 169,  310 => 168,  307 => 167,  305 => 166,  302 => 165,  296 => 163,  294 => 162,  291 => 161,  289 => 38,  286 => 159,  279 => 157,  276 => 156,  268 => 155,  261 => 154,  258 => 153,  244 => 152,  240 => 150,  238 => 81,  219 => 80,  216 => 79,  213 => 78,  210 => 77,  202 => 75,  200 => 74,  193 => 73,  190 => 72,  187 => 71,  184 => 70,  167 => 69,  162 => 68,  158 => 67,  153 => 64,  147 => 62,  144 => 61,  137 => 59,  132 => 57,  130 => 56,  127 => 54,  124 => 52,  122 => 51,  120 => 50,  118 => 49,  114 => 48,  109 => 46,  103 => 44,  99 => 42,  95 => 41,  91 => 39,  89 => 38,  86 => 37,  83 => 35,  81 => 34,  79 => 30,  78 => 29,  77 => 28,  76 => 25,  75 => 24,  72 => 23,  69 => 14,  63 => 12,  61 => 11,  58 => 10,  56 => 9,  54 => 8,  52 => 7,  50 => 6,  48 => 5,  46 => 4,  44 => 3,  42 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set static = static ?? false %}
{%- set fullWidth = fullWidth ?? true %}
{%- set cols = cols ?? [] %}
{%- set rows = rows ?? [] %}
{%- set initJs = not static and (initJs ?? true) -%}
{%- set minRows = minRows ?? null %}
{%- set maxRows = maxRows ?? null %}
{%- set staticRows = static or (staticRows ?? false) or (minRows == 1 and maxRows == 1 and rows|length == 1) %}
{%- set fixedRows = not staticRows and (minRows and minRows == maxRows and minRows == rows|length) %}

{% if not static %}
    {{ hiddenInput(name, '') }}
{% endif %}

{% macro cellClass(fullWidth, col, class) %}
    {{- (class is iterable ? class : [class])|merge([
        \"#{col.type}-cell\",
        col.type in ['color', 'date', 'email', 'multiline', 'number', 'singleline', 'template', 'time', 'url'] ? 'textual' : null,
        fullWidth and (col.thin ?? false) ? 'thin' : null,
        col.info is defined ? 'has-info' : null,
    ]|filter)|join(' ') -}}
{% endmacro %}

{% set tableAttributes = {
    id: id,
    class: [
        'editable',
        fullWidth ? 'fullwidth',
        static ? 'static',
        rows|length == 0 ? 'hidden',
    ]|filter,
} %}

{%- if block('attr') is defined %}
  {%- set tableAttributes = tableAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% tag 'table' with tableAttributes %}
    <thead>
        <tr>
            {% for col in cols %}
                {%- switch col.type %}
                    {%- case 'time' %}
                        {%- do view.registerAssetBundle('craft\\\\web\\\\assets\\\\timepicker\\\\TimepickerAsset') %}
                    {%- case 'template' %}
                        {%- do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\vue\\\\VueAsset\") %}
                {%- endswitch %}
                <th scope=\"col\" class=\"{{ _self.cellClass(fullWidth, col, col.class ?? []) }}\">
                    {%- if col.headingHtml is defined %}
                        {{- col.headingHtml|raw }}
                    {%- elseif col.heading ?? false %}
                        {{- col.heading }}
                    {%- else %}
                        &nbsp;
                    {%- endif %}
                    {%- if col.info is defined -%}
                        <span class=\"info\">{{ col.info|md|raw }}</span>
                    {%- endif -%}
                </th>
            {% endfor %}
            {% if not staticRows %}
                <th colspan=\"{{ fixedRows ? 1 : 2 }}\"></th>
            {% endif %}
        </tr>
    </thead>
    <tbody>
        {% for rowId, row in rows %}
            <tr data-id=\"{{ rowId }}\">
                {% for colId, col in cols %}
                    {% set cell = row[colId] is defined ? row[colId] : (defaultValues[colId] ?? null) %}
                    {% set value = cell.value is defined ? cell.value : cell %}
                    {% if col.type == 'heading' %}
                        <th scope=\"row\" class=\"{{ _self.cellClass(fullWidth, col, cell.class ?? col.class ?? []) }}\">{{ value|raw }}</th>
                    {% elseif col.type == 'html' %}
                        <td class=\"{{ _self.cellClass(fullWidth, col, cell.class ?? col.class ?? []) }}\">{{ value|raw }}</td>
                    {% else %}
                        {% set hasErrors = cell.hasErrors ?? false %}
                        {% set cellName = name~'['~rowId~']['~colId~']' %}
                        {% set isCode = (col.code ?? false) or col.type == 'color' %}
                        <td class=\"{{ _self.cellClass(fullWidth, col, col.class ?? []) }} {% if isCode %}code{% endif %} {% if hasErrors %}error{% endif %}\"{% if col.width ?? false %} width=\"{{ col.width }}\"{% endif %}>
                            {% block tablecell %}
                                {%- switch col.type -%}
                                    {%- case 'checkbox' -%}
                                        <div class=\"checkbox-wrapper\">
                                            {% include \"_includes/forms/checkbox\" with {
                                                name: cellName,
                                                value:  col.value ?? 1,
                                                checked: value is not empty,
                                                disabled: static
                                            } only %}
                                        </div>
                                    {%- case 'color' -%}
                                        {% include \"_includes/forms/color\" with {
                                            name: cellName,
                                            value: value,
                                            small: true,
                                            disabled: static
                                        } only %}
                                    {%- case 'date' -%}
                                        {% include \"_includes/forms/date\" with {
                                            name: cellName,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'lightswitch' -%}
                                        {% include \"_includes/forms/lightswitch\" with {
                                            name: cellName,
                                            on: value,
                                            value: col.value ?? 1,
                                            small: true,
                                            disabled: static
                                        } only %}
                                    {% case 'select' -%}
                                        {% include \"_includes/forms/select\" with {
                                            class: 'small',
                                            name: cellName,
                                            options: cell.options ?? col.options,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'time' -%}
                                        {% include \"_includes/forms/time\" with {
                                            name: cellName,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'email' or 'url' -%}
                                        {% include \"_includes/forms/text\" with {
                                            type: col.type,
                                            name: cellName,
                                            placeholder: col.placeholder ?? null,
                                            value:  value,
                                            disabled: static
                                        } only %}
                                    {%- case 'template' -%}
                                        {% include \"_includes/forms/autosuggest\" with {
                                            name: cellName,
                                            suggestions: craft.cp.getTemplateSuggestions(),
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- default -%}
                                        {% if static %}
                                            <pre class=\"disabled\">{{ value }}</pre>
                                        {% else %}
                                            <textarea name=\"{{ cellName }}\" rows=\"{{ col.rows ?? 1 }}\"{% if col.placeholder is defined %} placeholder=\"{{ col.placeholder }}\"{% endif %}>{{ value }}</textarea>
                                        {% endif %}
                                {%- endswitch -%}
                            {% endblock %}
                        </td>
                    {% endif %}
                {% endfor %}
                {% if not staticRows %}
                    <td class=\"thin action\"><a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" aria-label=\"{{ 'Reorder'|t('app') }}\"></a></td>
                    {% if not fixedRows %}<td class=\"thin action\"><a class=\"delete icon\" title=\"{{ 'Delete'|t('app') }}\" aria-label=\"{{ 'Delete'|t('app') }}\"></a></td>{% endif %}
                {% endif %}
            </tr>
        {% endfor %}
    </tbody>
{% endtag %}

{% if not staticRows and not fixedRows %}
    <button type=\"button\" class=\"btn add icon\">{{ addRowLabel ?? \"Add a row\"|t('app') }}</button>
{% endif %}

{% if initJs %}
    {% set jsId = id|namespaceInputId|e('js') %}
    {% set jsName = name|namespaceInputName|e('js') %}
    {% set jsCols = cols|json_encode %}
    {% set defaultValues = defaultValues ?? null %}
    {% js %}
        new Craft.EditableTable(\"{{ jsId }}\", \"{{ jsName }}\", {{ jsCols|raw }}, {
            defaultValues: {{ defaultValues ? defaultValues|json_encode|raw : '{}' }},
            staticRows: {{ staticRows ? 'true' : 'false' }},
            minRows: {{ minRows ? minRows : 'null' }},
            maxRows: {{ maxRows ? maxRows : 'null' }}
        });
    {% endjs %}
{% endif %}
", "_includes/forms/editableTable", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/editableTable.html");
    }
}
