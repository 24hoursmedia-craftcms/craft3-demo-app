<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* comments-work/_components/widgets/CommentsWorkWidget_settings */
class __TwigTemplate_bffa5ef4f5e6a296a2ce92d0a76d6d036233f63f35c14b45f29dbe6cc0eb0d01 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "comments-work/_components/widgets/CommentsWorkWidget_settings");
        // line 15
        echo "
";
        // line 16
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "comments-work/_components/widgets/CommentsWorkWidget_settings", 16)->unwrap();
        // line 17
        echo "
";
        // line 18
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 18, $this->source); })()), "registerAssetBundle", [0 => "twentyfourhoursmedia\\commentswork\\assetbundles\\commentswork\\CommentsWorkAsset"], "method");
        // line 19
        echo "
";
        // line 20
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => "Message", "instructions" => "Enter a message here.", "id" => "message", "name" => "message", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 25
(isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new RuntimeError('Variable "widget" does not exist.', 25, $this->source); })()), "message", [], "array")]], 20, $context, $this->getSourceContext());
        // line 26
        echo "
";
        craft\helpers\Template::endProfile("template", "comments-work/_components/widgets/CommentsWorkWidget_settings");
    }

    public function getTemplateName()
    {
        return "comments-work/_components/widgets/CommentsWorkWidget_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 26,  52 => 25,  51 => 20,  48 => 19,  46 => 18,  43 => 17,  41 => 16,  38 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * Comments Work plugin for Craft CMS
 *
 * CommentsWorkWidget Widget Settings
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2018 24hoursmedia
 * @link      https://www.24hoursmedia.com
 * @package   CommentsWork
 * @since     1.0.0
 */
#}

{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle(\"twentyfourhoursmedia\\\\commentswork\\\\assetbundles\\\\commentswork\\\\CommentsWorkAsset\") %}

{{ forms.textField({
    label: 'Message',
    instructions: 'Enter a message here.',
    id: 'message',
    name: 'message',
    value: widget['message']})
}}
", "comments-work/_components/widgets/CommentsWorkWidget_settings", "/var/www/html/vendor/twentyfourhoursmedia/comments-work/src/templates/_components/widgets/CommentsWorkWidget_settings.twig");
    }
}
