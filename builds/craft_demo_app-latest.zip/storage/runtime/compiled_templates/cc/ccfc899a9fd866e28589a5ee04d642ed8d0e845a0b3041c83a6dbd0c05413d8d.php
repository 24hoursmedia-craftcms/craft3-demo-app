<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* views-work/_components/widgets/ViewsWorkWidget_body */
class __TwigTemplate_5260fa668475bcf3deb6e8513ddfeeae9b0784c279530c8151e97ec9ef330467 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "views-work/_components/widgets/ViewsWorkWidget_body");
        // line 15
        echo "
";
        // line 16
        $macros["cpmacros"] = $this->macros["cpmacros"] = $this->loadTemplate("views-work/_macros", "views-work/_components/widgets/ViewsWorkWidget_body", 16)->unwrap();
        // line 17
        $macros["macros"] = $this->macros["macros"] = $this;
        // line 72
        $context["iconUrl"] = (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 72, $this->source); })()), "getAssetManager", [], "method"), "getPublishedUrl", [0 => "@twentyfourhoursmedia/viewswork/assetbundles/viewsworkwidgetwidget/dist", 1 => true], "method") . "/img/ViewsWorkWidget-icon.svg");
        // line 73
        echo "


";
        // line 76
        if ((isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 76, $this->source); })())) {
            // line 77
            echo "    <div class=\"vw-widget-heading\">
        <span class=\"vw-heading\">Showing items for section `";
            // line 78
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 78, $this->source); })()), "name", []), "html", null, true);
            echo "`</span>
    </div>
";
        }
        // line 81
        echo "
";
        // line 82
        if ((isset($context["showTotal"]) || array_key_exists("showTotal", $context) ? $context["showTotal"] : (function () { throw new RuntimeError('Variable "showTotal" does not exist.', 82, $this->source); })())) {
            // line 83
            echo "    <div class=\"vw-widget-section\">
        <div class=\"vw-widget-heading\">
            <span class=\"vw-badge vw-badge-info vw-w-20\">";
            // line 85
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All time", "views-work"), "html", null, true);
            echo "</span>
            <span class=\"vw-heading\">Top ";
            // line 86
            echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 86, $this->source); })()), "html", null, true);
            echo "</span>
        </div>
        ";
            // line 88
            echo twig_call_macro($macros["macros"], "macro_show", [(isset($context["total"]) || array_key_exists("total", $context) ? $context["total"] : (function () { throw new RuntimeError('Variable "total" does not exist.', 88, $this->source); })()), "total"], 88, $context, $this->getSourceContext());
            echo "
    </div>
";
        }
        // line 91
        echo "
";
        // line 92
        if ((isset($context["showMonthly"]) || array_key_exists("showMonthly", $context) ? $context["showMonthly"] : (function () { throw new RuntimeError('Variable "showMonthly" does not exist.', 92, $this->source); })())) {
            // line 93
            echo "    <div class=\"vw-widget-section\">
        <div class=\"vw-widget-heading\">
            <span class=\"vw-badge vw-badge-info vw-w-20\">";
            // line 95
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("This month", "views-work"), "html", null, true);
            echo "</span>
            <span class=\"vw-heading\">Top ";
            // line 96
            echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 96, $this->source); })()), "html", null, true);
            echo "</span>
        </div>
        ";
            // line 98
            echo twig_call_macro($macros["macros"], "macro_show", [(isset($context["monthly"]) || array_key_exists("monthly", $context) ? $context["monthly"] : (function () { throw new RuntimeError('Variable "monthly" does not exist.', 98, $this->source); })()), "month"], 98, $context, $this->getSourceContext());
            echo "
    </div>
";
        }
        // line 101
        echo "
";
        // line 102
        if ((isset($context["showWeekly"]) || array_key_exists("showWeekly", $context) ? $context["showWeekly"] : (function () { throw new RuntimeError('Variable "showWeekly" does not exist.', 102, $this->source); })())) {
            // line 103
            echo "    <div class=\"vw-widget-section\">
        <div class=\"vw-widget-heading\">
            <span class=\"vw-badge vw-badge-info vw-w-20\">";
            // line 105
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("This week", "views-work"), "html", null, true);
            echo "</span>
            <span class=\"vw-heading\">Top ";
            // line 106
            echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 106, $this->source); })()), "html", null, true);
            echo "</span>
        </div>

        ";
            // line 109
            echo twig_call_macro($macros["macros"], "macro_show", [(isset($context["weekly"]) || array_key_exists("weekly", $context) ? $context["weekly"] : (function () { throw new RuntimeError('Variable "weekly" does not exist.', 109, $this->source); })()), "week"], 109, $context, $this->getSourceContext());
            echo "
    </div>
";
        }
        // line 112
        echo "
";
        // line 113
        if ((isset($context["showDaily"]) || array_key_exists("showDaily", $context) ? $context["showDaily"] : (function () { throw new RuntimeError('Variable "showDaily" does not exist.', 113, $this->source); })())) {
            // line 114
            echo "    <div class=\"vw-widget-section\">
        <div class=\"vw-widget-heading\">
            <span class=\"vw-badge vw-badge-info vw-w-20\">";
            // line 116
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Today", "views-work"), "html", null, true);
            echo "</span>
            <span class=\"vw-heading\">Top ";
            // line 117
            echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 117, $this->source); })()), "html", null, true);
            echo "</span>
        </div>
        ";
            // line 119
            echo twig_call_macro($macros["macros"], "macro_show", [(isset($context["today"]) || array_key_exists("today", $context) ? $context["today"] : (function () { throw new RuntimeError('Variable "today" does not exist.', 119, $this->source); })()), "day"], 119, $context, $this->getSourceContext());
            echo "
    </div>
";
        }
        // line 122
        echo "
";
        // line 123
        $this->loadTemplate("views-work/_partials/widget_footer.twig", "views-work/_components/widgets/ViewsWorkWidget_body", 123)->display($context);
        // line 124
        echo "



";
        craft\helpers\Template::endProfile("template", "views-work/_components/widgets/ViewsWorkWidget_body");
    }

    // line 18
    public function macro_show($__entries__ = null, $__stat__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "entries" => $__entries__,
            "stat" => $__stat__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "show");
            // line 19
            echo "
    ";
            // line 20
            if ((twig_length_filter($this->env, (isset($context["entries"]) || array_key_exists("entries", $context) ? $context["entries"] : (function () { throw new RuntimeError('Variable "entries" does not exist.', 20, $this->source); })())) == 0)) {
                // line 21
                echo "        <p class=\"vw-pb-2\">No items.</p>
    ";
            } else {
                // line 23
                echo "        <div class=\"vw-grid vw-grid-cols-12 vw-gap-1 vw-pb-2\">
            ";
                // line 24
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["entries"]) || array_key_exists("entries", $context) ? $context["entries"] : (function () { throw new RuntimeError('Variable "entries" does not exist.', 24, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                    // line 25
                    echo "                ";
                    $context["views"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 25, $this->source); })()), "views_work_cp", []), "recording", [0 => $context["item"]], "method");
                    // line 26
                    echo "                ";
                    // line 27
                    echo "                ";
                    $context["url"] = craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "cpEditUrl", []);
                    // line 28
                    echo "                <div class=\"vw-col-span-10\">
                    ";
                    // line 29
                    if (twig_test_empty((isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 29, $this->source); })()))) {
                        // line 30
                        echo "                        <div class=\"vw-overflow-ellipsis vw-truncate\"><span>";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
                        echo "</span></div>
                    ";
                    } else {
                        // line 32
                        echo "                        <div class=\"vw-overflow-ellipsis vw-truncate\">
                            <a href=\"";
                        // line 33
                        echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 33, $this->source); })()), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
                        echo "</a>
                        </div>
                        ";
                        // line 41
                        echo "                    ";
                    }
                    // line 42
                    echo "                </div>
                <div class=\"vw-col-span-1\">
                    <div class=\"vw-block vw-float-right \">
                    <span class=\"vw-badge vw-badge-success\">
                        ";
                    // line 46
                    switch ((isset($context["stat"]) || array_key_exists("stat", $context) ? $context["stat"] : (function () { throw new RuntimeError('Variable "stat" does not exist.', 46, $this->source); })())) {
                        case "total":
                        {
                            // line 48
                            echo "                            ";
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["views"]) || array_key_exists("views", $context) ? $context["views"] : (function () { throw new RuntimeError('Variable "views" does not exist.', 48, $this->source); })()), "total", []), "html", null, true);
                            echo "
                        ";
                            break;
                        }
                        case "month":
                        {
                            // line 50
                            echo "                            ";
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["views"]) || array_key_exists("views", $context) ? $context["views"] : (function () { throw new RuntimeError('Variable "views" does not exist.', 50, $this->source); })()), "thisMonth", []), "html", null, true);
                            echo "
                        ";
                            break;
                        }
                        case "week":
                        {
                            // line 52
                            echo "                            ";
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["views"]) || array_key_exists("views", $context) ? $context["views"] : (function () { throw new RuntimeError('Variable "views" does not exist.', 52, $this->source); })()), "thisWeek", []), "html", null, true);
                            echo "
                        ";
                            break;
                        }
                        case "day":
                        {
                            // line 54
                            echo "                            ";
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["views"]) || array_key_exists("views", $context) ? $context["views"] : (function () { throw new RuntimeError('Variable "views" does not exist.', 54, $this->source); })()), "today", []), "html", null, true);
                            echo "
                        ";
                            break;
                        }
                    }
                    // line 56
                    echo "                    </span>
                    </div>
                </div>
                <div class=\"vw-col-span-1\">
                    <div class=\"vw-ml-1 vw-text-right\">
                        ";
                    // line 61
                    $context["url"] = twig_trim_filter(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", []));
                    // line 62
                    echo "                        ";
                    if ( !twig_test_empty((isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 62, $this->source); })()))) {
                        // line 63
                        echo "                            ";
                        $context["url"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 63, $this->source); })()), "views_work_cp", []), "addBlockParamToUrl", [0 => (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 63, $this->source); })())], "method");
                        // line 64
                        echo "                            <a href=\"";
                        echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 64, $this->source); })()), "html", null, true);
                        echo "\" target=\"_blank\" data-icon=\"world\"></a>
                        ";
                    }
                    // line 66
                    echo "                    </div>
                </div>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 69
                echo "        </div>
    ";
            }
            craft\helpers\Template::endProfile("macro", "show");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "views-work/_components/widgets/ViewsWorkWidget_body";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  311 => 69,  303 => 66,  297 => 64,  294 => 63,  291 => 62,  289 => 61,  282 => 56,  274 => 54,  265 => 52,  256 => 50,  247 => 48,  243 => 46,  237 => 42,  234 => 41,  227 => 33,  224 => 32,  218 => 30,  216 => 29,  213 => 28,  210 => 27,  208 => 26,  205 => 25,  201 => 24,  198 => 23,  194 => 21,  192 => 20,  189 => 19,  174 => 18,  165 => 124,  163 => 123,  160 => 122,  154 => 119,  149 => 117,  145 => 116,  141 => 114,  139 => 113,  136 => 112,  130 => 109,  124 => 106,  120 => 105,  116 => 103,  114 => 102,  111 => 101,  105 => 98,  100 => 96,  96 => 95,  92 => 93,  90 => 92,  87 => 91,  81 => 88,  76 => 86,  72 => 85,  68 => 83,  66 => 82,  63 => 81,  57 => 78,  54 => 77,  52 => 76,  47 => 73,  45 => 72,  43 => 17,  41 => 16,  38 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("{# @var craft \\craft\\web\\twig\\variables\\CraftVariable #}
{#
/**
 * Views Work plugin for Craft CMS
 *
 * ViewsWorkWidget Widget Body
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2018 24hoursmedia
 * @link      http://www.24hoursmedia.com
 * @package   ViewsWork
 * @since     1.0.0
 */
#}

{% import 'views-work/_macros' as cpmacros %}
{% import _self as macros %}
{% macro show(entries, stat) %}

    {% if entries | length == 0 %}
        <p class=\"vw-pb-2\">No items.</p>
    {% else %}
        <div class=\"vw-grid vw-grid-cols-12 vw-gap-1 vw-pb-2\">
            {% for item in entries %}
                {% set views = craft.views_work_cp.recording(item) %}
                {# views \\twentyfourhoursmedia\\viewswork\\models\\ViewRecording #}
                {% set url = item.cpEditUrl %}
                <div class=\"vw-col-span-10\">
                    {% if url is empty %}
                        <div class=\"vw-overflow-ellipsis vw-truncate\"><span>{{ item.title }}</span></div>
                    {% else %}
                        <div class=\"vw-overflow-ellipsis vw-truncate\">
                            <a href=\"{{ url }}\">{{ item.title }}</a>
                        </div>
                        {#
                        <span class=\"light\">
                            {{ item.dateCreated|timestamp('short') }}
                            {%- if item.author %}, {{ item.author.username }}{% endif -%}
                        </span>
                        #}
                    {% endif %}
                </div>
                <div class=\"vw-col-span-1\">
                    <div class=\"vw-block vw-float-right \">
                    <span class=\"vw-badge vw-badge-success\">
                        {% switch stat %}
                        {% case 'total' %}
                            {{ views.total }}
                        {% case 'month' %}
                            {{ views.thisMonth }}
                        {% case 'week' %}
                            {{ views.thisWeek }}
                        {% case 'day' %}
                            {{ views.today }}
                        {% endswitch %}
                    </span>
                    </div>
                </div>
                <div class=\"vw-col-span-1\">
                    <div class=\"vw-ml-1 vw-text-right\">
                        {% set url = item.url | trim %}
                        {% if url is not empty %}
                            {% set url = craft.views_work_cp.addBlockParamToUrl(url) %}
                            <a href=\"{{ url }}\" target=\"_blank\" data-icon=\"world\"></a>
                        {% endif %}
                    </div>
                </div>
            {% endfor %}
        </div>
    {% endif %}
{% endmacro %}
{% set iconUrl = view.getAssetManager().getPublishedUrl('@twentyfourhoursmedia/viewswork/assetbundles/viewsworkwidgetwidget/dist', true) ~ '/img/ViewsWorkWidget-icon.svg' %}



{% if section %}
    <div class=\"vw-widget-heading\">
        <span class=\"vw-heading\">Showing items for section `{{ section.name }}`</span>
    </div>
{% endif %}

{% if showTotal %}
    <div class=\"vw-widget-section\">
        <div class=\"vw-widget-heading\">
            <span class=\"vw-badge vw-badge-info vw-w-20\">{{ 'All time' | t('views-work') }}</span>
            <span class=\"vw-heading\">Top {{ count }}</span>
        </div>
        {{ macros.show(total, 'total') }}
    </div>
{% endif %}

{% if showMonthly %}
    <div class=\"vw-widget-section\">
        <div class=\"vw-widget-heading\">
            <span class=\"vw-badge vw-badge-info vw-w-20\">{{ 'This month' | t('views-work') }}</span>
            <span class=\"vw-heading\">Top {{ count }}</span>
        </div>
        {{ macros.show(monthly, 'month') }}
    </div>
{% endif %}

{% if showWeekly %}
    <div class=\"vw-widget-section\">
        <div class=\"vw-widget-heading\">
            <span class=\"vw-badge vw-badge-info vw-w-20\">{{ 'This week' | t('views-work') }}</span>
            <span class=\"vw-heading\">Top {{ count }}</span>
        </div>

        {{ macros.show(weekly, 'week') }}
    </div>
{% endif %}

{% if showDaily %}
    <div class=\"vw-widget-section\">
        <div class=\"vw-widget-heading\">
            <span class=\"vw-badge vw-badge-info vw-w-20\">{{ 'Today' | t('views-work') }}</span>
            <span class=\"vw-heading\">Top {{ count }}</span>
        </div>
        {{ macros.show(today, 'day') }}
    </div>
{% endif %}

{% include 'views-work/_partials/widget_footer.twig' %}




", "views-work/_components/widgets/ViewsWorkWidget_body", "/var/www/html/vendor/twentyfourhoursmedia/views-work/src/templates/_components/widgets/ViewsWorkWidget_body.twig");
    }
}
