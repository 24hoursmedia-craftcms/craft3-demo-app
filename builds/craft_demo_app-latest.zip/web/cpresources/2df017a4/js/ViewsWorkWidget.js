/**
 * Views Work plugin for Craft CMS
 *
 * ViewsWorkWidget Widget JS
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2018 24hoursmedia
 * @link      http://www.24hoursmedia.com
 * @package   ViewsWork
 * @since     1.0.0
 */
