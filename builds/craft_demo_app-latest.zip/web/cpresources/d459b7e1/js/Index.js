/**
 * Comments Work plugin for Craft CMS
 *
 * Index Field JS
 *
 * @author    24hoursmedia
 * @copyright Copyright (c) 2018 24hoursmedia
 * @link      https://www.24hoursmedia.com
 * @package   CommentsWork
 * @since     1.0.0
 */
